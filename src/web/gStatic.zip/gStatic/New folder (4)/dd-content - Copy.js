(function(){
$.widget("PH_utils.ddContent",  $.PH_utils.uiBase, {
	version: "1.0",

	_create: function(){
//console.log('create...');
		this.element.addClass("hwgDdContent");
		
		wgThis = this;
		
		wgThis.value('classN',((wgThis.element.parentsUntil('.drag-drop-container').parent().attr('class') || '').match(/(\s+|^)(drag-drop-container_[\d]+)($|\s)/) || ['','',''])[2])
		wgThis.value('classN') && wgThis.value('classN','.' + wgThis.value('classN'))
		actCont$ = $(wgThis.value('classN') + ' .action-container')
		if (!$('body .dd-dyn-style').length) {
			$('body').prepend('<div class="dd-dyn-style"><style>\
			' + wgThis.value('classN') + ' .action-container {\
				margin:0 !important;\
				padding:0 !important;\
				line-height: 1 !important;\
				margin-top: -' + actCont$.height() + 'px !important;\
				position: relative;\
				z-index: 9;\
				width: 0.001px !important;\
			}\
			</style></div>');
			/*
			var mrkOffCont = $(wgThis.value('classN')).prev();
			if (!mrkOffCont.hasClass('dd-trap-draging'))
				mrkOffCont.on('mouseenter', function() {
					mrkOffCont.addClass('dd-trap-draging')
					actCont$.addClass('d-none')
					wgThis.value('rDraging', false)
				});
			mrkOffCont = $(wgThis.value('classN')).next();
			if (!mrkOffCont.hasClass('dd-trap-draging'))
				mrkOffCont.on('mouseenter', function() {
					mrkOffCont.addClass('dd-trap-draging')
					actCont$.addClass('d-none')
					wgThis.value('rDraging', false)
				});
			mrkOffCont = $(wgThis.value('classN')).parent();
			if (!mrkOffCont.hasClass('dd-trap-draging'))
				mrkOffCont.on('mouseenter', function() {
					mrkOffCont.addClass('dd-trap-draging')
					actCont$.addClass('d-none')
					wgThis.value('rDraging', false)
				});
			mrkOffCont = $(wgThis.value('classN'));
			if (!mrkOffCont.hasClass('dd-trap-draging'))
				mrkOffCont.on('mouseenter', function() {
					mrkOffCont.addClass('dd-trap-draging')
					actCont$.addClass('d-none')
					wgThis.value('rDraging', false)
				});
			*/
				/*
			$(wgThis.value('classN')).children('.row-dd-container').children('.col-dd-container').children('div,p').on('click', function() {
				actCont$.addClass('d-none')
				wgThis.value('rDraging', false)
				return false;
			});
			*/
		}
		
		this.element.draggable(Object.assign(this.options,{
			snap: false,
			
			start: function() {
				wgThis.value('rDraging', true)
				$(wgThis.value('classN')).children('.col-dd-container').removeClass("z-1")
				$(this).addClass("z-1")
				return true
			},
			//handle: '.act_move',
			cancel: ".ql-container",
			revert: "invalid",
			stop: function()
			{
				$(this).removeClass("d-none, z-1")
				wgThis.value('rDraging', false)
				$(wgThis.value('classN')).find('.col-dd-container').removeClass('hint-drop-left hint-drop-right hint-drop-top hint-drop-bottom');
				return true;
			}
		}));
		
		this.element.droppable({
			greedy: true,
			tolerance: "pointer",
			//hoverClass :  "ui-state-hover",
			over: function(event, ui) {
				$(wgThis.value('classN')).find('.col-dd-container').removeClass('hint-drop-left hint-drop-right hint-drop-top hint-drop-bottom');
				var that$ = $(this), ofs = that$.offset(), yCenter = that$.height()/2+ofs.top, xCenter = that$.width()/2+ofs.left;
				if (ui.offset.top > yCenter /*|| ui.offset.left > xCenter*/) {
					$(this).addClass("hint-drop-right");
				} else {
					$(this).addClass("hint-drop-left");
				}
				return true;
			},
			drop: function( event, ui ) {
				var that$ = $(this), ofs = that$.offset(), yCenter = that$.height()/2+ofs.top, xCenter = that$.width()/2+ofs.left;
				var style = ui.draggable.attr("style").replace(/;\s*left[^;]+/,'').replace(/;\s*top[^;]+/,'');
				ui.draggable.left = 0;
				if (ui.offset.top > yCenter /* || ui.offset.left > xCenter */) {
				  ui.draggable.attr('style',style).insertAfter(this);
				} else {
				  ui.draggable.attr('style',style).insertBefore(this);
				}
		  }
		});
		 
		$('.act_move').on('mousedown', function(event, ui) {
			event.type = 'mousedown.draggable'
			event.target = $(this).parentsUntil('.col-dd-container').parent().get(0)
			$(this).parentsUntil('.col-dd-container').parent().trigger(event);
		})
		
		
		/*
		actCont$.children().on('click', function() {
			actCont$.addClass('d-none')
		});
		*/
		this.element.on('click mouseenter mouseleave dmyClick', function(e, d) {
			e = e || window.event;
			e.preventDefault();
			if (e.type =='mouseleave') {
				if (!wgThis.options.gToolbar.hasClass('tbar-draged')) wgThis.options.gToolbar.addClass('d-none')
			}
			if (e.type =='mouseenter' && wgThis.value('rDraging')) return
			
			if (e.type =='click' && ($(e.target).parent().hasClass('ql-editor') 
					//|| $(e.target).parentsUntil('.ql-container').length*/)
					//|| wgThis.options.gToolbar.hasClass('tbar-draged')
					//|| !wgThis.options.gToolbar.hasClass('d-none')
					&& !wgThis.options.gToolbar.hasClass('tbar-draged')
				)){
				wgThis.options.gToolbar.addClass('d-none')
				//return
			}
			if (e.type=='mouseleave') {
				wgThis.value('rDraging', false)
				actCont$.addClass('d-none')
				return
			}
			var target$ = $((d && d.target) || e.currentTarget), actList = (d && d.actList ? d.actList : target$.data('actList')) || false;
			(e.type =='click') && target$.data('delayForUpdate',new Date().getTime() + 86400);
			
			if (!actList) return;
			
			actCont$.children().addClass('d-none')
			target$.prepend(actCont$.removeClass('d-none'))
			
			actCont$.removeClass('invisible').children('.'+actList.join(',.')).removeClass('d-none')
			actCont$.children('.act_add_padding,.act_remove_padding').addClass('d-none')
			var classOn = '.act_add_padding';
			if (d && target$.hasClass(wgThis.options.settings.indentClass || 'ps-3') && target$.find('.dd-line-container:first-child')) classOn = '.act_remove_padding';
			else if (actCont$.parent().hasClass(wgThis.options.settings.paddingClass || 'p-3')) classOn = '.act_remove_padding';
			actCont$.children(classOn).removeClass('d-none')
			
			actCont$.find('.act_plus').attr("title", phUtils.vi2e("Thêm " + (target$.find('.head-label').find('p').html()||'' ),22))
		});
		
		wgThis.element.find('.dd-lines-container').each(function() {
			var lines = this;
			$(this).on('mouseenter', function(e, d){
				e = e || window.event;
				e.preventDefault()
				
				//var qcont$ = $(this).find('.dd-line-container').slice(0,1).find('.item-dd-container').slice(0,1);
				var qcont$ = $(this).find('.dd-line-container').slice(0,1).find('.item-dd-container').slice(0,1);
				if (qcont$.hasClass('head-label') || /* qcont$.find('[contenteditable="false"]').length ||*/ qcont$.data('oQuill').editor.isBlank()) {
					return
				}
				wgThis.element.trigger('dmyClick',{target: lines, actList: qcont$.data('actList')})
				if (d && d.isQuillSender) $(wgThis.value('classN') + ' .act_ql_toolbar').trigger('click', {sender$: qcont$, isQuillSender: true, addTopPx: 34})
			})
			
		})
		
		
		this._m = {} //chứa widget nên cần phải khởi tạo trước
		  //this.options._values = {}
		
		this._super( this.options );
		if (!this.pluginStopped ) {
			
			 
			//$.proxy(
			//this._initWrapElem()
			;//, this);
			
			//$.proxy(
			//this._initSetEvent()
			;//, this);
		}
		else {
		  //this._promptPlaceHolderShow(); 
		}
	  },
	_destroy: function(){
//console.log("destroy...");
	  },
	_init: function(o) {
//console.log('init...', this, this.values('options'));
		this._super( this.options );
		
		this.refresh($.proxy(function(){
				//
			}, this));
			
	  },

	resize: function() {
		//this._superApply( arguments );
	},
	refresh: function(succOnloadCb) {
		//
	},
	_mkItemDragDrop: function() {
		var wgThis = this;
		wgThis.find('.item-dd-container').each(function() {
		})
	},
});
})();


(function(){
$.widget("PH_utils.mkDdCont",  $.PH_utils.uiBase, {

	_create: function(o) {
		this._super()
console.log('mkDdCont create...')
		var wgThis = this;
		wgThis.options.qStackWaitUpdate = []
		$(this.options.containerDotClass).addClass('drag-drop-container')
		if (!$(this.options.containerDotClass + '>' + this.options.eventDotClass).length) {
			if (!$(this.options.containerDotClass + '>' + this.options.eventDotClass).length) $(this.options.containerDotClass).append($(this.options.eventDotClass).clone(true));	
		}
		$(this.options.containerDotClass + '>' + this.options.eventDotClass).addClass('action-container')
		
		wgThis.options.gToolbar = $(wgThis.options.toolbarSelector || '#dd-dyn-toolbar')
		if (!wgThis.options.gToolbar.length) {
			wgThis.options.gToolbar = $('body').append($('<div></div>'))
		}
		wgThis.options.gToolbar.addClass('dd-dyn-toolbar-container dd-toolbar-fixed d-none')
		wgThis.dPathBranch = ''
		this.mkIconEvent()

/*		
		wgThis.options.gPageQuill = new Quill($(this.options.containerDotClass).get(0),
			{	theme: 'snow', // or 'bubble'
				modules: {
					toolbar: [
						[{ 'indent': '-1'}, { 'indent': '+1' }],          // outdent/indent
						[{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
						[{ 'header': [1, 2, 3, 4, 5, 6, false] }],

						[{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
						[{ 'font': [] }],
						[{ 'align': [] }],
						
						[{'link': []}],
						[{'undo': []}],
						

						['clean'] 
					],
					history: {
						delay: 2000,
						maxStack: 500,
						userOnly: true
					},
				}
			})
		$(this.options.containerDotClass).children('.ql-editor:first-child').empty()
		const Inline = Quill.import('blots/inline');


class BoldBlot extends Inline {
  static blotName = 'bold';
  static tagName = 'b';
}

class Link extends Inline {
  static blotName = 'link';
  static tagName = 'a';
  static create(value) {
  const node = super.create();
    // Sanitize url value if desired
    node.setAttribute('href', value);
    // Okay to set other non-format related attributes
    // These are invisible to Parchment so must be static
    node.setAttribute('target', '_blank');
    return node;
  }
  static formats(node) {
    // We will only be called with a node already
    // determined to be a Link blot, so we do
    // not need to check ourselves
    return node.getAttribute('href');
  }
}

class ItalicBlot extends Inline {
  static blotName = 'italic';
  static tagName = 'em';
}

Quill.register(BoldBlot);
Quill.register(ItalicBlot);

window.gPageQuill = wgThis.options.gPageQuill

$(this.options.containerDotClass).before('<button onclick="gPageQuill.format(\'bold\', true)">boldBold</buton>')
$(this.options.containerDotClass).before(`<button onclick="
const value = prompt('Enter link URL');
gPageQuill.format(\'link\', true)">link</buton>`)
$(this.options.containerDotClass).before(`<button onclick="
console.log(window.qDelta = gPageQuill.getContents())
console.log(window.qText = gPageQuill.getText())
console.log(window.qHtml = gPageQuill.getSemanticHTML())
console.log(window.qjDelta = JSON.stringify(window.qDelta).ops)
">get text</buton>`)
$(this.options.containerDotClass).before(`<button onclick="
gPageQuill.setText('')
gPageQuill.update()
gPageQuill.setContents(JSON.parse(window.qjDelta))

">nhap du lieu</buton>`)


window.gPageQuill.on(Quill.events.TEXT_CHANGE, update);
const playground = document.querySelector('#playground');
update();

function formatDelta(delta) {
  return `<div>${JSON.stringify(delta.ops, null, 2)}</div>`;
}

function update(delta, oldDelta) {
  const contents = window.gPageQuill.getContents();
  let html = `<h3>contents</h3>${formatDelta(contents)}`
  if (delta) {
	delta.map(function(op) {
console.log('*** ', op);
		return op;
	})
    html = `${html}<h3>change</h3>${formatDelta(delta)}<h3>old delta</h3>${formatDelta(oldDelta)}`;
  }
  playground.innerHTML = html;
}

return;
*/
		
		$(this.options.containerDotClass).each(function(i){
			$(this).addClass('drag-drop-container_'+i)
			wgThis.value('classN', '.drag-drop-container_'+i);
			var row$, n = 0;
			
			for (k in wgThis.options.ddData) {
				if (k[0] == '_') continue;
				if (n % wgThis.options.col == 0) {
					row$ = wgThis.mkRowDD()
					$(this).append(row$)
				}
				dd$ = wgThis.mkColDD(wgThis.options.ddData, k, wgThis.options.ddData);
				row$.append(dd$);
				dd$.ddContent(wgThis.options);
				n++
				var maxW = 0, aItemLabel = dd$.find('[class^="line-label"], [class*=" line-label"]')
				aItemLabel.each(function(i){
					var m = $(this).width();
					if (m>maxW) for (var z = i-1; z>=0; z--) $(aItemLabel[z]).css({width: m+'px'});
				})
window.dd = wgThis.options.ddData;
				dd$.find('.ql-container').each(function(i) {
					
const toolbarOptions = [
  ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
  //mod ['blockquote', 'code-block'],
  ['blockquote'],
  //mod ['link', 'image', 'video', 'formula'],
  ['link', 'image', 'video'],

  //[{ 'header': 1 }, { 'header': 2 }],               // custom button values
  //[{ 'list': 'ordered'}, { 'list': 'bullet' }, { 'list': 'check' }],
  //[{ 'script': 'sub'}, { 'script': 'super' }],      // superscript/subscript
  [{ 'indent': '-1'}, { 'indent': '+1' }],          // outdent/indent
  //[{ 'direction': 'rtl' }],                         // text direction

  //[{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
  [{ 'header': [1, 2, 3, 4, 5, 6, false] }],

  [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
  [{ 'font': [] }],
  [{ 'align': [] }],

  ['clean']                                         // remove formatting button
];
					var that$ = $(this), childP = that$.children('p');

					
					var dOpts = that$.parent().data('ddOpts')
						, qOpts = {	theme: 'snow', // or 'bubble'
									modules: {
										toolbar: toolbarOptions
									}
								};
	
					if (dOpts.textEmpty) {
						var t = $(childP[0]).html() || '';
						$(childP[0]).empty()
						qOpts.placeholder = t
					}
					
//console.log(dOpts, that$.data())	
				
					that$.data('oQuill', new Quill(this, qOpts));
					
					var qBar = that$.prev();
					if (qBar.length && qBar.hasClass('ql-toolbar')) qBar.addClass('d-none dd-dyn-toolbar');
					 
					qBar.append($('<span class="ql-formats float-end me-0" style="min-width:2rem"><button type="button"  class="dd-btn-close-tbar float-end" onclick="wgThis.options.gToolbar.addClass(\'d-none\').removeClass(\'tbar-draged\');" aria-pressed="false" aria-label="hide-tools" title="Đóng thanh công cụ"><i class="fa fa-light fa-eye-slash"></i></button></span>'))
						.prepend('<div class="dd-ql-tools-thumb" title="Di chuyển thanh công cụ"><button class="p-2" type="button" onclick="wgThis.options.gToolbar.addClass(\'tbar-draged\');" aria-pressed="false" aria-label="hide-tools" title="Ghim/di chuyển thanh công cụ"><i class="fa fa-light fa-thumbtack"></i></button></span></div>')
		
					wgThis.dynToolBar(that$)
					 
					that$.data('oQuill').on('text-change', function(delta, deltaOld, source) {
						wgThis.doQuillEvents(that$, 'text-change', delta, deltaOld, source)
					})
					
		
					childP = that$.children().children('p');
					
					childP.each(function(){
						if (!this.innerHTML.replace('<br>','').length) $(this).remove()
					})
					if (dOpts.readonly) {
						that$.children().prop('contenteditable','false')
					} 
					if (dOpts.hidden) {
						that$.addClass('d-none')
					}
				});
			}
		})
		this.addColMenu()
	},
	_init: function(o) {
		this._super()
console.log('mkDdCont init...')	
	},
	qUpdateLines: function(o) {
			o.elm$.data('delayForUpdate', o.nowWaitFor + 86400)
			var wgThis = o.wgThis, quill = o.elm$.data('oQuill'), htm = quill.getSemanticHTML(), text = quill.getText(), dOpts = o.elm$.children('div:first-child').parentsUntil('.dd-line-container').parent().data('ddOpts');
/*			
console.log(quill.getContents().ops)
console.log(text)
console.log(htm)
*/
//console.log(dOpts.dPath+'.options.formats',1)
//*
			phUtils.objPathValue(wgThis.options.ddData, dOpts.dPath+'.text', text, true, true);
			phUtils.objPathValue(wgThis.options.ddData, dOpts.dPath+'.options.formats', htm, true, true);
			
			
			//update db var dd = JSON.stringify(wgThis.options.ddData);

			while (wgThis.options.qStackWaitUpdate.length) {
				o = wgThis.options.qStackWaitUpdate.shift();
				quill = o.elm$.data('oQuill')
				quill.update()
				if (quill.getSemanticHTML() !== htm) {
					wgThis.qUpdateLines(o)
					htm = quill.getSemanticHTML()
				}// else quill.insertText(htm, 'silent')
			}
	},
	doQuillEvents: function(elm$, evName, delta, deltaOld, source) {
		var wgThis = this
			,doDbUpdate = function(o) {
				return o.nowWaitFor >= o.elm$.data('delayForUpdate') || o.wgThis.options.delayForUpdate <=0
			  }
			;
		if (!wgThis.options.quillHasFirstClick) return;
		
		if (evName == 'text-change') {
			phUtils.waitForElement(null, wgThis.options.delayForUpdate+1000, doDbUpdate, null, {wgThis: wgThis, elm$: elm$, delta:delta, deltaOld:deltaOld, source:source}).then(function(o) {
				o.wgThis.qUpdateLines(o);
				o.elm$.data('delayForUpdate', o.nowWaitFor + 86400)
			}).catch(function(o){

console.log('false')
				//if (!o) return;
				o.elm$.data('delayForUpdate', o.nowWaitFor + 86400)
				o.wgThis.options.qStackWaitUpdate.push(o)
			});
		}
		
	},
	dynToolBar: function(elm$, pCont$) {
		var wgThis = this;
		if (!pCont$ && (this.options.lastQuillObject || false) === elm$.data('oQuill')) {console.log(999); return}
		var tBar = wgThis.options.gToolbar;
		
		var restoreTbar = function(pContSaved$) {
				if (pContSaved$) {
					var tBar = wgThis.options.gToolbar.children('.ql-toolbar')
					if (tBar.length) {
						pContSaved$.parent().prepend(tBar.addClass('d-none'))
						pContSaved$.append(wgThis.options.gToolbar.children('.ql-tooltip'))
					}
				}
				wgThis.options.lastQuillObject = null;
			}, mkTbar = function(pCont$) {
				var pContSaved$ = wgThis.options.pCont;
				restoreTbar(pContSaved$)
				wgThis.options.pCont = pCont$
				if (pCont$.length) {
					wgThis.options.gToolbar.prepend(pCont$.parent().children('.ql-toolbar').removeClass('d-none'))
					wgThis.options.gToolbar.append (pCont$.children('.ql-tooltip'))
					wgThis.options.lastQuillObject = elm$.data('oQuill')
					pCont$.parentsUntil('.dd-lines-container').trigger('mouseenter',{isQuillSender: true /*sender$: pCont$*/});
				} else {
					wgThis.options.pCont = null;
					wgThis.options.lastQuillObject = null;
				}
			};
			
		if (!elm$) {
			if (!this.options.lastQuillObject) {
				restoreTbar(wgThis.options.pCont)
				return;
			}
		}
		
		if (pCont$) {
			mkTbar(pCont$);
			return;
		}
		
		elm$.data('oQuill').on('selection-change', function(range, oldRange, source) {
			if (range) {
				wgThis.options.quillHasFirstClick = true;
				elm$.data('delayForUpdate',new Date().getTime() + (wgThis.options.delayForUpdate));
				mkTbar($(this.domListeners.selectionchange[0].node.activeElement).parent())
			}
		});
	},	
	
	_getAction: function(d, k, dParent = {}, isDefaultHead = false) {
		
		var act = d[k] && d[k].actions !== undefined ? d[k].actions : 
				(this._fakeParent && this._fakeParent.actions ? this._fakeParent.actions : 
					(isDefaultHead ? d._defaultAction || dParent._defaultAction || false : 
							(d._defaultActionLine ? dParent._defaultActionLine || false : false)))
		//var act = d[k].actions === undefined ? (isDefaultHead ? (d._defaultAction || dParent._defaultAction || false) : (d._defaultActionLine || dParent._defaultActionLine || false)) : (d[k].actions !== false ? d[k].actions : false);
		var act = d[k] && d[k].actions ? d[k].actions :
				this._fakeParent && this._fakeParent.actions ? this._fakeParent.actions :
					isDefaultHead ? d._defaultAction || dParent._defaultAction || false: 
						d._defaultActionLine || dParent._defaultActionLine || false;
		
		return act ? (' data-act-list = \'["' + act.join('","') + '"]\'') : ''
	},
	mkRowDD: function(d, k, dParent, cClass, prop) {
		return $(('<div class="row ' + (cClass || 'row-dd-container') + (prop ? ' '+prop : '') +'"></div>'));
	},
	mkColDD: function(d, k, dParent, cClass, prop) {
		var dd$ = $(('<div class="col ' + (cClass || 'col-dd-container') + (prop ? ' '+prop : '') + '" ' + this._getAction(d,k, dParent, true) + '></div>'));
		return $(dd$.get(0)).append($(this.mkLinesQ(dd$, d, k)).get(0))
	},
	mkLineContainer: function(line$, cClass) {
		return $('<div class="' + (cClass || 'dd-lines-container') + '"></div>').append(line$);
	},
	mkLinesQ: function(q$, dParent, kWork) {
		var d = dParent[kWork], wgThis = this;
		//var q$ = this.mkLineContainer(qq$);
		
		var mkLines = function(v, k, mClass = '', opts = {}, cssProp = '', wrapLine = true, col2class = '') {
			var s = '';
			for (var i=0; i<k.length; i++) {
				if (k[i] == '_' || k[i] == '-' ) s += '';
				else if (k[i].toUpperCase() == k[i]) s += (i==0 ? '' : '-' + k[i].toLowerCase());
				else s += k[i];
			}
			var sCont = '<div class="dd-line-container ' + col2class + '"><div class="ql-container item-dd-container ' + s + ' '+mClass + '" ' + cssProp+ wgThis._getAction(d,k,dParent) + '><p>$2</p></div></div>';
			if (v=='' || !v) return $(sCont.replace('$2','')).data('ddOpts',opts)
			line$ = $(v.replace(/(<p>)(.*)(<\/p>)/gm,'$2\n').replace(/[\r]+/gm,'').replace(/(\n|^)([^\n$]+)/gm, sCont).replace(/\n+$/,'')).data('ddOpts',opts)
			if (!wrapLine) return line$	
			return wgThis.mkLineContainer(line$)
		}
	
		var dFlex = function(d,k, cClass, prop){return '<div class="d-flex ' + (cClass || 'item-dd-container') + '"' + wgThis._getAction(d,k,dParent) + '></div>'}, waitLineValue = 0, divFlex$, hasFirstLine = true;
		
		var doLineLabel = function(ks, k, opts) {
				var classAdd = 'ms-3' + (hasFirstLine ? ' mt-3' : ''), prop = opts.readonly ? 'contenteditable="false"' : '';
				divFlex$ = $(dFlex(d,k))
				divFlex$.append(mkLines(ks, k, classAdd, opts, prop,  false).removeClass('item-dd-container'))
				waitLineValue = 1;
			},
			doLineValue = function(ks, k, opts) {
				var classAdd = 'ms-3' + (hasFirstLine ? ' mt-3' : ''), prop = opts.readonly ? 'contenteditable="false"' : '';
				if (waitLineValue !== 1) {
					divFlex$ = $(dFlex(d,k))
					$(divFlex$.get(0)).append(mkLines(' ', 'lineLabel', classAdd, opts, prop, false).removeClass('item-dd-container'))
					$(divFlex$.get(0)).append(mkLines(ks,k, classAdd , opts, prop, false, 'col').removeClass('item-dd-container'))
					$(q$.get(0)).append($(wgThis.mkLineContainer(divFlex$.removeClass('item-dd-container')).get(0)))
					waitLineValue = 0
					divFlex$ = $(dFlex(d,k))
					hasFirstLine = false
					return
				}
				$(divFlex$.get(0)).append(mkLines(ks,k, classAdd, opts, prop, false, 'col').removeClass('item-dd-container'))
				var elP$;
				divFlex$.children().each(function(i) {
					if (i==0) return true;
					if (i==1) {elP$ = $(this); return true}
					elP$.children().append($(this).find('p'))
					$(this).remove()
				})
				$(q$.get(0)).append($(wgThis.mkLineContainer(divFlex$).get(0)))
				waitLineValue = 0
				divFlex$ = $(dFlex(d,k))
				hasFirstLine = false
				return
			},
			isEmpty = function isEmpty(obj) {
			  for (const prop in obj) {
				if (Object.hasOwn(obj, prop)) {
				  return false;
				}
			  }
			  return true;
			}
			;
			
			
		wgThis.dPathBranch = '.'+ kWork
		if (kWork[0] !== '_') {
			if (!dParent[kWork].headLabel) dParent[kWork].headLabel  = '{text:"", hint: "", dPath:""}';
			if (!dParent[kWork].headLabel.hint) dParent[kWork].headLabel.hint = "";
		}
		
		for (k in d) {
			var isStr = false;
			if (typeof d[k] === 'string') {
				ks = d[k]
				opts = {hint: ks, text: ks, options: {dPath:''} }
				d[k].options = opts;
				isStr = true
			} else {
				ks = d[k].text || false
				opts = d[k].options || {}
			}
			
			
			
			opts.dPath = wgThis.dPathBranch + '.'+k
			
			if (k=='headLabel' && !d[k].options) d[k].options  = opts;
			
			if (opts.readonly === undefined && dParent._allLabelReadonly && k.indexOf('Label')>=0) {
				opts.readonly = dParent._allLabelReadonly
			}
			
			if (!opts.options) opts = Object.assign(opts,{options:{formats: false}})
			if (opts.formats) ks = opts.formats
			
			if (!ks) {
				opts.textEmpty = true
				opts.readonly = false
				ks = d[k].hint
				if (isEmpty(d[k])) {
					opts.objEmpty = true
				}
			}
			
		
			switch(k) {
				case 'actions' :
					q$.append( mkLines(ks,k, 'd-none', opts) )
					break;
				case 'headLabel' :
					q$.append( mkLines(ks,k, '', opts) )
					break;
				case 'headValue' :
					q$.append( mkLines(ks, k, '', opts) )
					break;
				case 'lineLabel' :
					doLineLabel(ks, k, opts)
					break
				case 'lineValue' :
					doLineValue(ks, k, opts)
					break
				case 'contentLabel' :
					q$.append( mkLines(ks,k, '', opts) )
					break
				case 'contentValue' :
					q$.append( mkLines(ks,k, '', opts) )
					break
				default:
					if (k.indexOf('lineLabel')==0) doLineLabel(ks, k, opts);
					else if (k.indexOf('lineValue')==0) doLineValue(ks, k, opts);
					else q$.append( mkLines(ks, k, '', opts) );
					break
			}
				
			if (k.match(/Label$/)) {
				wgThis._fakeParent = isStr ? {text: ks, options: opts} : d[k]
			} else if (opts.textEmpty) wgThis._fakeParent = {}	
		}
		wgThis._fakeParent = {}
		wgThis.dPathBranch = ''
	},
	mkIconEvent: function() {
		var wgThis = this;
		this.element.find('.action-container').children('div').each(function(i) {
			var that$ = $(this);
			if (that$.hasClass('act_add_padding')) {
				that$.on('click', function() {
					var that$ = $(this), contAct$ = that$.parent().parent();
					that$.addClass('d-none').parent().find('.act_remove_padding').removeClass('d-none')
					if (contAct$.hasClass('dd-lines-container')) {
						contAct$.addClass(wgThis.options.settings.indentClass || 'ps-3')
					}
					else that$.children(':first-child').parentsUntil('.col-dd-container').parent().addClass(wgThis.options.settings.paddingClass || 'p-3');
					that$.parent().addClass('d-none')
				})
			} else if (that$.hasClass('act_remove_padding')) {
				that$.on('click', function() {
					var that$ = $(this), contAct$ = that$.parent().parent();
					that$.addClass('d-none').parent().find('.act_add_padding').removeClass('d-none')
					if (contAct$.hasClass('dd-lines-container')) {
						contAct$.removeClass(wgThis.options.settings.indentClass || 'ps-3')
					}
					else that$.children(':first-child').parentsUntil('.col-dd-container').parent().removeClass(wgThis.options.settings.paddingClass || 'p-3');
					that$.parent().addClass('d-none')
				})
			} else if (that$.hasClass('act_line_up')) {
				that$.on('click', function() {
					var that$ = $(this), contAct$ = that$.parent().parent(); //that$.parentsUntil('.dd-lines-container').parent()
					$(contAct$.get(0)).insertBefore(contAct$.prev().get(0))
					that$.parent().addClass('d-none')
				})
			} else if (that$.hasClass('act_line_down')) {
				that$.on('click', function() {
					var that$ = $(this), contAct$ = that$.parent().parent();//that$.parentsUntil('.dd-lines-container').parent();
					$(contAct$.get(0)).insertAfter(contAct$.next().get(0))
					that$.parent().addClass('d-none')
				})
			} else if (that$.hasClass('act_plus')) {
				that$.on('click', function() {
					var contAct$ = $(this).parent().parent(), clone$ = contAct$.clone(true);
					$(clone$.get(0)).insertAfter($(contAct$.get(0))).find('.action-container').remove()
					clone$.find('div[data-o-quill]').each(function(){$(this).data('oQuill').update()})
					//clone$.insertAfter(contAct$).find('.action-container').remove()
					clone$.ddContent(wgThis.options)
					that$.parent().addClass('d-none')
					//triggerCloneRegion
				})
			} else if (that$.hasClass('act_delete')) {
				that$.on('click', function() {
					var contAct$ = $(this).parent().parent();
					$(this).parent().addClass('d-none')
					contAct$.parent().append(contAct$.find('.action-container'))
					contAct$.remove()
					//triggerRemoveRegion
				})
			} else if (that$.hasClass('act_ql_toolbar')) {
				that$.on('click', function(e, d) {
					
					
					var target$  = d && d.sender$ ? d.sender$ : $(e.currentTarget)
						, reg$   =  target$.parentsUntil('.col-dd-container').parent()
						, pCont$ = d && d.pCont$ ? d.pCont$ : reg$.find('.ql-container').slice(0,1)
						, tBar$  = wgThis.options.gToolbar
						
					tBar$.addClass('invisible').removeClass('d-none');
					var tWid = tBar$.outerWidth();
					
					if (tBar$.children('.ql-toolbar').length) tWid = tBar$.children('.ql-toolbar').outerWidth();
					
					tBar$.removeClass('invisible')
					
					//wgThis.options.gToolbar.css({'width': tWid})
						
					var	 ofs    = reg$.offset()
						, bLeft  = ofs.left + tWid+32-16 <= screen.width ?  -16 : - (tWid-reg$.outerWidth())-32
						//, bTop   = target$.offset().top - tBar$.outerHeight() - ofs.top - target$.outerHeight() - 15
						, bTop   = target$.offset().top - tBar$.outerHeight() - ofs.top - (d && d.addTopPx ? d.addTopPx : 14)
						;
					
					if (!d && (/*tBar$.children('.ql-toolbar').length || */ !wgThis.options.lastQuillObject) && pCont$.length /* && !tBar$.hasClass('dd-has-dmy-click')*/) {
						//wgThis.options.lastQuillObject && wgThis.dynToolBar();
						wgThis.dynToolBar(pCont$.data('oQuill'), pCont$);
						target$.trigger('click',{antiRecusive: true, sender$: target$/*, bTop: bTop, bLeft: bLeft*/, pCont$: pCont$})
						tBar$.removeClass('d-none')
						return false;
					}
					
					if (tBar$.children('.ql-toolbar').length) {
						/*tBar$.addClass('invisible').removeClass('d-none');
						var tWid = tBar$.outerWidth();
						tBar$.removeClass('invisible')
						wgThis.options.gToolbar.css({'width': tWid})
						*/
						tBar$.css({top: bTop, left: bLeft})
						
						$(tBar$.get(0)).detach().appendTo($(reg$.get(0)))
						
						phUtils.fastDragElement({element: wgThis.options.gToolbar,
									 start: function(e, ui) {
										reg$.draggable( "widget" ).draggable( "disable" )
										wgThis.options.gToolbar.addClass('tbar-draged')
									 },
									 stop: function(e, ui) {
										 reg$.draggable( "widget" ).draggable( "enable" )
									 }
								})
						if (!d) {
							if (!tBar$.hasClass('dd-has-focus')) {
								tBar$.addClass('dd-has-focus')
								//wgThis.options.lastQuillObject && wgThis.options.lastQuillObject.focus();
								!wgThis.options.notAutoThumbToolbar && tBar$.addClass('tbar-draged');
							}
							tBar$.removeClass('d-none')
						} else {
							//tBar$.addClass('dd-has-dmy-click')
							!tBar$.hasClass('dd-has-focus') && !wgThis.options.notAutoThumbToolbar && tBar$.addClass('tbar-draged');
						}
						wgThis.options.lastQuillObject && wgThis.options.lastQuillObject.focus();
					} else {
						wgThis.options.lastQuillObject = null
						tBar$.addClass('d-none').removeClass('dd-has-focus')
						//tBar$.removeClass('dd-has-focus')
					}
					
					//window.scrollTo(0,tBar$.offset().top)
					return false;
				})
			}
			//if (!that$.hasClass('act_move')) that$.parent().addClass('d-none')
		})
	},
	getDdData: function(itemStorage, retVal) {
		!!itemStorage && $(itemStorage).val(JSON.stringify(this.options.ddData));
		$(itemStorage).trigger('change')
		if (retVal) return JSON.stringify(this.options.ddData);
	},
	addColMenu: function() {
		var wgThis = this;
		for (var i=0, a = Object.keys(wgThis.options.ddData); i<a.length; i++) {
			if (a[i][0] == '_' || a[i]=='actions') continue;
			var oCol = wgThis.options.ddData[a[i]], text = oCol['headLabel']['text'], icon = oCol['headLabel']['icon'];
			if (!text || !text.length) text = oCol['headLabel']['hint'] || '';
			var gotoAnchor = function(e) {
				window.scroll(0,e.data[1].offset().top-40)
				e.data[1].parentsUntil('.col-dd-container').parent().fadeTo(800, 0.4, function() { $(this).fadeTo(900, 1.0,  function(){$(this).fadeTo(300, 0.3, function() { $(this).fadeTo(600, 1.0); })}  );});
			} 
			var elmPth$;
			$(wgThis.value('classN') + ' [data-ddOpts!=""] .dd-line-container').each(function(i){
				if ($(this).data('ddOpts').dPath == oCol.headLabel.options.dPath) {
					elmPth$ = $(this);
					return false;
				}
			})		
		$(wgThis.value('classN')).parentsUntil('.container').find('.dd-col-menu-container .dd-col-menu').append($('<div class="line-menu"><span class="' + (icon || 'fa fa-file') + '"></span><span class="menu-title">' + text  + '</span></div>').on('click', [oCol, elmPth$], gotoAnchor))
		}
	}
});
})();


/* init widget
window.addEventListener('load', function() {
	$('.dd-cont2').mkDdCont({
		containerDotClass: '.dd-cont2',
		eventDotClass: '.action-container',
		col: 3,
		settings: {
			indentClass: 'ps-3',
			paddingClass: 'p-3',
		},
		toolbarSelector: '#dd-dyn-toolbar',
		notAutoThumbToolbar: false,
		delayForUpdate: 5000,
		ddData: JSON.parse(window.ddData)
	});
})
*/