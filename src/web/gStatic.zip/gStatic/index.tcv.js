var n = Object.defineProperty, t = Object.defineProperties, e = Object.getOwnPropertyDescriptors, i = Object.getOwnPropertySymbols, a = Object.prototype.hasOwnProperty, d = Object.prototype.propertyIsEnumerable, o = (t, e, i) => e in t ? n(t, e, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: i
}) : t[e] = i, w = (n, t) => {
    for (var e in t || (t = {}))
        a.call(t, e) && o(n, e, t[e]);
    if (i)
        for (var e of i(t))
            d.call(t, e) && o(n, e, t[e]);
    return n
}, l = (n, i) => t(n, e(i)), r = (n, t, e) => (o(n, "symbol" != typeof t ? t + "" : t, e), e);
import {
    c as s,
    d as h,
    s as c,
    m as p,
    i as g,
    a as A,
    t as u,
    g as m,
    b,
    e as v,
    f,
    o as x,
    h as y,
    j as k,
    k as E,
    r as B,
    l as C,
    n as S,
    w as I,
    p as V,
    q as D,
    u as R,
    v as q,
    x as U,
    y as T,
    z as N,
    A as M,
    B as Q,
    C as F,
    D as H,
    E as G,
    F as O,
    G as j,
    H as L,
    V as P,
    I as K,
    J as X,
    K as Y,
    L as W,
    M as z,
    N as J,
    O as Z,
    P as _,
    Q as $,
    T as nn,
    R as tn,
    S as en,
    U as an,
    W as dn,
    X as on,
    Y as wn,
    Z as ln,
    _ as rn,
    $ as sn,
    a0 as hn,
    a1 as cn,
    a2 as pn,
    a3 as gn,
    a4 as An,
    a5 as un,
    a6 as mn,
    a7 as bn,
    a8 as vn,
    a9 as fn,
    aa as xn,
    ab as yn,
    ac as kn,
    ad as En,
    ae as Bn,
    af as Cn,
    ag as Sn,
    ah as In,
    ai as Vn,
    aj as Dn,
    ak as Rn,
    al as qn,
    am as Un,
    an as Tn,
    ao as Nn,
    ap as Mn,
    aq as Qn,
    ar as Fn,
    as as Hn,
    at as Gn,
    au as On,
    av as jn
}
from "./vendor.149580.js";
!function () {
    const n = document.createElement("link").relList;
    if (!(n && n.supports && n.supports("modulepreload"))) {
        for (const n of document.querySelectorAll('link[rel="modulepreload"]'))
            t(n);
        new MutationObserver((n => {
                for (const e of n)
                    if ("childList" === e.type)
                        for (const n of e.addedNodes)
                            "LINK" === n.tagName && "modulepreload" === n.rel && t(n)
            })).observe(document, {
            childList: !0,
            subtree: !0
        })
    }
    function t(n) {
        if (n.ep)
            return;
        n.ep = !0;
        const t = function (n) {
            const t = {};
            return n.integrity && (t.integrity = n.integrity),
            n.referrerpolicy && (t.referrerPolicy = n.referrerpolicy),
            "use-credentials" === n.crossorigin ? t.credentials = "include" : "anonymous" === n.crossorigin ? t.credentials = "omit" : t.credentials = "same-origin",
            t
        }
        (n);
        fetch(n.href, t)
    }
}
();
const Ln = {}, Pn = function (n, t) {
    return t && 0 !== t.length ? Promise.all(t.map((n => {
                if ((n = `https://static.topcv.vn/cv-builder/${n}`)in Ln)
                    return;
                Ln[n] = !0;
                const t = n.endsWith(".css"),
                e = t ? '[rel="stylesheet"]' : "";
                if (document.querySelector(`link[href="${n}"]${e}`))
                    return;
                const i = document.createElement("link");
                return i.rel = t ? "stylesheet" : "modulepreload",
                t || (i.as = "script", i.crossOrigin = ""),
                i.href = n,
                document.head.appendChild(i),
                t ? new Promise(((t, e) => {
                        i.addEventListener("load", t),
                        i.addEventListener("error", (() => e(new Error(`Unable to preload CSS for ${n}`))))
                    })) : void 0
            }))).then((() => n())) : n()
};
var Kn = (n => (n.TEXT = "text", n.TEXT_SINGLE = "text-single", n.IMAGE = "image", n.BUTTON = "button", n.ICON = "icon", n.SKILLRATE = "skillRate", n.TABLE = "table", n))(Kn || {}), Xn = (n => (n.SECTION = "section", n.COMPONENT = "component", n.COLUMN = "column", n.BLOCK = "block", n.BLOCK_CHILD = "block-child", n.ELEMENT_GROUP = "element-group", n))(Xn || {}), Yn = (n => (n[n.DOWN = 1] = "DOWN", n[n.UP = -1] = "UP", n[n.LEFT = -1] = "LEFT", n[n.RIGHT = 1] = "RIGHT", n))(Yn || {}), Wn = (n => (n.COLUMN = "column", n.GRID = "grid", n.ROW = "row", n.ROW_NOWRAP = "row-nowrap", n))(Wn || {}), zn = (n => (n.PROFILE = "profile", n.OBJECTIVE = "objective", n.SKILLGROUP = "skillgroup", n.AWARD = "award", n.EXPERIENCE = "experience", n.EDUCATION = "education", n.CERTIFICATION = "certification", n.ACTIVITY = "activity", n.REFERENCE = "reference", n.ADDITIONAL_INFO = "additional_info", n.INTERESTS = "interests", n.PROJECT = "project", n.SKILLRATE = "skillrate", n.INTEREST = "interest", n))(zn || {}), Jn = (n => (n.AVATAR = "avatar", n.BUSINESS_CARD = "business_card", n))(Jn || {});
const Zn = s();
function _n(n) {
    n.use(Zn)
}
var $n = (n => (n.VN = "vi", n.JP = "jp", n.EN = "en", n))($n || {});
const nt = {
    profile_meta: {
        blocktitle: "Thông tin cá nhân"
    },
    objective_meta: {
        blocktitle: "Mục tiêu nghề nghiệp"
    },
    education_meta: {
        blocktitle: "Học vấn"
    },
    experience_meta: {
        blocktitle: "Kinh nghiệm làm việc"
    },
    activity_meta: {
        blocktitle: "Hoạt động"
    },
    certification_meta: {
        blocktitle: "Chứng chỉ"
    },
    award_meta: {
        blocktitle: "Danh hiệu và giải thưởng"
    },
    skillgroup_meta: {
        blocktitle: "Các kỹ năng"
    },
    interests_meta: {
        blocktitle: "Sở thích"
    },
    additional_info_meta: {
        blocktitle: "Thông tin thêm"
    },
    reference_meta: {
        blocktitle: "Người giới thiệu"
    },
    project_meta: {
        blocktitle: "Dự án"
    },
    project_label: [{}
    ],
    skillrate_meta: {
        blocktitle: "Kĩ năng"
    },
    interest_meta: {
        blocktitle: "Sở thích"
    }
}, tt = {
    profile_meta: {
        blocktitle: "プロフィール"
    },
    objective_meta: {
        blocktitle: "目的"
    },
    education_meta: {
        blocktitle: "教育"
    },
    experience_meta: {
        blocktitle: "実務経験"
    },
    activity_meta: {
        blocktitle: "活動"
    },
    certification_meta: {
        blocktitle: "認定"
    },
    award_meta: {
        blocktitle: "栄誉と賞"
    },
    skillgroup_meta: {
        blocktitle: "スキル"
    },
    interests_meta: {
        blocktitle: "興味"
    },
    additional_info_meta: {
        blocktitle: "追加情報"
    },
    reference_meta: {
        blocktitle: "参考文献"
    },
    project_meta: {
        blocktitle: "プロジェクト"
    },
    skillrate_meta: {
        blocktitle: "スキル"
    },
    interest_meta: {
        blocktitle: "興味"
    }
}, et = {
    profile_meta: {
        blocktitle: "Profile"
    },
    objective_meta: {
        blocktitle: "Objective"
    },
    education_meta: {
        blocktitle: "Education"
    },
    experience_meta: {
        blocktitle: "Work experience"
    },
    activity_meta: {
        blocktitle: "Activities"
    },
    certification_meta: {
        blocktitle: "Certifications"
    },
    award_meta: {
        blocktitle: "Honors & Awards"
    },
    skillgroup_meta: {
        blocktitle: "Skills"
    },
    interests_meta: {
        blocktitle: "Interests"
    },
    additional_info_meta: {
        blocktitle: "Additional information"
    },
    reference_meta: {
        blocktitle: "References"
    },
    project_meta: {
        blocktitle: "Projects"
    },
    skillrate_meta: {
        blocktitle: "Skill"
    },
    interest_meta: {
        blocktitle: "Interest"
    }
}, it = h({
    id: "builder-data",
    state: () => ({
        builderWidget: {
            templateCvId: 0,
            templateCvInfo: {},
            templateCvDataSample: {},
            renderData: [],
            cvData: {},
            globalSetting: {
                language: "vi",
                styles: {
                    fontFamily: "Roboto",
                    backgroundImage: "",
                    lineHeight: "1.8"
                }
            },
            typeCreateCv: "",
            route: ""
        },
        renderData: [],
        templateBlocks: [],
        templateColors: [],
        builderData: [],
        cvData: {
            global: {
                cv_title: ""
            }
        },
        sampleData: {},
        pathEdit: "",
        typeBlockEdit: "",
        isPreview: !1,
        isApplyCv: !1,
        flagUndoRedo: !1,
        cvId: "",
        templateCvId: 0,
        templateCvInfo: {},
        templateCvDataSample: {},
        validate: [],
        globalSetting: {
            styles: {
                colorPrimary: "",
                backgroundImage: "",
                fontFamily: "",
                lineHeight: ""
            },
            language: ""
        },
        isShowListBlockContent: !1,
        isActivePromptRedirect: !0,
        isShowSettingProfile: !1,
        itemAddBlockContent: {},
        pathColumnAddBlockContent: "",
        pathAddedByDraggable: "",
        listTypeBlockUsed: [],
        currentActiveTab: "",
        pdfBlobFileBuilderData: {},
        builderDataHash: "",
        cvDataBlockRemoved: {},
        keyRemoved: {},
        validateErrors: {},
        validateWarnings: {},
        isShowWarning: !1,
        isUploadAvatar: !1,
        resizingImage: !1,
        isLoadingApi: !1,
        activeTextTourGuide: !1,
        isShowTourGuide: !1,
        elementTextTourGuide: "",
        stepTourGuide: "",
        quillInstance: null,
        disableApplyTheme: !1,
        listDataSample: [],
        listDataTemplate: [],
        listBlockSuggestFeedbacked: [],
        undoStack: [],
        redoStack: [],
        lastTextComponentKey: ""
    }),
    getters: {
        globalSettingStyle: n => {
            var t;
            return null != (t = n.globalSetting.styles) ? t : {}
        },
        colorPrimary: n => {
            var t,
            e,
            i;
            return null != (i = null == (e = null == (t = n.globalSetting) ? void 0 : t.styles) ? void 0 : e.colorPrimary) ? i : ""
        },
        backgroundImage: n => {
            var t,
            e,
            i;
            return null != (i = null == (e = null == (t = n.globalSetting) ? void 0 : t.styles) ? void 0 : e.backgroundImage) ? i : ""
        },
        cvDataWidget: n => {
            var t;
            return null != (t = null == n ? void 0 : n.builderWidget.cvData) ? t : {}
        },
        getCvTitle: n => {
            var t,
            e,
            i;
            return null != (i = null == (e = null == (t = n.cvData) ? void 0 : t.global) ? void 0 : e.cv_title) ? i : ""
        },
        fontFamily: n => {
            var t,
            e;
            return (null == (e = null == (t = n.globalSetting) ? void 0 : t.styles) ? void 0 : e.fontFamily) || ""
        },
        lineHeight: n => {
            var t,
            e;
            return (null == (e = null == (t = n.globalSetting) ? void 0 : t.styles) ? void 0 : e.lineHeight) || ""
        },
        globalSettingWidget: n => {
            var t,
            e;
            return null != (e = null == (t = n.builderWidget) ? void 0 : t.globalSetting) ? e : {}
        },
        language: n => {
            var t,
            e;
            return null != (e = null == (t = n.globalSetting) ? void 0 : t.language) ? e : $n.VN
        }
    },
    actions: {
        setStatusPromptRedirect(n) {
            this.isActivePromptRedirect = n
        },
        setBuilderDataHash(n) {
            this.builderDataHash = n
        },
        setPdfBlobFileBuilderData(n) {
            this.pdfBlobFileBuilderData = n
        },
        setTemplateCvId(n) {
            this.templateCvId = n
        },
        setTemplateCvInfo(n) {
            this.templateCvInfo = n
        },
        setTemplateCvDataSample(n) {
            this.templateCvDataSample = n
        },
        setBuilderWidget(n) {
            this.builderWidget = n
        },
        setBuilderData(n) {
            this.builderData = n
        },
        setRenderData(n) {
            this.renderData = n
        },
        setTemplateColors(n) {
            this.templateColors = n
        },
        setCvData(n) {
            this.cvData = n
        },
        setCvTitle(n) {
            this.cvData.global ? this.cvData.global.cv_title = n : c(this.cvData, "global", {
                cv_title: n
            })
        },
        setPathEdit(n) {
            this.pathEdit = n
        },
        setFlagUndoRedo(n) {
            this.flagUndoRedo = n
        },
        setTypeBlockEdit(n) {
            this.typeBlockEdit = n
        },
        setIsPreview(n) {
            this.isPreview = n
        },
        setCvId(n) {
            this.cvId = n
        },
        setPathColumnAddBlockContent(n) {
            this.pathColumnAddBlockContent = n
        },
        setPathAddedByDraggable(n) {
            this.pathAddedByDraggable = n
        },
        setItemAddBlockContent(n) {
            this.itemAddBlockContent = n
        },
        setIsShowListBlockContent(n) {
            this.isShowListBlockContent = n
        },
        setIsShowLSettingProfile(n) {
            this.isShowSettingProfile = n
        },
        setListTypeBlockUsed(n) {
            this.listTypeBlockUsed = n
        },
        setIsApplyCv(n) {
            this.isApplyCv = n
        },
        setBuilderDataWithKey(n) {
            n.path ? this.builderData = c(this.builderData, n.path, n.value) : this.builderData = n.value
        },
        setValidateDataWithKey(n) {
            this.validate = n
        },
        setGlobalSetting(n) {
            this.globalSetting = n
        },
        setGlobalSettingWithKey(n, t) {
            c(this.globalSetting, n, t)
        },
        setLineHeight(n) {
            this.globalSetting.styles.lineHeight = n
        },
        setFontFamily(n) {
            this.globalSetting.styles.fontFamily = n
        },
        setCurrentActiveTab(n) {
            this.currentActiveTab = n
        },
        setListKeyRenderRemoved(n) {
            this.keyRemoved[n] = !0
        },
        removeKeyRenderRemoved(n) {
            delete this.keyRemoved[n]
        },
        setEmptyListKeyRenderRemoved() {
            this.keyRemoved = {}
        },
        setDataExampleByLanguage() {
            let n = null;
            switch (this.language) {
            case $n.VN:
                n = nt;
                break;
            case $n.JP:
                n = tt;
                break;
            case $n.EN:
                n = et;
                break;
            default:
                n = nt
            }
            this.sampleData = n
        },
        setCvDataBlockRemoved(n) {
            const t = p(this.cvDataBlockRemoved, n);
            for (const [e, i] of Object.entries(t))
                Array.isArray(i) && (t[e] = i.filter((n => 0 !== Object.keys(n).length)));
            this.cvDataBlockRemoved = t
        },
        setEmptyCvData() {
            this.cvDataBlockRemoved = {}
        },
        addValidateError(n, t) {
            this.validateErrors[n] = t
        },
        addValidateWarning(n, t, e) {
            this.validateWarnings[n] = {
                error: t,
                block: e
            }
        },
        removeValidateError(n) {
            delete this.validateErrors[n]
        },
        removeValidateWarning(n) {
            delete this.validateWarnings[n]
        },
        setValidateError(n) {
            this.validateErrors = n
        },
        setValidateWarning(n) {
            this.validateWarnings = n
        },
        setTemplateBlocks(n) {
            this.templateBlocks = n
        },
        setIsUploadAvatar(n) {
            this.isUploadAvatar = n
        },
        setResizingImage(n) {
            this.resizingImage = n
        },
        setIsLoadingApi(n) {
            this.isLoadingApi = n
        },
        setListDataSample(n) {
            this.listDataSample = n
        },
        setListDataTemplate(n) {
            this.listDataTemplate = n
        },
        addItemBlockSuggestFeedbacked(n) {
            this.listBlockSuggestFeedbacked.push(n)
        },
        setUndoStack(n) {
            this.undoStack = n
        },
        setRedoStack(n) {
            this.redoStack = n
        },
        setLastTextComponentKey(n) {
            this.lastTextComponentKey = n
        }
    }
});
var at = (n => (n.INLINE = "inline", n.TEXTONLY = "textOnly", n.NOTEMPTY = "notEmpty", n.MAXLENGTH = "maxLength", n.DATE = "date", n.EMAIL = "email", n.DATEFORMAT = "dateFormat", n.PHONE = "phone", n))(at || {});
const dt = ["inline", "textOnly", "notEmpty", "maxLength", "date", "email", "dateFormat", "phone"];
function ot(n) {
    return g(n)
}
function wt(n) {
    const t = document.createElement("div");
    t.innerHTML = n;
    return t.textContent
}
function lt(n) {
    return !!new RegExp(".(gif|jpg|jpeg|png|bmp)$", "gi").test(n)
}
function rt(n) {
    const t = String(n)[0];
    return ["0", "+", "("].includes(t)
}
function st(n) {
    return n.replace(/[^0-9]*/g, "").length >= 7
}
function ht(n) {
    return n.includes("<br>")
}
function ct(n) {
    return !/\d/.test(n)
}
const pt = {
    "profile.phone": "Số điện thoại",
    "profile.address": "Thông tin địa chỉ",
    "profile.email": "Email",
    "profile.fullname": "Họ và tên",
    "profile.title": "Vị trí ứng tuyển",
    "objective.objective": "Mục tiêu nghề nghiệp",
    "experience.start": "Kinh nghiệm việc làm",
    "experience.end": "Kinh nghiệm việc làm",
    "experience.position": "Kinh nghiệm việc làm",
    "experience.company": "Kinh nghiệm việc làm",
    "project.start": "Dự án",
    "project.end": "Dự án",
    "project.project_name": "Dự án",
    "project.my_position": "Dự án",
    "education.start": "Học vấn",
    "education.end": "Học vấn",
    "education.school": "Học vấn",
    "education.title": "Học vấn"
};
function gt(n, t, e) {
    var i;
    const a = [];
    let d,
    o = {};
    if (t)
        for (const h of t)
            if (d = At(h), dt.includes(null != (i = d.name) ? i : ""))
                switch (d.name) {
                case at.NOTEMPTY:
                    ot(wt(e).trim()) && (o = {
                            status: !0,
                            message: `Vui lòng bổ sung ${pt[n].toLowerCase()}`
                        }, a.push(o));
                    break;
                case at.EMAIL:
                    s = wt(e),
                    /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(String(s)) || (o = {
                            status: !0,
                            message: `${pt[n]} bị sai định dạng`
                        }, a.push(o));
                    break;
                case at.PHONE: {
                        const t = wt(e);
                        rt(t) ? /^[\d \-\(\)\/\.\+]+$/g.test(t) ? st(t) || (o = {
                                status: !0,
                                message: `Độ dài ${pt[n]} từ 7 ký tự số`
                            }, a.push(o)) : (o = {
                                status: !0,
                                message: `${pt[n]} bị sai định dạng`
                            }, a.push(o)) : (o = {
                                status: !0,
                                message: `${pt[n]} phải bắt đầu bằng số 0 hoặc + hoặc (`
                            }, a.push(o));
                        break
                    }
                case at.INLINE:
                    ht(e) && (o = {
                            status: !0,
                            message: "Input không xuống dòng"
                        }, a.push(o));
                    break;
                case at.TEXTONLY:
                    ct(wt(e)) || (o = {
                            status: !0,
                            message: "Input chỉ được nhập chữ"
                        }, a.push(o));
                    break;
                case at.MAXLENGTH:
                    l = wt(e),
                    r = d.params,
                    String(l).length <= Number(r) || (o = {
                            status: !0,
                            message: "Input không vượt quá " + d.params + " kí tự"
                        }, a.push(o));
                    break;
                case at.DATEFORMAT:
                    (w = new Date(wt(e), d.params))instanceof Date && !isNaN(w) || (o = {
                            status: !0,
                            message: "Input không đúng định dạng"
                        }, a.push(o));
                    break;
                default:
                    o = {
                        status: !1,
                        message: ""
                    },
                    a.push(o)
                }
    var w,
    l,
    r,
    s;
    return a.length > 0 ? {
        status: !0,
        message: a[0].message
    }
     : {
        status: !1,
        message: ""
    }
}
const At = n => {
    let t;
    const e = n.split(":")[0];
    return n.includes(":") && (t = n.split(":").slice(1).join(":")), {
        name: e,
        params: t
    }
};
const ut = [];
for (let Nr = 0; Nr <= 15; Nr++)
    ut[Nr] = Nr.toString(16);
function mt() {
    let n = "";
    for (let t = 1; t <= 36; t++)
        n += 9 === t || 14 === t || 19 === t || 24 === t ? "-" : 15 === t ? 4 : 20 === t ? ut[4 * Math.random() | 8] : ut[16 * Math.random() | 0];
    return n.replace(/-/g, "")
}
let bt = 0;
let vt = !1;
const ft = mt(), xt = n => {
    var t;
    return null == (t = n.value) ? void 0 : t.path
}, yt = n => {
    var t;
    return null == (t = n.value) ? void 0 : t.type
}, kt = n => {
    var t;
    return null == (t = n.value) ? void 0 : t.block
}, Et = n => {
    var t;
    return null == (t = n.value) ? void 0 : t.keyRender
}, Bt = n => {
    var t;
    return null == (t = n.value) ? void 0 : t.currentIndex
}, Ct = n => {
    var t,
    e;
    return (null == (t = n.value) ? void 0 : t.type) === Kn.TEXT || (null == (e = n.value) ? void 0 : e.type) === Kn.TEXT_SINGLE
}, St = (n, t) => {
    var e,
    i;
    const a = document.createElement("div");
    a.setAttribute("id", ft);
    return (null == (i = null == (e = t.instance) ? void 0 : e.$root) ? void 0 : i.$el).appendChild(a),
    Ct(t) ? (n => {
        var t;
        const e = document.createElement("div");
        return e.classList.add("ql-text"),
        n.appendChild(e),
        null == (t = n.querySelector(".ql-editor")) || t.remove(),
        e
    })(n) : a
};
async function It(n, t) {
    const e = St(n, t),
    i = ((n, t, e) => {
        const i = A(e, {
            el: n,
            type: yt(t),
            path: xt(t),
            block: kt(t),
            currentIndex: Bt(t),
            keyRender: Et(t)
        });
        return _n(i),
        i
    })(n, t, await(async() => {
            if (!vt) {
                const n = await Pn((() => import("./BuilderStyle.149580.js")), ["assets/BuilderStyle.149580.js", "assets/BuilderStyle.149580.css", "assets/vendor.149580.js", "assets/usePopper.149580.js"]);
                vt = n.default
            }
            return vt
        })());
    i.mount(e),
    Ct(t) && function (n) {
        n.directive("validate-cvo", {
            updated(n, t) {
                var e,
                i;
                const a = it(),
                d = gt(null == (e = t.value.renderData) ? void 0 : e.rules, t.value.rawText),
                o = p({
                    value: null == (i = t.value.renderData) ? void 0 : i.text,
                    path: t.value.path
                }, d);
                !0 === d.status ? (n.classList.add("outline-validate"), n.setAttribute("data-message-error", d.message)) : n.classList.remove("outline-validate");
                const w = a.validate;
                if (w.find((n => n.path === t.value.path))) {
                    const n = w.map((n => n.path === t.value.path ? o : n));
                    a.setValidateDataWithKey(n)
                } else
                    w.push(o), a.setValidateDataWithKey(w)
            }
        })
    }
    (i)
}
const Vt = {
    mounted: async(n, t) => {
        if ((n => {
                var t;
                return ["lineFloating", "fullLineFloating"].includes(null == (t = n.value) ? void 0 : t.type)
            })(t))
            return;
        if ((n => {
                var t;
                return (null == (t = n.value) ? void 0 : t.block) === Xn.ELEMENT_GROUP
            })(t))
            return;
        if ((n => {
                var t;
                return null == (t = n.value) ? void 0 : t.isPreview
            })(t))
            return;
        if ((n => {
                var t;
                return null == (t = n.value) ? void 0 : t.isReadOnly
            })(t))
            return;
        if ((n => {
                var t;
                return null == (t = n.value) ? void 0 : t.disableBuilderStyle
            })(t))
            return;
        if (Ct(t) || (n => {
                var t;
                return (null == (t = n.value) ? void 0 : t.type) === Kn.IMAGE
            })(t) || (n => {
                var t;
                return null == (t = n.value) ? void 0 : t.immediateFocus
            })(t) || (n => {
                var t;
                return null == (t = n.value) ? void 0 : t.typeBlock
            })(t))
            return void It(n, t);
        let e = !0;
        e && n.addEventListener("mouseenter", (async function () {
                e && (e = !1, It(n, t))
            }))
    },
    unmounted(n, t) {
        var e;
        it().setListKeyRenderRemoved(t.value.keyRender),
        null == (e = document.getElementById(ft)) || e.remove()
    }
};
const Dt = {
    mounted: async(n, t) => {
        var e;
        (null == (e = t.value) ? void 0 : e.isPreview) || (n.addEventListener("mouseover", (function (t) {
                    ((n, t) => {
                        n.stopPropagation(),
                        t.classList.add("hover")
                    })(t, n)
                }), !1), n.addEventListener("mouseout", (function (t) {
                    ((n, t) => {
                        t.classList.remove("hover")
                    })(0, n)
                }), !1))
    }
};
const Rt = /[|\\{}()[\]^$+*?.]/g;
function qt(n) {
    return n.replace(Rt, "\\$&")
}
var Ut = {
    nm: "Search",
    mn: "",
    layers: [{
            ty: 4,
            nm: "Glass - 1",
            mn: "",
            sr: 1,
            st: 0,
            op: 222,
            ip: 0,
            hd: !1,
            cl: "",
            ln: "",
            ddd: 0,
            bm: 0,
            tt: 0,
            hasMask: !1,
            td: 0,
            ao: 0,
            ks: {
                a: {
                    a: 0,
                    k: [47.578, -14.992, 0],
                    ix: 1
                },
                s: {
                    a: 0,
                    k: [201, 201, 100],
                    ix: 6
                },
                sk: {
                    a: 0,
                    k: 0
                },
                p: {
                    a: 1,
                    k: [{
                            o: {
                                x: .74,
                                y: 0
                            },
                            i: {
                                x: .2,
                                y: 1
                            },
                            s: [288.578, 98.008, 0],
                            t: 0
                        }, {
                            o: {
                                x: .8,
                                y: 0
                            },
                            i: {
                                x: .2,
                                y: 1
                            },
                            s: [74.578, 167.008, 0],
                            t: 32
                        }, {
                            o: {
                                x: .8,
                                y: 0
                            },
                            i: {
                                x: .2,
                                y: 1
                            },
                            s: [249.631, 165.989, 0],
                            t: 64
                        }, {
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [288.578, 98.008, 0],
                            t: 98
                        }
                    ],
                    ix: 2
                },
                sa: {
                    a: 0,
                    k: 0
                },
                o: {
                    a: 0,
                    k: 100,
                    ix: 11
                },
                r: {
                    a: 1,
                    k: [{
                            o: {
                                x: .74,
                                y: 0
                            },
                            i: {
                                x: .2,
                                y: 1
                            },
                            s: [0],
                            t: 0
                        }, {
                            o: {
                                x: .8,
                                y: 0
                            },
                            i: {
                                x: .2,
                                y: 1
                            },
                            s: [92],
                            t: 32
                        }, {
                            o: {
                                x: .8,
                                y: 0
                            },
                            i: {
                                x: .2,
                                y: 1
                            },
                            s: [2.99],
                            t: 64
                        }, {
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [0],
                            t: 98
                        }
                    ],
                    ix: 10
                }
            },
            ef: [],
            shapes: [{
                    ty: "gr",
                    bm: 0,
                    cl: "",
                    ln: "",
                    hd: !1,
                    mn: "ADBE Vector Group",
                    nm: "Group 1",
                    ix: 1,
                    cix: 2,
                    np: 2,
                    it: [{
                            ty: "sh",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Shape - Group",
                            nm: "Path 1",
                            ix: 1,
                            d: 1,
                            ks: {
                                a: 0,
                                k: {
                                    c: !0,
                                    i: [[0, 0], [ - .779,  - .771], [0, 0], [.791,  - .783], [0, 0], [.779, .771], [0, 0], [ - .791, .783]],
                                    o: [[.779,  - .771], [0, 0], [.79, .783], [0, 0], [ - .779, .771], [0, 0], [ - .79,  - .783], [0, 0]],
                                    v: [[54.493, -11.608], [57.306, -11.607], [64.563, -4.422], [64.562, -1.579], [61.005, 1.938], [58.192, 1.938], [50.935, -5.248], [50.936, -8.091]]
                                },
                                ix: 2
                            }
                        }, {
                            ty: "fl",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Graphic - Fill",
                            nm: "Fill 1",
                            c: {
                                a: 0,
                                k: [0, .6941, .3098],
                                ix: 4
                            },
                            r: 1,
                            o: {
                                a: 0,
                                k: 100,
                                ix: 5
                            }
                        }, {
                            ty: "tr",
                            a: {
                                a: 0,
                                k: [0, 0],
                                ix: 1
                            },
                            s: {
                                a: 0,
                                k: [100, 100],
                                ix: 3
                            },
                            sk: {
                                a: 0,
                                k: 0,
                                ix: 4
                            },
                            p: {
                                a: 0,
                                k: [0, 0],
                                ix: 2
                            },
                            r: {
                                a: 0,
                                k: 0,
                                ix: 6
                            },
                            sa: {
                                a: 0,
                                k: 0,
                                ix: 5
                            },
                            o: {
                                a: 0,
                                k: 100,
                                ix: 7
                            }
                        }
                    ]
                }, {
                    ty: "gr",
                    bm: 0,
                    cl: "",
                    ln: "",
                    hd: !1,
                    mn: "ADBE Vector Group",
                    nm: "Group 2",
                    ix: 2,
                    cix: 2,
                    np: 2,
                    it: [{
                            ty: "sh",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Shape - Group",
                            nm: "Path 1",
                            ix: 1,
                            d: 1,
                            ks: {
                                a: 0,
                                k: {
                                    c: !1,
                                    i: [[0, 0], [0, 0]],
                                    o: [[0, 0], [0, 0]],
                                    v: [[47.91, -14.59], [54.804, -7.695]]
                                },
                                ix: 2
                            }
                        }, {
                            ty: "st",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Graphic - Stroke",
                            nm: "Stroke 1",
                            lc: 1,
                            lj: 1,
                            ml: 4,
                            o: {
                                a: 0,
                                k: 100,
                                ix: 4
                            },
                            w: {
                                a: 0,
                                k: 5,
                                ix: 5
                            },
                            d: [],
                            c: {
                                a: 0,
                                k: [0, .6941, .3098],
                                ix: 3
                            }
                        }, {
                            ty: "tr",
                            a: {
                                a: 0,
                                k: [0, 0],
                                ix: 1
                            },
                            s: {
                                a: 0,
                                k: [100, 100],
                                ix: 3
                            },
                            sk: {
                                a: 0,
                                k: 0,
                                ix: 4
                            },
                            p: {
                                a: 0,
                                k: [0, 0],
                                ix: 2
                            },
                            r: {
                                a: 0,
                                k: 0,
                                ix: 6
                            },
                            sa: {
                                a: 0,
                                k: 0,
                                ix: 5
                            },
                            o: {
                                a: 0,
                                k: 100,
                                ix: 7
                            }
                        }
                    ]
                }, {
                    ty: "gr",
                    bm: 0,
                    cl: "",
                    ln: "",
                    hd: !1,
                    mn: "ADBE Vector Group",
                    nm: "Group 3",
                    ix: 3,
                    cix: 2,
                    np: 3,
                    it: [{
                            ty: "el",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Shape - Ellipse",
                            nm: "Ellipse Path 1",
                            d: 1,
                            p: {
                                a: 0,
                                k: [41.016, -21.484],
                                ix: 3
                            },
                            s: {
                                a: 0,
                                k: [22.033, 22.033],
                                ix: 2
                            }
                        }, {
                            ty: "st",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Graphic - Stroke",
                            nm: "Stroke 1",
                            lc: 1,
                            lj: 1,
                            ml: 4,
                            o: {
                                a: 0,
                                k: 100,
                                ix: 4
                            },
                            w: {
                                a: 0,
                                k: 5,
                                ix: 5
                            },
                            d: [],
                            c: {
                                a: 0,
                                k: [0, .6941, .3098],
                                ix: 3
                            }
                        }, {
                            ty: "fl",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Graphic - Fill",
                            nm: "Fill 1",
                            c: {
                                a: 0,
                                k: [.9882, .9882, .9882],
                                ix: 4
                            },
                            r: 1,
                            o: {
                                a: 0,
                                k: 100,
                                ix: 5
                            }
                        }, {
                            ty: "tr",
                            a: {
                                a: 0,
                                k: [0, 0],
                                ix: 1
                            },
                            s: {
                                a: 0,
                                k: [100, 100],
                                ix: 3
                            },
                            sk: {
                                a: 0,
                                k: 0,
                                ix: 4
                            },
                            p: {
                                a: 0,
                                k: [0, 0],
                                ix: 2
                            },
                            r: {
                                a: 0,
                                k: 0,
                                ix: 6
                            },
                            sa: {
                                a: 0,
                                k: 0,
                                ix: 5
                            },
                            o: {
                                a: 0,
                                k: 100,
                                ix: 7
                            }
                        }
                    ]
                }
            ],
            ind: 0
        }, {
            ty: 0,
            nm: "Loop Container - 1",
            mn: "",
            sr: 1,
            st: 65,
            op: 110,
            ip: 65,
            hd: !1,
            cl: "",
            ln: "",
            ddd: 0,
            bm: 0,
            tt: 0,
            hasMask: !0,
            td: 0,
            ao: 0,
            ks: {
                a: {
                    a: 0,
                    k: [175, 125, 0],
                    ix: 1
                },
                s: {
                    a: 0,
                    k: [100, 100, 100],
                    ix: 6
                },
                sk: {
                    a: 0,
                    k: 0
                },
                p: {
                    a: 0,
                    k: [175, 125, 0],
                    ix: 2
                },
                sa: {
                    a: 0,
                    k: 0
                },
                o: {
                    a: 0,
                    k: 100,
                    ix: 11
                },
                r: {
                    a: 0,
                    k: 0,
                    ix: 10
                }
            },
            ef: [],
            masksProperties: [{
                    nm: "Mask 1",
                    mn: "",
                    inv: !1,
                    mode: "a",
                    x: {
                        a: 0,
                        k: 0,
                        ix: 4
                    },
                    o: {
                        a: 0,
                        k: 100,
                        ix: 3
                    },
                    pt: {
                        a: 0,
                        k: {
                            c: !0,
                            i: [[0, 0], [0, 0], [0, 0], [0, 0]],
                            o: [[0, 0], [0, 0], [0, 0], [0, 0]],
                            v: [[300.914, 68.5], [54, 68.5], [54, 180], [300.914, 180]]
                        },
                        ix: 1
                    }
                }
            ],
            w: 350,
            h: 250,
            refId: "comp_0",
            ind: 1
        }, {
            ty: 0,
            nm: "Loop Container - 2",
            mn: "",
            sr: 1,
            st: 32,
            op: 65,
            ip: 32,
            hd: !1,
            cl: "",
            ln: "",
            ddd: 0,
            bm: 0,
            tt: 0,
            hasMask: !0,
            td: 0,
            ao: 0,
            ks: {
                a: {
                    a: 0,
                    k: [175, 125, 0],
                    ix: 1
                },
                s: {
                    a: 0,
                    k: [100, 100, 100],
                    ix: 6
                },
                sk: {
                    a: 0,
                    k: 0
                },
                p: {
                    a: 0,
                    k: [175, 125, 0],
                    ix: 2
                },
                sa: {
                    a: 0,
                    k: 0
                },
                o: {
                    a: 0,
                    k: 100,
                    ix: 11
                },
                r: {
                    a: 0,
                    k: 0,
                    ix: 10
                }
            },
            ef: [],
            masksProperties: [{
                    nm: "Mask 1",
                    mn: "",
                    inv: !1,
                    mode: "a",
                    x: {
                        a: 0,
                        k: 0,
                        ix: 4
                    },
                    o: {
                        a: 0,
                        k: 100,
                        ix: 3
                    },
                    pt: {
                        a: 0,
                        k: {
                            c: !0,
                            i: [[0, 0], [0, 0], [0, 0], [0, 0]],
                            o: [[0, 0], [0, 0], [0, 0], [0, 0]],
                            v: [[300.914, 68.5], [54, 68.5], [54, 180], [300.914, 180]]
                        },
                        ix: 1
                    }
                }
            ],
            w: 350,
            h: 250,
            refId: "comp_0",
            ind: 2
        }, {
            ty: 0,
            nm: "Loop Container - 3",
            mn: "",
            sr: 1,
            st: 0,
            op: 33,
            ip: 0,
            hd: !1,
            cl: "",
            ln: "",
            ddd: 0,
            bm: 0,
            tt: 0,
            hasMask: !0,
            td: 0,
            ao: 0,
            ks: {
                a: {
                    a: 0,
                    k: [175, 125, 0],
                    ix: 1
                },
                s: {
                    a: 0,
                    k: [100, 100, 100],
                    ix: 6
                },
                sk: {
                    a: 0,
                    k: 0
                },
                p: {
                    a: 0,
                    k: [175, 125, 0],
                    ix: 2
                },
                sa: {
                    a: 0,
                    k: 0
                },
                o: {
                    a: 0,
                    k: 100,
                    ix: 11
                },
                r: {
                    a: 0,
                    k: 0,
                    ix: 10
                }
            },
            ef: [],
            masksProperties: [{
                    nm: "Mask 1",
                    mn: "",
                    inv: !1,
                    mode: "a",
                    x: {
                        a: 0,
                        k: 0,
                        ix: 4
                    },
                    o: {
                        a: 0,
                        k: 100,
                        ix: 3
                    },
                    pt: {
                        a: 0,
                        k: {
                            c: !0,
                            i: [[0, 0], [0, 0], [0, 0], [0, 0]],
                            o: [[0, 0], [0, 0], [0, 0], [0, 0]],
                            v: [[300.914, 68.5], [54, 68.5], [54, 180], [300.914, 180]]
                        },
                        ix: 1
                    }
                }
            ],
            w: 350,
            h: 250,
            refId: "comp_0",
            ind: 3
        }, {
            ty: 4,
            nm: "Sparkle - 2",
            mn: "",
            sr: 1,
            st: 78,
            op: 110,
            ip: 78,
            hd: !1,
            cl: "",
            ln: "",
            ddd: 0,
            bm: 0,
            tt: 0,
            hasMask: !1,
            td: 0,
            ao: 0,
            ks: {
                a: {
                    a: 0,
                    k: [32.024, -44.33, 0],
                    ix: 1
                },
                s: {
                    a: 1,
                    k: [{
                            o: {
                                x: .81,
                                y: 0
                            },
                            i: {
                                x: .19,
                                y: 1
                            },
                            s: [0, 0, 100],
                            t: 78
                        }, {
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [49, 49, 100],
                            t: 98
                        }
                    ],
                    ix: 6
                },
                sk: {
                    a: 0,
                    k: 0
                },
                p: {
                    a: 0,
                    k: [225.524, 69.17, 0],
                    ix: 2
                },
                sa: {
                    a: 0,
                    k: 0
                },
                o: {
                    a: 1,
                    k: [{
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [100],
                            t: 93
                        }, {
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [0],
                            t: 103
                        }
                    ],
                    ix: 11
                },
                r: {
                    a: 1,
                    k: [{
                            o: {
                                x: .81,
                                y: 0
                            },
                            i: {
                                x: .19,
                                y: 1
                            },
                            s: [0],
                            t: 78
                        }, {
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [-180],
                            t: 103
                        }
                    ],
                    ix: 10
                }
            },
            ef: [],
            shapes: [{
                    ty: "gr",
                    bm: 0,
                    cl: "",
                    ln: "",
                    hd: !1,
                    mn: "ADBE Vector Group",
                    nm: "Group 1",
                    ix: 1,
                    cix: 2,
                    np: 2,
                    it: [{
                            ty: "sh",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Shape - Group",
                            nm: "Path 1",
                            ix: 1,
                            d: 1,
                            ks: {
                                a: 0,
                                k: {
                                    c: !0,
                                    i: [[0, 0], [.337, 1.205], [0, 0], [.127, .038], [0, 0], [ - .357, 1.259], [ - .791, .224], [0, 0], [ - .035, .13], [0, 0], [ - .854, .175], [ - .337, -1.205], [0, 0], [ - .13,  - .031], [0, 0], [ - .029, -1.028], [.999,  - .329], [0, 0], [.041,  - .127], [0, 0], [.869,  - .167]],
                                    o: [[-1.221, .275], [0, 0], [ - .043,  - .125], [0, 0], [-1.259,  - .357], [.224,  - .791], [0, 0], [.128,  - .045], [0, 0], [.225,  - .842], [1.221,  - .275], [0, 0], [.036, .129], [0, 0], [.995, .258], [.039, 1.051], [0, 0], [ - .124, .05], [0, 0], [ - .217, .858], [0, 0]],
                                    v: [[32.61, -30.16], [29.83, -31.82], [27.61, -39.6], [27.34, -39.86], [19.54, -41.99], [17.907, -44.917], [19.54, -46.55], [27.28, -48.77], [27.54, -49.05], [29.67, -56.84], [31.43, -58.5], [34.21, -56.84], [36.43, -49.06], [36.7, -48.8], [44.5, -46.67], [46.23, -44.5], [44.61, -42.17], [36.78, -39.94], [36.52, -39.66], [34.39, -31.87], [32.61, -30.19]]
                                },
                                ix: 2
                            }
                        }, {
                            ty: "fl",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Graphic - Fill",
                            nm: "Fill 1",
                            c: {
                                a: 0,
                                k: [1, .5569, .2275],
                                ix: 4
                            },
                            r: 1,
                            o: {
                                a: 0,
                                k: 100,
                                ix: 5
                            }
                        }, {
                            ty: "tr",
                            a: {
                                a: 0,
                                k: [0, 0],
                                ix: 1
                            },
                            s: {
                                a: 0,
                                k: [100, 100],
                                ix: 3
                            },
                            sk: {
                                a: 0,
                                k: 0,
                                ix: 4
                            },
                            p: {
                                a: 0,
                                k: [0, 0],
                                ix: 2
                            },
                            r: {
                                a: 0,
                                k: 0,
                                ix: 6
                            },
                            sa: {
                                a: 0,
                                k: 0,
                                ix: 5
                            },
                            o: {
                                a: 0,
                                k: 100,
                                ix: 7
                            }
                        }
                    ]
                }
            ],
            ind: 4
        }, {
            ty: 4,
            nm: "Sparkle - 3",
            mn: "",
            sr: 1,
            st: 42,
            op: 74,
            ip: 42,
            hd: !1,
            cl: "",
            ln: "",
            ddd: 0,
            bm: 0,
            tt: 0,
            hasMask: !1,
            td: 0,
            ao: 0,
            ks: {
                a: {
                    a: 0,
                    k: [32.024, -44.33, 0],
                    ix: 1
                },
                s: {
                    a: 1,
                    k: [{
                            o: {
                                x: .81,
                                y: 0
                            },
                            i: {
                                x: .19,
                                y: 1
                            },
                            s: [0, 0, 100],
                            t: 42
                        }, {
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [49, 49, 100],
                            t: 62
                        }
                    ],
                    ix: 6
                },
                sk: {
                    a: 0,
                    k: 0
                },
                p: {
                    a: 0,
                    k: [295.024, 175.67, 0],
                    ix: 2
                },
                sa: {
                    a: 0,
                    k: 0
                },
                o: {
                    a: 1,
                    k: [{
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [100],
                            t: 57
                        }, {
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [0],
                            t: 73
                        }
                    ],
                    ix: 11
                },
                r: {
                    a: 1,
                    k: [{
                            o: {
                                x: .81,
                                y: 0
                            },
                            i: {
                                x: .19,
                                y: 1
                            },
                            s: [0],
                            t: 42
                        }, {
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [-180],
                            t: 73
                        }
                    ],
                    ix: 10
                }
            },
            ef: [],
            shapes: [{
                    ty: "gr",
                    bm: 0,
                    cl: "",
                    ln: "",
                    hd: !1,
                    mn: "ADBE Vector Group",
                    nm: "Group 1",
                    ix: 1,
                    cix: 2,
                    np: 2,
                    it: [{
                            ty: "sh",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Shape - Group",
                            nm: "Path 1",
                            ix: 1,
                            d: 1,
                            ks: {
                                a: 0,
                                k: {
                                    c: !0,
                                    i: [[0, 0], [.337, 1.205], [0, 0], [.127, .038], [0, 0], [ - .357, 1.259], [ - .791, .224], [0, 0], [ - .035, .13], [0, 0], [ - .854, .175], [ - .337, -1.205], [0, 0], [ - .13,  - .031], [0, 0], [ - .029, -1.028], [.999,  - .329], [0, 0], [.041,  - .127], [0, 0], [.869,  - .167]],
                                    o: [[-1.221, .275], [0, 0], [ - .043,  - .125], [0, 0], [-1.259,  - .357], [.224,  - .791], [0, 0], [.128,  - .045], [0, 0], [.225,  - .842], [1.221,  - .275], [0, 0], [.036, .129], [0, 0], [.995, .258], [.039, 1.051], [0, 0], [ - .124, .05], [0, 0], [ - .217, .858], [0, 0]],
                                    v: [[32.61, -30.16], [29.83, -31.82], [27.61, -39.6], [27.34, -39.86], [19.54, -41.99], [17.907, -44.917], [19.54, -46.55], [27.28, -48.77], [27.54, -49.05], [29.67, -56.84], [31.43, -58.5], [34.21, -56.84], [36.43, -49.06], [36.7, -48.8], [44.5, -46.67], [46.23, -44.5], [44.61, -42.17], [36.78, -39.94], [36.52, -39.66], [34.39, -31.87], [32.61, -30.19]]
                                },
                                ix: 2
                            }
                        }, {
                            ty: "fl",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Graphic - Fill",
                            nm: "Fill 1",
                            c: {
                                a: 0,
                                k: [1, .5569, .2275],
                                ix: 4
                            },
                            r: 1,
                            o: {
                                a: 0,
                                k: 100,
                                ix: 5
                            }
                        }, {
                            ty: "tr",
                            a: {
                                a: 0,
                                k: [0, 0],
                                ix: 1
                            },
                            s: {
                                a: 0,
                                k: [100, 100],
                                ix: 3
                            },
                            sk: {
                                a: 0,
                                k: 0,
                                ix: 4
                            },
                            p: {
                                a: 0,
                                k: [0, 0],
                                ix: 2
                            },
                            r: {
                                a: 0,
                                k: 0,
                                ix: 6
                            },
                            sa: {
                                a: 0,
                                k: 0,
                                ix: 5
                            },
                            o: {
                                a: 0,
                                k: 100,
                                ix: 7
                            }
                        }
                    ]
                }
            ],
            ind: 5
        }, {
            ty: 4,
            nm: "Sparkle - 4",
            mn: "",
            sr: 1,
            st: 16,
            op: 48,
            ip: 16,
            hd: !1,
            cl: "",
            ln: "",
            ddd: 0,
            bm: 0,
            tt: 0,
            hasMask: !1,
            td: 0,
            ao: 0,
            ks: {
                a: {
                    a: 0,
                    k: [32.024, -44.33, 0],
                    ix: 1
                },
                s: {
                    a: 1,
                    k: [{
                            o: {
                                x: .81,
                                y: 0
                            },
                            i: {
                                x: .19,
                                y: 1
                            },
                            s: [0, 0, 100],
                            t: 16
                        }, {
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [49, 49, 100],
                            t: 36
                        }
                    ],
                    ix: 6
                },
                sk: {
                    a: 0,
                    k: 0
                },
                p: {
                    a: 0,
                    k: [41.024, 157.17, 0],
                    ix: 2
                },
                sa: {
                    a: 0,
                    k: 0
                },
                o: {
                    a: 1,
                    k: [{
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [100],
                            t: 31
                        }, {
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [0],
                            t: 47
                        }
                    ],
                    ix: 11
                },
                r: {
                    a: 1,
                    k: [{
                            o: {
                                x: .81,
                                y: 0
                            },
                            i: {
                                x: .19,
                                y: 1
                            },
                            s: [0],
                            t: 16
                        }, {
                            o: {
                                x: .167,
                                y: .167
                            },
                            i: {
                                x: .833,
                                y: .833
                            },
                            s: [-180],
                            t: 47
                        }
                    ],
                    ix: 10
                }
            },
            ef: [],
            shapes: [{
                    ty: "gr",
                    bm: 0,
                    cl: "",
                    ln: "",
                    hd: !1,
                    mn: "ADBE Vector Group",
                    nm: "Group 1",
                    ix: 1,
                    cix: 2,
                    np: 2,
                    it: [{
                            ty: "sh",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Shape - Group",
                            nm: "Path 1",
                            ix: 1,
                            d: 1,
                            ks: {
                                a: 0,
                                k: {
                                    c: !0,
                                    i: [[0, 0], [.337, 1.205], [0, 0], [.127, .038], [0, 0], [ - .357, 1.259], [ - .791, .224], [0, 0], [ - .035, .13], [0, 0], [ - .854, .175], [ - .337, -1.205], [0, 0], [ - .13,  - .031], [0, 0], [ - .029, -1.028], [.999,  - .329], [0, 0], [.041,  - .127], [0, 0], [.869,  - .167]],
                                    o: [[-1.221, .275], [0, 0], [ - .043,  - .125], [0, 0], [-1.259,  - .357], [.224,  - .791], [0, 0], [.128,  - .045], [0, 0], [.225,  - .842], [1.221,  - .275], [0, 0], [.036, .129], [0, 0], [.995, .258], [.039, 1.051], [0, 0], [ - .124, .05], [0, 0], [ - .217, .858], [0, 0]],
                                    v: [[32.61, -30.16], [29.83, -31.82], [27.61, -39.6], [27.34, -39.86], [19.54, -41.99], [17.907, -44.917], [19.54, -46.55], [27.28, -48.77], [27.54, -49.05], [29.67, -56.84], [31.43, -58.5], [34.21, -56.84], [36.43, -49.06], [36.7, -48.8], [44.5, -46.67], [46.23, -44.5], [44.61, -42.17], [36.78, -39.94], [36.52, -39.66], [34.39, -31.87], [32.61, -30.19]]
                                },
                                ix: 2
                            }
                        }, {
                            ty: "fl",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Graphic - Fill",
                            nm: "Fill 1",
                            c: {
                                a: 0,
                                k: [1, .5569, .2275],
                                ix: 4
                            },
                            r: 1,
                            o: {
                                a: 0,
                                k: 100,
                                ix: 5
                            }
                        }, {
                            ty: "tr",
                            a: {
                                a: 0,
                                k: [0, 0],
                                ix: 1
                            },
                            s: {
                                a: 0,
                                k: [100, 100],
                                ix: 3
                            },
                            sk: {
                                a: 0,
                                k: 0,
                                ix: 4
                            },
                            p: {
                                a: 0,
                                k: [0, 0],
                                ix: 2
                            },
                            r: {
                                a: 0,
                                k: 0,
                                ix: 6
                            },
                            sa: {
                                a: 0,
                                k: 0,
                                ix: 5
                            },
                            o: {
                                a: 0,
                                k: 100,
                                ix: 7
                            }
                        }
                    ]
                }
            ],
            ind: 6
        }
    ],
    ddd: 0,
    h: 250,
    w: 350,
    meta: {
        a: "",
        k: "",
        d: "",
        g: "LottieFiles AE 0.1.21",
        tc: "#000000"
    },
    v: "5.5.7",
    fr: 24,
    op: 104,
    ip: 0,
    assets: [{
            nm: "",
            mn: "",
            layers: [{
                    ty: 4,
                    nm: "Fields - 1",
                    mn: "",
                    sr: 1,
                    st: 0,
                    op: 222,
                    ip: 0,
                    hd: !1,
                    cl: "",
                    ln: "",
                    ddd: 0,
                    bm: 0,
                    tt: 0,
                    hasMask: !1,
                    td: 0,
                    ao: 0,
                    ks: {
                        a: {
                            a: 0,
                            k: [-12, 18.951, 0],
                            ix: 1
                        },
                        s: {
                            a: 0,
                            k: [194, 194, 100],
                            ix: 6
                        },
                        sk: {
                            a: 0,
                            k: 0
                        },
                        p: {
                            a: 1,
                            k: [{
                                    o: {
                                        x: .77,
                                        y: 0
                                    },
                                    i: {
                                        x: .23,
                                        y: 1
                                    },
                                    s: [176, 47.951, 0],
                                    t: 0
                                }, {
                                    o: {
                                        x: .167,
                                        y: .167
                                    },
                                    i: {
                                        x: .833,
                                        y: .833
                                    },
                                    s: [176, 127.951, 0],
                                    t: 25
                                }
                            ],
                            ix: 2
                        },
                        sa: {
                            a: 0,
                            k: 0
                        },
                        o: {
                            a: 1,
                            k: [{
                                    o: {
                                        x: .167,
                                        y: .167
                                    },
                                    i: {
                                        x: .833,
                                        y: .833
                                    },
                                    s: [0],
                                    t: 2
                                }, {
                                    o: {
                                        x: .167,
                                        y: .167
                                    },
                                    i: {
                                        x: .833,
                                        y: .833
                                    },
                                    s: [100],
                                    t: 8
                                }
                            ],
                            ix: 11
                        },
                        r: {
                            a: 0,
                            k: 0,
                            ix: 10
                        }
                    },
                    ef: [],
                    shapes: [{
                            ty: "gr",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Group",
                            nm: "Group 1",
                            ix: 1,
                            cix: 2,
                            np: 2,
                            it: [{
                                    ty: "sh",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Shape - Group",
                                    nm: "Path 1",
                                    ix: 1,
                                    d: 1,
                                    ks: {
                                        a: 0,
                                        k: {
                                            c: !0,
                                            i: [[0, 0], [-1.711, 0], [0, 0], [0, -1.711], [0, 0], [1.711, 0], [0, 0], [0, 1.711]],
                                            o: [[0, -1.711], [0, 0], [1.711, 0], [0, 0], [0, 1.711], [0, 0], [-1.711, 0], [0, 0]],
                                            v: [[-38.5, 14.098], [-35.402, 11], [11.773, 11], [14.871, 14.098], [14.871, 14.098], [11.773, 17.195], [-35.402, 17.195], [-38.5, 14.098]]
                                        },
                                        ix: 2
                                    }
                                }, {
                                    ty: "fl",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Graphic - Fill",
                                    nm: "Fill 1",
                                    c: {
                                        a: 0,
                                        k: [.9686, .9686, .9686],
                                        ix: 4
                                    },
                                    r: 1,
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 5
                                    }
                                }, {
                                    ty: "tr",
                                    a: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 1
                                    },
                                    s: {
                                        a: 0,
                                        k: [100, 100],
                                        ix: 3
                                    },
                                    sk: {
                                        a: 0,
                                        k: 0,
                                        ix: 4
                                    },
                                    p: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 2
                                    },
                                    r: {
                                        a: 0,
                                        k: 0,
                                        ix: 6
                                    },
                                    sa: {
                                        a: 0,
                                        k: 0,
                                        ix: 5
                                    },
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 7
                                    }
                                }
                            ]
                        }, {
                            ty: "gr",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Group",
                            nm: "Group 2",
                            ix: 2,
                            cix: 2,
                            np: 2,
                            it: [{
                                    ty: "sh",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Shape - Group",
                                    nm: "Path 1",
                                    ix: 1,
                                    d: 1,
                                    ks: {
                                        a: 0,
                                        k: {
                                            c: !0,
                                            i: [[-1.711, 0], [0, 0], [0, -1.711], [0, 0], [1.711, 0], [0, 0], [0, 1.711], [0, 0]],
                                            o: [[0, 0], [1.711, 0], [0, 0], [0, 1.711], [0, 0], [-1.711, 0], [0, 0], [0, -1.711]],
                                            v: [[-35.402, 21.777], [22.421, 21.777], [25.519, 24.875], [25.519, 24.875], [22.421, 27.973], [-35.402, 27.973], [-38.5, 24.875], [-38.5, 24.875]]
                                        },
                                        ix: 2
                                    }
                                }, {
                                    ty: "fl",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Graphic - Fill",
                                    nm: "Fill 1",
                                    c: {
                                        a: 0,
                                        k: [.9686, .9686, .9686],
                                        ix: 4
                                    },
                                    r: 1,
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 5
                                    }
                                }, {
                                    ty: "tr",
                                    a: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 1
                                    },
                                    s: {
                                        a: 0,
                                        k: [100, 100],
                                        ix: 3
                                    },
                                    sk: {
                                        a: 0,
                                        k: 0,
                                        ix: 4
                                    },
                                    p: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 2
                                    },
                                    r: {
                                        a: 0,
                                        k: 0,
                                        ix: 6
                                    },
                                    sa: {
                                        a: 0,
                                        k: 0,
                                        ix: 5
                                    },
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 7
                                    }
                                }
                            ]
                        }, {
                            ty: "gr",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Group",
                            nm: "Group 3",
                            ix: 3,
                            cix: 2,
                            np: 2,
                            it: [{
                                    ty: "sh",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Shape - Group",
                                    nm: "Path 1",
                                    ix: 1,
                                    d: 1,
                                    ks: {
                                        a: 0,
                                        k: {
                                            c: !0,
                                            i: [[-1.105, 0], [0, 0], [0, -1.105], [0, 0], [1.105, 0], [0, 0], [0, 1.105], [0, 0]],
                                            o: [[0, 0], [1.105, 0], [0, 0], [0, 1.105], [0, 0], [-1.105, 0], [0, 0], [0, -1.105]],
                                            v: [[-57.5, 11], [-44.5, 11], [-42.5, 13], [-42.5, 26], [-44.5, 28], [-57.5, 28], [-59.5, 26], [-59.5, 13]]
                                        },
                                        ix: 2
                                    }
                                }, {
                                    ty: "fl",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Graphic - Fill",
                                    nm: "Fill 1",
                                    c: {
                                        a: 0,
                                        k: [.4353, .7961, .4588],
                                        ix: 4
                                    },
                                    r: 1,
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 5
                                    }
                                }, {
                                    ty: "tr",
                                    a: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 1
                                    },
                                    s: {
                                        a: 0,
                                        k: [100, 100],
                                        ix: 3
                                    },
                                    sk: {
                                        a: 0,
                                        k: 0,
                                        ix: 4
                                    },
                                    p: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 2
                                    },
                                    r: {
                                        a: 0,
                                        k: 0,
                                        ix: 6
                                    },
                                    sa: {
                                        a: 0,
                                        k: 0,
                                        ix: 5
                                    },
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 7
                                    }
                                }
                            ]
                        }, {
                            ty: "gr",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Group",
                            nm: "Group 4",
                            ix: 4,
                            cix: 2,
                            np: 2,
                            it: [{
                                    ty: "sh",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Shape - Group",
                                    nm: "Path 1",
                                    ix: 1,
                                    d: 1,
                                    ks: {
                                        a: 0,
                                        k: {
                                            c: !0,
                                            i: [[-2.352, 0], [0, 0], [0, -2.352], [0, 0], [2.352, 0], [0, 0], [0, 2.352], [0, 0]],
                                            o: [[0, 0], [2.352, 0], [0, 0], [0, 2.352], [0, 0], [-2.352, 0], [0, 0], [0, -2.352]],
                                            v: [[-62.241, 3.333], [38.241, 3.333], [42.5, 7.593], [42.5, 30.309], [38.241, 34.568], [-62.241, 34.568], [-66.5, 30.309], [-66.5, 7.593]]
                                        },
                                        ix: 2
                                    }
                                }, {
                                    ty: "fl",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Graphic - Fill",
                                    nm: "Fill 1",
                                    c: {
                                        a: 0,
                                        k: [.9882, .9882, .9882],
                                        ix: 4
                                    },
                                    r: 1,
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 5
                                    }
                                }, {
                                    ty: "tr",
                                    a: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 1
                                    },
                                    s: {
                                        a: 0,
                                        k: [100, 100],
                                        ix: 3
                                    },
                                    sk: {
                                        a: 0,
                                        k: 0,
                                        ix: 4
                                    },
                                    p: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 2
                                    },
                                    r: {
                                        a: 0,
                                        k: 0,
                                        ix: 6
                                    },
                                    sa: {
                                        a: 0,
                                        k: 0,
                                        ix: 5
                                    },
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 7
                                    }
                                }
                            ]
                        }
                    ],
                    ind: 0
                }, {
                    ty: 4,
                    nm: "Fields - 2",
                    mn: "",
                    sr: 1,
                    st: 0,
                    op: 222,
                    ip: 0,
                    hd: !1,
                    cl: "",
                    ln: "",
                    ddd: 0,
                    bm: 0,
                    tt: 0,
                    hasMask: !1,
                    td: 0,
                    ao: 0,
                    ks: {
                        a: {
                            a: 0,
                            k: [-12, 18.951, 0],
                            ix: 1
                        },
                        s: {
                            a: 0,
                            k: [194, 194, 100],
                            ix: 6
                        },
                        sk: {
                            a: 0,
                            k: 0
                        },
                        p: {
                            a: 1,
                            k: [{
                                    o: {
                                        x: .77,
                                        y: 0
                                    },
                                    i: {
                                        x: .23,
                                        y: 1
                                    },
                                    s: [176, 127.951, 0],
                                    t: 0
                                }, {
                                    o: {
                                        x: .167,
                                        y: .167
                                    },
                                    i: {
                                        x: .833,
                                        y: .833
                                    },
                                    s: [176, 197.951, 0],
                                    t: 25
                                }
                            ],
                            ix: 2
                        },
                        sa: {
                            a: 0,
                            k: 0
                        },
                        o: {
                            a: 1,
                            k: [{
                                    o: {
                                        x: .167,
                                        y: .167
                                    },
                                    i: {
                                        x: .833,
                                        y: .833
                                    },
                                    s: [100],
                                    t: 14
                                }, {
                                    o: {
                                        x: .167,
                                        y: .167
                                    },
                                    i: {
                                        x: .833,
                                        y: .833
                                    },
                                    s: [0],
                                    t: 20
                                }
                            ],
                            ix: 11
                        },
                        r: {
                            a: 0,
                            k: 0,
                            ix: 10
                        }
                    },
                    ef: [],
                    shapes: [{
                            ty: "gr",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Group",
                            nm: "Group 1",
                            ix: 1,
                            cix: 2,
                            np: 2,
                            it: [{
                                    ty: "sh",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Shape - Group",
                                    nm: "Path 1",
                                    ix: 1,
                                    d: 1,
                                    ks: {
                                        a: 0,
                                        k: {
                                            c: !0,
                                            i: [[0, 0], [-1.711, 0], [0, 0], [0, -1.711], [0, 0], [1.711, 0], [0, 0], [0, 1.711]],
                                            o: [[0, -1.711], [0, 0], [1.711, 0], [0, 0], [0, 1.711], [0, 0], [-1.711, 0], [0, 0]],
                                            v: [[-38.5, 14.098], [-35.402, 11], [11.773, 11], [14.871, 14.098], [14.871, 14.098], [11.773, 17.195], [-35.402, 17.195], [-38.5, 14.098]]
                                        },
                                        ix: 2
                                    }
                                }, {
                                    ty: "fl",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Graphic - Fill",
                                    nm: "Fill 1",
                                    c: {
                                        a: 0,
                                        k: [.9686, .9686, .9686],
                                        ix: 4
                                    },
                                    r: 1,
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 5
                                    }
                                }, {
                                    ty: "tr",
                                    a: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 1
                                    },
                                    s: {
                                        a: 0,
                                        k: [100, 100],
                                        ix: 3
                                    },
                                    sk: {
                                        a: 0,
                                        k: 0,
                                        ix: 4
                                    },
                                    p: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 2
                                    },
                                    r: {
                                        a: 0,
                                        k: 0,
                                        ix: 6
                                    },
                                    sa: {
                                        a: 0,
                                        k: 0,
                                        ix: 5
                                    },
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 7
                                    }
                                }
                            ]
                        }, {
                            ty: "gr",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Group",
                            nm: "Group 2",
                            ix: 2,
                            cix: 2,
                            np: 2,
                            it: [{
                                    ty: "sh",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Shape - Group",
                                    nm: "Path 1",
                                    ix: 1,
                                    d: 1,
                                    ks: {
                                        a: 0,
                                        k: {
                                            c: !0,
                                            i: [[-1.711, 0], [0, 0], [0, -1.711], [0, 0], [1.711, 0], [0, 0], [0, 1.711], [0, 0]],
                                            o: [[0, 0], [1.711, 0], [0, 0], [0, 1.711], [0, 0], [-1.711, 0], [0, 0], [0, -1.711]],
                                            v: [[-35.402, 21.777], [22.421, 21.777], [25.519, 24.875], [25.519, 24.875], [22.421, 27.973], [-35.402, 27.973], [-38.5, 24.875], [-38.5, 24.875]]
                                        },
                                        ix: 2
                                    }
                                }, {
                                    ty: "fl",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Graphic - Fill",
                                    nm: "Fill 1",
                                    c: {
                                        a: 0,
                                        k: [.9686, .9686, .9686],
                                        ix: 4
                                    },
                                    r: 1,
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 5
                                    }
                                }, {
                                    ty: "tr",
                                    a: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 1
                                    },
                                    s: {
                                        a: 0,
                                        k: [100, 100],
                                        ix: 3
                                    },
                                    sk: {
                                        a: 0,
                                        k: 0,
                                        ix: 4
                                    },
                                    p: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 2
                                    },
                                    r: {
                                        a: 0,
                                        k: 0,
                                        ix: 6
                                    },
                                    sa: {
                                        a: 0,
                                        k: 0,
                                        ix: 5
                                    },
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 7
                                    }
                                }
                            ]
                        }, {
                            ty: "gr",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Group",
                            nm: "Group 3",
                            ix: 3,
                            cix: 2,
                            np: 2,
                            it: [{
                                    ty: "sh",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Shape - Group",
                                    nm: "Path 1",
                                    ix: 1,
                                    d: 1,
                                    ks: {
                                        a: 0,
                                        k: {
                                            c: !0,
                                            i: [[-1.105, 0], [0, 0], [0, -1.105], [0, 0], [1.105, 0], [0, 0], [0, 1.105], [0, 0]],
                                            o: [[0, 0], [1.105, 0], [0, 0], [0, 1.105], [0, 0], [-1.105, 0], [0, 0], [0, -1.105]],
                                            v: [[-57.5, 11], [-44.5, 11], [-42.5, 13], [-42.5, 26], [-44.5, 28], [-57.5, 28], [-59.5, 26], [-59.5, 13]]
                                        },
                                        ix: 2
                                    }
                                }, {
                                    ty: "fl",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Graphic - Fill",
                                    nm: "Fill 1",
                                    c: {
                                        a: 0,
                                        k: [.4353, .7961, .4588],
                                        ix: 4
                                    },
                                    r: 1,
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 5
                                    }
                                }, {
                                    ty: "tr",
                                    a: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 1
                                    },
                                    s: {
                                        a: 0,
                                        k: [100, 100],
                                        ix: 3
                                    },
                                    sk: {
                                        a: 0,
                                        k: 0,
                                        ix: 4
                                    },
                                    p: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 2
                                    },
                                    r: {
                                        a: 0,
                                        k: 0,
                                        ix: 6
                                    },
                                    sa: {
                                        a: 0,
                                        k: 0,
                                        ix: 5
                                    },
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 7
                                    }
                                }
                            ]
                        }, {
                            ty: "gr",
                            bm: 0,
                            cl: "",
                            ln: "",
                            hd: !1,
                            mn: "ADBE Vector Group",
                            nm: "Group 4",
                            ix: 4,
                            cix: 2,
                            np: 2,
                            it: [{
                                    ty: "sh",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Shape - Group",
                                    nm: "Path 1",
                                    ix: 1,
                                    d: 1,
                                    ks: {
                                        a: 0,
                                        k: {
                                            c: !0,
                                            i: [[-2.352, 0], [0, 0], [0, -2.352], [0, 0], [2.352, 0], [0, 0], [0, 2.352], [0, 0]],
                                            o: [[0, 0], [2.352, 0], [0, 0], [0, 2.352], [0, 0], [-2.352, 0], [0, 0], [0, -2.352]],
                                            v: [[-62.241, 3.333], [38.241, 3.333], [42.5, 7.593], [42.5, 30.309], [38.241, 34.568], [-62.241, 34.568], [-66.5, 30.309], [-66.5, 7.593]]
                                        },
                                        ix: 2
                                    }
                                }, {
                                    ty: "fl",
                                    bm: 0,
                                    cl: "",
                                    ln: "",
                                    hd: !1,
                                    mn: "ADBE Vector Graphic - Fill",
                                    nm: "Fill 1",
                                    c: {
                                        a: 0,
                                        k: [.9882, .9882, .9882],
                                        ix: 4
                                    },
                                    r: 1,
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 5
                                    }
                                }, {
                                    ty: "tr",
                                    a: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 1
                                    },
                                    s: {
                                        a: 0,
                                        k: [100, 100],
                                        ix: 3
                                    },
                                    sk: {
                                        a: 0,
                                        k: 0,
                                        ix: 4
                                    },
                                    p: {
                                        a: 0,
                                        k: [0, 0],
                                        ix: 2
                                    },
                                    r: {
                                        a: 0,
                                        k: 0,
                                        ix: 6
                                    },
                                    sa: {
                                        a: 0,
                                        k: 0,
                                        ix: 5
                                    },
                                    o: {
                                        a: 0,
                                        k: 100,
                                        ix: 7
                                    }
                                }
                            ]
                        }
                    ],
                    ind: 1
                }
            ],
            id: "comp_0",
            fr: 30
        }
    ]
};
const Tt = n => Math.round(100 * n) / 100;
class Nt {
    constructor(n) {
        r(this, "instance"),
        r(this, "alphaValue", 0),
        r(this, "redValue", 0),
        r(this, "greenValue", 0),
        r(this, "blueValue", 0),
        r(this, "hueValue", 0),
        r(this, "saturationValue", 0),
        r(this, "brightnessValue", 0),
        r(this, "hslSaturationValue", 0),
        r(this, "lightnessValue", 0),
        r(this, "initAlpha", (() => {
                const n = this.instance.getAlpha();
                this.alphaValue = 100 * Math.min(1, n)
            })),
        r(this, "initLightness", (() => {
                const {
                    s: n,
                    l: t
                } = this.instance.toHsl();
                this.hslSaturationValue = Tt(n),
                this.lightnessValue = Tt(t)
            })),
        r(this, "initRgb", (() => {
                const {
                    r: n,
                    g: t,
                    b: e
                } = this.instance.toRgb();
                this.redValue = Tt(n),
                this.greenValue = Tt(t),
                this.blueValue = Tt(e)
            })),
        r(this, "initHsb", (() => {
                const {
                    h: n,
                    s: t,
                    v: e
                } = this.instance.toHsv();
                this.hueValue = Math.min(360, Math.ceil(n)),
                this.saturationValue = Tt(t),
                this.brightnessValue = Tt(e)
            })),
        r(this, "toHexString", (() => this.instance.toHexString())),
        r(this, "toRgbString", (() => this.instance.toRgbString())),
        this.instance = u(n),
        this.initRgb(),
        this.initHsb(),
        this.initLightness(),
        this.initAlpha()
    }
    toString(n) {
        return this.instance.toString(n)
    }
    get hex() {
        return this.instance.toHex()
    }
    set hex(n) {
        this.instance = u(n),
        this.initHsb(),
        this.initRgb(),
        this.initAlpha(),
        this.initLightness()
    }
    set hue(n) {
        0 === this.saturation && 0 === this.brightness && (this.saturationValue = 1, this.brightnessValue = 1),
        this.instance = u({
            h: Tt(n),
            s: this.saturation,
            v: this.brightness,
            a: this.alphaValue / 100
        }),
        this.initRgb(),
        this.initLightness(),
        this.hueValue = Tt(n)
    }
    get hue() {
        return this.hueValue
    }
    set saturation(n) {
        this.instance = u({
            h: this.hue,
            s: Tt(n),
            v: this.brightness,
            a: this.alphaValue / 100
        }),
        this.initRgb(),
        this.initLightness(),
        this.saturationValue = Tt(n)
    }
    get saturation() {
        return this.saturationValue
    }
    set brightness(n) {
        this.instance = u({
            h: this.hue,
            s: this.saturation,
            v: Tt(n),
            a: this.alphaValue / 100
        }),
        this.initRgb(),
        this.initLightness(),
        this.brightnessValue = Tt(n)
    }
    get brightness() {
        return this.brightnessValue
    }
    set lightness(n) {
        this.instance = u({
            h: this.hue,
            s: this.hslSaturationValue,
            l: Tt(n),
            a: this.alphaValue / 100
        }),
        this.initRgb(),
        this.initHsb(),
        this.lightnessValue = Tt(n)
    }
    get lightness() {
        return this.lightnessValue
    }
    set red(n) {
        const t = this.instance.toRgb();
        this.instance = u(l(w({}, t), {
                    r: Tt(n),
                    a: this.alphaValue / 100
                })),
        this.initHsb(),
        this.initLightness(),
        this.redValue = Tt(n)
    }
    get red() {
        return this.redValue
    }
    set green(n) {
        const t = this.instance.toRgb();
        this.instance = u(l(w({}, t), {
                    g: Tt(n),
                    a: this.alphaValue / 100
                })),
        this.initHsb(),
        this.initLightness(),
        this.greenValue = Tt(n)
    }
    get green() {
        return this.greenValue
    }
    set blue(n) {
        const t = this.instance.toRgb();
        this.instance = u(l(w({}, t), {
                    b: Tt(n),
                    a: this.alphaValue / 100
                })),
        this.initHsb(),
        this.initLightness(),
        this.blueValue = Tt(n)
    }
    get blue() {
        return this.blueValue
    }
    set alpha(n) {
        this.instance.setAlpha(n / 100),
        this.alphaValue = n
    }
    get alpha() {
        return this.alphaValue
    }
    get RGB() {
        return [this.red, this.green, this.blue, this.alpha / 100]
    }
    get HSB() {
        return [this.hue, this.saturation, this.brightness, this.alpha / 100]
    }
    get HSL() {
        return [this.hue, this.hslSaturationValue, this.lightness, this.alpha / 100]
    }
}
function Mt(n, t, e, i) {
    return `rgba(${[n, t, e, i / 100].join(",")})`
}
const Qt = (n, t, e) => t < e ? n < t ? t : n > e ? e : n : n < e ? e : n > t ? t : n;
function Ft(n, t) {
    return Object.keys(n).reduce((function (e, i) {
            return t.includes(i) || (e[i] = n[i]),
            e
        }), {})
}
function Ht(n, t) {
    return Object.keys(n).reduce((function (e, i) {
            return t.includes(i) && (e[i] = m(n, i, "")),
            e
        }), {})
}
function Gt(n) {
    return new URL({
        "../assets/logo.svg": "https://static.topcv.vn/cv-builder/assets/logo.da9b9095.svg",
        "../assets/fonts/Anton-Regular.ttf": "https://static.topcv.vn/cv-builder/assets/Anton-Regular.28beb8f6.ttf",
        "../assets/fonts/ArialTh.ttf": "https://static.topcv.vn/cv-builder/assets/ArialTh.1403f0a7.ttf",
        "../assets/images/basic-cv.png": "https://static.topcv.vn/cv-builder/assets/basic-cv.411e1a1d.png",
        "../assets/images/customize-cv.png": "https://static.topcv.vn/cv-builder/assets/customize-cv.c7883a50.png",
        "../assets/images/demo-block.png": "https://static.topcv.vn/cv-builder/assets/demo-block.9c8adc67.png",
        "../assets/images/feedback.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAMAAABF0y+mAAAAM1BMVEUAAAD///////////////////////////////////////////////////////////////+3leKCAAAAEHRSTlMA4IDAoGDPIBCw75BwQDBQajGe5QAAANdJREFUKM+NkdEWhCAIRFMEJav1/792A9sEfdl56FhXJ5nZnDK0IcoepmYFHlJz8jD8A+s5YIl7C/GB4biX14DQt3dIW9mu/YX4mJ3dNglT2QHi808StkJoVrvA47VFB6NeNryBYCW5cBLhEynfX7joOt7MhHowQGgEwCjQsmLzTLexLaM2K1ziJJmFoujjoWyXxzBbIW2svqEsEOBTRioemvSTg7sG0mONjujQoiNrC1w9LNrEhQpbmM8iA/ey8lkmpu+5z4HzwTNw+lVaZ3hJAtSHzB59Af77FWiGGkRBAAAAAElFTkSuQmCC",
        "../assets/images/no-data-suggest-job.png": "https://static.topcv.vn/cv-builder/assets/no-data-suggest-job.1add5e02.png",
        "../assets/images/non-color.svg": "https://static.topcv.vn/cv-builder/assets/non-color.ad2961b3.svg",
        "../assets/images/play-button.png": "https://static.topcv.vn/cv-builder/assets/play-button.599fd5e7.png",
        "../assets/images/skeleton.png": "https://static.topcv.vn/cv-builder/assets/skeleton.415a600e.png",
        "../assets/lotties/Search.json": Ut,
        "../assets/scss/main.scss": '@import url("https://fonts.googleapis.com/css?family=Bai+Jamjuree:400,500,600,700|Barlow:400,500,600,700|Be+Vietnam+Pro:400,500,600,700|Inter:400,500,600,700|Lexend:400,500,600,700|Maitree:400,500,600,700|Montserrat:400,500,600,700|Montserrat+Alternates:400,500,600,700|Mulish:400,500,600,700|Raleway:400,500,600,700|Roboto:400,500,600,700|Roboto+Condensed:400,500,600,700|Source+Code+Pro:400,500,600,700|Trirong:400,500,600,700|M+PLUS+1p:400,500,600,700|Noto+Sans+JP:400,500,600,700|Noto+Serif+JP:400,500,600,700|Roboto:400,500,600,700|Roboto+Condensed:400,500,600,700|Sawarabi+Gothic:400,500,600,700|Zen+Maru+Gothic&display:400,500,600,700=swap");\n@import url("https://fonts.cdnfonts.com/css/arial");\n@import url("https://fonts.cdnfonts.com/css/times-new-roman");\n@import url("https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap");\n.w-1 {\n  width: 1%;\n}\n.w-2 {\n  width: 2%;\n}\n.w-3 {\n  width: 3%;\n}\n.w-4 {\n  width: 4%;\n}\n.w-5 {\n  width: 5%;\n}\n.w-6 {\n  width: 6%;\n}\n.w-7 {\n  width: 7%;\n}\n.w-8 {\n  width: 8%;\n}\n.w-9 {\n  width: 9%;\n}\n.w-10 {\n  width: 10%;\n}\n.w-11 {\n  width: 11%;\n}\n.w-12 {\n  width: 12%;\n}\n.w-13 {\n  width: 13%;\n}\n.w-14 {\n  width: 14%;\n}\n.w-15 {\n  width: 15%;\n}\n.w-16 {\n  width: 16%;\n}\n.w-17 {\n  width: 17%;\n}\n.w-18 {\n  width: 18%;\n}\n.w-19 {\n  width: 19%;\n}\n.w-20 {\n  width: 20%;\n}\n.w-21 {\n  width: 21%;\n}\n.w-22 {\n  width: 22%;\n}\n.w-23 {\n  width: 23%;\n}\n.w-24 {\n  width: 24%;\n}\n.w-25 {\n  width: 25%;\n}\n.w-26 {\n  width: 26%;\n}\n.w-27 {\n  width: 27%;\n}\n.w-28 {\n  width: 28%;\n}\n.w-29 {\n  width: 29%;\n}\n.w-30 {\n  width: 30%;\n}\n.w-31 {\n  width: 31%;\n}\n.w-32 {\n  width: 32%;\n}\n.w-33 {\n  width: 33%;\n}\n.w-34 {\n  width: 34%;\n}\n.w-35 {\n  width: 35%;\n}\n.w-36 {\n  width: 36%;\n}\n.w-37 {\n  width: 37%;\n}\n.w-38 {\n  width: 38%;\n}\n.w-39 {\n  width: 39%;\n}\n.w-40 {\n  width: 40%;\n}\n.w-41 {\n  width: 41%;\n}\n.w-42 {\n  width: 42%;\n}\n.w-43 {\n  width: 43%;\n}\n.w-44 {\n  width: 44%;\n}\n.w-45 {\n  width: 45%;\n}\n.w-46 {\n  width: 46%;\n}\n.w-47 {\n  width: 47%;\n}\n.w-48 {\n  width: 48%;\n}\n.w-49 {\n  width: 49%;\n}\n.w-50 {\n  width: 50%;\n}\n.w-51 {\n  width: 51%;\n}\n.w-52 {\n  width: 52%;\n}\n.w-53 {\n  width: 53%;\n}\n.w-54 {\n  width: 54%;\n}\n.w-55 {\n  width: 55%;\n}\n.w-56 {\n  width: 56%;\n}\n.w-57 {\n  width: 57%;\n}\n.w-58 {\n  width: 58%;\n}\n.w-59 {\n  width: 59%;\n}\n.w-60 {\n  width: 60%;\n}\n.w-61 {\n  width: 61%;\n}\n.w-62 {\n  width: 62%;\n}\n.w-63 {\n  width: 63%;\n}\n.w-64 {\n  width: 64%;\n}\n.w-65 {\n  width: 65%;\n}\n.w-66 {\n  width: 66%;\n}\n.w-67 {\n  width: 67%;\n}\n.w-68 {\n  width: 68%;\n}\n.w-69 {\n  width: 69%;\n}\n.w-70 {\n  width: 70%;\n}\n.w-71 {\n  width: 71%;\n}\n.w-72 {\n  width: 72%;\n}\n.w-73 {\n  width: 73%;\n}\n.w-74 {\n  width: 74%;\n}\n.w-75 {\n  width: 75%;\n}\n.w-76 {\n  width: 76%;\n}\n.w-77 {\n  width: 77%;\n}\n.w-78 {\n  width: 78%;\n}\n.w-79 {\n  width: 79%;\n}\n.w-80 {\n  width: 80%;\n}\n.w-81 {\n  width: 81%;\n}\n.w-82 {\n  width: 82%;\n}\n.w-83 {\n  width: 83%;\n}\n.w-84 {\n  width: 84%;\n}\n.w-85 {\n  width: 85%;\n}\n.w-86 {\n  width: 86%;\n}\n.w-87 {\n  width: 87%;\n}\n.w-88 {\n  width: 88%;\n}\n.w-89 {\n  width: 89%;\n}\n.w-90 {\n  width: 90%;\n}\n.w-91 {\n  width: 91%;\n}\n.w-92 {\n  width: 92%;\n}\n.w-93 {\n  width: 93%;\n}\n.w-94 {\n  width: 94%;\n}\n.w-95 {\n  width: 95%;\n}\n.w-96 {\n  width: 96%;\n}\n.w-97 {\n  width: 97%;\n}\n.w-98 {\n  width: 98%;\n}\n.w-99 {\n  width: 99%;\n}\n.w-100 {\n  width: 100%;\n}\n.w-1 {\n  width: 1%;\n}\n.w-2 {\n  width: 2%;\n}\n.w-3 {\n  width: 3%;\n}\n.w-4 {\n  width: 4%;\n}\n.w-5 {\n  width: 5%;\n}\n.w-6 {\n  width: 6%;\n}\n.w-7 {\n  width: 7%;\n}\n.w-8 {\n  width: 8%;\n}\n.w-9 {\n  width: 9%;\n}\n.w-10 {\n  width: 10%;\n}\n.w-11 {\n  width: 11%;\n}\n.w-12 {\n  width: 12%;\n}\n.w-13 {\n  width: 13%;\n}\n.w-14 {\n  width: 14%;\n}\n.w-15 {\n  width: 15%;\n}\n.w-16 {\n  width: 16%;\n}\n.w-17 {\n  width: 17%;\n}\n.w-18 {\n  width: 18%;\n}\n.w-19 {\n  width: 19%;\n}\n.w-20 {\n  width: 20%;\n}\n.w-21 {\n  width: 21%;\n}\n.w-22 {\n  width: 22%;\n}\n.w-23 {\n  width: 23%;\n}\n.w-24 {\n  width: 24%;\n}\n.w-25 {\n  width: 25%;\n}\n.w-26 {\n  width: 26%;\n}\n.w-27 {\n  width: 27%;\n}\n.w-28 {\n  width: 28%;\n}\n.w-29 {\n  width: 29%;\n}\n.w-30 {\n  width: 30%;\n}\n.w-31 {\n  width: 31%;\n}\n.w-32 {\n  width: 32%;\n}\n.w-33 {\n  width: 33%;\n}\n.w-34 {\n  width: 34%;\n}\n.w-35 {\n  width: 35%;\n}\n.w-36 {\n  width: 36%;\n}\n.w-37 {\n  width: 37%;\n}\n.w-38 {\n  width: 38%;\n}\n.w-39 {\n  width: 39%;\n}\n.w-40 {\n  width: 40%;\n}\n.w-41 {\n  width: 41%;\n}\n.w-42 {\n  width: 42%;\n}\n.w-43 {\n  width: 43%;\n}\n.w-44 {\n  width: 44%;\n}\n.w-45 {\n  width: 45%;\n}\n.w-46 {\n  width: 46%;\n}\n.w-47 {\n  width: 47%;\n}\n.w-48 {\n  width: 48%;\n}\n.w-49 {\n  width: 49%;\n}\n.w-50 {\n  width: 50%;\n}\n.w-51 {\n  width: 51%;\n}\n.w-52 {\n  width: 52%;\n}\n.w-53 {\n  width: 53%;\n}\n.w-54 {\n  width: 54%;\n}\n.w-55 {\n  width: 55%;\n}\n.w-56 {\n  width: 56%;\n}\n.w-57 {\n  width: 57%;\n}\n.w-58 {\n  width: 58%;\n}\n.w-59 {\n  width: 59%;\n}\n.w-60 {\n  width: 60%;\n}\n.w-61 {\n  width: 61%;\n}\n.w-62 {\n  width: 62%;\n}\n.w-63 {\n  width: 63%;\n}\n.w-64 {\n  width: 64%;\n}\n.w-65 {\n  width: 65%;\n}\n.w-66 {\n  width: 66%;\n}\n.w-67 {\n  width: 67%;\n}\n.w-68 {\n  width: 68%;\n}\n.w-69 {\n  width: 69%;\n}\n.w-70 {\n  width: 70%;\n}\n.w-71 {\n  width: 71%;\n}\n.w-72 {\n  width: 72%;\n}\n.w-73 {\n  width: 73%;\n}\n.w-74 {\n  width: 74%;\n}\n.w-75 {\n  width: 75%;\n}\n.w-76 {\n  width: 76%;\n}\n.w-77 {\n  width: 77%;\n}\n.w-78 {\n  width: 78%;\n}\n.w-79 {\n  width: 79%;\n}\n.w-80 {\n  width: 80%;\n}\n.w-81 {\n  width: 81%;\n}\n.w-82 {\n  width: 82%;\n}\n.w-83 {\n  width: 83%;\n}\n.w-84 {\n  width: 84%;\n}\n.w-85 {\n  width: 85%;\n}\n.w-86 {\n  width: 86%;\n}\n.w-87 {\n  width: 87%;\n}\n.w-88 {\n  width: 88%;\n}\n.w-89 {\n  width: 89%;\n}\n.w-90 {\n  width: 90%;\n}\n.w-91 {\n  width: 91%;\n}\n.w-92 {\n  width: 92%;\n}\n.w-93 {\n  width: 93%;\n}\n.w-94 {\n  width: 94%;\n}\n.w-95 {\n  width: 95%;\n}\n.w-96 {\n  width: 96%;\n}\n.w-97 {\n  width: 97%;\n}\n.w-98 {\n  width: 98%;\n}\n.w-99 {\n  width: 99%;\n}\n.w-100 {\n  width: 100%;\n}\n.el-notification.right {\n  z-index: 9999 !important;\n}\n.el-dialog__body {\n  color: unset;\n}\n.validate-alert {\n  align-items: unset;\n}\n.validate-alert .el-message-icon--error {\n  display: none;\n}\n.validate-alert .el-message__closeBtn {\n  position: relative !important;\n  margin-left: 32px;\n  font-size: 20px !important;\n  top: 0 !important;\n  right: 0 !important;\n  transform: unset !important;\n}\n.validate-alert .validate__title {\n  font-weight: bold;\n  color: #DE4637;\n}\n.validate-alert .validate__message {\n  font-size: 14px;\n  margin-top: 12px !important;\n}\n.el-popper.is-error {\n  padding: 6px 12px;\n  background: rgba(222, 70, 55, 0.8);\n  color: white;\n}\n.el-popper.is-error .el-popper__arrow::before {\n  background: rgba(222, 70, 55, 0);\n}\n.el-popper.is-primary {\n  padding: 6px 12px;\n  background: #00B14F;\n  color: white;\n  width: 300px;\n}\n.el-popper.is-primary .el-popper__arrow::before {\n  background: #00B14F;\n}\n/**\n * Set up a decent box model on the root element\n */\nhtml {\n  box-sizing: border-box;\n}\n/**\n * Make all elements from the DOM inherit from the parent box-sizing\n * Since `*` has a specificity of 0, it does not override the `html` value\n * making all elements inheriting from the root box-sizing value\n * See: https://css-tricks.com/inheriting-box-sizing-probably-slightly-better-best-practice/\n */\n*,\n*::before,\n*::after {\n  box-sizing: inherit;\n}\nhtml {\n  font-size: 13px;\n}\nbody {\n  background: #f1f2f6;\n}\nimg {\n  max-width: 100%;\n  height: auto;\n}\n.cv-section-main {\n  font-family: var(--font-family-primary);\n  line-height: var(--line-height-primary);\n}\nlabel {\n  margin-bottom: inherit;\n}\na {\n  color: #606266;\n}\na:hover {\n  text-decoration: none;\n  color: #606266;\n}\n.text-highlight {\n  color: #00b14f;\n}\n.text-light {\n  color: rgb(255, 255, 255);\n}\n/* width */\n::-webkit-scrollbar {\n  width: 7px;\n}\n/* Handle */\n::-webkit-scrollbar-thumb {\n  background: #cccccc;\n  border-radius: 10px;\n}\n.el-overlay {\n  background-color: rgba(0, 0, 0, 0.1);\n}\n.v-enter-active,\n.v-leave-active {\n  transition: opacity 0.3s ease;\n}\n.v-enter-from,\n.v-leave-to {\n  opacity: 0;\n}\na {\n  text-decoration: none;\n  font-family: "Inter", sans-serif !important;\n}\n[v-cloak] {\n  display: none;\n}\nbutton {\n  font-family: "Inter", sans-serif !important;\n}\n#cvb-section-content a {\n  font-family: inherit !important;\n}\n.mt-1 {\n  margin-top: 1px;\n}\n.mt-2 {\n  margin-top: 2px;\n}\n.mt-3 {\n  margin-top: 3px;\n}\n.mt-4 {\n  margin-top: 4px;\n}\n.mt-5 {\n  margin-top: 5px;\n}\n.mt-6 {\n  margin-top: 6px;\n}\n.mt-7 {\n  margin-top: 7px;\n}\n.mt-8 {\n  margin-top: 8px;\n}\n.mt-9 {\n  margin-top: 9px;\n}\n.mt-10 {\n  margin-top: 10px;\n}\n.mt-11 {\n  margin-top: 11px;\n}\n.mt-12 {\n  margin-top: 12px;\n}\n.mt-13 {\n  margin-top: 13px;\n}\n.mt-14 {\n  margin-top: 14px;\n}\n.mt-15 {\n  margin-top: 15px;\n}\n.mt-16 {\n  margin-top: 16px;\n}\n.mt-17 {\n  margin-top: 17px;\n}\n.mt-18 {\n  margin-top: 18px;\n}\n.mt-19 {\n  margin-top: 19px;\n}\n.mt-20 {\n  margin-top: 20px;\n}\n.mr-1 {\n  margin-right: 1px;\n}\n.mr-2 {\n  margin-right: 2px;\n}\n.mr-3 {\n  margin-right: 3px;\n}\n.mr-4 {\n  margin-right: 4px;\n}\n.mr-5 {\n  margin-right: 5px;\n}\n.mr-6 {\n  margin-right: 6px;\n}\n.mr-7 {\n  margin-right: 7px;\n}\n.mr-8 {\n  margin-right: 8px;\n}\n.mr-9 {\n  margin-right: 9px;\n}\n.mr-10 {\n  margin-right: 10px;\n}\n.mr-11 {\n  margin-right: 11px;\n}\n.mr-12 {\n  margin-right: 12px;\n}\n.mr-13 {\n  margin-right: 13px;\n}\n.mr-14 {\n  margin-right: 14px;\n}\n.mr-15 {\n  margin-right: 15px;\n}\n.mr-16 {\n  margin-right: 16px;\n}\n.mr-17 {\n  margin-right: 17px;\n}\n.mr-18 {\n  margin-right: 18px;\n}\n.mr-19 {\n  margin-right: 19px;\n}\n.mr-20 {\n  margin-right: 20px;\n}\n.mb-1 {\n  margin-bottom: 1px;\n}\n.mb-2 {\n  margin-bottom: 2px;\n}\n.mb-3 {\n  margin-bottom: 3px;\n}\n.mb-4 {\n  margin-bottom: 4px;\n}\n.mb-5 {\n  margin-bottom: 5px;\n}\n.mb-6 {\n  margin-bottom: 6px;\n}\n.mb-7 {\n  margin-bottom: 7px;\n}\n.mb-8 {\n  margin-bottom: 8px;\n}\n.mb-9 {\n  margin-bottom: 9px;\n}\n.mb-10 {\n  margin-bottom: 10px;\n}\n.mb-11 {\n  margin-bottom: 11px;\n}\n.mb-12 {\n  margin-bottom: 12px;\n}\n.mb-13 {\n  margin-bottom: 13px;\n}\n.mb-14 {\n  margin-bottom: 14px;\n}\n.mb-15 {\n  margin-bottom: 15px;\n}\n.mb-16 {\n  margin-bottom: 16px;\n}\n.mb-17 {\n  margin-bottom: 17px;\n}\n.mb-18 {\n  margin-bottom: 18px;\n}\n.mb-19 {\n  margin-bottom: 19px;\n}\n.mb-20 {\n  margin-bottom: 20px;\n}\n.ml-1 {\n  margin-left: 1px;\n}\n.ml-2 {\n  margin-left: 2px;\n}\n.ml-3 {\n  margin-left: 3px;\n}\n.ml-4 {\n  margin-left: 4px;\n}\n.ml-5 {\n  margin-left: 5px;\n}\n.ml-6 {\n  margin-left: 6px;\n}\n.ml-7 {\n  margin-left: 7px;\n}\n.ml-8 {\n  margin-left: 8px;\n}\n.ml-9 {\n  margin-left: 9px;\n}\n.ml-10 {\n  margin-left: 10px;\n}\n.ml-11 {\n  margin-left: 11px;\n}\n.ml-12 {\n  margin-left: 12px;\n}\n.ml-13 {\n  margin-left: 13px;\n}\n.ml-14 {\n  margin-left: 14px;\n}\n.ml-15 {\n  margin-left: 15px;\n}\n.ml-16 {\n  margin-left: 16px;\n}\n.ml-17 {\n  margin-left: 17px;\n}\n.ml-18 {\n  margin-left: 18px;\n}\n.ml-19 {\n  margin-left: 19px;\n}\n.ml-20 {\n  margin-left: 20px;\n}\n.pt-1 {\n  padding-top: 1px;\n}\n.pt-2 {\n  padding-top: 2px;\n}\n.pt-3 {\n  padding-top: 3px;\n}\n.pt-4 {\n  padding-top: 4px;\n}\n.pt-5 {\n  padding-top: 5px;\n}\n.pt-6 {\n  padding-top: 6px;\n}\n.pt-7 {\n  padding-top: 7px;\n}\n.pt-8 {\n  padding-top: 8px;\n}\n.pt-9 {\n  padding-top: 9px;\n}\n.pt-10 {\n  padding-top: 10px;\n}\n.pt-11 {\n  padding-top: 11px;\n}\n.pt-12 {\n  padding-top: 12px;\n}\n.pt-13 {\n  padding-top: 13px;\n}\n.pt-14 {\n  padding-top: 14px;\n}\n.pt-15 {\n  padding-top: 15px;\n}\n.pt-16 {\n  padding-top: 16px;\n}\n.pt-17 {\n  padding-top: 17px;\n}\n.pt-18 {\n  padding-top: 18px;\n}\n.pt-19 {\n  padding-top: 19px;\n}\n.pt-20 {\n  padding-top: 20px;\n}\n.pr-1 {\n  padding-right: 1px;\n}\n.pr-2 {\n  padding-right: 2px;\n}\n.pr-3 {\n  padding-right: 3px;\n}\n.pr-4 {\n  padding-right: 4px;\n}\n.pr-5 {\n  padding-right: 5px;\n}\n.pr-6 {\n  padding-right: 6px;\n}\n.pr-7 {\n  padding-right: 7px;\n}\n.pr-8 {\n  padding-right: 8px;\n}\n.pr-9 {\n  padding-right: 9px;\n}\n.pr-10 {\n  padding-right: 10px;\n}\n.pr-11 {\n  padding-right: 11px;\n}\n.pr-12 {\n  padding-right: 12px;\n}\n.pr-13 {\n  padding-right: 13px;\n}\n.pr-14 {\n  padding-right: 14px;\n}\n.pr-15 {\n  padding-right: 15px;\n}\n.pr-16 {\n  padding-right: 16px;\n}\n.pr-17 {\n  padding-right: 17px;\n}\n.pr-18 {\n  padding-right: 18px;\n}\n.pr-19 {\n  padding-right: 19px;\n}\n.pr-20 {\n  padding-right: 20px;\n}\n.pb-1 {\n  padding-bottom: 1px;\n}\n.pb-2 {\n  padding-bottom: 2px;\n}\n.pb-3 {\n  padding-bottom: 3px;\n}\n.pb-4 {\n  padding-bottom: 4px;\n}\n.pb-5 {\n  padding-bottom: 5px;\n}\n.pb-6 {\n  padding-bottom: 6px;\n}\n.pb-7 {\n  padding-bottom: 7px;\n}\n.pb-8 {\n  padding-bottom: 8px;\n}\n.pb-9 {\n  padding-bottom: 9px;\n}\n.pb-10 {\n  padding-bottom: 10px;\n}\n.pb-11 {\n  padding-bottom: 11px;\n}\n.pb-12 {\n  padding-bottom: 12px;\n}\n.pb-13 {\n  padding-bottom: 13px;\n}\n.pb-14 {\n  padding-bottom: 14px;\n}\n.pb-15 {\n  padding-bottom: 15px;\n}\n.pb-16 {\n  padding-bottom: 16px;\n}\n.pb-17 {\n  padding-bottom: 17px;\n}\n.pb-18 {\n  padding-bottom: 18px;\n}\n.pb-19 {\n  padding-bottom: 19px;\n}\n.pb-20 {\n  padding-bottom: 20px;\n}\n.pl-1 {\n  padding-left: 1px;\n}\n.pl-2 {\n  padding-left: 2px;\n}\n.pl-3 {\n  padding-left: 3px;\n}\n.pl-4 {\n  padding-left: 4px;\n}\n.pl-5 {\n  padding-left: 5px;\n}\n.pl-6 {\n  padding-left: 6px;\n}\n.pl-7 {\n  padding-left: 7px;\n}\n.pl-8 {\n  padding-left: 8px;\n}\n.pl-9 {\n  padding-left: 9px;\n}\n.pl-10 {\n  padding-left: 10px;\n}\n.pl-11 {\n  padding-left: 11px;\n}\n.pl-12 {\n  padding-left: 12px;\n}\n.pl-13 {\n  padding-left: 13px;\n}\n.pl-14 {\n  padding-left: 14px;\n}\n.pl-15 {\n  padding-left: 15px;\n}\n.pl-16 {\n  padding-left: 16px;\n}\n.pl-17 {\n  padding-left: 17px;\n}\n.pl-18 {\n  padding-left: 18px;\n}\n.pl-19 {\n  padding-left: 19px;\n}\n.pl-20 {\n  padding-left: 20px;\n}\n/**\n * Clear inner floats\n */\n.clearfix::after {\n  clear: both;\n  content: "";\n  display: table;\n}\n/**\n   * Main content containers\n   * 1. Make the container full-width with a maximum width\n   * 2. Center it in the viewport\n   * 3. Leave some space on the edges, especially valuable on small screens\n   */\n.container {\n  max-width: 1180px;\n  /* 1 */\n  margin-left: auto;\n  /* 2 */\n  margin-right: auto;\n  /* 2 */\n  padding-left: 20px;\n  /* 3 */\n  padding-right: 20px;\n  /* 3 */\n  width: 100%;\n  /* 1 */\n}\n/**\n   * Hide text while making it readable for screen readers\n   * 1. Needed in WebKit-based browsers because of an implementation bug;\n   *    See: https://code.google.com/p/chromium/issues/detail?id=457146\n   */\n.hide-text {\n  overflow: hidden;\n  padding: 0;\n  /* 1 */\n  text-indent: 101%;\n  white-space: nowrap;\n}\n/**\n   * Hide element while making it readable for screen readers\n   * Shamelessly borrowed from HTML5Boilerplate:\n   * https://github.com/h5bp/html5-boilerplate/blob/master/src/css/main.css#L119-L133\n   */\n.visually-hidden {\n  border: 0;\n  clip: rect(0 0 0 0);\n  height: 1px;\n  margin: -1px;\n  overflow: hidden;\n  padding: 0;\n  position: absolute;\n  width: 1px;\n}\n/**\n * Outline validate\n */\n.outline-validate {\n  outline: 1px dashed red !important;\n  position: relative;\n}\n.outline-validate:hover:after {\n  font-family: helvetica neue, Helvetica, Arial, sans-serif;\n  content: attr(data-message-error);\n  position: absolute;\n  z-index: 1;\n  top: 108%;\n  margin-bottom: 3px;\n  right: 0;\n  width: 180px;\n  background-color: rgba(251, 88, 88, 0.86);\n  font-size: 11px;\n  line-height: 1.6em;\n  font-weight: 400;\n  text-decoration: none;\n  text-transform: none;\n  text-align: center;\n  color: rgb(255, 255, 255);\n  padding: 5px;\n  border-radius: 5px;\n}\n/**\n * GlobalSetting\n */\n.cvo-border-color {\n  border-color: var(--text-primary-color);\n}\n.cvo-text-color {\n  color: var(--text-primary-color);\n}\n.cvo-text-color-100 {\n  color: var(--text-primary-color-100);\n}\n.cvo-text-color-50 {\n  color: var(--text-primary-color-50);\n}\n.cvo-text-color-30 {\n  color: var(--text-primary-color-30);\n}\n.cvo-bg-color {\n  background-color: var(--text-primary-color);\n}\n.cvo-bg-color-100 {\n  background-color: var(--text-primary-color-100);\n}\n.cvo-bg-color-50 {\n  background-color: var(--text-primary-color-50);\n}\n.cvo-bg-color-30 {\n  background-color: var(--text-primary-color-30);\n}\n.cvo-bg-color-15 {\n  background-color: var(--text-primary-color-15);\n}\n.cvo-border-color {\n  border-color: var(--text-primary-color);\n}\n.cvo-border-color-100 {\n  border-color: var(--text-primary-color-100);\n}\n.cvo-border-color-50 {\n  border-color: var(--text-primary-color-50);\n}\n.cvo-border-color-30 {\n  border-color: var(--text-primary-color-30);\n}\n.cvo-outline-color {\n  outline-color: var(--text-primary-color);\n}\n.cvo-text-darken-color {\n  background-color: var(--darken-primary-color);\n}\n.cvo-text-lighten-color {\n  background-color: var(--lighten-primary-color);\n}\n.cvo-bg-darken-color {\n  background-color: var(--darken-primary-color);\n}\n.cvo-bg-lighten-color {\n  background-color: var(--lighten-primary-color);\n}\n:root {\n  --background-image-global: none;\n  --opacity-overlay: 0;\n  --transaction: all 0.3s;\n}\n.cursor-pointer {\n  cursor: pointer;\n}\n/**\n * Flex\n */\n.flex-column {\n  flex-direction: column !important;\n  display: flex;\n}\n.flex-row {\n  flex-direction: row !important;\n  display: flex;\n}\n.flex-wrap {\n  flex-wrap: wrap;\n}\n.flex-nowrap {\n  flex-wrap: nowrap;\n}\n.flex {\n  display: flex;\n}\n.items-center {\n  align-items: center;\n}\n.text-center {\n  text-align: center;\n}\n.border-l {\n  border-left: 1px solid #eeeeee;\n}\n.border-r {\n  border-right: 1px solid #eeeeee;\n}\n.w-160px {\n  width: 160px;\n}\n.outline-error {\n  outline: 1px solid red !important;\n}\n.spinner {\n  -webkit-animation: spin 1s linear infinite;\n  /* Safari */\n  animation: spin 1s linear infinite;\n}\n@-webkit-keyframes spin {\n  0% {\n    -webkit-transform: rotate(0deg);\n  }\n  100% {\n    -webkit-transform: rotate(360deg);\n  }\n}\n@keyframes spin {\n  0% {\n    transform: rotate(0deg);\n  }\n  100% {\n    transform: rotate(360deg);\n  }\n}\n.justify-content-center {\n  justify-content: center;\n}\n.justify-content-space-between {\n  justify-content: space-between;\n}\n.align-items-center {\n  align-items: center;\n}\n.min-height-80 {\n  min-height: 80px;\n}\n.min-height-80 .block-button {\n  display: none;\n}\n.min-height-80.hover .block-button {\n  display: block;\n}\n.slide-fade-enter-active {\n  transition: all 0.3s ease-out;\n}\n.slide-fade-leave-active {\n  transition: all 0.8s cubic-bezier(1, 0.5, 0.8, 1);\n}\n.slide-fade-enter-from,\n.slide-fade-leave-to {\n  transform: translateY(-100px);\n}\n.d-flex {\n  display: flex;\n}\n.d-block {\n  display: block;\n}\n.d-inline-block {\n  display: inline-block;\n}\n.d-inline-flex {\n  display: inline-flex;\n}\n.text-center {\n  text-align: center;\n}\n.padding-0-16 {\n  padding: 0 16px;\n}\n.padding-10 {\n  padding: 10px;\n}\n.padding-0-8 {\n  padding: 0 8px;\n}\n.padding-0-10-10 {\n  padding: 0 10px 10px;\n}\n.padding-10-10-0 {\n  padding: 10px 10px 0px;\n}\n.padding-0-20 {\n  padding: 0 20px;\n}\n.margin-top-10 {\n  margin-top: 10px;\n}\n.gap-10 {\n  gap: 10px;\n}\n.gap-5 {\n  gap: 5px;\n}\n/**\n * Basic typography style for copy text\n */\nbody {\n  color: rgb(34, 34, 34);\n  font: normal 125%/1.4 "Inter", sans-serif;\n}\n.btn {\n  transition: all 0.3s;\n}\n.btn__topcv {\n  color: #e5f7ed;\n  background-color: #00b14f;\n}\n.btn__topcv--outline {\n  color: #00b14f;\n  background-color: #e5f7ed;\n}\n.btn__topcv--outline:hover, .btn__topcv--outline:focus {\n  color: white;\n  border-color: #00b14f;\n  background-color: #00b14f;\n  outline: 0;\n}\n.btn__topcv--disable {\n  background-color: #eeeeee;\n  color: #999999;\n  border: none;\n}\n.btn__topcv--disable:hover, .btn__topcv--disable:focus {\n  background-color: #dddddd;\n  color: #999999;\n}\n.btn__topcv:hover, .btn__topcv:focus {\n  color: #e5f7ed;\n  background-color: #3ba769;\n  outline: 0;\n}\n.btn__close {\n  height: 40px;\n  width: 40px;\n  background: rgba(63, 63, 63, 0.6);\n  border: none;\n  cursor: pointer;\n  border-radius: 50%;\n}\n.btn__close i {\n  color: #cfcfcf;\n  font-size: 23px;\n}\n.btn__close:hover {\n  background: rgba(63, 63, 63, 0.4);\n}\n.btn__close-rectangle {\n  width: 120px;\n  height: 40px;\n  padding: 9px 12px;\n  gap: 8px;\n  border-radius: 4px;\n  background: #F2F4F5;\n  color: #263A4D;\n  font-family: "Inter", sans-serif;\n  font-size: 14px;\n  font-weight: 600;\n  line-height: 22px;\n  letter-spacing: 0.0125em;\n  text-align: left;\n  border: unset;\n}\n.btn__close-rectangle:hover {\n  background: #F2F4F5;\n  outline: 0;\n  color: #263A4D !important;\n}\n.btn__save {\n  width: 120px;\n  height: 40px;\n  padding: 9px 12px;\n  gap: 8px;\n  border-radius: 4px;\n  background: #00b14f;\n  color: #fff;\n  font-family: "Inter", sans-serif;\n  font-size: 14px;\n  font-weight: 600;\n  line-height: 22px;\n  letter-spacing: 0.0125em;\n  text-align: left;\n  border: unset;\n}\n.btn__save:hover, .btn__save:focus {\n  color: white;\n  border-color: #00b14f;\n  background-color: #00b14f;\n  outline: 0;\n}\n.btn-cv {\n  padding: 9px 19px;\n  border-radius: 5px;\n  justify-content: center;\n  align-items: center;\n  white-space: nowrap;\n  border: none;\n  cursor: pointer;\n  color: rgb(255, 255, 255);\n  transition: all 0.3s;\n}\n.btn-cv__text {\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n}\n.btn-cv--small {\n  padding: 7px 15px;\n}\n.btn-cv--small__text {\n  font-size: 13px;\n}\n.btn-cv--success {\n  background-color: #00b14f;\n  color: rgb(255, 255, 255);\n}\n.btn-cv--success.is-plain {\n  background-color: #e5f7ed;\n  color: #00b14f;\n}\n.btn-cv--success:hover, .btn-cv--success:focus {\n  color: rgb(255, 255, 255);\n  background-color: #3ba769;\n  outline: 0;\n}\n.btn-cv--fix-size {\n  height: 40px;\n  min-width: 142px;\n}\n.btn-cv--disable {\n  background-color: #eeeeee;\n  color: #999999;\n}\n.btn-cv--disable:hover, .btn-cv--disable:focus {\n  background-color: #dddddd;\n  color: #999999;\n}\n.btn-cv--disable.is-plain {\n  background-color: #e5f7ed;\n  color: #00b14f;\n}\n.btn-cv + .btn-cv {\n  margin-left: 12px;\n}\n.grid-3fr4fr5fr,\n.grid-5fr2fr5fr,\n.grid-2fr5fr5fr,\n.grid-2fr10fr,\n.grid-2fr10fr,\n.grid-3fr3fr6fr,\n.grid-3fr5fr2fr2fr,\n.grid-3fr6fr2fr1fr,\n.grid-3fr6fr3fr,\n.grid-3fr9fr,\n.grid-4fr8fr,\n.grid-6fr6fr,\n.grid-6fr3fr3fr,\n.grid-8fr4fr,\n.grid-9fr3fr,\n.grid-10fr2fr,\n.grid-form,\n.grid-repeat21fr,\n.grid-repeat31fr,\n.grid-repeat41fr,\n.grid-repeat51fr,\n.grid-repeat61fr,\n.grid-4fr3fr5fr,\n.grid-5fr4fr3fr,\n.grid-3fr5fr4fr,\n.grid-4fr5fr3fr,\n.grid-15fr105fr {\n  display: grid;\n}\n.grid-4fr3fr5fr {\n  grid-template-columns: 4fr 3fr 5fr;\n}\n.grid-5fr4fr3fr {\n  grid-template-columns: 5fr 4fr 3fr;\n}\n.grid-3fr5fr4fr {\n  grid-template-columns: 3fr 5fr 4fr;\n}\n.grid-4fr5fr3fr {\n  grid-template-columns: 4fr 5fr 3fr;\n}\n.grid-3fr4fr5fr {\n  grid-template-columns: 3fr 4fr 5fr;\n}\n.grid-2fr5fr5fr {\n  grid-template-columns: 2fr 5fr 5fr;\n}\n.grid-5fr2fr5fr {\n  grid-template-columns: 5fr 2fr 5fr;\n}\n.grid-repeat21fr {\n  grid-template-columns: repeat(2, 1fr);\n}\n.grid-repeat31fr {\n  grid-template-columns: repeat(3, 1fr);\n}\n.grid-repeat41fr {\n  grid-template-columns: repeat(4, 1fr);\n}\n.grid-repeat51fr {\n  grid-template-columns: repeat(5, 1fr);\n}\n.grid-repeat61fr {\n  grid-template-columns: repeat(6, 1fr);\n}\n.grid-9fr3fr {\n  grid-template-columns: 9fr 3fr;\n}\n.grid-3fr9fr {\n  grid-template-columns: 3fr 9fr;\n}\n.grid-4fr8fr {\n  grid-template-columns: 4fr 8fr;\n}\n.grid-6fr6fr {\n  grid-template-columns: 6fr 6fr;\n}\n.grid-5fr7fr {\n  grid-template-columns: 5fr 7fr;\n}\n.grid-7fr5fr {\n  grid-template-columns: 7fr 5fr;\n}\n.grid-8fr4fr {\n  grid-template-columns: 8fr 4fr;\n}\n.grid-6fr3fr3fr {\n  grid-template-columns: 6fr 3fr 3fr;\n}\n.grid-3fr3fr6fr {\n  grid-template-columns: 3fr 3fr 6fr;\n}\n.grid-3fr6fr3fr {\n  grid-template-columns: 3fr 6fr 3fr;\n}\n.grid-3fr5fr2fr2fr {\n  grid-template-columns: 3fr 5fr 2fr 2fr;\n}\n.grid-2fr10fr {\n  grid-template-columns: 2fr 10fr;\n}\n.grid-10fr2fr {\n  grid-template-columns: 10fr 2fr;\n}\n.grid-3fr6fr2fr1fr {\n  grid-template-columns: 3fr 6fr 2fr 1fr;\n}\n.grid-15fr105fr {\n  grid-template-columns: 1.5fr 10.5fr;\n}\n.cv-grid {\n  display: grid;\n  margin-left: 0;\n  margin-right: 0;\n}\n.cv-grid > div {\n  min-width: 0;\n}\n.edit-image {\n  display: flex;\n  width: 100%;\n  padding: 16px;\n  justify-content: center;\n}\n.edit-image__btn {\n  background: transparent;\n  cursor: pointer;\n  border: none;\n  font-size: 15px;\n  line-height: 20px;\n  color: #212f3f;\n  padding: 0px 12px;\n}\n.edit-image__btn[disabled] {\n  cursor: not-allowed;\n}\n.edit-image__btn i {\n  margin-right: 18px;\n}\n.edit-image__btn:last-child {\n  border: none;\n}\n.edit-image__btn:hover {\n  background-color: #f4f4f4;\n  border-radius: 4px;\n}\n.edit-image__separate {\n  height: 100%;\n  width: 1px;\n  background-color: #cccccc;\n  margin-left: 12px;\n  margin-right: 12px;\n}\n.bg-primary {\n  background: #00b14f;\n}\n.bg-primary:hover {\n  background-color: #15964b;\n}\n.bg-secondary {\n  background: #eeeeee;\n}\n.bg-secondary:hover {\n  background-color: #dddddd;\n  color: #888888 !important;\n}\n.text-gray-400 {\n  color: #999999 !important;\n}\n.dialog-footer {\n  text-align: center;\n  display: block;\n  padding-top: 18px;\n}\n.modal-edit-image__action {\n  text-align: center;\n  display: flex;\n  flex-direction: column;\n  gap: 9px;\n  margin: 0;\n  align-items: center;\n  margin-top: 5px;\n}\n.modal-edit-image__btn {\n  padding: 10px 20px;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 22px;\n  border: none;\n  color: #fff;\n  border-radius: 5px;\n  cursor: pointer;\n}\n.modal-edit-image__btn[disabled] {\n  cursor: not-allowed;\n}\n.modal-edit-image__btn-delete {\n  background: #fceceb !important;\n  color: #de4637 !important;\n}\n.modal-edit-image__btn-delete:hover {\n  background-color: #de4637 !important;\n  color: #ffffff !important;\n}\n.modal-edit-image__btn-sm {\n  border: none;\n  border-radius: 5px;\n  background: #e5f7ed;\n  padding: 5px 19.5px;\n  color: #00b14f;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 22px;\n  cursor: pointer;\n}\n.modal-edit-image__btn-sm:hover {\n  background-color: #00b14f;\n  color: #ffffff;\n}\n.modal-edit-image__caption {\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #333333;\n}\n.modal-edit-image__upload-image {\n  width: 490px;\n  height: 100%;\n  position: relative;\n}\n.modal-edit-image__input-upload {\n  height: 200px;\n  width: 100%;\n  opacity: 0;\n  z-index: 1;\n  position: absolute;\n  cursor: pointer;\n}\n.modal-edit-image__input-upload:hover + .empty {\n  background-color: #e5f7ed;\n}\n.modal-edit-image .el-dialog__headerbtn {\n  font-weight: bold;\n  font-size: 19px;\n  line-height: 27px;\n  color: #333333;\n}\n.modal-edit-image .el-dialog__headerbtn:hover .el-dialog__close {\n  color: #333333;\n}\n.modal-edit-image .el-dialog__title {\n  font-size: 15px;\n  font-weight: 700;\n}\n.modal-edit-image .el-dialog__close {\n  color: var(--el-color-info);\n  font-weight: 700;\n  font-size: 18px;\n}\n.modal-edit-image .el-dialog__body {\n  padding: calc(var(--el-dialog-padding-primary) + 10px) var(--el-dialog-padding-primary) !important;\n}\n.empty {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n  height: 200px;\n  background: #f1f2f6;\n  border: 1px dashed #cccccc;\n  border-radius: 8px;\n  cursor: pointer;\n}\n.ie-container {\n  width: 100%;\n  max-width: 100%;\n  position: relative;\n  z-index: 2;\n}\n.vue-cropper {\n  height: 300px;\n}\n.align-setting {\n  padding: 0 10px;\n}\n.align-setting__item {\n  width: 28px;\n  height: 28px;\n  margin: 0px 12px;\n}\n.align-setting__item label {\n  margin-bottom: 0px;\n  width: 100%;\n  height: 100%;\n  cursor: pointer;\n  font-weight: 500;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.align-setting__item.active {\n  background: #e5f7ed;\n  border-radius: 3px;\n  color: #00b14f;\n}\n.align-setting__item:hover {\n  background-color: #f4f4f4;\n  border-radius: 4px;\n}\n.align-setting .active {\n  color: #00b14f;\n}',
        "../assets/images/box-type/Audio.svg": "https://static.topcv.vn/cv-builder/assets/Audio.cb075da3.svg",
        "../assets/images/box-type/Banner.svg": "https://static.topcv.vn/cv-builder/assets/Banner.22ba980a.svg",
        "../assets/images/box-type/Blank.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAE2SURBVHgB7Zg/boMwFMafnY6A6AZMPUJv0NygvUGbkyS9RbemJ2hvULhB1mzdgM0SzNDPCYmQIv4otiIP7ydZtvAz/mzEk/2JOI5/iWhJE7RtuyqKYksWwJwvqD5RwonQVNIMcR0PZAks9pGmxWmWAqtpu0FbVNlQpK3dO6F3EXOGg8KEeNWNu97DzLaIMfI8/xnqi6JIVweBkhyHBZrCAk3RApVuNE2jyEEWvu/vkY/2ZVl+kCPUdb3zPE+g+UUMwzAMwzAMwxiwwC3+LQiC56qqMnKIJEnWOPbf972Z1S2tjzE69+sbRTl57eyZSiFf3E1hgaY4L/DssEopnzpn8wLYsWrMEb0GnX+H+rQW/MnHuU95cAoMeEee3JAFIG6DRa/nxOpPnM6IU3jhjuzxNycIm5L+A6DbYUcRtiSMAAAAAElFTkSuQmCC",
        "../assets/images/box-type/Blog.svg": "https://static.topcv.vn/cv-builder/assets/Blog.2b8d0652.svg",
        "../assets/images/box-type/Blogging.svg": "https://static.topcv.vn/cv-builder/assets/Blog.2b8d0652.svg",
        "../assets/images/box-type/Button.svg": "https://static.topcv.vn/cv-builder/assets/Button.420176d4.svg",
        "../assets/images/box-type/Counter.svg": "https://static.topcv.vn/cv-builder/assets/Counter.6a5ad734.svg",
        "../assets/images/box-type/Custom-Product.svg": "https://static.topcv.vn/cv-builder/assets/Custom-Product.c933275d.svg",
        "../assets/images/box-type/Custom_Product.svg": "https://static.topcv.vn/cv-builder/assets/Custom-Product.c933275d.svg",
        "../assets/images/box-type/Default-Category.svg": "https://static.topcv.vn/cv-builder/assets/Default_Category.a16dbcb0.svg",
        "../assets/images/box-type/Default_Category.svg": "https://static.topcv.vn/cv-builder/assets/Default_Category.a16dbcb0.svg",
        "../assets/images/box-type/Divider.svg": "https://static.topcv.vn/cv-builder/assets/Divider.6f4a17aa.svg",
        "../assets/images/box-type/Drag-Audio.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Audio.e22c643c.svg",
        "../assets/images/box-type/Drag-Banner.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Banner.dc1149a4.svg",
        "../assets/images/box-type/Drag-Blog.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Blog.d20d45e8.svg",
        "../assets/images/box-type/Drag-Button.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Button.60bbd213.svg",
        "../assets/images/box-type/Drag-Counter.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Counter.6e3d9382.svg",
        "../assets/images/box-type/Drag-Custom-Product.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Custom-Product.000c34d0.svg",
        "../assets/images/box-type/Drag-Default-Category.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Default-Category.3af1047e.svg",
        "../assets/images/box-type/Drag-Divider.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Divider.2eca542d.svg",
        "../assets/images/box-type/Drag-Element-Group.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Element-Group.eab01cff.svg",
        "../assets/images/box-type/Drag-Footer-Menu.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Footer-Menu.c995db6d.svg",
        "../assets/images/box-type/Drag-Heading.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Heading.b864fd18.svg",
        "../assets/images/box-type/Drag-Horizontal-Menu.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Horizontal-Menu.09d8014f.svg",
        "../assets/images/box-type/Drag-Icon.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Icon.323fcaa7.svg",
        "../assets/images/box-type/Drag-Image.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Image.49f768b5.svg",
        "../assets/images/box-type/Drag-Map.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Map.a5294f2d.svg",
        "../assets/images/box-type/Drag-Menu.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Menu.40e15cfa.svg",
        "../assets/images/box-type/Drag-Policy.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Policy.4d0b6d5b.svg",
        "../assets/images/box-type/Drag-Progress Bar.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Progress Bar.8f6bda1e.svg",
        "../assets/images/box-type/Drag-Section.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Section.982f087b.svg",
        "../assets/images/box-type/Drag-Services.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Services.59f90a23.svg",
        "../assets/images/box-type/Drag-Testimonial.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Testimonial.065080f9.svg",
        "../assets/images/box-type/Drag-Text.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Text.2e18fb6e.svg",
        "../assets/images/box-type/Drag-Toggle-Menu.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Toggle-Menu.62d6979f.svg",
        "../assets/images/box-type/Drag-Top-Menu.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Top-Menu.45377823.svg",
        "../assets/images/box-type/Drag-Video.svg": "https://static.topcv.vn/cv-builder/assets/Drag-Video.5c699719.svg",
        "../assets/images/box-type/Heading.svg": "https://static.topcv.vn/cv-builder/assets/Heading.f44a2045.svg",
        "../assets/images/box-type/Icon.svg": "https://static.topcv.vn/cv-builder/assets/Icon.e553841b.svg",
        "../assets/images/box-type/Image.svg": "https://static.topcv.vn/cv-builder/assets/Image.64a64e95.svg",
        "../assets/images/box-type/Progress_Bar.svg": "https://static.topcv.vn/cv-builder/assets/Progress_Bar.45f6164a.svg",
        "../assets/images/box-type/Service.svg": "https://static.topcv.vn/cv-builder/assets/Service.dc0c22b6.svg",
        "../assets/images/box-type/Templates.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAeCAYAAABe3VzdAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEySURBVHgB7ZgxcoMwEEX/JikpKKGKjuAjcIQcIT4BSZkuPoHbdCE3cZkyN4gqhjIFPflrZI9cWTMqvIXezLJCswsfASuBIKJpGgcDTNPkT23RTdu2Pd07rYYNvIgM4zjuhKP2zJ1P2ORVOHq/bDjaD223LMsfbgwHbE+3gY4kBS7aSWFb3vsBBojv6h2MUwTmUgTmcn6LsZaZm5eYgAuGh6hzA4PEAg+shf5aAutTh/XqPOMPSIA5T1in0aQcxju67kIgE79SCjWL6KAH0Ith/BYJ8DFyekIVl5ITCnWn7fIW51IE5lIE5lIE5lIE5lIE5qKLBU9znJx7TtL+WgLjHoOvGd8hjTo1R2Po+rB7/Ox8YWMPg+in8P08z99VVUlYg1n59aEr+zcuzT4k7rX48+gf/f1eCyEQxSEAAAAASUVORK5CYII=",
        "../assets/images/box-type/Testimonial.svg": "https://static.topcv.vn/cv-builder/assets/Testimonial.f4db22b2.svg",
        "../assets/images/box-type/Text.svg": "https://static.topcv.vn/cv-builder/assets/Text.78f94e4b.svg",
        "../assets/images/box-type/Video.svg": "https://static.topcv.vn/cv-builder/assets/Video.6433ac7a.svg",
        "../assets/images/column-display-type/1.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAACvUlEQVR4Xu3dPW7iUBiFYZaQJWRp2clkZywBKQ1BKdxEgo6ASO3xN4rR6DgnAyaZc4vX0lMY27ouXl3/UHix+Fi6rrs7HA6/3t7eloMeCFjt9/uHscnzst1u74eN3ScHAAldNXkOtH6oDcMM2r+/vwMx1eAY6TCb3i1qSiVOtGSMdGjzsWbPVa3oTkBSNXk8HpcV6J8V3QFIGrskUDSJQNE0AkXTCBRNI1A0jUDRtJsDPZ1O/evra//y8tI/PT0BE5vNpt/tdpN2LnFToPWmf71eT04I+Ey1cu0/lTcFSpy4VjVTV11tyZkdaE3ZOjhwibol1J6c2YHWfYUODFyinle0J2d2oDoocA3tySFQRGhPDoEiQntyCBQR2pNDoIjQnhwCRYT25BAoIrQnh0ARoT05BIoI7ckhUERoTw6BIkJ7cggUEdqTQ6CI0J4cAkWE9uQQKCK0J4dAEaE9OQSKCO3JIVBEaE8OgSJCe3IIFBHak0OgiNCeHAJFhPbkECgitCeHQBGhPTkEigjtySFQRGhPDoEiQntyCBQR2pNDoIjQnhwCRYT25BAoIrQnh0ARoT05BIoI7ckhUERoTw6BIkJ7cggUEdqTQ6CI0J4cAkWE9uQQKCK0J4dAEaE9OQSKCO3JIVBEaE8OgSJCe3IIFBHak0OgiNCeHAJFhPbkzA60PqmsgwKXeH5+nvTkzA60PkqvAwOX2O12k56c2YGeTqd+vV5PBge+Us1oS1+ZHWg5HA5EiotVK9WMdvSVmwId1ZS92WwmJwSUel6pW8K66mo7//ItgQI/hUDRNAJF0wgUTSNQNI1A0TQCRdPOgR6PxyWBojUfga4W+/3+sVaufdMP/JRqsZoc2nyoQO+GlW6MdM5bf+C7jHFWk4txGSK9HyMFGtBVk+dA/wr1Ydi4+uQA4H9Y1i1nXdXHJn8DWHStl+T/TygAAAAASUVORK5CYII=",
        "../assets/images/column-display-type/10_2.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAYCAYAAACbU/80AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAABISURBVHgB7c6xDQAgDANBwySwWUbLZmQUREkkyojmXbn7a+6+JA3VLsxsnpN60VUfV2pcv+vzAAAAAAAAAAAAAAA4gFD94vU3h34M7+hYlsgAAAAASUVORK5CYII=",
        "../assets/images/column-display-type/1_1.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADPklEQVR4Xu3dTW7aABRFYZaQJXRp2UmzM5aAxISgDJhECjMCImPXr4kpPTg/D16KVR+kb+AAMjq6MogMmEzebqvV6ma73f58fn6ethrpCmabzea22+Th9vT09KO9c9XzBOkaVrHJw0DjD3FHewVtXl5epKuJDXYjba+mN5O4pDpODUk30nabd3H1nMUBHyRdU2xyt9tNY6C/D/gA6Zq6XTpQDZID1aA5UA2aA9WgOVANmgPVoF080P1+3zw+PjYPDw/NfD4fleVy2azX65MmfcbcqZPp1blooPFN/2KxOHkhYxMNPvoPnJ3+9lmvYxcN1Oh/RIu4SrKRnfp91OvY2QONSzVPOnbxFm6nr+vrRWcPND5P8IRjF58v7fR1fb3o7IHyZHplpxz2IgdazE457EUOtJidctiLHGgxO+WwFznQYnbKYS9yoMXslMNe5ECL2SmHvciBFrNTDnuRAy1mpxz2IgdazE457EUOtJidctiLHGgxO+WwFznQYnbKYS9yoMXslMNe5ECL2SmHvciBFrNTDnuRAy1mpxz2IgdazE457EUOtJidctiLHGgxO+WwFznQYnbKYS9yoMXslMNe5ECL2SmHvciBFrNTDnuRAy1mpxz2IgdazE457EUOtJidctiLHGgxO+WwFznQYnbKYS9yoMXslMNe5ECL2SmHvciBFrNTDnuRAy1mpxz2IgdazE457EUOtJidctiLHGgxO+WwFznQYnbKYS9yoMXslMNe5ECL2SmHvciBFrNTDnuRAy1mpxz2IgdazE457EUOtJidctiLHGgxO+WwFznQYnbKYS9yoMXslMNedPZA46eUebKxu7+/t1NCXy86e6DxY/Q84dit12s7JfT1orMHut/vm8VicXLSsYoWbGSn973Xi84eaNhut8afv8aOFuxjp36f9Tp20UA7caleLpcnL+R/F58v4y08rpJs0mesnTrZXqFkoNJ3caAaNAeqQXOgGjQHqkFzoBo0B6pBOwx0t9tNHaiG5m2gs8lms7mLg69+wy99t9hibLLd5m0M9KY9WHUjzXzbL1XrxhmbnHS3dqQ/upFKA7CKTR4GejTU2/bOWc8TpH9hGh8541292+QvAKHoOPNg8o8AAAAASUVORK5CYII=",
        "../assets/images/column-display-type/1_1_1.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADQElEQVR4Xu3dQWoiARCFYY+QI+RoucnkZh5ByEYli94EdGcUXfd0DWkZ2heLTPfYj+IPfAsnFXiEn45kFlksvj6apnk6Ho+/Pj8/l50WmMHqcDi89E1eP3a73XP3yUZ8ATCHJpq8Bhr/EJ/onqDt5XIBZhMN9pF2T9OnRTxSiRNO+ki7Nl/j6bmKF8MjYE7R5Ol0Wkagf14MD4A59V0SKCwRKKwRKKwRKKwRKKwRKKxNFuj5fG4/Pj7a9/f39u3tzcJ2u233+/3NVoX90/vJ/u9MEmj8xn+9Xt8MdBHb7v0PGfv/r2z/PZME6vzN6cXGeMoMt7P/Me7tv2d0oPEIH45xFT8C2T8ftT8zOtB4nzEc4iren7F/Pmp/ZnSgwxHu2D+v4f4MgYobZ9X2ZwhU3Dirtj9DoOLGWbX9GQIVN86q7c8QqLhxVm1/hkDFjbNq+zMEKm6cVdufIVBx46za/gyBihtn1fZnCFTcOKu2P0Og4sZZtf0ZAhU3zqrtzxCouHFWbX+GQMWNs2r7MwQqbpxV258hUHHjrNr+DIGKG2fV9mcIVNw4q7Y/Q6Dixlm1/RkCFTfOqu3PEKi4cVZtf4ZAxY2zavszBCpunFXbnyFQceOs2v4MgYobZ9X2ZwhU3Dirtj9DoOLGWbX9GQIVN86q7c8QqLhxVm1/hkDFjbNq+zMEKm6cVdufIVBx46za/gyBihtn1fZnCFTcOKu2P0Og4sZZtf0ZAhU3zqrtzxCouHFWbX+GQMWNs2r7MwQqbpxV258hUHHjrNr+DIGKG2fV9mcIVNw4q7Y/Q6Dixlm1/RkCFTfOqu3PEKi4cVZtf2Z0oPEnlocjXG02G/bPSO3PjA40/kj9cIir/X7P/hmp/ZnRgZ7P53a9Xt+McRMbh9vZ/zjf7c+MDjQcj0frb1Jsi43D3ex/jGz/PZME2otH+Ha7vRk4l3h/Fj8C4ykz3Kqwf1o/3a9MGigwNQKFNQKFNQKFNQKFNQKFNQKFtWugp9NpSaBw8xXoanE4HF7jxb/+xh+YWrQYTXZtvkSgT92Lpo90zG//gbH6OKPJRf/RRfrcRwoYaKLJa6B/hfrSfXIlvgB4hGW85Yyf6n2TvwF60NqohR6hfgAAAABJRU5ErkJggg==",
        "../assets/images/column-display-type/1_1_1_1.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADLUlEQVR4Xu3dQU4iURRGYZbgElyaO2l3xhJInCBxwMREZgjBMV23YxE80B0vfaFemUPyDRDNOya/BcEBk8nnbblc3m02m1/v7+/Tzl4awGy9Xj/0mzzc3t7e7rsHl2d+QBrCMjZ5GGh8IR7orqD7j48PaTCxwX6k3dX0bhKXVMeplvQj7bb5GFfPWdzhN0lDik1ut9tpDPTPHX6DNKR+lw5UTXKgapoDVdMcqJrmQNU0B6qmXTzQ3W63f3193b+8vOyfnp6uarFY7Fer1UnDOXb9jK7eRQONd/jn8/lJwLXFmf/6T5ddX42169hFAx3il+rF2fFXzya7zhtj17H0QOMSzcNuLZ6S7Pq+MXVReqDxOoIH3Vq8XrLr+8bURemB8pCh2JUzli5yoMXsymEXOdBiduWwixxoMbty2EUOtJhdOewiB1rMrhx2kQMtZlcOu8iBFrMrh13kQIvZlcMucqDF7MphFznQYnblsIscaDG7cthFDrSYXTnsIgdazK4cdpEDLWZXDrvIgRazK4dd5ECL2ZXDLnKgxezKYRc50GJ25bCLHGgxu3LYRQ60mF057CIHWsyuHHaRAy1mVw67yIEWsyuHXeRAi9mVwy5yoMXsymEXOdBiduWwixxoMbty2EUOtJhdOewiB1rMrhx2kQMtZlcOu8iBFrMrh13kQIvZlcMucqDF7MphFznQYnblsIscaDG7cthFDrSYXTnsIgdazK4cdpEDLWZXDrvIgRazK4dd5ECL2ZXDLnKgxezKYRc50GJ25bCLHGgxu3LYRQ60mF057CIHWsyuHHZReqDxEco85Naen5/tShhTF6UHGh9Cz4NubbVa2ZUwpi5KD3S32+3n8/nJYbcSZ7PJrr8bWxelBxo2m80gv1ycGWezx67zxtp17KKB9uISvVgsTgKqxeuleEqKv3o2nGPXz+gK/zVQ6docqJrmQNU0B6qmOVA1zYGqaQ5UTTsMdLvdTh2oWvM50NlkvV4/xp3vvsMvXVtsMTbZbfMhBnrX3Vn2I8282y9V68cZm5z0t26k9/1IpQYsY5OHgR4N9aF7cHbmB6RbmMZLznhW7zf5G35Ri3lTvqLLAAAAAElFTkSuQmCC",
        "../assets/images/column-display-type/1_1_2.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADgElEQVR4Xu3dPW7iABQEYI6QI+RoucnmZhwBiQYQhRuk0PEjqL1+qxitBoenrP2YiXaQvsIB5NFoZCxSMJt9PpqmeTmdTr+Ox+O805oRLA6Hw1u/ydvj4+PjtXuyGXiDGUMTm7wNNP4QT3RX0PZ6vZrRxAb7kXZX05dZXFI9TlPSj7Tb5ntcPRdxgC8yY4pNns/neQz0zwG+wIyp36UHapI8UJPmgZo0D9SkeaAmzQM1aZMN9HK5tLvdrt1ut+1yuSy12Wza/X5/l2GIc/F8p4+vTDLQ+MZ/tVrdBawW53z0ny/n0pD18cgkA2WWHeeOqxFmci4tj/p4ZPRA4xKOYZ4tPiqdS99QH5nRA437DAzybHEf51z6hvrIjB4ohmBxrp8B+8h4oMVUc7FgHxkPtJhqLhbsI+OBFlPNxYJ9ZDzQYqq5WLCPjAdaTDUXC/aR8UCLqeZiwT4yHmgx1Vws2EfGAy2mmosF+8h4oMVUc7FgHxkPtJhqLhbsI+OBFlPNxYJ9ZDzQYqq5WLCPjAdaTDUXC/aR8UCLqeZiwT4yHmgx1Vws2EfGAy2mmosF+8h4oMVUc7FgHxkPtJhqLhbsI+OBFlPNxYJ9ZDzQYqq5WLCPjAdaTDUXC/aR8UCLqeZiwT4yHmgx1Vws2EfGAy2mmosF+8h4oMVUc7FgHxkPtJhqLhbsI+OBFlPNxYJ9ZDzQYqq5WLCPjAdaTDUXC/aR8UCLqeZiwT4yHmgx1Vws2EfGAy2mmosF+8h4oMVUc7FgHxkPtJhqLhbsI+OBFlPNxYJ9ZDzQYqq5WLCPjAdaTDUXC/aR8UCLqeZiwT4yHmgx1Vws2EfGAy2mmosF+8h4oMVUc7FgHxkPtJhqLhbsI+OBFlPNxYJ9ZDzQYqq5WLCPjAdaTDUXC/aRGT3Q+IllDPFs6/XauX6AoT4yowcaP1KPQZ5tv9871w8w1Edm9EAvl0u7Wq3uwjxLnBszOZeer/rIjB5oOJ1OlNLjnHFuzONcWrI+HplkoL24hG82m7uAU4v7uPiojKsRZhjyv+di+W4fQyYdqNnUPFCT5oGaNA/UpHmgJs0DNWkeqEm7DfR8Ps89UFPzOdDF7HA4vMfBv37jbza12GJsstvmWwz0pTto+pGO+fbfbKx+nLHJWf/oRvraj9RMQBObvA30r6G+dU8uBt5g9gzzuOWMT/V+k78BgafaqPBlCGcAAAAASUVORK5CYII=",
        "../assets/images/column-display-type/1_2.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADVUlEQVR4Xu3dQWoicRDFYY/gEXK03GRyM48gZGMki94EdGcUXfd0DWkZnhWLTHeN9Ydf4Fs4eYHi5dGRzCKLxddH13XL4/H46/PzczXogQdYHw6H53GT14/dbvc0fLJzvgB4hM42eR2o/YN9YniC9pfLBXgY2+A40uFpulzYI5VxopJxpMM2X+zpubYXGgIeyTZ5Op1WNtA/LzQAPNK4SwaKkhgoSmOgKI2BojQGitIYKEqbbaDn87n/+Pjo39/f+9fX1xK2222/3+9vbvVUvL91P+n/O7MM1H7jv9lsbg6swm679z9k1e9vXdT/PbMMtIVvrt1oT0m9vZX7W3ev/3smD9Qe4XpMVfYjvOX7W+f1H5k8UHufoYdUZe8vW76/dV7/kckD1SOqa/3+1mn/EQbqZJBH+48wUCeDPNp/hIE6GeTR/iMM1Mkgj/YfYaBOBnm0/wgDdTLIo/1HGKiTQR7tP8JAnQzyaP8RBupkkEf7jzBQJ4M82n+EgToZ5NH+IwzUySCP9h9hoE4GebT/CAN1Msij/UcYqJNBHu0/wkCdDPJo/xEG6mSQR/uPMFAngzzaf4SBOhnk0f4jDNTJII/2H2GgTgZ5tP8IA3UyyKP9Rxiok0Ee7T/CQJ0M8mj/EQbqZJBH+48wUCeDPNp/hIE6GeTR/iMM1Mkgj/YfYaBOBnm0/wgDdTLIo/1HGKiTQR7tP8JAnQzyaP8RBupkkEf7jzBQJ4M82n+EgToZ5NH+IwzUySCP9h9hoE4GebT/CAN1Msij/UcYqJNBHu0/wkCdDPJo/xEG6mSQR/uPMFAngzzaf4SBOhnk0f4jDNTJII/2H2GgTgZ5tP/I5IHan1jWI6p6e3tr+v7Wef1HJg/U/ki9HlLVfr9v+v7Wef1HJg/0fD73m83m5phq7Ea9vaX7W/dd/5HJAzXH47H0N9lusxv17lbub13U/z2zDHRkj/Dtdntz4KPY+0v7EW5PSb3VU+3+1v20f8+sAwXmxkBRGgNFaQwUpTFQlMZAURoDRWnXgZ5OpxUDRTVfA10vDofDi73419/4A3OzLdomh20+20CXw4tuHOmU3/4DU43jtE0uxo9hpE/jSIECOtvkdaB/DfV5+OTa+QLgf1jZW077qT5u8jdx13IX1lW7IQAAAABJRU5ErkJggg==",
        "../assets/images/column-display-type/1_2_1.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADcElEQVR4Xu3dQWrqcBgEcI/gEXo0b/J6M48guIniIpuC7jSi67x8j0bKmDr0Jc1/+Bjht0hVMg5DFLtwsfi81XW9bJrmz+VyWXdaswI25/N51W/ycTsej2/dnfXAE8xKqGOTj4HGH+KO7gra3u93s2Jig/1Iu6vpchGXVI/TlPQj7bb5HlfPTRzgg8xKik1er9d1DPTfAT7ArKR+lx6oSfJATZoHatI8UJPmgZo0D9SkTTbQ2+3Wfnx8tIfDod1ut79qv9+3p9PpKcOQOXOVotrHT3J9Z5KBxjf+VVU9Bfxtcc5X//kqlasU1T5YrlcmGWiJF92Lc8dVATOVzlWKah+vcr0yeqBxCccwc4u3LMVcpaj2MZSLGT3Q+JyBQeYWn6cUc5Wi2sdQLmb0QDFEKaq5SlHtA3MxHmhSqn1gLsYDTUq1D8zFeKBJqfaBuRgPNCnVPjAX44EmpdoH5mI80KRU+8BcjAealGofmIvxQJNS7QNzMR5oUqp9YC7GA01KtQ/MxXigSan2gbkYDzQp1T4wF+OBJqXaB+ZiPNCkVPvAXIwHmpRqH5iL8UCTUu0DczEeaFKqfWAuxgNNSrUPzMV4oEmp9oG5GA80KdU+MBfjgSal2gfmYjzQpFT7wFyMB5qUah+Yi/FAk1LtA3MxHmhSqn1gLsYDTUq1D8zFeKBJqfaBuRgPNCnVPjAX44EmpdoH5mI80KRU+8BcjAealGofmIvxQJNS7QNzMR5oUqp9YC7GA01KtQ/MxXigSan2gbkYDzQp1T4wF+OBJqXaB+ZiPNCkVPvAXIwHmpRqH5iL8UCTUu0DczEeaFKqfWAuxgNNSrUPzMV4oEmp9oG5GA80KdU+MBfjgSal2gfmYkYPNH5iGUPMbbfbSeYqRbWPoVzM6IHGj9RjkLmdTifJXKWo9jGUixk90Nvt1lZV9RRmLnFuzKSQqxTVPr7LxYweaGiapsiLj3PGuTFP6VylqPbBcr0yyUB7cQnf7/dPAacWn6fiLSuuCphhyFy5SlHt46e5hkw6ULOpeaAmzQM1aR6oSfNATZoHatI8UJP2GOj1el17oKbmc6Cbxfl8fo+D//3G32xqscXYZLfNVQx02R3U/UjHfPtvNlY/ztjkor91I33rR2omoI5NPgb6Zair7s7NwBPM5rCOj5zxrt5v8i960NqoHZ+L6QAAAABJRU5ErkJggg==",
        "../assets/images/column-display-type/1_3.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAAC/ElEQVR4Xu3dPW7iYBSFYZbAErI0djLZGUtAogFE4SYSdPwIao/vKEbxweEoY+f6K16kp2BI5E86rwxiisxmn4+qquaXy+XP+XxeNmpgAqvT6bRom3w8DofDW/Ni1fMLwBSqaPIRaPxDvNDcQev7/Q5MJhpsI23upvNZ3FKJEyVpI23afI+75yqe6A8BU4omr9frMgL990R/AJhS2yWBokgEiqIRKIpGoCgagaJoBIqijRbo7XarPz4+6v1+X6/X61+12+3q4/H4dIY+medC1092+s4ogcY3/pvN5umAvy2u+ep/vqY6F7rcTq+MEuiUEcS14y6pZ5r6XOh6tdMrgwONW7geJlu8hZd4LnT17eQMDjQ+Z+hBssXnyxLPha6+nZzBgeohplLqudClOzkEilS6k0OgSKU7OQSKVLqTQ6BIpTs5BIpUupNDoEilOzkEilS6k0OgSKU7OQSKVLqTQ6BIpTs5BIpUupNDoEilOzkEilS6k0OgSKU7OQSKVLqTQ6BIpTs5BIpUupNDoEilOzkEilS6k0OgSKU7OQSKVLqTQ6BIpTs5BIpUupNDoEilOzkEilS6k0OgSKU7OQSKVLqTQ6BIpTs5BIpUupNDoEilOzkEilS6k0OgSKU7OQSKVLqTQ6BIpTs5BIpUupNDoEilOzkEilS6k0OgSKU7OQSKVLqTQ6BIpTs5BIpUupNDoEilOzkEilS6k0OgSKU7OQSKVLqTMzjQ+BPLeohs2+22yHOhq28nZ3Cg8Ufq9SDZjsdjkedCV99OzuBAb7dbvdlsng6TJa6tZyrhXOj6bidncKDhcrlMEkNcM66t55n6XOhyO70ySqCtuIXvdrunA44tPl/GW3jcJfUMfbLOha6f7tRn1ECBsREoikagKBqBomgEiqIRKIpGoCjaI9Dr9bokUJTmM9DV7HQ6vceT//3GHxhbtBhNNm0uItB586RqIx3y7T8wVBtnNDlrH02kb22kQAGqaPIR6JdQF82Lq55fADIs4yNnvKu3Tf4FyW9yF0u+RZIAAAAASUVORK5CYII=",
        "../assets/images/column-display-type/2_1.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADSklEQVR4Xu3dQWoiYRiEYY+QI+RoucnkZh5ByMZIFm4CcWcUs3b6G9IylB2LpNvxr+EVnkVHhaIofhuzcDb7fKzX67vdbvfr/f193jkCN7DYbrcP/SZPj7e3t/vuyfXAG4BbWNcmTwOtP9QT3Ql6/Pj4AG6mNtiPtDtN72Z1pDJOtKQfabfNxzo9F3WhLwJuqTa53+/nNdA/F/oC4Jb6XTJQNImBomkMFE1joGgaA0XTGCiaNtlAD4fD8fX19fjy8nJ8enrCBFar1XGz2Zx1PaTF/r+T/yuTDLS+8V8ul2cBMY3q9tJ/+Frv3+W/ZJKBtlzO/6I6rlNSu0/p/1L+S0YPtI5wDYPrqI/w5P6H8jujB1r3GRoE11H3l8n9D+V3Rg9UQ+C60vvX/A4DDZPev+Z3GGiY9P41v8NAw6T3r/kdBhomvX/N7zDQMOn9a36HgYZJ71/zOww0THr/mt9hoGHS+9f8DgMNk96/5ncYaJj0/jW/w0DDpPev+R0GGia9f83vMNAw6f1rfoeBhknvX/M7DDRMev+a32GgYdL71/wOAw2T3r/mdxhomPT+Nb/DQMOk96/5HQYaJr1/ze8w0DDp/Wt+h4GGSe9f8zsMNEx6/5rfYaBh0vvX/A4DDZPev+Z3GGiY9P41v8NAw6T3r/kdBhomvX/N7zDQMOn9a36HgYZJ71/zOww0THr/mt9hoGHS+9f8DgMNk96/5ncYaJj0/jW/w0DDpPev+R0GGia9f83vMNAw6f1rfoeBhknvX/M7DDRMev+a32GgYdL71/wOAw2T3r/mdxhomPT+Nb/DQMOk96/5HQYaJr1/ze8w0DDp/Wt+Z/RA6yeWNQSu4/n5Obr/ofzO6IHWj9RrEFzHZrOJ7n8ovzN6oIfD4bhcLs/CYFrVsXaf1P9X+Z3RAy273S6ipFTVbXWsvaf07/JfMslAe3WEr1ars4D4mbq/rI/wOiW16yGt9f/d/EMmHSgwNQaKpjFQNI2BomkMFE1joGgaA0XTTgPd7/dzBorWfA50Mdtut4918dNv/IGp1RZrk902H2qgd93Fuh/pmG//gbH6cdYmZ/2jG+l9P1KgAeva5Gmgfw31oXtyMfAG4F+Y1y1nfar3m/wNAIVyF0KtUkYAAAAASUVORK5CYII=",
        "../assets/images/column-display-type/2_10.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAYCAYAAACbU/80AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAABLSURBVHgB7c6xCQAgDETR00l0s4yWzcwoIjYiWAab/6vTJq+4+5DUtAsz62tc/1lFvY68dlat6nMAAAAAAAAAAAAAACxAHO/Xziom75wM76dpx/IAAAAASUVORK5CYII=",
        "../assets/images/column-display-type/2_1_1.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADXUlEQVR4Xu3dQWoiYRQEYI/gEXK03GRyM48gZKOSRW8CujOKWff0G9IytI4FU41dpSV8C6NC/UXRilk4m/3cmqaZHw6HX19fX4tOGzGB5X6/f+03eb5tt9uX7sHmygsiptDUJs8DrT/UA90VtP3+/o6YTG2wH2l3NZ3P6pKacYaSfqTdNt/q6rmsO8MnRUypNnk8Hhc10D93hk+ImFK/yww0JGWgIS0DDWkZaEjLQENaBhrSRhvo6XRqPz8/24+Pj/b9/f0hbTabdrfbXZz9mnv28Qi5/mWUgdY3/qvV6iLgo6qz3vqP21R9uOa6ZZSBTnHoqdWZ62o07GLqPhxz3UIPtC7hwzDPot4qFftwyoXQA63PGcMgz6I+xyn24ZQLoQc6DPFsVPtwyYVkoCTVPlxyIRkoSbUPl1xIBkpS7cMlF5KBklT7cMmFZKAk1T5cciEZKEm1D5dcSAZKUu3DJReSgZJU+3DJhWSgJNU+XHIhGShJtQ+XXEgGSlLtwyUXkoGSVPtwyYVkoCTVPlxyIRkoSbUPl1xIBkpS7cMlF5KBklT7cMmFZKAk1T5cciEZKEm1D5dcSAZKUu3DJReSgZJU+3DJhWSgJNU+XHIhGShJtQ+XXEgGSlLtwyUXkoGSVPtwyYVkoCTVPlxyIRkoSbUPl1xIBkpS7cMlF5KBklT7cMmFZKAk1T5cciEZKEm1D5dcSAZKUu3DJReSgZJU+3DJhWSgJNU+XHIhGShJtQ+XXEgGSlLtwyUXkoGSVPtwyYVkoCTVPlxyIRkoSbUPl1xIBkpS7cMlF5KBklT7cMmFZKAk1T5cciEZKEm1D5dcSAZKUu3DJReSgZJU+3DJhWSgJNU+XHIh9EDrJ5aHIZ7Fer2W7MMpF0IPtH6kfhjkWex2O8k+nHIh9EBPp1O7Wq0uwjy6OvOwC4U+3HIh9EDL4XCY9PD3VmetMw97mLoP11y3jDLQXl3CN5vNRcBHUZ/j6q2yrkbDs19zrz4eJdc1ow40YmwZaEjLQENaBhrSMtCQloGGtAw0pJ0HejweFxloqPkZ6HK23+/f6s7/fuMfMbbaYm2y2+ZrDXTe3Wn6kTLf/kew+nHWJmf9rRvpSz/SCAFNbfI80L+G+to9uLzygoh7WNRHznpX7zf5G3P52qiiTgPSAAAAAElFTkSuQmCC",
        "../assets/images/column-display-type/3_1.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADUUlEQVR4Xu3dQWoiYRTEcY+QI+RoucnkZh5ByMZIFm4CcWcUs+7pN5OWUHZ8ZLrHr3j8hd+io0JJFZ9iFi4Wn7ftdnt3OBx+vb+/L3sd0MBqv98/DJs8397e3u77O7cjTwBa2MYmzwONP8Qd/QnafXx8AM3EBoeR9qfp3SKOVMYJJ8NI+20+xum5igt9ENBSbPJ4PC5joH8u9AFAS8MuGSgsMVBYY6CwxkBhjYHCGgOFtdkGejqdutfX1+7l5aV7enrCDW02m2632110MuaWPf0k13dmGWh8479ery8C4raig2v/CWzVU5brmlkG2uJFY1x0EaekdtS6p2u5rpk80DjCNQzairdwx57GcmUmDzQ+Z2gQtBWfLx17GsuVmTxQDQEPrj1prgwDLcq1J82VYaBFufakuTIMtCjXnjRXhoEW5dqT5sow0KJce9JcGQZalGtPmivDQIty7UlzZRhoUa49aa4MAy3KtSfNlWGgRbn2pLkyDLQo1540V4aBFuXak+bKMNCiXHvSXBkGWpRrT5orw0CLcu1Jc2UYaFGuPWmuDAMtyrUnzZVhoEW59qS5Mgy0KNeeNFeGgRbl2pPmyjDQolx70lwZBlqUa0+aK8NAi3LtSXNlGGhRrj1prgwDLcq1J82VYaBFufakuTIMtCjXnjRXhoEW5dqT5sow0KJce9JcGQZalGtPmivDQIty7UlzZRhoUa49aa4MAy3KtSfNlWGgRbn2pLkyDLQo1540V4aBFuXak+bKMNCiXHvSXBkGWpRrT5orw0CLcu1Jc2UYaFGuPWmuDAMtyrUnzZVhoEW59qS5Mgy0KNeeNFeGgRbl2pPmyjDQolx70lyZyQONn1jWEGjr+fnZsqexXJnJA40fqdcgaGu321n2NJYrM3mgp9OpW6/XF2HQRnShHTn09F2uzOSBhsPh0PTF46/oILrQflr3lOW6ZpaBDuII32w2FwHxf8Xny3gLj1NSOxlzq55+mmvMrAMF5sZAYY2BwhoDhTUGCmsMFNYYKKydB3o8HpcMFG4+B7pa7Pf7x7j412/8gbnFFmOT/TYfYqB3/cV2GOmUb/+BqYZxxiYXw60f6f0wUsDANjZ5HuiXoT70d65GngDcwjI+csa7+rDJ36jechfeHy09AAAAAElFTkSuQmCC",
        "../assets/images/column-display-type/3_4_5.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADn0lEQVR4Xu3dQWoiYRQEYI+QI+RoucnkZh5ByMZIFm4CujOKWTv9hrQMZcci1Z1+/4MSvkVHpaukaMUsXCy+btvt9uF4PP75+PhYdi5mCVaHw+Gp3+T1ttvtHrs7twNPMMuwjU1eBxp/iDu6K+jl8/PTLE1ssB9pdzV9WMQl1eO0lvQj7bb5HFfPVRzgg8wyxSZPp9MyBvrvAB9glqnfpQdqTfJArWkeqDXNA7WmeaDWNA/UmjbZQM/n8+X9/f3y9vZ2eXl5+VWbzeay3+9vMgyZMxdTNbfqJ32/M8lA4xv/9Xp9E/C3xTnv/ecrKxdTNbeK9b1nkoFmvphx7rjaYKbsXEzV3Kp7fe8ZPdC4hGOYucVbYYu5mKq5VUN9mdEDjc8ZGGRu8TmtxVxM1dyqob7M6IFiiCyt5mKq5lZhX8YDTVY1twr7Mh5osqq5VdiX8UCTVc2twr6MB5qsam4V9mU80GRVc6uwL+OBJquaW4V9GQ80WdXcKuzLeKDJquZWYV/GA01WNbcK+zIeaLKquVXYl/FAk1XNrcK+jAearGpuFfZlPNBkVXOrsC/jgSarmluFfRkPNFnV3Crsy3igyarmVmFfxgNNVjW3CvsyHmiyqrlV2JfxQJNVza3CvowHmqxqbhX2ZTzQZFVzq7Av44Emq5pbhX0ZDzRZ1dwq7Mt4oMmq5lZhX8YDTVY1twr7Mh5osqq5VdiX8UCTVc2twr6MB5qsam4V9mU80GRVc6uwL+OBJquaW4V9GQ80WdXcKuzLeKDJquZWYV/GA01WNbcK+zIeaLKquVXYl/FAk1XNrcK+jAearGpuFfZlPNBkVXOrsC/jgSarmluFfRkPNFnV3Crsy3igyarmVmFfxgNNVjW3CvsyHmiyqrlV2JfxQJNVza3CvowHmqxqbhX2ZTzQZFVzq7AvM3qg8RPLGGJur6+vTeZiquZWDfVlRg80fqQeg8xtv983mYupmls11JcZPdDz+XxZr9c3YeYS58ZMLeRiquZWfdeXGT3QcDweU17UOGecG/Nk52Kq5laxvvdMMtBeXMI3m81NwKnF57R4K4yrDWYYMlcupmpu1U/7Dpl0oGZT80CtaR6oNc0DtaZ5oNY0D9Sa5oFa064DPZ1OSw/UWvM10NXicDg8x4H6jb/Z1GKLsclum08x0IfuYNuPdMy3/2Zj9eOMTS76WzfSx36kZg3YxiavA/1vqE/dnauBJ5jNYRkfOeNdvd/kX27E2qjcxi4VAAAAAElFTkSuQmCC",
        "../assets/images/column-display-type/3_5_2_2.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAYCAYAAABwZEQ3AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAABcSURBVHgB7c6xDYAwDETRI5OYzTyaN8OjoNToR0lHca86QaL8q6oeSaGvzsx7jsWZFbqP34f4kYC9K0730I84hjiGOIY4hjiGOIY4hjiGOIY4hsyYhn8Ne1ef7hebqxrvJxkUEQAAAABJRU5ErkJggg==",
        "../assets/images/column-display-type/3_5_4.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADZ0lEQVR4Xu3dQYriUBgEYI/gEfpo3mT6Zh5BcBPFRTaC7qIhrjP5h440ZdqiJ3nJKyjhW6RVUiVFFHvhavV1K8tyfb/f/9xut22nNVvArqqqTb/J5+1yuXx0d5YDTzBbQhmbfA40/hB3dFfQ9vF4mC0mNtiPtLuarldxSfU4LSf9SLttfsbVcxcH+CCzJcUm67rexkD/HeADzJbU79IDtSx5oJY1D9Sy5oFa1jxQy5oHalmbbKBN07Tn87k9nU7tfr9P6ng8ttfr9SXDkDlzpaLa9ze5fzLJQOMb/6IoXgKmFud895+vpXKlotqX5X5nkoEu+aLEueOqgZmWzpWKat93ud8ZPdC4hGOYucVbWo65UlHtO5SbGT3Q+JyBQeYWn7dyzJWKat+h3MzogWKIpeSaKxXVvpib8UBFqfbF3IwHKkq1L+ZmPFBRqn0xN+OBilLti7kZD1SUal/MzXigolT7Ym7GAxWl2hdzMx6oKNW+mJvxQEWp9sXcjAcqSrUv5mY8UFGqfTE344GKUu2LuRkPVJRqX8zNeKCiVPtibsYDFaXaF3MzHqgo1b6Ym/FARan2xdyMBypKtS/mZjxQUap9MTfjgYpS7Yu5GQ9UlGpfzM14oKJU+2JuxgMVpdoXczMeqCjVvpib8UBFqfbF3IwHKkq1L+ZmPFBRqn0xN+OBilLti7kZD1SUal/MzXigolT7Ym7GAxWl2hdzMx6oKNW+mJvxQEWp9sXcjAcqSrUv5mY8UFGqfTE344GKUu2LuRkPVJRqX8zNeKCiVPtibsYDFaXaF3MzHqgo1b6Ym/FARan2xdyMBypKtS/mZjxQUap9MTfjgYpS7Yu5GQ9UlGpfzM2MHmj8xDKGmNvhcMgyVyqqfYdyM6MHGj9Sj0Hmdr1es8yVimrfodzM6IE2TdMWRfESZi5xbsyUQ65UVPv+lJsZPdBwv98XeXHinHFuzLN0rlRU+7Lc70wy0F5cwo/H40vAqcXnrXhLi6sGZhgyV65UVPv+NveQSQdqNjUP1LLmgVrWPFDLmgdqWfNALWseqGXtOdC6rrceqOXma6C7VVVVn3Hwv9/4m00tthib7La5iYGuu4OyH+mYb//NxurHGZtc9bdupB/9SM0yUMYmnwP9NtRNd+du4Almc9jGR854V+83+ReNs9qouoYXbwAAAABJRU5ErkJggg==",
        "../assets/images/column-display-type/3_6_2_1.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAYCAYAAABwZEQ3AAAACXBIWXMAAAsTAAALEwEAmpwYAAAFFmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDggNzkuMTY0MDM2LCAyMDE5LzA4LzEzLTAxOjA2OjU3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMCAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDIyLTAxLTExVDA4OjMxOjU5KzA3OjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyMi0wMS0xMVQxNToyNzoxMiswNzowMCIgeG1wOk1ldGFkYXRhRGF0ZT0iMjAyMi0wMS0xMVQxNToyNzoxMiswNzowMCIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoxOGIwYzNiNi1iMDhjLTY3NGEtYjVlZS01ZmQzYjU1NDlhYjkiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MThiMGMzYjYtYjA4Yy02NzRhLWI1ZWUtNWZkM2I1NTQ5YWI5IiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6MThiMGMzYjYtYjA4Yy02NzRhLWI1ZWUtNWZkM2I1NTQ5YWI5Ij4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDoxOGIwYzNiNi1iMDhjLTY3NGEtYjVlZS01ZmQzYjU1NDlhYjkiIHN0RXZ0OndoZW49IjIwMjItMDEtMTFUMDg6MzE6NTkrMDc6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4wIChXaW5kb3dzKSIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7IzkDnAAAAcUlEQVRIie3XuxGAIBCE4ZVKoDIo7ajMK8VAAwdYYJwx2y/hAh5/ymFmJ4CInpdSEgBM9sz4c8ZzzgkAaq3ve7r7w+SRSOZdsVmXc/jwyG8UwyiGUQyjGEYxjGIYxTCKYRTDKIYJuL8UI07mXd6sy/kCILEbDwOREdQAAAAASUVORK5CYII=",
        "../assets/images/column-display-type/4_3_5.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADkElEQVR4Xu3dQUojARSE4RzBI8zRvMl4M48QcBODi2wEs4sJcZ3pN9gyVNo8nE6lalHCt8ioUE9+WnEWLhafb5vN5m6/3/9+f39/HJwiBJa73e5+bPLr7e3t7dfwzs3EJ0QobKrJr0DrH+odwxP09PHxESFTDY6RDk/Tu0U9UhNnOBkjHdp8qKfnsl7gB0UoVZOHw+GxAv37Aj8gQmnsMoGGpQQa1hJoWEugYS2BhrUEGtauFujxeDy9vr6eXl5eTk9PT1Lr9fq03W7PNk655W7XXSw/ufc7Vwm0fuO/Wq3OBqrVpkv/M6ba7bqLpbv3kqsE6vzFrG31NMLN6t2uu1gu3XvJ7EDrEY5j3NS3SsfdrrtYpu7tzA60fs7AIW7q5zjH3a67WKbu7cwOFEe4ct3tuosF7+0kUDHXXSx4byeBirnuYsF7OwlUzHUXC97bSaBirrtY8N5OAhVz3cWC93YSqJjrLha8t5NAxVx3seC9nQQq5rqLBe/tJFAx110seG8ngYq57mLBezsJVMx1Fwve20mgYq67WPDeTgIVc93Fgvd2EqiY6y4WvLeTQMVcd7HgvZ0EKua6iwXv7SRQMdddLHhvJ4GKue5iwXs7CVTMdRcL3ttJoGKuu1jw3k4CFXPdxYL3dhKomOsuFry3k0DFXHex4L2dBCrmuosF7+0kUDHXXSx4byeBirnuYsF7OwlUzHUXC97bSaBirrtY8N5OAhVz3cWC93YSqJjrLha8t5NAxVx3seC9nQQq5rqLBe/tJFAx110seG8ngYq57mLBezsJVMx1Fwve20mgYq67WPDeTgIVc93Fgvd2EqiY6y4WvLeTQMVcd7HgvZ0EKua6iwXv7SRQMdddLHhvJ4GKue5iwXs7CVTMdRcL3ttJoGKuu1jw3k4CFXPdxYL3dmYHWn9iGUe4eX5+ttztuotl6t7O7EDrj9TjEDfb7dZyt+sulql7O7MDPR6Pp9VqdTbGRW3DzQ67XXexfHdvZ3agZb/fW35Ra1Ntw73q3a67WLp7L7lKoKN6hK/X67OBt1Y/x9W3ynoa4cYpt9rtuovlp/dOuWqgEdeWQMNaAg1rCTSsJdCwlkDDWgINa1+BHg6HxwQabj4DXS52u91Dvfjf3/hHXFu1WE0Obd5XoHfDi80Y6Zzf/kfMNcZZTS7GtyHSX2OkEQY21eRXoP+Eej+8cznxCRG38Fg/ctZ39bHJP1vh2qhtXUlAAAAAAElFTkSuQmCC",
        "../assets/images/column-display-type/4_5_3.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADaUlEQVR4Xu3dQWriABjFcY/gEXo0bzK9mUcQ3Ki4yEbQnRriOpNvaKQ8o2+ahOb58Qq/hdMW3gd/UuksOpt9fRRFMb9er38ul8uyUZtNYHU+nxdtk/eP4/H40Xyy6PgGsykU0eQ90PiH+ETzBK1vt5vZZKLBNtLmaTqfxSPVcZqSNtKmzc94eq7iBX6R2ZSiybIslxHovxf4BWZTart0oCbJgZo0B2rSHKhJc6AmzYGatNECraqqPhwO9X6/r9fr9aR2u119Op0eNnZR2t2X6r0/2fXMKIHGb/w3m83DwKnFplf/M6a6uy/Ve9muV0YJdIqj/1dsi6cGblbf3Zfqva92vTI40HiE4xg18SPtHXf3pXpv1y5mcKDxPgOHqIn3W++4uy/Ve7t2MYMDxRGq3nV3X6r34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYhxoUqr34i7GgSalei/uYgYHGn9iGUeo2W63b7m7L9V7u3YxgwONP1KPQ9ScTqe33N2X6r1du5jBgVZVVW82m4cxKmIbbn6H3X2p3vtsFzM40HC9Xic9/pnYFNtwr/ruvlTvZbteGSXQVjzCd7vdw8DfFu+34kdaPDVwYxeV3X2p3vvTXV1GDdRsbA7UpDlQk+ZATZoDNWkO1KQ5UJN2D7Qsy6UDNTVfga5m5/P5M170/Y2/2diixWiyaXMRgc6bF0Ub6ZDf/psN1cYZTc7ajybSjzZSMwFFNHkP9Fuoi+aTq45vMPsNy3jLGT/V2yb/Amft2qidmWBCAAAAAElFTkSuQmCC",
        "../assets/images/column-display-type/5.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAcCAYAAAAEN20fAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAC3SURBVHgB7ZddDcIwFEZvp2AS6oCiAHBCHYADUAAOWieAg6GASpiD8pF04fINAXu4J1nS9vTnvM7lnF8i4uVLqbWuY4wj3AXzg3ICt4O7p5T2zrlE7gh3hQtwNyz1yp3hTnC+uZ83O1qQNg9tHGTOtH/LAg+s1Lme3Ead93xnJwvBQhgLYSyEsRDGQhgLYSyEsRDGQhgLYSyEsRDmE1JorUxr+E18kBvxDW088GVqf/njnurc7M03/Gs69b+stIYAAAAASUVORK5CYII=",
        "../assets/images/column-display-type/5_4_3.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADo0lEQVR4Xu2dT2oicRhEPUKOkKPlJpObeQTBjZEsehOIO/9g1j39DWkJZcci0z3TVVLCW3RUeAWPn41ZuFh8PpqmeTgej78Oh8Oyow1hBlb7/f6pb/LyeH9/f+yebAbeEMIcNNXkJdD6Qz3RnaDtx8dHCLNRDfaRdqfpw6KO1MQZlOgj7dp8rtNzVRf4ohDmpJo8nU7LCvTPBb4ghDnpu0ygQZIEGqRJoEGaBBqkSaBBmgQapJks0PP53L69vbWvr6/ter22ZLvdtrvd7mrbEEp7Vb1/4vUdkwRa3/hvNpsrQVdqy63/qKnuVfVmXreYJNA5Rv9ralOdNrhVfa+q9y2vW4wOtI5wlLkX6qPQca+q95AXY3SgdZ+BIvdC3ac57lX1HvJijA4UJe4N172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFSKAE172q3ujFGB1o/cQyStwLLy8vlntVvYe8GKMDrR+pR5F7YbfbWe5V9R7yYowO9Hw+t5vN5krGndqEWx32qnp/58UYHWhxPB5nHT81taU24U71varezOsWkwTaU0f4dru9EnSh7tPqo7BOG9w2hMpeVe+feg0xaaAhTE0CDdIk0CBNAg3SJNAgTQIN0iTQIM0l0NPptEygQY3PQFeL/X7/XBd/+41/CFNTLVaTXZtPFehDd9H0kY759j+EsfRxVpOL/tFF+thHGoIATTV5CfRLqE/dk6uBN4TwP1jWLWd9qvdN/gaG3Nqo8iFH9gAAAABJRU5ErkJggg==",
        "../assets/images/column-display-type/5_7.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADfklEQVR4Xu3dTYriYBgEYI/gEfpo3mT6Zh5BcKPiIhtBd/6g60zeoSNDmbboSWr8zFvCs0irkCqLKPbCyeTrVlXV9Hw+/zqdTvNGbfYCi+PxOGs3eb/t9/uP5s6q4wlmr1DFJu8DjT/EHc0VtL7dbmYvExtsR9pcTaeTuKR6nFaSdqTNNj/j6rmIA3yQ2SvFJi+XyzwG+ucAH2D2Su0uPVArkgdqRfNArWgeqBXNA7WieaBWtMEGer1e691uV2+323q5XL6lzWZTHw6Hh2xdxpBX7Sd9fmeQgcY3/qvV6uEE31VkefYftbHlVWN9PjPIQMf4YkWmuEpi1rHmVXvW5zO9BxqXcDyZsYi38Ex51br6ZHoPND5n4ImMRXy+zJRXratPpvdA8STGJlteNeyT8UCJbHnVsE/GAyWy5VXDPhkPlMiWVw37ZDxQIlteNeyT8UCJbHnVsE/GAyWy5VXDPhkPlMiWVw37ZDxQIlteNeyT8UCJbHnVsE/GAyWy5VXDPhkPlMiWVw37ZDxQIlteNeyT8UCJbHnVsE/GAyWy5VXDPhkPlMiWVw37ZDxQIlteNeyT8UCJbHnVsE/GAyWy5VXDPhkPlMiWVw37ZDxQIlteNeyT8UCJbHnVsE/GAyWy5VXDPhkPlMiWVw37ZDxQIlteNeyT8UCJbHnVsE/GAyWy5VXDPhkPlMiWVw37ZDxQIlteNeyT8UCJbHnVsE/GAyWy5VXDPhkPlMiWVw37ZDxQIlteNeyT8UCJbHnVsE/GAyWy5VXDPhkPlMiWVw37ZDxQIlteNeyT8UCJbHnVsE/GAyWy5VXDPhkPlMiWVw37ZDxQIlteNeyT8UCJbHnVsE/GAyWy5VXDPhkPlMiWVw37ZDxQIlteNeyT8UCJbHnVsE+m90DjJ5bxJMZivV6nyqvW1SfTe6DxI/V4ImNxOBxS5VXr6pPpPdDr9VqvVquHk3l3kQmzjjmv2nd9Mr0HGs7n86hetMgSmTDnWPOqsT6fGWSgrbiEbzabhxN8F/H5Mt7C4yqJ2bq8e161n/bZZdCBmg3NA7WieaBWNA/UiuaBWtE8UCuaB2pFuw/0crnMPVArzddAF5Pj8fgZB//6jb/Z0GKLsclmm7MY6LQ5qNqR9vn236yvdpyxyUl7a0b60Y7UrABVbPI+0L+GOmvuXHQ8wex/mMdHznhXbzf5G9V7chccXp4PAAAAAElFTkSuQmCC",
        "../assets/images/column-display-type/6.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAcCAYAAAAEN20fAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAABSSURBVHgB7c6xEYAwDATBx5VAZy5NneFSGA+J5wrABLfRS9EdVXUnOfMavfdrjq//bTmyc7f8hCFkCBlChpAhZAgZQoaQIWQIGUKG0AwZy71tPyTLKPdnxJI7AAAAAElFTkSuQmCC",
        "../assets/images/column-display-type/7_5.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABQCAYAAACNij7AAAADVUlEQVR4Xu3dTW7aYBgEYI7AEXI0btLcjCMgsQHEwptIsONHsHb9tjGqBoeB2s371TNIz8IBJM9oZCyyYDL5fFRVNT2dTj+Ox+O8UZslWBwOh1m7ydtjt9u9NU9WHW8wy1DFJm8DjT/EE80VtL5er2ZpYoPtSJur6XQSl1SP00rSjrTZ5ntcPRdxgC8yyxSbPJ/P8xjorwN8gVmmdpceqBXJA7WieaBWNA/UiuaBWtE8UCvaYAO9XC71x8dHvd1u6+VyaR02m0293+/vuusyhj5fyfuVQQYa3/ivVqu7E7Ru0dWj/9iNrU+W95FBBjqmMr9LdBZXSexyrH0+yvtI74HGJRxPxp4TH+FKfXblZXoPNO4z8ETsOXF/qdRnV16m90DxJOw1an1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+ZlPNBkan1iXsYDTabWJ+Zleg80fmIZT8Kes16vpfrsysv0Hmj8SD2eiD1nv99L9dmVl+k90MvlUq9Wq7uTsceiM+xyzH1+lZfpPdBwOp1GWeq/El1FZ9jjWPtkeR8ZZKCtuIRvNpu7E7Tf4v4yPsLjKonddfnf+3w1b5dBB2o2NA/UiuaBWtE8UCuaB2pF80CtaB6oFe020PP5PPdArTSfA11MDofDexz87Tf+ZkOLLcYmm23OYqDT5qBqR9rn23+zvtpxxiYn7aMZ6Vs7UrMCVLHJ20D/GOqseXLR8Qaz7zCPW874VG83+ROc0nIXluNaTAAAAABJRU5ErkJggg==",
        "../assets/images/default/avatar.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAs2SURBVHgB7d0JU9tIGsbxlowN4TBXIJlsZrK13/9LbW0q2QRIgHAZsDx+ZBwoxn6xka0+9P9VXKZSNYMj69Hbh9SdnZ1fDRyAiXIHYCoCAhgICGAgIICBgAAGAgIYCAhgICCAgYAABgICGAgIYCAggIGAAAYCAhgICGAgIICBgAAGAgIYCAhgICCAgYAABgICGAgIYCAggIGAAAYCAhgICGAgIICBgAAGAgIYCAhgICCAgYAABgICGAgIYCAggIGAAAYCAhgICGAgIICBgAAGAgIYCAhgICCAYcXBo4EbDB5//qfMZdnoHX4QkKVTCAYP78VDDoqHv5tdViYl0w/DP7kbhefh77A0BGThRoEYDPrDH+cPwtT/60PIRn/6v/++DMkwMFnWeggOFomALMSoOgyKvnusGDX9Zv2uYRjHoSmDkue/qwyqISAVPIaiqDUUFlWuQf8hLHmLylIRAXmF8iQcBqPsUwSs/IzDyqJmWJavlGHBfAjIHAbF/SgcgVSLWZV9ov7dMCD3BGVOBGQGo4pxH10wniMo8yMgpoErhidU6E2peT0Gpe/yVtvRmZ+OgEw0KCtGUfRdyhT8/n3P5aomOafCJAxv/IOqxm3y4Xiq0MWg33OTZ/ObjYA8oVEfXVFj72u8hv7N5b99GBY8oq6WmtGkmoWqSTY8HnnZ5KJvQgVpYJPqJaqkOiY0uRofkFE4mtikeomOCSFpdEAIx0tG/ZJmH6OG9kHCCEdRFO7+/t71er3yZ70kz3PXbrfL97W1NefX6Fjlrc7D7fXN0sCA+A2HQnB2duZubm7c9fX1TP/Nmzdv3Pr6utvY2HArKz6+suaGJDs7v2pQ/fQXDgXi58+fM4diGoVke3vbU2XJGheSBgXETzju7u7c8fFx5WA8t7W15XZ3d2uvKAqHQtKUIeCGBMRPONSUUtUY9y0WTX0UhUQVpU5NCkkj+iCFhztxT05OyoAsk4Kn36N3BaUu5RDw8JjmedulLvlh3vI29ZonAb9//770cDylKqXfWafyYawGTK4mHpDRla5OuqJfXFy4uul31h2SorhLfo4k6YCMZoLroyt5nZXjOYVEn6FOgyLt2fZkA1L3E4DjYVzfFjGUPI9RfyTdplaiAam/aVV388ZydHS0tJGzSVJ4HHmaJAPio2mlW0ZCoc9Sd1NvMOyPpCi5gNS96oiu1L9+/XKhUUBqrSLlKpLpNbXSC0jNTavLy8ugqseYj+Cm+DRiUgHxsWaVz1Grlyi8dRpPIKYkrYDU/OXoPqvb23r7O/PQyFrd1S21ycNkAuKjeugEDF3dVWS0eHc6IUknIB5Ke53zDa/lo8KlVEWSCMhg4Gd19X4//BPBS0DK7yON1SgTCYifE1V9kND5CnEqVSSBgAy8fRkhDu8+5+szjipI/LPr0QcktYWl0zFI4ruJPyAs+BasFL4bKkgFflYYmY/Pz/h749GIRR0Q3yVcz4SHzm+IBy72u3wjD4jfEr66uupCpwXofIp90jDuJpbnCtLpdFzofK/MSAXxxn/51iJuodOqjF5FPtwbbUBCuDKpfe9/7dzp1AQMYSAh5ipCQCoKuYp0u10XAgLiRRiTUFoCNMTRLFWOcMIb74RhvAEJ5KqkcNS99OcsNjc3wwluxP30qDvpoVBAQpo01GfZ29tzoRhQQeoXUrtWV+qDgwMXipA+S4k+SN3CO+AaTt3Z2XG+6TN4H9qdKM6QRBmQUC9Iatao7e+LRq1Calo9FWsRoYIs2OHhoZeQ6He+ffvWYbHYJ30JFJI6m1uqHPqdYYuzhDR0l9vlU1NHnffT09Ol7jClIIbQ90kVAVkinbiarNPavYveM0S3uKhqxPBMSsyi3KNQz4HUvUB1VVoiSKswXl1duSoUDG23FuZI1XSj3XHja9Fz+amJTmi9tBKKQqIF3WZdeE6h0EsVKYaHtFISaQXRrrU9lwJVFvVRtPrIuK+iEOil5030wFMKochbq1Hurx5lBUlpH/vYmkqvFet3FumlqRmb2Kclzu8s3tqdUhlJXYSd87FoP3lGFUENqCBYuhg752MRD48w3BmPeL+raOdBdFWK9SmD8ZCu3rX6un5+fjvKeKi31WqV75oxj3XWPOYKEnVAQqeTXvtz9Hq98l1zHlVXWx+vVKKJQ/2suZLQ50liDkiUE4VjmiwMbcUMzY6PZ8kVjDpoLkVB0X1fwS1DlKkKhr/A3jRxB6S4C2IF8XEotO1ynXuTT6LqosBotZUQwpLlaiL6Xf60iqgD4vOmRQVBNx/q5TsU0ygs4xsbffVfYr1JcSzqgOghnP79ravzYRxVi/Pz84Xfvr5sqigKS91Baa2Eu/LkLCIPiCsrSB3bIKg/8ePHjyh2trXUGZQsGzavWvE2ryT6gGh5/aK/vM001Xw6Pj6OrmK8pI6gZLnuRG65mEX/PMiofathxMXnXP0LPQ0Yah+jCg0oqBoqJArLMqRwm370FURUQRa5UUsqzalZqYp8+PBhodUkheaVJBGQRY5mqWqcnJy4Jtrf31/YOsOxj16NJfHIrb4Ivap01tWM+vbtW2OqxiS6MGjGv3rfJEsiHJLOHX/Z6zuDalJ9/vy50eEYU9/ky5cvlW6JyfJ0ljpIJiCj0ZL57/nRCfH169fK90ilRMdCFwzdHTC/LPqRq6eSumc8m/OL0QjV0dFRkqNUVY2bnDpG80ipekhSAcnLL2e2KqIvft4vv4nmO05pVQ9J7qmjWa5ghGM+sx6v1KqHJBcQXcGsERTC8TovHrcsveohST63mk25vZpwVKNjp3miSfI83mc+LGkGZHg1e95h14gM4ahOcyXPh8PVtIr5qUFLsisfPO2waz1cjVZhMTS69Tgsnj0c6zQlvDRIVt7uoHBonoOh3MXRsdRkot7ziB+nnUXSa+eo7N/e9pkEXAId017vLtmm1Vjyi0t1t3fc1tZibsDDo52dXbfZgOPaiNXXDg/fu05n1WExtCXD/tvQ90RcjEYEJG+13Id//elWVuJ/PsE3hePjx09JznlM0pj1O9vtzvCL/YsdmirQsVM4Vtppd8yfatTZ0h42sz5+/DcheYUmhkMad6asrq0RkjmNw7G61ozdsJ5q5FlCSGbX5HBIY88QheSvT/+h425Qh1zHqKnhkEZfQsuO+5+fCMkEnbK/9qk8Rk2WxKomVRX9vjs5+e5OT7mZUTSxevjufWOGci3p3mU2B82THBz+UZ4QP34cu6ZSf2N//8Dt7O47jFBBnrm7u3Wf//dfd3+/vOVMQ6Qm1fv3Hxrd35iEgExxcvy9MdVkb++t293bp0k1AQExqJp8+/8Xd3195VL05s26Ozh4R9UwEJAZnJ+dDjvxR8k0uzR8e/juD7e+vulgIyBziD0oWk5UnfDu9q7DbAjIKygop6cntW3SWZWaUnouptvdcZgPAang6urSnZ+fussL/5t3Pqch2253221sdodNqQ2H1yEgC6CtqH+dn7mLC21Kc+ktLArF6uqa2+rulJviMCpVHQFZAlWWy8tfrndzs/QRMO1gq1GojY3Rts+EYrEIyJKpuigkvd5N2blXaIqiP1f/RZVBJ76qQ7vTLu8dU7+i0+kQiCUjIB4pKP1+Uc63PKcTv9XSKycEHnEvlkc68fXSvATCxBNDgIGAAAYCAhgICGAgIICBgAAGAgIYCAhgICCAgYAABgICGAgIYCAggIGAAAYCAhgICGAgIICBgAAGAgIYCAhgICCAgYAABgICGAgIYCAggIGAAAYCAhgICGAgIICBgAAGAgIYCAhgICCAgYAABgICGAgIYCAggIGAAAYCAhgICGAgIICBgAAGAgIYCAhg+BsloETaF+QZAAAAAABJRU5ErkJggg==",
        "../assets/images/default/default-avatar.png": "https://static.topcv.vn/cv-builder/assets/default-avatar.fc9c40ba.png",
        "../assets/images/default/placeholder.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF0AAABdCAYAAADHcWrDAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAdcSURBVHgB7Z3LbxNHGMC/GdsNGBISQPRQKHZIAHMhOSCqiodzKD3iiFsvhf4DJeLUShXh0kqtEHAoVU+EQ6EcaIwqVQoXAmoRFWqTSjQmzsMuShFtQ2JScCDJznRn6QQ/1vY+Zl/O/qQoq/Ujym9H32N2dxbAx8fHx6deQCCY1NhYnFKUwBgflr88AisQ+f/OEYBhSsjF2Pa2PpXXxTA0NNS8pqnppCz8OPgUkiVUOhZrbx/kO4RIT6VSERxs6Je/rQN8VJEo7dnVvu0s28YgABRquOALr04AoTMs9LJt0yM9lR4/KsfvC+CjhWz+3yedpqWPjk9mYIUmTCOwMGMqvKTGMnHwhesiiNBhU9IRJn4c1wkF6DAlnRJoBh+9NAupXnz04Ut3gCA4DEZz0BBKQSgwBRJpAkKbYH5hL9QzjklnsjesPQfr1lxVtgtZlDbDk/wRmHn6IdQjjoSXhtAItL5+AFrWXigTzmCjfmPjOYhuOgBBebvesF06E7plw3uqss2810vYLn2zTolMPAtD9YSt0ptWX1Uk6qVSGPIqtkpfu+o6GIUdsHrBVumh4J9glFAdJVRbpQdMhAiM6ye82FqnS3LjY/QPErlxsoLp/DQMTA7Ar49+UbbDoTC8uW4r7N+yD/Zt2Q9WYKv0/Iu90BAcASNY0aUOTAxAMt0P+cX88j62fX86pfz0j/bDR29/DBvDG0EktoaXp8/fASMsSm/A0xeHQCT997+DS79/UyS8FDbyP7v9qfJbJLZKn194C/IGRuzss2MgEiY8mU5qeq8V4m1vjh7Ofq2MXK3MzR+B3LMPQBR6hHNEi7ddOkuIU48vaxrxbIQ/yn0BojAinCNSvCMTXmwWkYl/lPu8LEES2qiM7qnHl+CfuU9AFGaEc0SJ13Q1QDqT6dgejQ6X7k+NTfRihE6CAHjzww6IaEQIL4RVM2aqGk0jnSyROFgMk+0F4QyzI76mdHbJHMJ4N3gQK4RzzIivPdIDoTh4ECuFc4yKrykdIUiAx7BDOMeIeA3S8WHwEHYK5+gVX1X66Pi47aP8OZmHe3P34O7sXeX3w+cPNX/WCeEcPeKrTngRAglsUyXPZN+avqX8zEvzRa+tf209HNr0Luxp2VPx804K53DxtcrJqkoxxgfBBmYXZ+D02GkY+GugTDhjZmEGvp26DNf/HlD9vBuEc7SM+IrS0+k0uzg0AhbDhJ+fPK+IrQU7KKXi3SScU0t8RekSClgez/UI5xSKd6NwTjXxFaUHMLK0ajEinMPEnxs561rhnEriVaWzLpRS6+4hMiOc80B6AOHmMLgdNfHqI93CLlSEcE64JexJ8arSrepCRQrneFF8Beniu1ArhHO8Jr5MuhVdqJXCOV4SXyaddaEgEDuEc7wivky6yC7UTuEcL4gvki6yC3VCOMft4ouki+pCnRTOcbP4IukiulA3COe4VfyydBFdqJuEc9wo/tVIN9mFulE4x23il6Wb6ULdLJzjJvEF0o11oV4QznGLeOV0Xa0ulBLaorZ/Mj8OV6aueEI4h4ln5HN5cApFeu1zoUR1tYsvx7/K2nUOVSROiqcAOUVZrS5UDj1bVV/AMAwexalQgwB+wxq70AhbArB05w/dyWG2BiF4FEfEU9KHtXahq9Y0VnrfKfAw9oqn2TsnbvdhOXRomuAKYPy+2v7vu5NsrcFB8DC2iUdIuY8HY0Q1daFyAoizrlXtNTkbd8thJgsexmrxlNKeOz0/DrJtLLf+mtfhwqHXzqjtT3YncwGATvnIXAQPY414mpWzZ9fPJ346y/eg9MTkrB7xhEpdhevGlpLoT0SWKPTKmx3yH/Pkde352bzZcvKPxlBjdm5hLrkah/oGewaLig2UHs/coEDjoJ0sWXzRFYvFsuBjCEwQuQb6iOBQw41K8d2nNrgB4z55sktvre2LNwGORqM5AtRIrc3ED42MTRwHH10s39I4OjbRC8ZvT8wSQk6prYrvU07RfaQmxf//WAI6KJeONykQz87L6GJpKau3qCi7eTeVyUSwRGX5cFCWFwGfqtQqodWoesc0u1NaDhtxICiB2EHwKQZBdse21ijoRNei9Wy9dIRIAlEU92rjIxKEUN/2bVHd66IYflLAUCbTHJYgLre5iZUaiiQg3bva2nTfmSDskTssF4AkxTFgJRTpmVrwKLkdba0tYADhD5fiKKGIPUmgTvOBPKiu7WxvNXQFhWXSC2GhaNUSdNRTPiBAjsXajPUltkgv5WVZyq4m824+IAEUjUWjWTCAI9JLYaWpJEkdXskHlJKbO9vb4mAQV0gv5eWjfEgcAYq7MR+YCS0MV0ovhJemlB0El+QDM6GF4XrppRSUpnFH8gGCYbkL7QQTeE56KYVTFRjDbqvzgdnQwvC89FIszQcG51rKv6aOKZqqoCZPlMvCCUZdZmL5q69aQRROVSgHQGM+oOz8QBAdFSGcsaKkl1Jr6lqRDag31h4dBIGsaOmlKE3aEjQHgpB7Jp+C7JTPH4OPj4+Pd/gP0p/r4IAvIbkAAAAASUVORK5CYII=",
        "../assets/images/feedback/feedback-success.png": "https://static.topcv.vn/cv-builder/assets/feedback-success.61251432.png",
        "../assets/images/feedback/fine.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAMGSURBVHgBvVbLbtpAFB0blMeOfkGdLyhZJ1LorrsmXxCy665UyktsMDsei8IXxH8Q+gUxEkjdlT/A/YK4O16CngMXazq1g2maXGk845k798x9zlhqSyqVSjl0bKrVagVqS7LSMF1eXhYymcw5hgU0x1gO0Pz5fN5tNpveJllPAl5fX5csy6oo0QgUonUXi0Uo/w7W32nrAYCrTwHHAt7e3joQeqdWGoUQ2qYWtVrNj+Mvl8v52WzGw9EKCnsHtm2fgT/YCChgD2plus54PL6Ar0KVgrgXGroCHKB/b4JaSWBgroLZVf9AkONCTiUO1NYZcbr754KRuJcyKEtcE1FmPbi6uirC7p8w9Or1+hf1TOr1ev7x8XEeww9HR0e/+v3+d85HGgKMJlBysv9C+/v7F2oV2ZUIhx9qp1ZB4plOlkRPRSav67ohTNqGEjn4tRABYmL5Ax+29Q3Iw8ru7u7jzc3N1w1YijzkZe7q87Cczx7A5zrgCZMZCTvQmTF/KMyFTYDgOZPhqT4vuUuzFviflXkHrWsKAWAJWofZbLalNlMJoKcJvJT9kSbPSu5R+NDkEn8WVQpqNBoddJ24NVoP8tXe3l7OVq9MNlCXZQume6NeiKDdW/a0mC2h+5OBo16OWAACDtYm9fVcMSlNLibxIMcJxjU/AkSueOxh1oK5AfnV2tnZGSYdhsQLGjk4BO+ducZIl36ZBZYm+JHROplMDvTrCEBFrQB7GH9DC6bTaYiD5CHos5IcYy5KtK73MgMY/QHq80GkoTBXaVYI+eOUcLSHeTIHaEWM72GRH9SIY4JhbxdPkEMdTCzminZRfbYM8z2IABeb/yriNKuY3ZEp3uyDuJcAyyKAeC8OIOswFlC/gJNA09AaTMVcwJueGJ5cxoFKQYxUmJouOVVpnhgGKP2TlymPN4lZ3NfEKIVpTyQic/Qp/oupHlEGcFHeJo5MMXoJGvAHazm52qJnJIMPrkgs9qkewgRmsEg1cvQ1Vil0PnM56Rm5NWDMARz2o9EoTPuEXNNvIDyem/hE5FEAAAAASUVORK5CYII=",
        "../assets/images/feedback/happiness.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAPBSURBVHgBvVZNUlpBEO4ZNBJXeII8TiCeQL0BLPIjSRW4UpOFegLxBOAiUVdiVQqtykJyAvUE4gnAG7CJUlq8yffNe0MGBAJWKl314L2Znv6b7q9byQT04dCsKCVZPMsSSiBKUnbDSNsoaeDt1hipn2+pq7/JUuM2176ZHdGyDaYgVnCH34YRaceHAzyLJjYA6y0o3ofi6lQK4VGgtFwoIxlFL0QOQpEqBLVG8WuRIqQV8BnEileH8T9TuHZsCiqUig0brL1PSqW+rtoyIeUPTQln92y4tayfbaj6SIXvjk12xsgFXlvSlVzti2rIC8h6rORS6K2SIpSePlMYh+UGK+1wRDhepNRICtex5OTpnmZuIoz/QhnJykCUKFNrGzXpKYQ1RWZcGGVYa9BSmZCyJyblf9srgUw8mffMeIlDunZkmnypbaq0p2gFlpXJzG9kXuVsU+0OU4REKyPRmKUpZij+d12yFGHEY0eauMs2zqf1JxZ15N2p7xXjDyFM8QNouwbPDgwrD1VmhNbfkpeG4/vi7VdjDa1GGc71wDoRAkHis1UnBJsl/ndx2bBqp7alaNQVlfpho/Wxsip5yMsc4N5sQrYdXxjLJlppIgVrxr87FSFHw18LQ/k56F2n04O4a7fGMzjfQOGn/TWiFHQta2xkEIpbX9D9nBTxrPprZ59VBdanfRCgIPAt1Aag7NcrWX1I9iLnwsYECmZ40dDc9PdGIcuwchnGO2wNjrUZOS3/mTTvD6FaGNyYpv4mOYtkeUNdGipb+Fj0N1kqWGsSEGR6ZUWedWXhyOWKjjMs8K2aSdoLbqPwt2VKUuwUKP6neQDAHyOipo3E0RqdOl4vOgZXrESZYcU+ivLHZs+BiJ84OpbNqcBCWx7QRlRH7+tL+49H5hJhWAE4lM431P44ZT3EgRe1DbXUt+dB54zVrCz0lJMdixolxzg7J7nHR7lEFEo4VOT40ElK3RlF1Hn9AOsTUuB0wOtBXWYHvWb94Vnnt/I2bhjCp64s/RhovHEXt+ODXTDRTOOGKTeGAABK/rkYk1njLdcYnjVgovqweYTezHcki/2MijoIJ7YW3hv3nte+PPZYRCfV9RqwGmBiSp+MG4ImoTxKwiQwhEUjRs6fa/qQhuMdGWB1ytYh4z8FMQr2TEJu6BmydfwQ5ahvCKK3Cu0llNNxYyJML+jQZqmtN3SX3ERjok95Ik1UyIFdiCdtJVFRwxgCf6a3T+NCOWBnGSVzrEJHhLouR30Oxt6kzeyEhDs02KsEivr7BKP+b4Vs9L1jQ4Q4AAAAAElFTkSuQmCC",
        "../assets/images/feedback/sad.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAMBSURBVHgBvVZhctJQEN59Mja0f+IJpCcQT9B4AtsTQHR0xn/cADiB8ssfDiaegHqCwgnsDUpPUJxxLIJm3d33KEkIEIRxZ0LCvt39Xja7+z2EHYUi34fp1JdnfDcdw46CZYzokxdAxTT4MeCrllsdc5ghJMkIX0/jbbE2AlK/2gKDbX70nWoCBCO9W/caID1brjN4Qt1NwIWAFHk1Xor4ClzwHoAZYvhjWGx/UgeiFkdrONU1QHKB4WrKsRjMXIGmji4BjkIMJxMoIepLpmOBJdX0Ig+K68Ggi+HPDvyDUHTc4Vu7CNRkTc1gXzAR59vVb6yfpnBXJ03eGfEVwYGEoupAY/aPWgtd6g2pbe9JFw4mRyFI0ZlH7QygvB3YVMb5j6yNXlLytlpsiVQ4+FwfwQMgl3RgTea9bACPdza749S8h61gYsO2qfSpmGToHhpLQIQz/p1gOL/ORjHP3V4D2IqIF9a0cp5Wc8aGYHs5kP8Vp+f+wdFKEExaDDoBnH+AbYLAtnAOOFu1lemE8FJSXrG9Jw50sxLDfs8mlBBuBR4ScLlm2Q4OHvoG/rMwoGfRiZ6UdaKPXm2X6uXsPdUb01lFSpc+H98C4tlGEKUoYQ6sg7LDTEYYb5aG8Jt6+EaLYx1i3Y65ZeOL8UOvZID4TXT6VGTGcrUSfOfrC19fudBuWXcua9IWRW+tTKIbRMFwVYpJrH2SmMCBpzzmMv2bWsWIHXyVpSgbkHgGI/ffTADDrL/SFghBK9TS8fjOPj0+TdMR66Wv6tuGOfWZIbjJXd85X2WfG0knhvenWYeo2rLDuzqAAwnXRmyHt9csNoiqVxbUa8OeIjEc+3xL63N9SJL/Mas7+4BaX2Z+rczkIr225YgBsdBV0dmkGEiq9FeklVvmiJEDlW9Zd6oY5vMevs0N94W99qgQgBGm8G1F/2mWOkRlgYUnlZhrTiWNzqA4dha+YxI/tc4ZuV877MsdhAVYONPSWC27CNz83Lto4nXHyJ0BVzfgGIbncNkj5EL+AquLasiYwLYWAAAAAElFTkSuQmCC",
        "../assets/images/feedback/smile.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAANSSURBVHgBtVbRWdtADNYpGYBO0HSC0gnqvtMv9gSECYAJSCZoOgFhgji074QJ6k6AmaB57kfu+ks6xw44IYSih9g53+nXSXf/L0e72PQoIeKUnPtMjnoYOYhfFhSooBB+E/mcsp/z51y57UBfB8R8gbee/g90Ty4U5AEkxjLuPjYCKMn7EWU/Ji8DnKY9OL7E10R3Qe47QCaU5eXG+UwDRHQcgwOw+9I2/yng9Cgl7lxa1G4EoDEWLmhXm6VDAF9ooH55gjTnmwENbBojzABU0D6mOw43JLv1y6wJ6h5N+mWRtadjT9AD+PtU+ePVhPrj68HExIdkSXx2wmU1bDu004jBMKL+9TBGiBo+HNq0bvFsHXX+3x4ix7NbroKeoqaMmnp/IqfXAGf9O332Zx90oUQUKG24w+IwQTCjDWBn6rS+HnKFJhTcub5zEP8L8c+YnJAWN1zZTD80sHCrUfm4iNwQcw9bwBI4/EZ20M51DcGXk2sCX5IZj2slGCCQLgZTyyxPzAOPyT/M147zNJVvyYZTW8RazRtpn2AN1rti9Z/oQtjKUd6/Ad4htvuO3tLyfonfP6xgJFz4xiaUCB5GSlHo4O5WH+Tyu84p/Q8LYKosn+u78C/TQffpLFEF1EuI+jXm6D0QS5LaNkwAF9hus35ljC7ZmwDkNDuwVgh10M69Fyw2AJWYaDy35zKlvW0Zrw/XpzqeFcb9uyW9I+A+M5m0oA73aV8zDV0gQ3a1zDdokwrskON98wN9VBc1oI6z7JheakKTqokVkagNIkbO8RSVxO7U+FBtrGPkx63sshFMFIIj6/B4Nc4qzKW0IKYW3glHAsyfUb3LLE6+iVE/AyZaqvJGUUtLfZ+l1qIYRkMPr8E4kkbTriJGfAgnU10QcLzDEpzYrSnMFCXRe2vtyLpwmybe6bgIA+0iwDoOEibXrGfFmXX3JjXzPGwE0yrAj1qMNI07etoE2UlLkC/sWo64BKZAc6JOvqaXzczYjltajHXQ2ESF4UYNbDNJMftTlTLL1EkTrB2w2k3VBFXi6/lqe5vokXJ3FgOFlvJgtzZx3dEgKnkvjlinXdGfOFcGWX0v9TRm+WSTy+2ANXCiQq21W+u0pYb3qOVcCaRShi32D1rZm6+GrzlFAAAAAElFTkSuQmCC",
        "../assets/images/feedback/very-sad.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAQFSURBVHgBtVbfbhJdEJ85Z4v9vnz5gk/gotTEq9JEC3duIzRewhNIn6D1CYAnUJ6g9AnKZdPWdL2yVBPwykRt2T6BeKMR4Ywzuyxu+a/WSQi7e+bM7/z5zW8GYQH7kL3vIOq8AngISDYAxoMR6gBhywC8JerXV47fuPNi4azBj7kHRYWqxI+2Hx7hEola/NgZuMj31Z8LAM+QqSSPXtd+CfCdk7FvLNEujzqyCwJVVQpqiYNTb5J/+3HGNgaKCPRksAjvWxc37rnj/mOAHx+t55WGXVk1AVZUd/l5wnU7sKCdb2bKDFwCog4vYiv54qw+FTAAw31ZIZIpJI5et+A3THZMhk740TZ9KkRBh4D+McZMkz91UOHGtOP7ZVCi+Lfvai08XhU63IjJijB+HWBiEkNOCRDjPh8G5gMKG/nP7gNVrgNsCMpXIjwQ8g0wAsAB9b2Vw7MyXLMJ6YTpAwxQ7WzGgWB3e/AXTBguaSUYIiDKIOVlwFKqFjqdZ9M7F5vpdtNxwoT21eYil24KGcJvQrSLzfVPMhYF4blNiRG+Sw7Lv6iVxWe6SpwziYOGFzoQMlOB7P+Xvj57n3tQZXWJa6Xl4u1o4GVY5tV/ARljv8LSd90xMdrmoRTHqA53ybw4z6UvFdJDRUgpg/A2Gih5dFozRHuIULRQNTlgkFOEW1FSyXEZUk9lTPwoRm3Osx3D1yMxojFZFltA7CepoBHaMGLJo7Nie3O9zsKc4rPgS8d6cgKDJTAfs2uMKQbHp9zkQcMd9VMi9JwiFsywxKGvEHWYY4Ndl2EBs3xxJrgJC1qbidKzerY893qWN0mgJxkS3iLGkiOVCavzJggTNeoS37mjQfvfdIyAmcv10FRnlSQxnytcNxXv7iW/21G6j+0qmyn5xOFJ7F81ymzJDyR3EeKc1Lvn2fXStPmSPn7N5GJtMU3rjL7dCy69POosksTjZWZYC7Uq3L5KnNpApPdZg8uce5/vHDeej8aIxaDo71L36ypxfOrys6cJtqOJPjRUIgweaixM0llfpLv/bIgPqUBExkIEhdlbOXjj+lrK+VURyv4X+7Iz6pw8bOQ54NosUZd8FB/d/XcMUK4DghyuBODhQC59wsnp9Mis3f3NwjtqQY0lyXHv9mEjId+G9RA0Cgk6rBj7wSVfC9iJxJQaG34fAsqRMW0ZFHzHPwFlXU0FYNJi6CtyqKKOSVYW1sECryouRzGL6pNMSCdzRFclhukr7mdeTW+iQos2QSDsM1Tr9tTeNFUR9TGWeYIKdoIelV6iUsVJRJvTCGe4EaZhIxx22jzJkzeupXEETP0cl0YYK6OVYmHA4Q4eZxxu9/LISgNXOm1eAOAlq4/L7WWdd+TOi/UD44ACeCBavH8AAAAASUVORK5CYII=",
        "../assets/images/guide-tour/arrow-large.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGsAAAAsCAYAAABi4kbYAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAANbSURBVHgB7Zw/dBJBEIcHn00oQ0piia12mlIsY6ulabW1tbRNmzw7W21DS8pQRkophVIsSUnmB7PJcOwddwd3t8B8781b3vIn7Pt2Z/f2lhAZ+8F0Oq1znHF853hDRqE8oZywnAYXXzleS9UJGYXylHLAolpcfOKoS9WEo0dGodQoI5LuPqiqMcdFrVYbkVEomWSxqFMu3qmqAccli5qQUTipZXlEdVnSLzJKI5UsrPjocSEBOizqioxSWbkaZFHvyUQFQaIsSX1tVWWiKiQ2DXrmKBNVMV5ZJipMltIgi3pBJipIFnYwZAvpo6rqRkXJaw44jqRE1CUOKB13NN/1AGNPeWfXbss8yMKmLBdfaHELaSirwUOOZxwNKgn+uyjG8j0m8hiS/0npnvu/L2If5izPtdS2MaRHsSNd7spW2EyWjJ52itePJVzvdqUvrflwKdPRiJQulR6p+uh78uK+90iVo20alS4NrvrCXY6bKnuozJVarguIhcxDSpbqXv888rmzdE9zedjrHHI7kzpcZbiRhUZiuX7M0Up4PRp1w9EPtUFKKtrUpEWhzZQfg7b95ejTXF4QaTTuOgvCsIRHL4xrIMRhxA1CFeeD24b2QB7KY/U4CbTvD8076W+qiJUbudJTIe+E4kcdRluPGzKgLUQyS1MCHRQSk1a+tzQXV+oN16z3s5y4t+TvjeiBV2U3oghUW5Fh4uRhvsNI65aRKjPfKXZIY7DTgQZFG4LUeE47hEwNLrv4xM2mhSI7am5ZGm4Irs90msSk/I12lBXiCssuG5HlkMkbaaO3TYuOdZCOigxTuLSNytpnZLS5aUEDaT9ZWp/WxGRtmARpWDF31sk4JqsgYtLjWqnRZBUMS4Ow00g1hHUoIyarBOQyB7ef9CjDddlFlrRoskpCdkkwyvQPOCDqPK0wk1UynrSYWpjJqgA554LjE+6WTiphJqsiZANBH6NYKSz377OM9ZCN30tVhcXH56T3mKwKkVtK+scdTTli4cVkVQwLww3ca1XVll2QJUxWGOBspp6rzmSpv4DJCgA5YfVDVWH+WvpBvckKBJm/9LGIdnR0mayw0EfVIeqVftJkBYRndL3Uz5us8LhVj1s6Feb6PxhGcfDoumZB2FnC8n2gj3ffA/KySPOvEG8eAAAAAElFTkSuQmCC",
        "../assets/images/guide-tour/arrow.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABbCAYAAAAhpJj/AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAPbSURBVHgB7ZuvU1tBEMc3nZrGYqmlssiCbG2xrSyyU9t/ganDoovFgsWSulKLJbJUYul+yW44bvJ+kffe7R37mbl5vJDJTD6zu3e3l0fkOI7jOI7jOI7jOI5jjgk9M+7u7rb4ssnjNY83PF7xmAZvueZxPplMZi/pGSBCtnns0GMRq4C0DfxRtByWAhkfaPGFY255/JOrMpX7GW6KTCuRskcSAQK+9JzHbx5/OG1umj6nKDmSPh9pUUuUK1oI+cVCbjt8XDlyWMwnWqSQAimnLOSKnkj2clgKUucbLWYggOg4YynntCZZy5HagojRGeiSx3HX9KkiWzksBrVlT24h4wRrE+qRLOWwmH1arFkAZqCjNrNPV7KSw1KQPkgjFYNIOekrjWKykSNivtND4UXRPaUBeUH58JVGFAOykCM1Rhd2o4gB5uXIrKQ1ZjQxwHTNiabrUcUAs5HDYtBiUDHnY4sBJuXIluCL3M5ZzAklwJwcEYMpG1M3FnZHlAiLkaN9GCzsDodY+bbFlJwVM1MyMcCMHEmnsACv3XJYFxNygq0BQLSckQGsRA7SSfu9h0NtJLuSXE5wQgCS15mQpHKiOnOTYqFXR+rICY9PDskYyeRIOpmZtleRRI7MTmbTSUkVOe/JcDopo8uJirDJdFJSRM5ysWc1nZRR5XDUhOn0k4wzmpwonS7WOcMeizEjB2K0R2Ni79TEKHKiNc2p5SIcMlbkaDrN+z7PHpLB5UgDS4twspbnUxhUTk5rmlUMHTnLLQKP5J29rgwmZ0URNtHA6sKQkZNlEQ4ZRE7ORTikdzlShHfl9iK3IhwyROSE3b0sVsJV9CpHosZ0d68LfUdOOHVfUOb0JieKmmz2T3VUykGfF2sV+dJtCHvCWU7dMXWRg+l4X0YtcdRQIdTJ+SvXTWqmuKgBdXLmcp3WpVapUQPayAFbNe8rMmpApRzZKGqfd6WcKGouqTCapvJruW5X/D+U9qglAXE8fshoeujUJE1yNBqm8ohgTHiasFzX8HtRxHE+tSHjFWVIrRw5PtE+zCM5IksL9Sx4HWmmYpL/6HEd2qyQNXp2o9f1/kbPoOTQbp8ejmAOcjifqqKNHI2KjSi13sr1fg8lPZzP8hrEZBsxSqOcKLXuC7P89F6L7Cx6RgFLgIOi91YRGj07MvPo7IXZTB9wBxBj5geP69JWznLW4vGOHlIq/BFSUWJA60eKOGIwA6Hm4MvH65bixIAu/RzdN8Vi7h/eKE0MaC1HCnNcZIuYlaro2gkMd91ZL/Da0EmO7Lo1fY5LFvMkpH3atnXqOI7jOI7jGOQ/FMFlb6Qbk0QAAAAASUVORK5CYII=",
        "../assets/images/guide-tour/guide-block.png": "https://static.topcv.vn/cv-builder/assets/guide-block.20fb17b8.png",
        "../assets/images/guide-tour/video_1.png": "https://static.topcv.vn/cv-builder/assets/video_1.9481096e.png",
        "../assets/images/guide-tour/video_2.png": "https://static.topcv.vn/cv-builder/assets/video_2.b6b34900.png",
        "../assets/images/guide-tour/video_guide_1.png": "https://static.topcv.vn/cv-builder/assets/video_guide_1.5429e194.png",
        "../assets/images/guide-tour/video_guide_2.png": "https://static.topcv.vn/cv-builder/assets/video_guide_2.bd7ea9f8.png",
        "../assets/images/language/check.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAMAAABhq6zVAAAAPFBMVEUAAAAAsU8AsE8AsE8Ar1AAr1AAsU4Ar1AAr00AsU/////f9emf4b1gzpEgu2Wv5shAxHswwHAQtloQtVpWq8yFAAAACXRSTlMA38+AIBDQYGC8okP/AAAAVElEQVQI11XNWw6AIAxE0aFQYETxtf+92gqJcb7OTQgFoFFIqfClwHchWZhnKerkQUbI8LrcFBj2bt4MFldrw/RnvQ0LIq1O+gr0+/p/1FcymaMCD0EzBCU1cjAvAAAAAElFTkSuQmCC",
        "../assets/images/language/en.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAYCAMAAAClZq98AAAAaVBMVEXYACcAUrTw8PDqtL7qtL0eZbvS3enbHkDnlqXhWnLaDzSWtdrs0dfePFm0yeE8ecN4odLh5uzv4ePg1+CHq9YPXLjkeIzkeIvdLUx4oNLrw8tajcvlh5jjaX7ppbEtb7/fS2XPvs/mh5jMFiy5AAABF0lEQVQoz82T23KDMAxE1yI2DgQC5n5J0vb/P7Ky7DaBCTN97L5hn/GstAvOF6JcqyiTgHUy6lddmxSAx8x0AHVTcwYwZMh6IrO8g5am5+sB1SejqWXsuoeu5ZoBN0dQOr947C7WXqBHmYxAMRO1UIqxe4owQR2h6Lc4EZVaITxsbMQiJH4zy4g3AR001cOYjjZCZMc0HRzVlVyCtorQVki2WsH62h3iP+q0lRhfd4d/W4H2qmpyffpcprP80fMqgyBpE1mfd1OZn5ckdMvN8ILSjEiYc9upCNU5Yx++G1JatESz5F0+XvukGQuhMwZyN5+3pP2EpBkRmydIP5vlXccXQ24Atxvitzv4WyojEwS/6gBSWib4BgrXD8UmvTeOAAAAAElFTkSuQmCC",
        "../assets/images/language/jp.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAAYBAMAAACPVClDAAAAHlBMVEUAAADw8PDYACfePFnt0tfqtL7jaX7bHkDgS2bdLUyyRZHfAAAAAXRSTlMAQObYZgAAAFZJREFUGNNjYBREBwI0EwtrTkUXc1ZSUpqCKiZSBBRTd0QRE1cCAUMUsSCwmCqKWBJYTA1FzAgspoFFTBmbXoJ2CIPFJhJ0s6A7UMwEIwws4GFAj7AHAJjZJtuhp+k/AAAAAElFTkSuQmCC",
        "../assets/images/language/vi.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAYCAMAAAClZq98AAAAM1BMVEXYACf/2kTdGyrbDSj6v0H1ozzpXzPnUTHuejf9zUP4sT7zljvwiDnrbTXkRDDiNy7gKS0VmXckAAAAVklEQVQoz+WPORKAMAwD5cg24eb/r2XIAB02NWyt0Ur4DqUgx2fkDPbCJsI01Il4WKJyo8/z65WpjGStrF8QYkfIsm8NJt903VQ8to0EyhT6eFY48R92zJsBG0C8nx4AAAAASUVORK5CYII=",
        "../assets/images/layouts/layout_1.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA3YAAAIYAgMAAABcSpaAAAAADFBMVEX///8AAADl5eX9/f1gkoALAAAChklEQVR42uzaQQ3DMAAEwZAoH5MIv76LshQsJZKzziyDedzvDkmSJElX+5xbhlfuLbxxbBheObxyeOXwyuGVwyuHVw6vHF45vHJ45fDK4ZXDK4dXDq8cXjm8cnjl8MrhlcMrh1cOrxxeObxyeOXwyuGVwyuHVw6vHF45vHJ45fDK4ZXDK4dXDq8cXjm8cnjl8MrhlcMrh1cOrxxeObxyeOXwyuGVwyuHVw6vHF45vHJ45fDK4ZXDK4dXDq8cXjm8cnjl8Mq9hnduGV65l/AkSZIkSar127nv7jxJkiRJkprdcx0YT7sh4OE9nzfuGPB42P0ODw9vKjw8PDy85eHh4U2Fh4eHh7c8PDy8qfDw8PDwloeHhzcVHh4eHt7y8PDwpsLDw8PDWx4eHt5UeHh4eHjLw8PDmwoPDw8Pb3l4eHj/9u7YVmEgiKKoKOL38YvB/RFTHSWAHnqhpUUg1jbnJhuuTj6aGQoPDw8Pb3p4eHhD4eHh4eFNDw8Pbyg8PDw8vOnh4eENhYeHh4c3PTw8vKHw8PDw8KaHh4c3FB4eHh7e9PDw8IbCw/tF3sGPIuPhbZUnSZIkSdLeuh65y9F5kiRJkiTts7/lO53z22lZa9OTEXh4n+V9c8ztdO6z1oYnAvHw8PDwHuHh4SU8PLyGh4eX8PDwGh4eXsLDw2t4eHgJDw+v4eHhJTw8vIaHh5fwXub94+2Yd8PDw8PDw8N7hoeHl/Dw8BoeHl7Cw8NreHh4CQ8Pr+Hh4SU8PLyGh4eX8PDwGh4eXsLDw2t4eHgJDw+v4eHhJTw8vIaHh5fw8PAaHh5ewsPDa3h4eAkPD6/h4VnD1j7P+4WjyMtKeHjTeJIkSZLe7Q5Vwfb7bWq1gQAAAABJRU5ErkJggg==",
        "../assets/images/layouts/layout_2.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA3UAAAIXAgMAAABGK59WAAAADFBMVEX///8AAADl5eX9/f1gkoALAAACk0lEQVR42uzdMXFDQRBEwZ8IgvgIgpLjYzxGaVftOFR68pz6JRtuNYK5JEmSpA3d1qbm3drUAw/v3/Oe15bW39nSHQ8PD+83PDy8hIeHN+Hh4SU8PLwJDw8v4eHhTXh4eAkPD2/Cw8NLeHh4Ex4eXsLDw5vw8PASHh7ehIeHl/Dw8CY8PLyEh4c34eHhJTw8vAkPDy/h4eFNeHh4CQ8Pb8LDw0t4eHgTHh5ewsPDm/Dw8BIeHt6Eh4eX8PDwJjw8vISHhzfh4eElPDy8CQ8PL+HhvZ+3XnTIKPJ6ER7e+3iSJEmSJHX2fXJfp/MkSZIkSersto7sgVfcp/Ce14Hd8YrDaw6vObzm8JrDaw6vObzm8JrDaw6vObzm8JrDaw6vObzm8JrDaw6vObzm8JrDaw6vObzm8JrDaw6vObzm8JrDaw6vObzm8JrDaw6vObzm8JrD+2nvjk0bCAIgigau8fpxPa7Cpdkw4/DAICQxd+8nGy4vH3aXw1sObzm85fCWw1sObzm85fCWw1sObzm85fCWw1sObzm85fCWw1sObzm85fCWw1sObzm85fCWw1sObzm85fCWw1sOb7nb8I5LhrfcTXiSJEmSJK31deU+r86TJEmSJGmzl00Hct1x2vgyAg/vv716Mnf8HWdtLwLx8PDwfsPDw0t4eHgNDw8v4eHhNTw8vISHh9fw8PASHh5ew8PDS3h4eA0PDy/h4aXyvvF2eR94eHh4eHh4DQ8PL+Hh4TU8PLyEh4fX8PDwEh4eXsPDw0t4eHgNDw8v4eHhNTw8vISHh9fw8PASHh5ew8PDS3h4eA0PDy/h4eE1PDy8hIeH1/Dw8BIeHl7Dw/MMW3oG7w6fIh8n4eG9jydJkiTpwX4AjKntw7pcMycAAAAASUVORK5CYII=",
        "../assets/images/layouts/layout_3.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA3IAAAFeAgMAAAC9SMUWAAAADFBMVEX///8AAADl5eX9/f1gkoALAAAB0ElEQVR42uzdsW0CQRBAURy4BPpwCZRAcO7PsatzCR4hTpCQIIH+nd5PNjidVi/YaEfagyRJkvSaPr6faLn+2u1MR5ds1S1PnNVlXap90tElo6NrRkfXjI6uGR1dMzq6ZnR0zejomtHRNaOja0ZH14yOrhkdXTM6umZ0dM3o6JrR0TWjo2tGR9eMjq4ZHV0zOrpmdHTN6Oia0dE1o6NrRkfXjI6uGR1dMzq6ZnR0zejomtHRNaOja0ZH14yOrhkdXTM6umZ0dM3o6JrR0TWjo2tGR9eMjq4ZHV0zuh3o9v0SMR1dq/NBkiRJkqRN9LvjfnaukyRJkiRpC73tav902e748Htn5oGO7nXdpuDe0vG0Lg/KzPjR0d1FR0c30dHRTXR0dBMdHd1ER0c30dHRTXR0dBMdHd1ER0c30dHRTXR0dBNdW/dFt1ndHx0dHR0dHR0dHR0dHd1ER0c30dHRTXR0dBMdHd1ER/ff3h0TAQDCQBBUiX8rnIHUMLDXploDH7qio6MrOjq6oqOjKzo6uqKjoys6Orqio6MrOjq6oqOjKzo6uqKjoys6Orqio6MrOjq6oqOjKzo6a2lFZ6XwL90aeuMT8XSnozulkyRJursN/Pw9ukpsznkAAAAASUVORK5CYII=",
        "../assets/images/layouts/layout_4.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA3UAAAIWAgMAAACNd0zzAAAADFBMVEX///8AAADl5eX9/f1gkoALAAACn0lEQVR42uzdsU0DQRRFUSeU4H5cAon7oR6qRALkEL4E0t+7PjeZbDQnf9JcJEmSMr3cD9Pt80HX/7kL75fw9nmvl4N0vT2OP3fF+zk8PDw8vPXw8PBG4eHh4eGth4eHNwoPDw8Pbz08PLxReHh4eHjr4eHhjcLDw8PDWw8PD28UHh4eHt56eHh4o/Dw8PDw1sPDwxuFh4eHh7ceHh7eKDw8PDy89fDw8Ebh4eHh4a2Hh4c3Cg8PDw9vPTw8vFF4eHh4eOvh4eGNwsPDw8NbDw8PbxQeHh7e8/Luh8mfz3hPxZMkSZIkqdb7mXs7O0+SJEmSpGYHmg58d9ZlBB7eV8ebzD065yIQDw+vH145vHJ45fDK4ZXDK4dXDq8cXjm8cnjl8MrhlcMrh1cOrxxeObxyeOXwyuGVwyuHVw6vHF45vHJ45fDK4ZXDK4dXDq8cXjm8cnjl8Mp9tHcHJxWDQRhFBWuwH5tIP9ZjFZamMIMrA67e4ybnbrIMZ//xD145vHJ45fDK4ZXDK4dXDq8cXjm8cnjl8MrhlcMrh1cOrxxeObxyeOXwyuGVwyuHVw6vHF45vHJ45fDK4ZXDK/d2l6PIxyXDK/f+IkmSJElSs88r93F1niRJkiRJzR42HZjfHafFlxF4eP/t0ZO54/dzUnsRiIeHh/cTHh7ehIeHt+Hh4U14eHgbHh7ehIeHt+Hh4U14eHgbHh7ehIeHt+Hh4U14eHfifeF1ea94eHh4eHh4Gx4e3oSHh7fh4eFNeHh4Gx4e3oSHh7fh4eFNeHh4Gx4e3oSHh7fh4eFNeHh4Gx4e3oSHh7fh4eFNeHh4Gx4e3oSHh7fh4eFNeHh4Gx4e3oSHh7fh4T3/GbbjpPxR5IvzbnHS+jjpGjxJkiRJ+rtvZ+Dtw+CHHu0AAAAASUVORK5CYII=",
        "../assets/images/layouts/layout_5.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA3QAAAIYAgMAAABYv0a9AAAADFBMVEX///8AAADl5eX9/f1gkoALAAACZElEQVR42uzdoQ1CQRAA0UFQAv1QAgKapEqyCUgMCZ8D3pgVp56+TTZJkiRJL3S4bNO5aXfZKDq6tXXHtmh3foxNoqOjo6Ojoys6Orqio6Ob6Ojoio6ObqKjoys6OrqJjo6u6OjoJjo6uqKjo5vo6OiKjo5uoqOjKzo6uomOjq7o6OgmOjq6oqOjm+jo6IqOjm6io6MrOjq6iY6Orujo6CY6Orqio6Ob6Ojoio6ObqKjoys6OrqJjo6u6OjoJjo6uqKjo5vo6OiKjo5uoqP7jO5PLhE/e6ej+5BOkiRJkqSv6PrL/bhOkiRJkqSv6LDSh/+pab/UzgMd3Tt0x3UW3Pan+1hox4+Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo7u1t4dFCEQBEEQnIgTwAs/mFiTqEQDv6u5LAdpoJuOjo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6Ojo6OLqDb/URMR3dLnSRJkiRJN++7ueU6SZIkSZISvc/K6Lo9Q/eZhdF1o+tG142uG103um503ei60XWj60bXja4bXTe6bnTd6LrRdaPrRteNrhtdN7pudN3OzEXX7My86JrRdaPrRteNrhtdN7pudN3outF1o+tG142uG103um503ei60XWj60bXja4bXTe6bnTd6LrRdaPrRteNrhtdN7pudN3outF1o+tG142uG103um503ei60XWj60bXbf1a2vWAJ+KzMrpuI0mSJOn/fvAT8iN5hlO8AAAAAElFTkSuQmCC",
        "../assets/images/layouts/layout_6.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA3kAAAIZAgMAAABmHR6oAAAADFBMVEX///8AAADl5eX9/f1gkoALAAACg0lEQVR42uzasalCQRRFUS3i9/OL0H6sxyoF4cokgoEIe97ayQQTXFZ+TpIkSZK+2991y/jaHcf3f9owvnZ87fja8bXja8fXjq8dXzu+dnzt+NrxteNrx9eOrx1fO752fO342vG142vH146vHV87vnZ87fja8bXja8fXjq8dXzu+dnzt+NrxteNrx9eOrx1fO752fO342vG142vH146vHV87vnZ87fja8bXja8fXjq8dXzu+dnzt+NrxteNrx9eOrx1fO752fO342vG1O5DvumV87Q7jkyRJkiSp3n3rbtv7JEmSJEnapV/tCy7Pa+e3//X9BB/f5/18X3e+zPOu9n6Qj4+P7xUfH9/Ex8e3xsfHN/Hx8a3x8fFNfHx8a3x8fBMfH98aHx/fxMfHt8bHxzfx8fGt8fHxTXx8fGt8fHwTHx/fGh8f38THx7fGx8c38T3au2MThMEoCqOFZAT3cYQ07uM8TuFogvjgNoJNwsvL+Zp0gdNf/sfHl/Hx8VV8fHwZHx9fxcfHl/Hx8VV8fHwZHx9fxcfHl/Hx8VV8fHwZHx9fxcfHl/Hx8VV8fHwZHx9fxcfHl/Hx8VV8fNmJ7jPff8TH18AnSZIkSdLRe47uMd4nSZIkSdKUrp2mA+vnT0uz/QQf33a+W5/p3LJ+P632g3x8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHxdfC++I/sufHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fLu97zb8PvN030nuaw/3SZIkSdIfvQEemTeub4z8dgAAAABJRU5ErkJggg==",
        "../assets/images/menu/block-child.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAD+SURBVHgBtZXBEYIwEEU/SAGUECsQO6AErEAowZtdqBWIFagdUIIdmKNHr97cJZkRMwkDJLyZHyCQT2azm0RQZKQCYahJMqJGkK6kC+kNP1LSllQl1JTa9IhwFLG+8Z1pl9YrsbwQpNwxqCFJDMBmnGpzL2zGD63gxjnUyo7hZE7GZiyhsmQM0uxwGUt44grFGeOooDKm15g/WMKTGDMxu3GKcLReHOMaandjuM4b/GdFpjXUlGtgE+kOAbXLrbR51ennn94xDB57gyVdS/xSTZCecG9IvfQt3gGqAhtMYGE8cyyFvn5Ie0zEViB89nGs1vDAnLEk8YLuSC948AWsXCrsdbbkGwAAAABJRU5ErkJggg==",
        "../assets/images/menu/block.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAF5SURBVHgBzVXBUcMwELyT88clKHkTOwWQ2HTgDoAOQgfQQegAKiAdIAx/PB7eiUqAHx9b3Dn4AWM5kiEz7EMjSyut7k5eARwY2HbkLJ2hMQ/UfQd3HBljbnWZX+5ljuNkSyISPDGJk3s5nWe2ecFNu7EulAZP1Ih3EATW+VHfYhIOoapS6oZWUlXtuNP5edMxRuvXZ7VXgKPimhjER/AACpHIaMF1ue4VgLrKDApFxAvwAEdNN4freUMpfxN2KoZQ116nZ/Cm0NzEjyatI9eFMpovKf7YSkDkExc/h50FQASK2qKHobsGnQW6TucCAQeGcwTjaLGmPM9s8wbrpS6e1oMFtmWewQD8nxTJ45OUUiSthCBQXV7mLCCESGvS6aGorkFngU2ZX8EAtDXg33vnnn+MJgL2jwmZE1nti4wT1eVBv7aKTaFWFAHfY0kFK0hk+Y050CqsILGMn0PwBL8j/Py239hHnkSLFT04Z/BVI0eEtOZ0qHd54xOmBIZtQLGqjQAAAABJRU5ErkJggg==",
        "../assets/images/menu/column.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAABZSURBVHgB7ZWxDcAgDAQ/UQbICGSBJAtEWYlNGQFGYAMQ/ZsCQfcnuTnJOncGxAjX80fm3f35NsZOYP4Ax3G9nbB5mdyxGAUUUEABBWZg/YPEdcmdkxLECBVbDwj74oyG7AAAAABJRU5ErkJggg==",
        "../assets/images/menu/icon-padding-close.svg": "https://static.topcv.vn/cv-builder/assets/icon-padding-close.364de0ac.svg",
        "../assets/images/menu/icon-padding-open.svg": "https://static.topcv.vn/cv-builder/assets/icon-padding-open.95f12349.svg",
        "../assets/images/menu/icon-padding.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAADhSURBVHgBvZSBDYIwEEX/GQbADRiBDWQE3MQRZALjJjiBuoFu4AgwQf2VHtbaRDDVlxxpaa/3e71WjDEFgB0tx5O1iHSIEJl/ozUZP1taRbu6gc5Nii7k/i+9fm37wghHNihAKnyB+i+QCLu1Hl5+GKHEa76icAcn1xz8bfJouS5iplM4n4e/hJEmKuqo6IJfIIGaAu815bOnkjY2kAX9sEb+T7pk26MLjnIqpe+vV6RnhNoNVPjMqEj9NdnjVryKnUOe/K6tnERlzntkc9VaRRvaAcMJCoJLHEFrTeefac0db+3AkjAAdH0AAAAASUVORK5CYII=",
        "../assets/images/menu/icon-setting-block.svg": "https://static.topcv.vn/cv-builder/assets/icon-setting-block.c7997dc4.svg",
        "../assets/images/menu/icon-setting-column.svg": "https://static.topcv.vn/cv-builder/assets/icon-setting-column.f62f627f.svg",
        "../assets/images/menu/icon-setting-row.svg": "https://static.topcv.vn/cv-builder/assets/icon-setting-row.ea3dbf03.svg",
        "../assets/images/menu/row.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAABgSURBVHgB7dTBDYAgDAXQrxM4AiygcQDjSo7iSsYFlAVgBDaAXkjgDCQE+i7N76Gn5gOse1Mc5HZqGgJ5jP4fCTaO5IvEely0WpDFWaPeO6QZpZW/yFpXo+w+KrsdbBwe47oQCFOsjdYAAAAASUVORK5CYII=",
        "../assets/images/tab-navigation/block-content-active.svg": "https://static.topcv.vn/cv-builder/assets/block-content-active.e434b78b.svg",
        "../assets/images/tab-navigation/block-content.svg": "https://static.topcv.vn/cv-builder/assets/block-content.05665035.svg",
        "../assets/images/tab-navigation/change-template-active.svg": "https://static.topcv.vn/cv-builder/assets/change-template-active.a2501bd2.svg",
        "../assets/images/tab-navigation/change-template.svg": "https://static.topcv.vn/cv-builder/assets/change-template.0334ccf2.svg",
        "../assets/images/tab-navigation/cv-sample-active.svg": "https://static.topcv.vn/cv-builder/assets/cv-sample-active.0ad69f81.svg",
        "../assets/images/tab-navigation/cv-sample.svg": "https://static.topcv.vn/cv-builder/assets/cv-sample.f336b55d.svg",
        "../assets/images/tab-navigation/job-offer-active.svg": "https://static.topcv.vn/cv-builder/assets/job-offer-active.bf30ce8d.svg",
        "../assets/images/tab-navigation/job-offer.svg": "https://static.topcv.vn/cv-builder/assets/job-offer.16d5cd10.svg",
        "../assets/images/tab-navigation/suggest-write-cv-active.svg": "https://static.topcv.vn/cv-builder/assets/suggest-write-cv-active.49410a5c.svg",
        "../assets/images/tab-navigation/suggest-write-cv.svg": "https://static.topcv.vn/cv-builder/assets/suggest-write-cv.d520b00e.svg",
        "../assets/scss/abstracts/_functions.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}",
        "../assets/scss/abstracts/_mixins.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}",
        "../assets/scss/abstracts/_variables.scss": "",
        "../assets/scss/base/_base.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n/**\n * Set up a decent box model on the root element\n */\nhtml {\n  box-sizing: border-box;\n}\n\n/**\n * Make all elements from the DOM inherit from the parent box-sizing\n * Since `*` has a specificity of 0, it does not override the `html` value\n * making all elements inheriting from the root box-sizing value\n * See: https://css-tricks.com/inheriting-box-sizing-probably-slightly-better-best-practice/\n */\n*,\n*::before,\n*::after {\n  box-sizing: inherit;\n}\n\nhtml {\n  font-size: 13px;\n}\n\nbody {\n  background: #f1f2f6;\n}\n\nimg {\n  max-width: 100%;\n  height: auto;\n}\n\n.cv-section-main {\n  font-family: var(--font-family-primary);\n  line-height: var(--line-height-primary);\n}\n\nlabel {\n  margin-bottom: inherit;\n}\n\na {\n  color: #606266;\n}\na:hover {\n  text-decoration: none;\n  color: #606266;\n}\n\n.text-highlight {\n  color: #00b14f;\n}\n\n.text-light {\n  color: rgb(255, 255, 255);\n}\n\n/* width */\n::-webkit-scrollbar {\n  width: 7px;\n}\n\n/* Handle */\n::-webkit-scrollbar-thumb {\n  background: #cccccc;\n  border-radius: 10px;\n}\n\n.el-overlay {\n  background-color: rgba(0, 0, 0, 0.1);\n}\n\n.v-enter-active,\n.v-leave-active {\n  transition: opacity 0.3s ease;\n}\n\n.v-enter-from,\n.v-leave-to {\n  opacity: 0;\n}\n\na {\n  text-decoration: none;\n  font-family: "Inter", sans-serif !important;\n}\n\n[v-cloak] {\n  display: none;\n}\n\nbutton {\n  font-family: "Inter", sans-serif !important;\n}\n\n#cvb-section-content a {\n  font-family: inherit !important;\n}',
        "../assets/scss/base/_fonts.scss": '@import url("https://fonts.googleapis.com/css?family=Bai+Jamjuree:400,500,600,700|Barlow:400,500,600,700|Be+Vietnam+Pro:400,500,600,700|Inter:400,500,600,700|Lexend:400,500,600,700|Maitree:400,500,600,700|Montserrat:400,500,600,700|Montserrat+Alternates:400,500,600,700|Mulish:400,500,600,700|Raleway:400,500,600,700|Roboto:400,500,600,700|Roboto+Condensed:400,500,600,700|Source+Code+Pro:400,500,600,700|Trirong:400,500,600,700|M+PLUS+1p:400,500,600,700|Noto+Sans+JP:400,500,600,700|Noto+Serif+JP:400,500,600,700|Roboto:400,500,600,700|Roboto+Condensed:400,500,600,700|Sawarabi+Gothic:400,500,600,700|Zen+Maru+Gothic&display:400,500,600,700=swap");\n@import url("https://fonts.cdnfonts.com/css/arial");\n@import url("https://fonts.cdnfonts.com/css/times-new-roman");\n@import url("https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap");\n.w-1 {\n  width: 1%;\n}\n.w-2 {\n  width: 2%;\n}\n.w-3 {\n  width: 3%;\n}\n.w-4 {\n  width: 4%;\n}\n.w-5 {\n  width: 5%;\n}\n.w-6 {\n  width: 6%;\n}\n.w-7 {\n  width: 7%;\n}\n.w-8 {\n  width: 8%;\n}\n.w-9 {\n  width: 9%;\n}\n.w-10 {\n  width: 10%;\n}\n.w-11 {\n  width: 11%;\n}\n.w-12 {\n  width: 12%;\n}\n.w-13 {\n  width: 13%;\n}\n.w-14 {\n  width: 14%;\n}\n.w-15 {\n  width: 15%;\n}\n.w-16 {\n  width: 16%;\n}\n.w-17 {\n  width: 17%;\n}\n.w-18 {\n  width: 18%;\n}\n.w-19 {\n  width: 19%;\n}\n.w-20 {\n  width: 20%;\n}\n.w-21 {\n  width: 21%;\n}\n.w-22 {\n  width: 22%;\n}\n.w-23 {\n  width: 23%;\n}\n.w-24 {\n  width: 24%;\n}\n.w-25 {\n  width: 25%;\n}\n.w-26 {\n  width: 26%;\n}\n.w-27 {\n  width: 27%;\n}\n.w-28 {\n  width: 28%;\n}\n.w-29 {\n  width: 29%;\n}\n.w-30 {\n  width: 30%;\n}\n.w-31 {\n  width: 31%;\n}\n.w-32 {\n  width: 32%;\n}\n.w-33 {\n  width: 33%;\n}\n.w-34 {\n  width: 34%;\n}\n.w-35 {\n  width: 35%;\n}\n.w-36 {\n  width: 36%;\n}\n.w-37 {\n  width: 37%;\n}\n.w-38 {\n  width: 38%;\n}\n.w-39 {\n  width: 39%;\n}\n.w-40 {\n  width: 40%;\n}\n.w-41 {\n  width: 41%;\n}\n.w-42 {\n  width: 42%;\n}\n.w-43 {\n  width: 43%;\n}\n.w-44 {\n  width: 44%;\n}\n.w-45 {\n  width: 45%;\n}\n.w-46 {\n  width: 46%;\n}\n.w-47 {\n  width: 47%;\n}\n.w-48 {\n  width: 48%;\n}\n.w-49 {\n  width: 49%;\n}\n.w-50 {\n  width: 50%;\n}\n.w-51 {\n  width: 51%;\n}\n.w-52 {\n  width: 52%;\n}\n.w-53 {\n  width: 53%;\n}\n.w-54 {\n  width: 54%;\n}\n.w-55 {\n  width: 55%;\n}\n.w-56 {\n  width: 56%;\n}\n.w-57 {\n  width: 57%;\n}\n.w-58 {\n  width: 58%;\n}\n.w-59 {\n  width: 59%;\n}\n.w-60 {\n  width: 60%;\n}\n.w-61 {\n  width: 61%;\n}\n.w-62 {\n  width: 62%;\n}\n.w-63 {\n  width: 63%;\n}\n.w-64 {\n  width: 64%;\n}\n.w-65 {\n  width: 65%;\n}\n.w-66 {\n  width: 66%;\n}\n.w-67 {\n  width: 67%;\n}\n.w-68 {\n  width: 68%;\n}\n.w-69 {\n  width: 69%;\n}\n.w-70 {\n  width: 70%;\n}\n.w-71 {\n  width: 71%;\n}\n.w-72 {\n  width: 72%;\n}\n.w-73 {\n  width: 73%;\n}\n.w-74 {\n  width: 74%;\n}\n.w-75 {\n  width: 75%;\n}\n.w-76 {\n  width: 76%;\n}\n.w-77 {\n  width: 77%;\n}\n.w-78 {\n  width: 78%;\n}\n.w-79 {\n  width: 79%;\n}\n.w-80 {\n  width: 80%;\n}\n.w-81 {\n  width: 81%;\n}\n.w-82 {\n  width: 82%;\n}\n.w-83 {\n  width: 83%;\n}\n.w-84 {\n  width: 84%;\n}\n.w-85 {\n  width: 85%;\n}\n.w-86 {\n  width: 86%;\n}\n.w-87 {\n  width: 87%;\n}\n.w-88 {\n  width: 88%;\n}\n.w-89 {\n  width: 89%;\n}\n.w-90 {\n  width: 90%;\n}\n.w-91 {\n  width: 91%;\n}\n.w-92 {\n  width: 92%;\n}\n.w-93 {\n  width: 93%;\n}\n.w-94 {\n  width: 94%;\n}\n.w-95 {\n  width: 95%;\n}\n.w-96 {\n  width: 96%;\n}\n.w-97 {\n  width: 97%;\n}\n.w-98 {\n  width: 98%;\n}\n.w-99 {\n  width: 99%;\n}\n.w-100 {\n  width: 100%;\n}',
        "../assets/scss/base/_helpers.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n/**\n * Clear inner floats\n */\n.clearfix::after {\n  clear: both;\n  content: "";\n  display: table;\n}\n\n/**\n   * Main content containers\n   * 1. Make the container full-width with a maximum width\n   * 2. Center it in the viewport\n   * 3. Leave some space on the edges, especially valuable on small screens\n   */\n.container {\n  max-width: 1180px;\n  /* 1 */\n  margin-left: auto;\n  /* 2 */\n  margin-right: auto;\n  /* 2 */\n  padding-left: 20px;\n  /* 3 */\n  padding-right: 20px;\n  /* 3 */\n  width: 100%;\n  /* 1 */\n}\n\n/**\n   * Hide text while making it readable for screen readers\n   * 1. Needed in WebKit-based browsers because of an implementation bug;\n   *    See: https://code.google.com/p/chromium/issues/detail?id=457146\n   */\n.hide-text {\n  overflow: hidden;\n  padding: 0;\n  /* 1 */\n  text-indent: 101%;\n  white-space: nowrap;\n}\n\n/**\n   * Hide element while making it readable for screen readers\n   * Shamelessly borrowed from HTML5Boilerplate:\n   * https://github.com/h5bp/html5-boilerplate/blob/master/src/css/main.css#L119-L133\n   */\n.visually-hidden {\n  border: 0;\n  clip: rect(0 0 0 0);\n  height: 1px;\n  margin: -1px;\n  overflow: hidden;\n  padding: 0;\n  position: absolute;\n  width: 1px;\n}\n\n/**\n * Outline validate\n */\n.outline-validate {\n  outline: 1px dashed red !important;\n  position: relative;\n}\n\n.outline-validate:hover:after {\n  font-family: helvetica neue, Helvetica, Arial, sans-serif;\n  content: attr(data-message-error);\n  position: absolute;\n  z-index: 1;\n  top: 108%;\n  margin-bottom: 3px;\n  right: 0;\n  width: 180px;\n  background-color: rgba(251, 88, 88, 0.86);\n  font-size: 11px;\n  line-height: 1.6em;\n  font-weight: 400;\n  text-decoration: none;\n  text-transform: none;\n  text-align: center;\n  color: rgb(255, 255, 255);\n  padding: 5px;\n  border-radius: 5px;\n}\n\n/**\n * GlobalSetting\n */\n.cvo-border-color {\n  border-color: var(--text-primary-color);\n}\n\n.cvo-text-color {\n  color: var(--text-primary-color);\n}\n\n.cvo-text-color-100 {\n  color: var(--text-primary-color-100);\n}\n\n.cvo-text-color-50 {\n  color: var(--text-primary-color-50);\n}\n\n.cvo-text-color-30 {\n  color: var(--text-primary-color-30);\n}\n\n.cvo-bg-color {\n  background-color: var(--text-primary-color);\n}\n\n.cvo-bg-color-100 {\n  background-color: var(--text-primary-color-100);\n}\n\n.cvo-bg-color-50 {\n  background-color: var(--text-primary-color-50);\n}\n\n.cvo-bg-color-30 {\n  background-color: var(--text-primary-color-30);\n}\n\n.cvo-bg-color-15 {\n  background-color: var(--text-primary-color-15);\n}\n\n.cvo-border-color {\n  border-color: var(--text-primary-color);\n}\n\n.cvo-border-color-100 {\n  border-color: var(--text-primary-color-100);\n}\n\n.cvo-border-color-50 {\n  border-color: var(--text-primary-color-50);\n}\n\n.cvo-border-color-30 {\n  border-color: var(--text-primary-color-30);\n}\n\n.cvo-outline-color {\n  outline-color: var(--text-primary-color);\n}\n\n.cvo-text-darken-color {\n  background-color: var(--darken-primary-color);\n}\n\n.cvo-text-lighten-color {\n  background-color: var(--lighten-primary-color);\n}\n\n.cvo-bg-darken-color {\n  background-color: var(--darken-primary-color);\n}\n\n.cvo-bg-lighten-color {\n  background-color: var(--lighten-primary-color);\n}\n\n:root {\n  --background-image-global: none;\n  --opacity-overlay: 0;\n  --transaction: all 0.3s;\n}\n\n.cursor-pointer {\n  cursor: pointer;\n}\n\n/**\n * Flex\n */\n.flex-column {\n  flex-direction: column !important;\n  display: flex;\n}\n\n.flex-row {\n  flex-direction: row !important;\n  display: flex;\n}\n\n.flex-wrap {\n  flex-wrap: wrap;\n}\n\n.flex-nowrap {\n  flex-wrap: nowrap;\n}\n\n.flex {\n  display: flex;\n}\n\n.items-center {\n  align-items: center;\n}\n\n.text-center {\n  text-align: center;\n}\n\n.border-l {\n  border-left: 1px solid #eeeeee;\n}\n\n.border-r {\n  border-right: 1px solid #eeeeee;\n}\n\n.w-160px {\n  width: 160px;\n}\n\n.outline-error {\n  outline: 1px solid red !important;\n}\n\n.spinner {\n  -webkit-animation: spin 1s linear infinite;\n  /* Safari */\n  animation: spin 1s linear infinite;\n}\n\n@-webkit-keyframes spin {\n  0% {\n    -webkit-transform: rotate(0deg);\n  }\n  100% {\n    -webkit-transform: rotate(360deg);\n  }\n}\n@keyframes spin {\n  0% {\n    transform: rotate(0deg);\n  }\n  100% {\n    transform: rotate(360deg);\n  }\n}\n.justify-content-center {\n  justify-content: center;\n}\n\n.justify-content-space-between {\n  justify-content: space-between;\n}\n\n.align-items-center {\n  align-items: center;\n}\n\n.min-height-80 {\n  min-height: 80px;\n}\n.min-height-80 .block-button {\n  display: none;\n}\n.min-height-80.hover .block-button {\n  display: block;\n}\n\n.slide-fade-enter-active {\n  transition: all 0.3s ease-out;\n}\n\n.slide-fade-leave-active {\n  transition: all 0.8s cubic-bezier(1, 0.5, 0.8, 1);\n}\n\n.slide-fade-enter-from,\n.slide-fade-leave-to {\n  transform: translateY(-100px);\n}\n\n.d-flex {\n  display: flex;\n}\n\n.d-block {\n  display: block;\n}\n\n.d-inline-block {\n  display: inline-block;\n}\n\n.d-inline-flex {\n  display: inline-flex;\n}\n\n.text-center {\n  text-align: center;\n}\n\n.padding-0-16 {\n  padding: 0 16px;\n}\n\n.padding-10 {\n  padding: 10px;\n}\n\n.padding-0-8 {\n  padding: 0 8px;\n}\n\n.padding-0-10-10 {\n  padding: 0 10px 10px;\n}\n\n.padding-10-10-0 {\n  padding: 10px 10px 0px;\n}\n\n.padding-0-20 {\n  padding: 0 20px;\n}\n\n.margin-top-10 {\n  margin-top: 10px;\n}\n\n.gap-10 {\n  gap: 10px;\n}\n\n.gap-5 {\n  gap: 5px;\n}',
        "../assets/scss/base/_space.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.mt-1 {\n  margin-top: 1px;\n}\n\n.mt-2 {\n  margin-top: 2px;\n}\n\n.mt-3 {\n  margin-top: 3px;\n}\n\n.mt-4 {\n  margin-top: 4px;\n}\n\n.mt-5 {\n  margin-top: 5px;\n}\n\n.mt-6 {\n  margin-top: 6px;\n}\n\n.mt-7 {\n  margin-top: 7px;\n}\n\n.mt-8 {\n  margin-top: 8px;\n}\n\n.mt-9 {\n  margin-top: 9px;\n}\n\n.mt-10 {\n  margin-top: 10px;\n}\n\n.mt-11 {\n  margin-top: 11px;\n}\n\n.mt-12 {\n  margin-top: 12px;\n}\n\n.mt-13 {\n  margin-top: 13px;\n}\n\n.mt-14 {\n  margin-top: 14px;\n}\n\n.mt-15 {\n  margin-top: 15px;\n}\n\n.mt-16 {\n  margin-top: 16px;\n}\n\n.mt-17 {\n  margin-top: 17px;\n}\n\n.mt-18 {\n  margin-top: 18px;\n}\n\n.mt-19 {\n  margin-top: 19px;\n}\n\n.mt-20 {\n  margin-top: 20px;\n}\n\n.mr-1 {\n  margin-right: 1px;\n}\n\n.mr-2 {\n  margin-right: 2px;\n}\n\n.mr-3 {\n  margin-right: 3px;\n}\n\n.mr-4 {\n  margin-right: 4px;\n}\n\n.mr-5 {\n  margin-right: 5px;\n}\n\n.mr-6 {\n  margin-right: 6px;\n}\n\n.mr-7 {\n  margin-right: 7px;\n}\n\n.mr-8 {\n  margin-right: 8px;\n}\n\n.mr-9 {\n  margin-right: 9px;\n}\n\n.mr-10 {\n  margin-right: 10px;\n}\n\n.mr-11 {\n  margin-right: 11px;\n}\n\n.mr-12 {\n  margin-right: 12px;\n}\n\n.mr-13 {\n  margin-right: 13px;\n}\n\n.mr-14 {\n  margin-right: 14px;\n}\n\n.mr-15 {\n  margin-right: 15px;\n}\n\n.mr-16 {\n  margin-right: 16px;\n}\n\n.mr-17 {\n  margin-right: 17px;\n}\n\n.mr-18 {\n  margin-right: 18px;\n}\n\n.mr-19 {\n  margin-right: 19px;\n}\n\n.mr-20 {\n  margin-right: 20px;\n}\n\n.mb-1 {\n  margin-bottom: 1px;\n}\n\n.mb-2 {\n  margin-bottom: 2px;\n}\n\n.mb-3 {\n  margin-bottom: 3px;\n}\n\n.mb-4 {\n  margin-bottom: 4px;\n}\n\n.mb-5 {\n  margin-bottom: 5px;\n}\n\n.mb-6 {\n  margin-bottom: 6px;\n}\n\n.mb-7 {\n  margin-bottom: 7px;\n}\n\n.mb-8 {\n  margin-bottom: 8px;\n}\n\n.mb-9 {\n  margin-bottom: 9px;\n}\n\n.mb-10 {\n  margin-bottom: 10px;\n}\n\n.mb-11 {\n  margin-bottom: 11px;\n}\n\n.mb-12 {\n  margin-bottom: 12px;\n}\n\n.mb-13 {\n  margin-bottom: 13px;\n}\n\n.mb-14 {\n  margin-bottom: 14px;\n}\n\n.mb-15 {\n  margin-bottom: 15px;\n}\n\n.mb-16 {\n  margin-bottom: 16px;\n}\n\n.mb-17 {\n  margin-bottom: 17px;\n}\n\n.mb-18 {\n  margin-bottom: 18px;\n}\n\n.mb-19 {\n  margin-bottom: 19px;\n}\n\n.mb-20 {\n  margin-bottom: 20px;\n}\n\n.ml-1 {\n  margin-left: 1px;\n}\n\n.ml-2 {\n  margin-left: 2px;\n}\n\n.ml-3 {\n  margin-left: 3px;\n}\n\n.ml-4 {\n  margin-left: 4px;\n}\n\n.ml-5 {\n  margin-left: 5px;\n}\n\n.ml-6 {\n  margin-left: 6px;\n}\n\n.ml-7 {\n  margin-left: 7px;\n}\n\n.ml-8 {\n  margin-left: 8px;\n}\n\n.ml-9 {\n  margin-left: 9px;\n}\n\n.ml-10 {\n  margin-left: 10px;\n}\n\n.ml-11 {\n  margin-left: 11px;\n}\n\n.ml-12 {\n  margin-left: 12px;\n}\n\n.ml-13 {\n  margin-left: 13px;\n}\n\n.ml-14 {\n  margin-left: 14px;\n}\n\n.ml-15 {\n  margin-left: 15px;\n}\n\n.ml-16 {\n  margin-left: 16px;\n}\n\n.ml-17 {\n  margin-left: 17px;\n}\n\n.ml-18 {\n  margin-left: 18px;\n}\n\n.ml-19 {\n  margin-left: 19px;\n}\n\n.ml-20 {\n  margin-left: 20px;\n}\n\n.pt-1 {\n  padding-top: 1px;\n}\n\n.pt-2 {\n  padding-top: 2px;\n}\n\n.pt-3 {\n  padding-top: 3px;\n}\n\n.pt-4 {\n  padding-top: 4px;\n}\n\n.pt-5 {\n  padding-top: 5px;\n}\n\n.pt-6 {\n  padding-top: 6px;\n}\n\n.pt-7 {\n  padding-top: 7px;\n}\n\n.pt-8 {\n  padding-top: 8px;\n}\n\n.pt-9 {\n  padding-top: 9px;\n}\n\n.pt-10 {\n  padding-top: 10px;\n}\n\n.pt-11 {\n  padding-top: 11px;\n}\n\n.pt-12 {\n  padding-top: 12px;\n}\n\n.pt-13 {\n  padding-top: 13px;\n}\n\n.pt-14 {\n  padding-top: 14px;\n}\n\n.pt-15 {\n  padding-top: 15px;\n}\n\n.pt-16 {\n  padding-top: 16px;\n}\n\n.pt-17 {\n  padding-top: 17px;\n}\n\n.pt-18 {\n  padding-top: 18px;\n}\n\n.pt-19 {\n  padding-top: 19px;\n}\n\n.pt-20 {\n  padding-top: 20px;\n}\n\n.pr-1 {\n  padding-right: 1px;\n}\n\n.pr-2 {\n  padding-right: 2px;\n}\n\n.pr-3 {\n  padding-right: 3px;\n}\n\n.pr-4 {\n  padding-right: 4px;\n}\n\n.pr-5 {\n  padding-right: 5px;\n}\n\n.pr-6 {\n  padding-right: 6px;\n}\n\n.pr-7 {\n  padding-right: 7px;\n}\n\n.pr-8 {\n  padding-right: 8px;\n}\n\n.pr-9 {\n  padding-right: 9px;\n}\n\n.pr-10 {\n  padding-right: 10px;\n}\n\n.pr-11 {\n  padding-right: 11px;\n}\n\n.pr-12 {\n  padding-right: 12px;\n}\n\n.pr-13 {\n  padding-right: 13px;\n}\n\n.pr-14 {\n  padding-right: 14px;\n}\n\n.pr-15 {\n  padding-right: 15px;\n}\n\n.pr-16 {\n  padding-right: 16px;\n}\n\n.pr-17 {\n  padding-right: 17px;\n}\n\n.pr-18 {\n  padding-right: 18px;\n}\n\n.pr-19 {\n  padding-right: 19px;\n}\n\n.pr-20 {\n  padding-right: 20px;\n}\n\n.pb-1 {\n  padding-bottom: 1px;\n}\n\n.pb-2 {\n  padding-bottom: 2px;\n}\n\n.pb-3 {\n  padding-bottom: 3px;\n}\n\n.pb-4 {\n  padding-bottom: 4px;\n}\n\n.pb-5 {\n  padding-bottom: 5px;\n}\n\n.pb-6 {\n  padding-bottom: 6px;\n}\n\n.pb-7 {\n  padding-bottom: 7px;\n}\n\n.pb-8 {\n  padding-bottom: 8px;\n}\n\n.pb-9 {\n  padding-bottom: 9px;\n}\n\n.pb-10 {\n  padding-bottom: 10px;\n}\n\n.pb-11 {\n  padding-bottom: 11px;\n}\n\n.pb-12 {\n  padding-bottom: 12px;\n}\n\n.pb-13 {\n  padding-bottom: 13px;\n}\n\n.pb-14 {\n  padding-bottom: 14px;\n}\n\n.pb-15 {\n  padding-bottom: 15px;\n}\n\n.pb-16 {\n  padding-bottom: 16px;\n}\n\n.pb-17 {\n  padding-bottom: 17px;\n}\n\n.pb-18 {\n  padding-bottom: 18px;\n}\n\n.pb-19 {\n  padding-bottom: 19px;\n}\n\n.pb-20 {\n  padding-bottom: 20px;\n}\n\n.pl-1 {\n  padding-left: 1px;\n}\n\n.pl-2 {\n  padding-left: 2px;\n}\n\n.pl-3 {\n  padding-left: 3px;\n}\n\n.pl-4 {\n  padding-left: 4px;\n}\n\n.pl-5 {\n  padding-left: 5px;\n}\n\n.pl-6 {\n  padding-left: 6px;\n}\n\n.pl-7 {\n  padding-left: 7px;\n}\n\n.pl-8 {\n  padding-left: 8px;\n}\n\n.pl-9 {\n  padding-left: 9px;\n}\n\n.pl-10 {\n  padding-left: 10px;\n}\n\n.pl-11 {\n  padding-left: 11px;\n}\n\n.pl-12 {\n  padding-left: 12px;\n}\n\n.pl-13 {\n  padding-left: 13px;\n}\n\n.pl-14 {\n  padding-left: 14px;\n}\n\n.pl-15 {\n  padding-left: 15px;\n}\n\n.pl-16 {\n  padding-left: 16px;\n}\n\n.pl-17 {\n  padding-left: 17px;\n}\n\n.pl-18 {\n  padding-left: 18px;\n}\n\n.pl-19 {\n  padding-left: 19px;\n}\n\n.pl-20 {\n  padding-left: 20px;\n}",
        "../assets/scss/base/_typography.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n/**\n* Basic typography style for copy text\n*/\nbody {\n  color: rgb(34, 34, 34);\n  font: normal 125%/1.4 "Inter", sans-serif;\n}',
        "../assets/scss/components/_add-block.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.block-content {\n  background: #ffffff;\n  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n}\n.block-content .br {\n  border: 1px solid #eeeeee;\n  margin: 16px 0;\n}\n.block-content__header {\n  padding: 16px;\n  word-break: break-all;\n  position: relative;\n  border-bottom: 1px solid #eeeeee;\n}\n.block-content__header--btn {\n  position: absolute;\n  top: 12px;\n  right: 16px;\n  padding: 0;\n  border: none;\n  outline: none;\n  cursor: pointer;\n  font-size: 16px;\n  border-radius: 20px;\n  background: #eeeeee;\n  width: 32px;\n  height: 32px;\n  color: #777777;\n}\n.block-content__title {\n  font-style: normal;\n  font-weight: 500;\n  font-size: 19px;\n  line-height: 24px;\n  color: #212f3f;\n}\n.block-content__title-not-use, .block-content__title-use {\n  font-weight: bold;\n  color: #212f3f;\n  margin-bottom: 10px;\n  font-size: 15px;\n}\n.block-content__body {\n  padding: 12px 16px;\n  max-height: 66vh;\n  overflow-y: auto;\n}\n.block-content__description {\n  font-style: italic;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #555555;\n  margin-bottom: 12px;\n}\n.block-content .block-item-not-use {\n  position: relative;\n  background: #f4f4f4;\n  border-radius: 6px;\n  margin-bottom: 10px;\n  padding: 10px;\n  cursor: pointer;\n  display: flex;\n  align-items: center;\n}\n.block-content .block-item-not-use:hover {\n  background: #e5f7ed;\n}\n.block-content .block-item-not-use:hover .block-item-not-use__title {\n  color: #00b14f;\n}\n.block-content .block-item-not-use:hover .block-item-not-use__check, .block-content .block-item-not-use:hover .block-item-not-use__icon {\n  color: #00b14f;\n}\n.block-content .block-item-not-use__icon {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #999999;\n  margin-right: 16px;\n  width: 20px;\n}\n.block-content .block-item-not-use__title {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #212f3f;\n  flex: 1;\n}\n.block-content .block-item-not-use__check {\n  color: #999999;\n  font-size: 18px;\n}\n.block-content .block-item-use {\n  position: relative;\n  background: #f4f4f4;\n  border-radius: 6px;\n  margin-bottom: 10px;\n  padding: 10px;\n  cursor: pointer;\n}\n.block-content .block-item-use__icon {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #999999;\n  margin-right: 16px;\n  width: 20px;\n}\n.block-content .block-item-use__title {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #999999;\n}\n.block-content .block-item-use:hover .block-item-use__icon {\n  color: #212F3F;\n}\n.block-content .block-item-use:hover .block-item-use__title {\n  color: #212F3F;\n}\n\n@media screen and (max-height: 667px) {\n  .block-content__body {\n    max-height: 50vh !important;\n  }\n}\n.block-item-not-use.ghost-drag-render-item {\n  background-color: #E5F7ED;\n  border: 1px solid #00B14F;\n  min-height: 80px;\n}\n.block-item-not-use.ghost-drag-render-item > * {\n  opacity: 0;\n}\n\n.block-item-not-use.fallback-block-item {\n  background-color: #00B14F;\n  opacity: 1 !important;\n  width: fit-content !important;\n}\n.block-item-not-use.fallback-block-item * {\n  color: white;\n  opacity: 1 !important;\n}\n.block-item-not-use.fallback-block-item .block-item-not-use__check {\n  display: none;\n}\n.block-item-not-use.fallback-block-item .block-item-not-use__title {\n  font-weight: 500;\n  padding-left: 16px;\n  padding-right: 16px;\n}",
        "../assets/scss/components/_add-section.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.section-add {\n  border: unset;\n  position: relative;\n  min-height: 109px;\n}\n.section-add__button {\n  width: 130px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-style: normal;\n  font-size: 14px;\n  line-height: 20px;\n  color: #00b14f;\n  padding: 10px 16px;\n  background: #e5f7ed;\n  border-radius: 50px;\n  border: unset;\n  font-family: "Inter", sans-serif;\n  cursor: pointer;\n}\n.section-add__button:hover {\n  background-color: #00b14f;\n  color: #ffffff;\n}',
        "../assets/scss/components/_background-setting.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.global-setting__container {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n}\n.global-setting__section {\n  display: inline-block;\n}\n.global-setting__title {\n  text-align: left;\n  font-size: 14px;\n  margin-bottom: 10px;\n  font-weight: bold;\n}\n.global-setting__header {\n  text-align: left;\n  margin-bottom: 20px;\n}",
        "../assets/scss/components/_builder-setting.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.builder-setting__container {\n  display: grid;\n  gap: 0;\n  grid-template-columns: 50% 50%;\n  grid-template-rows: unset;\n  align-content: center;\n  align-items: center;\n  width: 100%;\n}\n\n.builder-setting__contents {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: end;\n  align-items: unset;\n}\n\n.builder-setting__inputs {\n  display: flex;\n  flex-wrap: unset;\n  justify-content: unset;\n  align-items: center;\n  margin-bottom: 10px;\n}\n\n.builder-setting__input {\n  display: flex;\n  flex-wrap: unset;\n  justify-content: unset;\n  align-items: center;\n  margin: 0 5px;\n}\n\n.builder-setting__input > span {\n  margin-right: 5px;\n}\n\n.builder-setting__input > input {\n  width: 50px;\n  height: 30px;\n}\n\n.builder-setting__input--number {\n  width: 100px;\n}\n\n.builder-setting__title {\n  align-self: center;\n  text-align: left;\n  font-weight: bold;\n}",
        "../assets/scss/components/_button.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.btn {\n  transition: all 0.3s;\n}\n.btn__topcv {\n  color: #e5f7ed;\n  background-color: #00b14f;\n}\n.btn__topcv--outline {\n  color: #00b14f;\n  background-color: #e5f7ed;\n}\n.btn__topcv--outline:hover, .btn__topcv--outline:focus {\n  color: white;\n  border-color: #00b14f;\n  background-color: #00b14f;\n  outline: 0;\n}\n.btn__topcv--disable {\n  background-color: #eeeeee;\n  color: #999999;\n  border: none;\n}\n.btn__topcv--disable:hover, .btn__topcv--disable:focus {\n  background-color: #dddddd;\n  color: #999999;\n}\n.btn__topcv:hover, .btn__topcv:focus {\n  color: #e5f7ed;\n  background-color: #3ba769;\n  outline: 0;\n}\n.btn__close {\n  height: 40px;\n  width: 40px;\n  background: rgba(63, 63, 63, 0.6);\n  border: none;\n  cursor: pointer;\n  border-radius: 50%;\n}\n.btn__close i {\n  color: #cfcfcf;\n  font-size: 23px;\n}\n.btn__close:hover {\n  background: rgba(63, 63, 63, 0.4);\n}\n.btn__close-rectangle {\n  width: 120px;\n  height: 40px;\n  padding: 9px 12px;\n  gap: 8px;\n  border-radius: 4px;\n  background: #F2F4F5;\n  color: #263A4D;\n  font-family: "Inter", sans-serif;\n  font-size: 14px;\n  font-weight: 600;\n  line-height: 22px;\n  letter-spacing: 0.0125em;\n  text-align: left;\n  border: unset;\n}\n.btn__close-rectangle:hover {\n  background: #F2F4F5;\n  outline: 0;\n  color: #263A4D !important;\n}\n.btn__save {\n  width: 120px;\n  height: 40px;\n  padding: 9px 12px;\n  gap: 8px;\n  border-radius: 4px;\n  background: #00b14f;\n  color: #fff;\n  font-family: "Inter", sans-serif;\n  font-size: 14px;\n  font-weight: 600;\n  line-height: 22px;\n  letter-spacing: 0.0125em;\n  text-align: left;\n  border: unset;\n}\n.btn__save:hover, .btn__save:focus {\n  color: white;\n  border-color: #00b14f;\n  background-color: #00b14f;\n  outline: 0;\n}\n\n.btn-cv {\n  padding: 9px 19px;\n  border-radius: 5px;\n  justify-content: center;\n  align-items: center;\n  white-space: nowrap;\n  border: none;\n  cursor: pointer;\n  color: rgb(255, 255, 255);\n  transition: all 0.3s;\n}\n.btn-cv__text {\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n}\n.btn-cv--small {\n  padding: 7px 15px;\n}\n.btn-cv--small__text {\n  font-size: 13px;\n}\n.btn-cv--success {\n  background-color: #00b14f;\n  color: rgb(255, 255, 255);\n}\n.btn-cv--success.is-plain {\n  background-color: #e5f7ed;\n  color: #00b14f;\n}\n.btn-cv--success:hover, .btn-cv--success:focus {\n  color: rgb(255, 255, 255);\n  background-color: #3ba769;\n  outline: 0;\n}\n.btn-cv--fix-size {\n  height: 40px;\n  min-width: 142px;\n}\n.btn-cv--disable {\n  background-color: #eeeeee;\n  color: #999999;\n}\n.btn-cv--disable:hover, .btn-cv--disable:focus {\n  background-color: #dddddd;\n  color: #999999;\n}\n.btn-cv--disable.is-plain {\n  background-color: #e5f7ed;\n  color: #00b14f;\n}\n.btn-cv + .btn-cv {\n  margin-left: 12px;\n}',
        "../assets/scss/components/_component-render.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.element-main {\n  position: relative;\n}\n.element-main.active, .element-main.cvb-active-focus, .element-main:hover {\n  outline: 1px dashed #999999;\n  outline-offset: 1px;\n}\n.element-main.active.element-type-table, .element-main.cvb-active-focus.element-type-table, .element-main:hover.element-type-table {\n  outline: none;\n}\n.element-main:after {\n  content: "";\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  pointer-events: none;\n}\n.element-main.element-type-text-single, .element-main.element-type-text, .element-main.readOnly {\n  outline: unset;\n}\n\n.view-cv .element-main:hover,\n.cvb-preview .element-main:hover {\n  outline: inherit;\n}',
        "../assets/scss/components/_grid.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.grid-3fr4fr5fr,\n.grid-5fr2fr5fr,\n.grid-2fr5fr5fr,\n.grid-2fr10fr,\n.grid-2fr10fr,\n.grid-3fr3fr6fr,\n.grid-3fr5fr2fr2fr,\n.grid-3fr6fr2fr1fr,\n.grid-3fr6fr3fr,\n.grid-3fr9fr,\n.grid-4fr8fr,\n.grid-6fr6fr,\n.grid-6fr3fr3fr,\n.grid-8fr4fr,\n.grid-9fr3fr,\n.grid-10fr2fr,\n.grid-form,\n.grid-repeat21fr,\n.grid-repeat31fr,\n.grid-repeat41fr,\n.grid-repeat51fr,\n.grid-repeat61fr,\n.grid-4fr3fr5fr,\n.grid-5fr4fr3fr,\n.grid-3fr5fr4fr,\n.grid-4fr5fr3fr,\n.grid-15fr105fr {\n  display: grid;\n}\n\n.grid-4fr3fr5fr {\n  grid-template-columns: 4fr 3fr 5fr;\n}\n\n.grid-5fr4fr3fr {\n  grid-template-columns: 5fr 4fr 3fr;\n}\n\n.grid-3fr5fr4fr {\n  grid-template-columns: 3fr 5fr 4fr;\n}\n\n.grid-4fr5fr3fr {\n  grid-template-columns: 4fr 5fr 3fr;\n}\n\n.grid-3fr4fr5fr {\n  grid-template-columns: 3fr 4fr 5fr;\n}\n\n.grid-2fr5fr5fr {\n  grid-template-columns: 2fr 5fr 5fr;\n}\n\n.grid-5fr2fr5fr {\n  grid-template-columns: 5fr 2fr 5fr;\n}\n\n.grid-repeat21fr {\n  grid-template-columns: repeat(2, 1fr);\n}\n\n.grid-repeat31fr {\n  grid-template-columns: repeat(3, 1fr);\n}\n\n.grid-repeat41fr {\n  grid-template-columns: repeat(4, 1fr);\n}\n\n.grid-repeat51fr {\n  grid-template-columns: repeat(5, 1fr);\n}\n\n.grid-repeat61fr {\n  grid-template-columns: repeat(6, 1fr);\n}\n\n.grid-9fr3fr {\n  grid-template-columns: 9fr 3fr;\n}\n\n.grid-3fr9fr {\n  grid-template-columns: 3fr 9fr;\n}\n\n.grid-4fr8fr {\n  grid-template-columns: 4fr 8fr;\n}\n\n.grid-6fr6fr {\n  grid-template-columns: 6fr 6fr;\n}\n\n.grid-5fr7fr {\n  grid-template-columns: 5fr 7fr;\n}\n\n.grid-7fr5fr {\n  grid-template-columns: 7fr 5fr;\n}\n\n.grid-8fr4fr {\n  grid-template-columns: 8fr 4fr;\n}\n\n.grid-6fr3fr3fr {\n  grid-template-columns: 6fr 3fr 3fr;\n}\n\n.grid-3fr3fr6fr {\n  grid-template-columns: 3fr 3fr 6fr;\n}\n\n.grid-3fr6fr3fr {\n  grid-template-columns: 3fr 6fr 3fr;\n}\n\n.grid-3fr5fr2fr2fr {\n  grid-template-columns: 3fr 5fr 2fr 2fr;\n}\n\n.grid-2fr10fr {\n  grid-template-columns: 2fr 10fr;\n}\n\n.grid-10fr2fr {\n  grid-template-columns: 10fr 2fr;\n}\n\n.grid-3fr6fr2fr1fr {\n  grid-template-columns: 3fr 6fr 2fr 1fr;\n}\n\n.grid-15fr105fr {\n  grid-template-columns: 1.5fr 10.5fr;\n}\n\n.cv-grid {\n  display: grid;\n  margin-left: 0;\n  margin-right: 0;\n}\n.cv-grid > div {\n  min-width: 0;\n}",
        "../assets/scss/components/_icon-picker.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.icon-picker__header {\n  display: flex;\n  align-items: center;\n  padding: 12px 16px 12px 16px;\n  border-bottom: 1px solid #eeeeee;\n  color: #212f3f;\n  font-size: 19px;\n  font-weight: 500;\n}\n\n.icon-picker__header .btn-close {\n  margin-left: auto;\n  color: #555555;\n  cursor: pointer;\n}\n\n.icon-picker__title {\n  font-weight: 600;\n  font-size: 19px;\n  line-height: 24px;\n  color: #212f3f;\n}\n\n.icon-picker__container {\n  width: 100%;\n  display: grid;\n  padding: 12px 16px 16px;\n  max-height: 330px;\n  overflow-y: scroll;\n  display: grid;\n  gap: 0px;\n  grid-template-columns: 12.5% 12.5% 12.5% 12.5% 12.5% 12.5% 12.5% 12.5%;\n  grid-template-rows: unset;\n}\n\n.icon-picker__container::-webkit-scrollbar {\n  width: 4px;\n}\n\n.icon-picker__container::-webkit-scrollbar-thumb {\n  background: #cccccc;\n}\n\n.icon-picker__area {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: center;\n  align-items: center;\n  cursor: pointer;\n  padding: 3px;\n  font-size: 29px;\n}\n\n.icon-picker__area.selected {\n  background: #e5f7ed;\n}\n\n.icon-picker__area.selected i {\n  color: #00B14F;\n}\n\n.icon-picker__area:hover {\n  background: #e5e7e9;\n}\n\n.icon-picker-element__container {\n  width: 100%;\n  display: flex;\n  flex-wrap: nowrap;\n  justify-content: space-between;\n  align-items: center;\n}\n\n.icon-picker-element__title {\n  font-weight: bold;\n  font-size: 14px;\n}",
        "../assets/scss/components/_image-editor.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.vue-cropper {\n  height: 200px;\n}\n\n.image-editor-actions {\n  padding: 5px;\n  width: 100%;\n  display: flex;\n  justify-content: center;\n}\n\n.btn {\n  display: inline-block;\n  line-height: 1;\n  white-space: nowrap;\n  cursor: pointer;\n  background: #fff;\n  border: 1px solid #c0ccda;\n  color: #1f2d3d;\n  text-align: center;\n  box-sizing: border-box;\n  outline: none;\n  margin: 5px;\n  padding: 9px 15px;\n  font-size: 14px;\n  border-radius: 4px;\n  color: #fff;\n  background-color: #50bfff;\n  border-color: #50bfff;\n  transition: all 0.2s ease;\n  text-decoration: none;\n  user-select: none;\n}",
        "../assets/scss/components/_layout-render.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.min-padding {\n  height: 100%;\n}\n\n.layout-render {\n  width: 100%;\n  height: 100%;\n  flex-wrap: nowrap;\n  transition: none;\n}\n.layout-render .column-main {\n  position: relative;\n  height: 100%;\n}\n.layout-render .column-main::after {\n  content: "";\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  pointer-events: none;\n}\n.layout-render .column-main .btn-add-block-info {\n  text-align: center;\n  display: block;\n  position: absolute;\n  left: 50%;\n  z-index: 1;\n  transform: translate(-50%, -50%);\n  top: 50%;\n}\n.layout-render .block-main {\n  position: relative;\n}\n.layout-render .block-main:hover {\n  outline: 1px solid #00b14f !important;\n}\n.layout-render .block-main:hover .btn-add-block {\n  display: block;\n}\n.layout-render .block-main::after {\n  content: "";\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  pointer-events: none;\n}\n.layout-render .block-child-main {\n  position: relative;\n}\n.layout-render .block-child-main > .min-padding {\n  padding: 4px;\n}\n.layout-render .block-child-main:hover {\n  outline: 1px solid #00b14f !important;\n}\n.layout-render .block-child-main::after {\n  content: "";\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  pointer-events: none;\n}\n\n.no-padding .column-main {\n  outline: none !important;\n}\n\n.element-group-main {\n  position: relative;\n}\n.element-group-main::after {\n  content: "";\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  pointer-events: none;\n}\n\n.cvb-preview .layout-render .column-main {\n  outline-style: unset !important;\n}\n.cvb-preview .layout-render .block-main {\n  outline-style: unset !important;\n}\n.cvb-preview .layout-render .block-child-main {\n  outline-style: unset !important;\n}\n\n.min-height-95 {\n  min-height: 95px;\n}\n\n.blur .btn-add-block {\n  opacity: 0;\n  z-index: -1 !important;\n}\n\n.highlight .btn-add-block {\n  opacity: 0;\n  z-index: -1 !important;\n}\n\n.block-main.highlight .btn-add-block {\n  opacity: 0.7;\n  z-index: 1 !important;\n  display: block;\n}\n.block-main.highlight .btn-add-block:hover {\n  opacity: 1;\n}\n\n.btn-drag-block {\n  display: block;\n  opacity: 0;\n  z-index: -1;\n  position: absolute;\n  top: 50%;\n  left: 0;\n  width: 0px;\n  height: 0px;\n}\n\n.render-item.ghost-drag-render-item {\n  background-color: #E5F7ED;\n  border: 1px solid #00B14F;\n  z-index: 1;\n}\n\n.render-item.ghost-drag-render-item * {\n  color: #00B14F;\n  pointer-events: none;\n}\n\n.fallback-render-item {\n  width: fit-content !important;\n  height: fit-content !important;\n  background: #00B14F !important;\n  padding: 10px !important;\n  border-radius: 6px !important;\n  opacity: 1 !important;\n}\n.fallback-render-item .fallback-preview {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.fallback-render-item .fallback-preview-icon {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #FFF;\n  width: 20px;\n}\n.fallback-render-item .fallback-preview-title {\n  font-style: normal;\n  font-weight: 500;\n  font-size: 15px;\n  line-height: 20px;\n  color: #FFF;\n  padding-left: 16px;\n  padding-right: 16px;\n  white-space: nowrap;\n}',
        "../assets/scss/components/_nav-data-sample.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.box-data-sample {\n  background: #ffffff;\n  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n}\n.box-data-sample .tooltip-info {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  color: #00B14F;\n  cursor: pointer;\n  border-radius: 50%;\n}\n.box-data-sample .tooltip-info:hover {\n  background-color: #00B14F;\n  color: #fff;\n}\n.box-data-sample__header {\n  padding: 16px;\n  word-break: break-all;\n  position: relative;\n  border-bottom: 1px solid #eeeeee;\n}\n.box-data-sample__header--btn {\n  position: absolute;\n  top: 12px;\n  right: 16px;\n  padding: 0;\n  border: none;\n  outline: none;\n  cursor: pointer;\n  font-size: 16px;\n  border-radius: 20px;\n  background: #eeeeee;\n  width: 32px;\n  height: 32px;\n  color: #777777;\n}\n.box-data-sample__title {\n  font-style: normal;\n  font-weight: 500;\n  font-size: 19px;\n  line-height: 24px;\n  color: #212f3f;\n  word-break: break-word;\n}\n.box-data-sample__template {\n  padding: 20px 12px 12px 12px;\n  max-height: 70vh;\n  overflow: auto;\n}\n.box-data-sample .data-sample {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 12px;\n}\n.box-data-sample .data-sample__item {\n  cursor: pointer;\n  border-radius: 10px;\n  border: 1px solid #e9eaec;\n  padding: 12px;\n  text-align: center;\n  position: relative;\n  overflow: hidden;\n}\n.box-data-sample .data-sample__item img {\n  height: 48px;\n  width: 48px;\n  margin-bottom: 12px;\n}\n.box-data-sample .data-sample__item:hover {\n  border: 1px solid #00b14f;\n}\n.box-data-sample .data-sample__item:hover .block-hidden {\n  opacity: 1;\n}\n.box-data-sample .data-sample--active {\n  border: 1px solid #00b14f;\n}\n.box-data-sample .data-sample .block-hidden {\n  opacity: 0;\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background: #ffffff;\n  box-shadow: 0px -1px 8px rgba(0, 0, 0, 0.08);\n  padding: 12px;\n  display: flex;\n  justify-content: center;\n}\n.box-data-sample .data-sample .block-hidden .data-sample__desc {\n  margin-bottom: 8px;\n}\n.box-data-sample .data-sample__tag {\n  border-radius: 15px;\n  display: inline-block;\n  font-size: 12px;\n  padding: 4px 10px;\n  margin-bottom: 14px;\n}\n.box-data-sample .data-sample__tag i {\n  margin-right: 8px;\n}\n.box-data-sample .data-sample__title {\n  font-weight: 500;\n  font-size: 12px;\n  line-height: 16px;\n  color: #212f3f;\n  margin-bottom: 0;\n  display: -webkit-box;\n  -webkit-line-clamp: 1;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n}\n.box-data-sample .data-sample__desc {\n  font-size: 12px;\n  line-height: 16px;\n  color: #646d79;\n  display: -webkit-box;\n  -webkit-line-clamp: 1;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n}\n.box-data-sample .data-sample__action button {\n  width: 100%;\n}\n.box-data-sample .data-sample::-webkit-scrollbar-thumb {\n  background: #c1bebe;\n}\n.box-data-sample .data-sample::-webkit-scrollbar {\n  width: 5px;\n  border-radius: 10px;\n}\n\n@media only screen and (max-width: 1441px) {\n  .data-sample__item .btn-cv--fix-size {\n    min-width: fit-content;\n  }\n  .data-sample__item .btn-cv--fix-size i {\n    display: none;\n  }\n  .data-sample__item .btn-cv__text {\n    font-size: 13px;\n  }\n}",
        "../assets/scss/components/_nav-suggest-job.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.box-suggest-job {\n  background: #ffffff;\n  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n  min-height: 500px;\n}\n.box-suggest-job__header {\n  padding: 16px;\n  word-break: break-all;\n  position: relative;\n  border-bottom: 1px solid #eeeeee;\n}\n.box-suggest-job__title {\n  font-style: normal;\n  font-weight: 500;\n  font-size: 19px;\n  line-height: 24px;\n  color: #212F3F;\n}\n.box-suggest-job__content {\n  background: #FFFFFF;\n  display: flow-root;\n  grid-template-columns: repeat(1, 1fr);\n  gap: 12px;\n  padding: 20px 12px 12px 12px;\n  max-height: 54vh;\n  overflow: auto;\n}\n.box-suggest-job .suggest-job__item {\n  background: #FFFFFF;\n  border: 1px solid #F4F5F5;\n  border-radius: 5px;\n  padding: 12px;\n  margin-bottom: 10px;\n}\n.box-suggest-job .suggest-job__item img {\n  max-width: 25%;\n  border: 1px solid #F4F5F5;\n  border-radius: 5px;\n  min-height: 35px;\n}\n.box-suggest-job .suggest-job__item--info {\n  width: 75%;\n  float: right;\n  padding-left: 12px;\n}\n.box-suggest-job .suggest-job__item--info__title {\n  font-style: normal;\n  font-weight: 700;\n  font-size: 15px;\n  line-height: 20px;\n  color: #212F3F;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  -webkit-line-clamp: 1;\n  display: -webkit-box;\n  -webkit-box-orient: vertical;\n}\n.box-suggest-job .suggest-job__item--info__description {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 12px;\n  line-height: 16px;\n  color: #777777;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  -webkit-line-clamp: 2;\n  display: -webkit-box;\n  -webkit-box-orient: vertical;\n}\n.box-suggest-job .suggest-job__item--footer {\n  margin-top: 12px;\n  display: inline-block;\n}\n.box-suggest-job .suggest-job__item--footer span {\n  justify-content: center;\n  padding: 4px 10px;\n  background: #F4F5F5;\n  border-radius: 5px;\n  font-style: normal;\n  font-weight: 400;\n  font-size: 12px;\n  line-height: 16px;\n  align-items: center;\n  color: #212F3F;\n  margin-right: 6px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  -webkit-line-clamp: 1;\n  -webkit-box-orient: vertical;\n}\n.box-suggest-job .suggest-job__nodata {\n  text-align: center;\n}\n.box-suggest-job .suggest-job__nodata h3 {\n  font-style: normal;\n  font-weight: 500;\n  font-size: 15px;\n  line-height: 20px;\n  text-align: center;\n  color: #212F3F;\n}\n.box-suggest-job .suggest-job__nodata span {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  text-align: center;\n  color: #646D79;\n}\n.box-suggest-job .suggest-job::-webkit-scrollbar-thumb {\n  background: #c1bebe;\n}\n.box-suggest-job .suggest-job::-webkit-scrollbar {\n  width: 5px;\n  border-radius: 10px;\n}",
        "../assets/scss/components/_paginate.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.paging__separator {\n  position: absolute;\n  top: 0;\n  width: 1px;\n}\n.paging__separator:hover {\n  border-bottom: 1px dashed rgb(31, 188, 137);\n  width: 100%;\n  transition: all 0.1s ease;\n}\n.paging__separator--arrow {\n  width: 45px;\n  height: 20px;\n  background-color: rgba(31, 188, 137, 0.6);\n  color: white;\n  font-size: 11px;\n  line-height: 20px;\n  text-align: center;\n  margin-bottom: -10px;\n  cursor: default;\n  transition: all 0.3s ease;\n  pointer-events: auto;\n  position: relative;\n  left: -20px;\n}\n.paging__separator--arrow:hover {\n  background-color: rgb(31, 188, 137);\n}\n\n.cvb-preview .paging__separator--arrow {\n  display: none;\n}",
        "../assets/scss/components/_preview-mode.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.cvb-preview .layout-render .column-main {\n  outline-style: unset !important;\n}\n.cvb-preview .layout-render .block-main {\n  outline-style: unset !important;\n}\n.cvb-preview .layout-render .block-child-main {\n  outline-style: unset !important;\n}\n.cvb-preview .layout-render .block-button {\n  display: none;\n}\n.cvb-preview .layout-render .btn-show-popup-edit-image {\n  display: none !important;\n}",
        "../assets/scss/components/_section-render.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.section-main {\n  position: relative;\n}\n.section-main::after {\n  content: "";\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  pointer-events: none;\n}\n\n.cv-section-wrapper.cvb-preview .section-main {\n  outline: unset !important;\n}',
        "../assets/scss/components/_suggest-sample.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.wrap-suggestion {\n  background: #f8f8f8;\n  border-radius: 5px;\n  padding: 10px;\n}\n\n.suggestion-sample .wrap-title {\n  font-size: 16px;\n  line-height: 24px;\n  color: #212f3f;\n  font-style: normal;\n  font-weight: 700;\n  margin-bottom: 10px;\n}\n.suggestion-sample .suggestion-category {\n  width: 70%;\n}\n.suggestion-sample .suggestion-level {\n  width: 30%;\n}",
        "../assets/scss/components/_suggest-write-cv.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.box-suggest-write-cv__container {\n  background-color: #ffffff;\n  border-radius: 5px;\n  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);\n}\n.box-suggest-write-cv__header {\n  padding: 0 16px;\n  word-break: break-all;\n  position: relative;\n  border-bottom: 1px solid #eeeeee;\n  display: flex;\n  justify-content: space-around;\n}\n.box-suggest-write-cv__header--btn {\n  position: absolute;\n  top: 12px;\n  right: 16px;\n  padding: 0;\n  border: none;\n  outline: none;\n  cursor: pointer;\n  font-size: 16px;\n  border-radius: 20px;\n  background: #eeeeee;\n  width: 32px;\n  height: 32px;\n  color: #777777;\n}\n.box-suggest-write-cv__tab {\n  color: #646d79;\n  font-weight: 400;\n  font-size: 15px;\n  padding-top: 16px;\n  padding-bottom: 8px;\n  padding-left: 5px;\n  padding-right: 5px;\n  cursor: pointer;\n  word-break: break-word;\n}\n.box-suggest-write-cv__tab--active {\n  font-weight: 700;\n  color: #00b14f;\n  border-bottom: 3px solid #00b14f;\n}\n.box-suggest-write-cv__contact-box {\n  padding: 16px;\n  margin-top: 12px;\n  font-size: 15px;\n  color: #555555;\n  background-color: #ffffff;\n  border-radius: 5px;\n  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);\n}\n.box-suggest-write-cv .suggest-content {\n  font-size: 14px;\n  color: #555555;\n  padding: 12px;\n  line-height: 24px;\n  overflow-y: auto;\n}\n.box-suggest-write-cv .suggest-content::-webkit-scrollbar {\n  position: absolute;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  width: 3px;\n}\n.box-suggest-write-cv .suggest-content__title {\n  font-weight: 700;\n  font-size: 16px;\n  color: #212f3f;\n  margin-bottom: 16px;\n}\n.box-suggest-write-cv .suggest-content__heading {\n  font-weight: 700;\n  color: #212f3f;\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 14px;\n}\n.box-suggest-write-cv .suggest-content__refer {\n  margin-top: 16px;\n  font-size: 13px;\n  border: 1px solid #424e5c;\n  cursor: pointer;\n  padding: 6px 10px;\n  border-radius: 10px;\n  transition: border-color 0.2s ease-in;\n  text-align: center;\n  align-items: center;\n  justify-content: center;\n}\n.box-suggest-write-cv .suggest-content__refer a {\n  color: unset;\n  pointer-events: none;\n  transition: color 0.2s ease-in;\n}\n.box-suggest-write-cv .suggest-content__refer a:hover {\n  text-decoration: none;\n}\n.box-suggest-write-cv .suggest-content__refer i {\n  transition: color 0.2s ease-in;\n}\n.box-suggest-write-cv .suggest-content__refer:hover {\n  border-color: #00B14F;\n}\n.box-suggest-write-cv .suggest-content__refer:hover a {\n  color: #00B14F;\n}\n.box-suggest-write-cv .suggest-content__refer:hover i {\n  color: #00B14F;\n}\n.box-suggest-write-cv .suggest-content__paragraph {\n  margin-top: 16px;\n  margin-bottom: 16px;\n}\n.box-suggest-write-cv .suggest-content__link {\n  color: #00b14f;\n  text-decoration: none;\n}\n.box-suggest-write-cv .suggest-content__show-more {\n  color: #00b14f;\n  cursor: pointer;\n  font-weight: 400;\n  width: 100%;\n  padding-bottom: 0 !important;\n  transition: background-color 0.3s ease-in;\n}\n.box-suggest-write-cv .suggest-content__show-more:hover {\n  color: #15964B;\n}\n.box-suggest-write-cv .suggest-content__show-more i {\n  margin-left: 5px;\n  font-size: 12px;\n}\n.box-suggest-write-cv__collapse {\n  transition: height 0.3s linear;\n  overflow: hidden;\n  border-bottom: 1px solid #EEEEEE;\n}\n.box-suggest-write-cv .icon {\n  margin-right: 12px;\n}\n.box-suggest-write-cv .icon--recommend {\n  color: #00b14f;\n}\n.box-suggest-write-cv .icon--not-recommend {\n  color: #de4637;\n}\n.box-suggest-write-cv .email {\n  margin: 12px 0;\n}\n.box-suggest-write-cv a {\n  color: #00b14f;\n  cursor: pointer;\n}\n.box-suggest-write-cv a:hover {\n  text-decoration: underline;\n  color: #00b14f;\n}\n.box-suggest-write-cv .evaluate-suggest-cv {\n  padding: 10px;\n  border-bottom: 1px solid #eeeeee;\n  border-top: 1px solid #eeeeee;\n}\n.box-suggest-write-cv .evaluate-suggest-cv p {\n  font-size: 15px;\n  line-height: 20px;\n  margin-bottom: 16px;\n  color: #212f3f;\n}\n.box-suggest-write-cv .evaluate-suggest-cv__option {\n  display: inline-block;\n  color: #777777;\n  font-size: 15px;\n  padding: 10px 30px;\n  border: 1px solid #cccccc;\n  border-radius: 5px;\n  width: 105px;\n  margin-right: 12px;\n  text-align: center;\n  cursor: pointer;\n  transition: 0.3s;\n}\n.box-suggest-write-cv .evaluate-suggest-cv__option:hover {\n  color: #00b14f;\n  border: 1px solid #00b14f;\n}\n.box-suggest-write-cv .evaluate-suggest-cv .success p {\n  margin-bottom: 0;\n}\n\n@media screen and (max-width: 1024px) {\n  .box-suggest-write-cv {\n    background-color: #ffffff;\n    border-radius: 5px;\n    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);\n  }\n  .box-suggest-write-cv__container, .box-suggest-write-cv__container-box {\n    border-radius: inherit;\n    box-shadow: none;\n    background: transparent !important;\n  }\n}",
        "../assets/scss/components/_zoom.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.zoom {\n  display: flex;\n  flex-direction: column;\n  /*height: 40px;\n  min-width: 100px;*/\n  border-radius: 20px;\n  background: #242d33;\n  color: #fff;\n  align-items: center;\n  justify-content: space-between;\n  position: fixed;\n  bottom: 10%;\n  z-index: 2;\n  right: 10px;\n  font-size: 13px;\n  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.3);\n  min-height: 100px;\n  width: 40px;\n}\n.zoom__button {\n  width: 28px;\n  height: 28px;\n  border-radius: 12px;\n  border: unset;\n  cursor: pointer;\n  color: #fff;\n  display: flex;\n  justify-content: center;\n  align-content: center;\n  margin: 10px auto;\n  font-size: 20px;\n  background-color: rgba(255, 255, 255, 0.1);\n  padding: 3px;\n}\n.zoom .zoom__slider {\n  height: 0px;\n  width: 0px;\n  padding-top: 0px;\n  visibility: hidden;\n  transition: height 0.5s, width 0.5s, padding 0.5s, visibility 0.3s;\n}\n\n.zoom:hover .zoom__slider {\n  height: 133px;\n  width: 133px;\n  padding-top: 54px;\n  visibility: visible;\n}\n\n.slider__container {\n  display: flex;\n  align-items: center;\n}\n.slider__wrapper {\n  flex: 1;\n  position: relative;\n  transform: rotate(270deg);\n}\n.slider__input {\n  position: relative;\n  z-index: 1;\n  display: block;\n  -webkit-appearance: none;\n  background-color: #bdc3c7;\n  height: 5px;\n  border-radius: 5px;\n  outline: 0;\n}\n.slider__input::-webkit-slider-thumb {\n  -webkit-appearance: none;\n  appearance: none;\n  width: 20px;\n  height: 20px;\n  background: #04aa6d;\n  border-radius: 15px;\n  cursor: pointer;\n  border: 2px solid #ffffff;\n}\n.slider__tick {\n  position: absolute;\n  left: 65%;\n  top: calc(100% - 3px);\n  height: 6px;\n  width: 1px;\n  background-color: #fff;\n}",
        "../assets/scss/components/image-element.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.figure-image {\n  margin: 0 !important;\n  width: auto;\n  height: 100%;\n}\n\n.wrap-image {\n  overflow: hidden;\n  height: 100%;\n  display: flex;\n}\n.wrap-image img {\n  width: 100%;\n  height: 100%;\n}\n.wrap-image .resize-class {\n  width: 100%;\n  position: relative;\n  margin: 0 auto;\n  display: inline-block;\n}\n\n.resize-icon {\n  display: none;\n  position: absolute;\n  width: 8px;\n  height: 8px;\n  background-color: #ffffff;\n  border: 1px solid #4285f4;\n  z-index: 4;\n}\n.resize-icon.top-left {\n  top: 0;\n  left: 0;\n}\n.resize-icon.top-right {\n  top: 0;\n  right: 0;\n}\n.resize-icon.bottom-left {\n  bottom: 0;\n  left: 0;\n}\n.resize-icon.bottom-right {\n  bottom: 0;\n  right: 0;\n}\n\n.box-loader {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  right: 0;\n  left: 0;\n  text-align: center;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: rgba(0, 0, 0, 0.1607843137);\n}\n.box-loader .loader {\n  border: 3px solid #cccccc;\n  border-radius: 50%;\n  border-top: 3px solid white;\n  width: 40px;\n  height: 40px;\n  -webkit-animation: spin 2s linear infinite;\n  /* Safari */\n  animation: spin 2s linear infinite;\n}\n\n/* Safari */\n@-webkit-keyframes spin {\n  0% {\n    -webkit-transform: rotate(0deg);\n  }\n  100% {\n    -webkit-transform: rotate(360deg);\n  }\n}\n@keyframes spin {\n  0% {\n    transform: rotate(0deg);\n  }\n  100% {\n    transform: rotate(360deg);\n  }\n}\n.wrap-image .overlay-image {\n  position: absolute;\n  bottom: -100%;\n  display: none;\n}\n.wrap-image .btn-show-popup-edit-image {\n  display: none;\n  position: absolute;\n  bottom: 25px;\n  left: 50%;\n  transform: translateX(-50%);\n  z-index: 2;\n  justify-content: center;\n  align-items: center;\n  padding: 12px 24px 12px 16px;\n  gap: 8px;\n  background: #00b14f;\n  border-radius: 5px;\n  cursor: pointer;\n  width: 148px;\n  color: #ffffff;\n}\n.wrap-image .btn-show-popup-edit-image p {\n  font-size: 17px;\n  line-height: 20px;\n}\n.wrap-image:hover .overlay-image {\n  display: block;\n  bottom: 0;\n  top: 0;\n  left: 0;\n  right: 0;\n  z-index: 1;\n}\n.wrap-image:hover .btn-show-popup-edit-image {\n  display: flex;\n}\n\n.element-main.cvb-active-focus .btn-show-popup-edit-image {\n  display: flex;\n}\n.element-main.cvb-active-focus .resize-icon {\n  display: block;\n}",
        "../assets/scss/components/quill.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.element-main--error .ql-editor {\n  outline: 1px dashed #de4637 !important;\n  outline-offset: 1px;\n}\n.element-main--error:hover .ql-editor {\n  outline: 1px dashed #de4637 !important;\n}\n.element-main--warning .ql-editor {\n  outline: 1px dashed #F5C8C3 !important;\n  outline-offset: 1px;\n}\n.element-main--warning:hover .ql-editor {\n  outline: 1px dashed #F5C8C3 !important;\n}\n.element-main.readOnly .ql-editor {\n  outline: unset !important;\n}\n.element-main .placeholder-right .ql-editor {\n  text-align: right;\n}\n.element-main .placeholder-right .ql-editor:before {\n  margin-left: auto !important;\n}\n.element-main .placeholder-center .ql-editor {\n  text-align: center;\n}\n.element-main .placeholder-center .ql-editor:before {\n  margin: 0 auto !important;\n}\n\n.element-type-text-single .ql-editor {\n  display: block;\n}\n\n.cvb-preview .element-main:hover .ql-editor {\n  outline: none;\n}\n\n.overflow-hidden {\n  overflow: hidden;\n}\n.overflow-hidden .ql-editor {\n  padding: 3px;\n}\n.overflow-hidden .ql-editor:hover {\n  outline-offset: -1px;\n}\n\n.ql-editor {\n  height: auto !important;\n  padding: 0;\n  word-break: break-word;\n  text-align: unset;\n}\n.ql-editor .ql-toolbar {\n  display: none;\n}\n.ql-editor .ql-toolbar.ql-snow {\n  border: unset;\n  z-index: 1000;\n  width: intrinsic;\n  width: -moz-max-content;\n  width: -webkit-max-content;\n  padding: 8px 10px;\n  font-size: 0;\n  white-space: nowrap;\n  background: #ffffff;\n  border: unset;\n}\n.ql-editor .ql-toolbar.ql-snow .ql-picker-label::before {\n  display: block;\n}\n.ql-editor .ql-toolbar.ql-snow .ql-formats {\n  border-right: 1px solid #cccccc;\n  margin-right: 10px;\n  padding-right: 10px;\n}\n.ql-editor .ql-toolbar.ql-snow .ql-formats:last-child {\n  border-color: transparent;\n  padding-right: 0px;\n  margin-right: 0px;\n}\n.ql-editor .ql-toolbar.ql-snow .ql-picker.ql-expanded .ql-picker-options {\n  background: #ffffff;\n  box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.1);\n  border-radius: 5px;\n  margin-top: 16px;\n  border-color: transparent;\n  min-width: 186px;\n  margin-left: -10px;\n}\n.ql-editor .ql-toolbar.ql-snow .ql-picker.ql-expanded .ql-picker-label {\n  color: #000;\n  background: transparent;\n}\n.ql-editor .ql-toolbar.ql-snow .ql-picker-options .ql-picker-item {\n  padding: 12px;\n  border-bottom: 1px solid #eeeeee;\n}\n.ql-editor .ql-toolbar.ql-snow .ql-picker-options .ql-picker-item:last-child {\n  border: none;\n}\n.ql-editor .ql-toolbar.ql-snow .ql-picker-item.ql-selected {\n  color: #00b14f;\n  background: transparent;\n  display: flex;\n}\n.ql-editor .ql-toolbar.ql-snow .ql-picker-item.ql-selected:after {\n  content: "\\f00c";\n  font-family: "Font Awesome 6 Pro";\n  margin-left: auto;\n}\n.ql-editor ul li:before {\n  content: "•" !important;\n}\n.ql-editor ul .ql-indent-1:before {\n  content: "◦" !important;\n}\n.ql-editor ul .ql-indent-2:before {\n  content: "▪" !important;\n}\n\n.ql-editor {\n  overflow-y: unset;\n  font-size: 13px;\n}\n.ql-editor span, .ql-editor strong, .ql-editor em, .ql-editor u {\n  line-height: var(--line-height-primary);\n}\n\n.ql-editor:hover {\n  outline: 1px dashed #999999;\n  outline-offset: 0px;\n}\n\n.ql-container {\n  height: auto;\n  font-family: inherit !important;\n  font-size: inherit;\n}\n\n.ql-container.ql-snow {\n  border: none;\n}\n\n.ql-toolbar.ql-snow {\n  border: unset;\n}\n\n.ql-editor.ql-blank {\n  display: flex;\n  align-items: flex-start;\n  flex-direction: row-reverse;\n  justify-content: flex-end;\n}\n.ql-editor.ql-blank[contenteditable=true] p {\n  min-width: 0.1px;\n  line-height: var(--line-height-primary);\n}\n.ql-editor.ql-blank::before {\n  color: inherit;\n  opacity: 0.5;\n  font-size: 13px;\n  right: 0;\n  left: 0;\n  position: relative;\n}\n\n.ql-editor ul > li::before {\n  content: "-";\n}\n\n.ql-picker.ql-size, .ql-picker.ql-font, .ql-picker.ql-lineHeight {\n  width: auto !important;\n}\n.ql-picker-label {\n  margin-right: 5px;\n}\n\n.ql-align .ql-picker-item.ql-selected,\n.ql-color .ql-picker-item.ql-selected {\n  color: initial;\n  border: transparent;\n}\n.ql-align .ql-picker-item.ql-selected::after,\n.ql-color .ql-picker-item.ql-selected::after {\n  display: none;\n}\n\n.ql-align .ql-picker-item {\n  width: 100% !important;\n  display: flex !important;\n  padding: 9px 0px !important;\n  height: 100% !important;\n  margin: initial !important;\n}\n.ql-align .ql-picker-item svg {\n  height: 24px;\n  width: 24px;\n}\n.ql-align .ql-picker-item[data-value=""]::after {\n  content: "Căn trái" !important;\n}\n.ql-align .ql-picker-item[data-value=center]::after {\n  content: "Căn giữa" !important;\n}\n.ql-align .ql-picker-item[data-value=right]::after {\n  content: "Căn phải" !important;\n}\n.ql-align .ql-picker-item[data-value=justify]::after {\n  content: "Căn đều" !important;\n}\n.ql-align .ql-picker-item.ql-selected::after {\n  display: block;\n  font-family: inherit !important;\n  margin-left: unset !important;\n}\n.ql-align .ql-picker-item::after {\n  padding-left: 15px;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #212f3f;\n}\n\n.ql-container[is-empty=true]:before {\n  content: attr(data-placeholder);\n  font-style: italic;\n  pointer-events: none;\n  color: #333;\n  opacity: 0.3;\n  font-size: 13px;\n}\n.ql-container[is-empty=true] > * {\n  display: none;\n}\n\n.ql-editor ol,\n.ql-editor ul {\n  padding: unset;\n}\n\n.ql-undo[disabled],\n.ql-redo[disabled] {\n  cursor: not-allowed !important;\n  opacity: 0.5;\n}\n\n.ql-snow.ql-toolbar .ql-picker-item.ql-selected {\n  color: #409eff;\n  background: #f5f7fa;\n}\n\n.ql-snow .ql-picker-options .ql-picker-item {\n  font-size: 14px;\n  padding: 0 32px 0 20px;\n  position: relative;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  color: #606266;\n  height: 34px;\n  line-height: 34px;\n  box-sizing: border-box;\n  cursor: pointer;\n  text-align: left;\n}\n.ql-snow .ql-picker-options .ql-picker-item:hover {\n  background: var(--el-fill-color-light) !important;\n}\n\n.ql-snow .ql-picker-label {\n  display: inline-flex;\n  flex-grow: 1;\n  align-items: center;\n  padding: 1px;\n  border-radius: 4px;\n  height: 32px;\n  color: #212f3f;\n  margin-left: 12px;\n}\n\n.ql-snow .ql-picker-options {\n  box-shadow: 0px 0px 12px rgba(0, 0, 0, 0.12);\n  border: 1px solid #e4e7ed !important;\n  background: #ffffff;\n  margin-top: 10px !important;\n  max-height: 274px;\n  overflow: auto;\n}\n.ql-snow .ql-picker-options::-webkit-scrollbar {\n  width: 6px;\n}\n.ql-snow .ql-picker-options::-webkit-scrollbar-thumb {\n  position: relative;\n  display: block;\n  width: 0;\n  height: 0;\n  cursor: pointer;\n  border-radius: inherit;\n  background-color: rgba(215, 217, 221, 0);\n  width: 6px;\n  opacity: 0.3;\n  border-radius: 10px;\n}\n\n.ql-snow .ql-picker {\n  height: inherit !important;\n}\n\n.ql-snow.ql-toolbar .ql-picker-label.ql-active {\n  background: transparent;\n  color: #212f3f;\n}\n\n.ql-toolbar.ql-snow .ql-picker.ql-expanded .ql-picker-label {\n  border-color: transparent !important;\n}\n\n.ql-snow .ql-picker-label::after {\n  content: "\\f107";\n  font-family: "Font Awesome 6 Pro";\n  margin-left: auto;\n  transition: transform 0.3s;\n}\n\n.ql-snow .ql-picker:not(.ql-color-picker):not(.ql-icon-picker) svg {\n  display: none !important;\n}\n\n.ql-toolbar.ql-snow .ql-picker-label[aria-expanded=true]:after {\n  transform: rotateZ(180deg) !important;\n}\n\n.ql-snow .ql-picker.ql-expanded .ql-picker-label {\n  color: #212f3f;\n}\n\n.ql-snow .ql-formats {\n  display: inline-flex;\n  align-items: center;\n}\n\n.ql-snow.ql-toolbar button.ql-lineHeight {\n  color: #555555;\n}\n.ql-snow.ql-toolbar button.ql-lineHeight i {\n  font-weight: 400;\n}\n\n.ql-toolbar.ql-snow .ql-formats {\n  border-right: 1px solid #CCCCCC;\n  padding-right: 10px;\n}\n\n.ql-toolbar.ql-snow .ql-formats:last-child {\n  border-right: none;\n}\n\n.ql-snow .ql-picker.ql-size:before {\n  content: "Cỡ chữ";\n  white-space: nowrap;\n  color: #646D79;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n}\n\n.ql-snow .ql-picker.ql-size {\n  display: flex;\n  align-items: center;\n}\n\n.ql-picker.ql-size .ql-picker-label::before {\n  margin-right: 15px;\n  font-weight: 400;\n}\n\n.ql-align.ql-active, .ql-bold.ql-active, .ql-italic.ql-active, .ql-underline.ql-active, .ql-list.ql-active {\n  background: #E5F7ED !important;\n  color: #00B14F !important;\n}\n\n.ql-snow.ql-toolbar button.ql-active .ql-stroke {\n  stroke: #00B14F;\n}\n\n.ql-snow.ql-toolbar button, .ql-snow .ql-toolbar button {\n  padding: 6px 9px;\n  height: 32px;\n  width: 32px;\n  border-radius: 5px;\n}\n\n.ql-snow.ql-toolbar button svg, .ql-snow .ql-toolbar button svg {\n  color: #646D79;\n}\n\n.ql-snow.ql-toolbar button.ql-active svg, .ql-snow .ql-toolbar button.ql-active svg {\n  color: #646D79;\n}\n\n.ql-lineHeight.ql-picker {\n  display: flex;\n  align-items: center;\n  padding-left: 4px;\n}\n.ql-lineHeight.ql-picker:before {\n  content: "Khoảng cách dòng";\n  font-weight: 400;\n  white-space: nowrap;\n}\n\n.ql-lineHeight.ql-picker.ql-expanded {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #646D79;\n}\n\n.ql-lineHeight .ql-picker-label::after {\n  margin-left: 10px;\n}\n\n.ql-snow.ql-toolbar .ql-picker-item.ql-selected {\n  color: #00B14F;\n  background: #e5f7ed;\n  display: flex;\n  align-items: center;\n  padding-right: 0px;\n}\n\n.ql-snow .ql-lineHeight .ql-picker-options .ql-picker-item {\n  padding-right: 5px;\n}\n.ql-snow .ql-lineHeight .ql-picker-options .ql-picker-item:hover {\n  background-color: #F4F5F5;\n}\n\n.ql-snow.ql-toolbar button:hover, .ql-snow .ql-toolbar button:hover, .ql-snow.ql-toolbar button:focus, .ql-snow .ql-toolbar button:focus, .ql-snow.ql-toolbar .ql-picker-label:hover, .ql-snow .ql-toolbar .ql-picker-label:hover, .ql-snow.ql-toolbar .ql-picker-item:hover, .ql-snow .ql-toolbar .ql-picker-item:hover {\n  background-color: transparent;\n}\n\n.ql-font .ql-picker-label {\n  padding-right: 16px;\n}',
        "../assets/scss/layout/_change-background.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.change-background {\n  padding: 4px 8px;\n  border-radius: 4px;\n}\n.change-background label {\n  display: block;\n  cursor: pointer;\n  height: 100%;\n}\n.change-background__list {\n  display: flex;\n  flex-wrap: wrap;\n  max-height: 344px;\n  overflow-y: auto;\n  padding-left: 10px;\n}\n.change-background__item {\n  width: 33%;\n  margin-bottom: 8px;\n}\n.change-background:hover {\n  background-color: #f4f4f4;\n}\n\n.background-radio__label {\n  width: var(--background-width);\n  height: var(--background-height);\n  background-image: var(--background-bg-image);\n  display: block;\n  cursor: pointer;\n  position: relative;\n  border: 1px solid #fff;\n  border-radius: 3px;\n  background-size: 100%;\n}\n.background-radio__input {\n  display: none;\n}\n.background-radio__btn {\n  opacity: 0;\n  background: #00b14f;\n  border-radius: 16px;\n  padding: 6px 15px;\n  font-size: 12px;\n  color: #fff;\n  border: none;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  width: 68px;\n  transform: translate(-50%, -50%);\n  transition: opacity 0.3s;\n  cursor: pointer;\n}\n.background-radio:hover .background-radio__btn {\n  opacity: 1;\n}\n\n.background-radio__input:checked + .background-radio__label {\n  border-color: #00b14f;\n}\n\n@media screen and (max-width: 1024px) {\n  .background-radio:hover .background-radio__btn {\n    opacity: 0;\n  }\n}",
        "../assets/scss/layout/_header.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.header {\n  position: fixed;\n  width: 100%;\n  z-index: 100;\n  background: #fff;\n}\n.header__container {\n  padding: 12px 30px;\n  background: #ffffff;\n  border-bottom: 1px solid #eeeeee;\n  position: relative;\n  z-index: 4;\n}\n.header__version {\n  font-size: 13px;\n  color: #999;\n}\n.header__title {\n  margin-right: auto;\n  padding: 0 10px;\n  transition: 0.1s;\n  display: flex;\n  flex-wrap: unset;\n  justify-content: center;\n  align-items: center;\n}\n.header__tool {\n  margin-left: auto;\n  display: flex;\n}\n.header__input {\n  border: #dcdfe6 solid 1px;\n  font-style: normal;\n  font-weight: 500;\n  font-size: 19px;\n  line-height: 24px;\n  padding: 4px;\n  border-radius: 5px;\n  font-family: "Inter", sans-serif;\n}\n.header__input:focus-visible {\n  outline: none;\n  border-color: #00b14f;\n  caret-color: #00b14f;\n}\n.header__edit {\n  width: 28px;\n  height: 28px;\n  display: flex;\n  flex-wrap: unset;\n  justify-content: center;\n  align-items: center;\n  background: #eeeeee;\n  border-radius: 50%;\n  cursor: pointer;\n}\n.header__edit i {\n  color: #777777;\n  font-size: 12px;\n}\n.header__btn {\n  padding: 10px 23px;\n  border-radius: 8px;\n  outline: none;\n  border: none;\n  cursor: pointer;\n  min-height: 40px;\n}\n.header__advanced {\n  position: relative;\n  padding: 12px 0;\n  background-color: #ffffff;\n  font-size: 15px;\n  line-height: 20px;\n  color: #555555;\n  align-items: center;\n  z-index: 3;\n  box-shadow: 0 2px 10px -2px rgba(0, 0, 0, 0.1);\n}\n.header__advanced label {\n  font-weight: initial;\n}\n.header__selection {\n  border: 1px solid #cccccc;\n  border-radius: 5px;\n  padding: 10px 12px;\n}\n.header__preview-cv {\n  margin-left: auto;\n  display: initial !important;\n}\n.header__language--content {\n  height: 26px;\n  display: flex;\n  gap: 0 12px;\n}\n.header__language--content img {\n  width: 38px;\n  height: 26px;\n}\n.header__language .content__item {\n  cursor: pointer;\n  position: relative;\n}\n.header__language .content__item--check {\n  display: none;\n}\n.header__language .content__item--image:hover {\n  outline: 1px solid #00B14F;\n}\n.header__language .content__item--image {\n  width: 100%;\n  height: 100%;\n  overflow: hidden;\n  border-radius: 5px;\n}\n.header__language .content .active .content__item--image {\n  outline: 1px solid #00b14f;\n}\n.header__language .content .active .content__item--check {\n  height: 12px;\n  width: 12px;\n  position: absolute;\n  bottom: -6px;\n  display: block;\n  right: -6px;\n}\n.header__layout-setting {\n  padding: 6px 10px 6px 10px;\n  gap: 16px;\n  border-radius: 100px;\n  background: #E5F7ED;\n  color: #00B14F;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.header__layout-setting i {\n  font-size: 14px;\n}\n.header__layout-setting span {\n  font-family: Roboto;\n  font-size: 15px;\n  font-weight: 500;\n  line-height: 20px;\n  text-align: left;\n  cursor: pointer;\n}\n\n.dialog-preview .el-dialog__body {\n  max-height: 850px;\n  overflow-y: scroll;\n}\n.dialog-preview .el-dialog__title {\n  font-weight: bold;\n}\n.dialog-preview .el-dialog__headerbtn:focus .el-dialog__close, .dialog-preview .el-dialog__headerbtn:hover .el-dialog__close {\n  color: unset !important;\n}\n\n@media screen and (max-width: 1024px) {\n  .header__container {\n    position: fixed;\n    bottom: 0;\n    width: 100%;\n  }\n  .header__tool .header__preview-cv {\n    display: initial !important;\n    margin-right: 16px !important;\n  }\n}\n#blockEditToolbar {\n  display: flex;\n}',
        "../assets/scss/layout/_onboarding.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\nhtml,\nbody {\n  height: 100%;\n  margin: 0;\n}\n\na {\n  text-decoration: unset;\n}\n\n#app {\n  background: #f5f5f5;\n  height: 100%;\n}\n\n.selection {\n  display: flex;\n  padding: 36px 50px;\n  background: #ffffff;\n  border-radius: 5px;\n}\n.selection__column {\n  flex: 50%;\n  padding: 10px;\n  margin: 0 10px;\n  text-align: center;\n  background: #ffffff;\n  border: 1px solid #eeeeee;\n  border-radius: 6px 8px 6px 6px;\n}\n.selection__column:hover, .selection__column:active, .selection__column:focus {\n  background: #e5f7ed;\n  border: 1px solid #00b14f;\n  border-radius: 6px 8px 6px 6px;\n  cursor: pointer;\n}\n.selection__column--title {\n  font-style: normal;\n  font-weight: 500;\n  font-size: 24px;\n  line-height: 30px;\n  color: #555555;\n}\n.selection__column--description {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #555555;\n}\n.selection__column--image {\n  width: 313px;\n}\n\n.slogan-block {\n  background: #00b14f;\n  height: 200px;\n  padding-top: 28px;\n  padding-left: 40px;\n}\n.slogan-block__title {\n  font-family: "SVN-Gilroy";\n  font-style: normal;\n  font-weight: 700;\n  width: 421px;\n  font-size: 30px;\n  line-height: 50px;\n  color: #ffffff;\n  padding: unset;\n  margin: unset;\n}',
        "../assets/scss/layout/_sidebar-left.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.tab-navigation {\n  position: sticky;\n  top: 200px;\n}\n.tab-navigation__container {\n  box-shadow: none;\n  display: flex;\n  gap: 0;\n}\n.tab-navigation__item {\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n  align-items: center;\n  height: auto;\n  width: 86px;\n  min-height: 86px;\n  cursor: pointer;\n  background: #ffffff;\n  border-radius: 10px;\n  margin-bottom: 12px;\n  padding: 9px 11px;\n}\n.tab-navigation__item:hover {\n  transition: 0.3s;\n  background-color: #00b14f;\n  color: #ffffff !important;\n}\n.tab-navigation__item.active {\n  outline: 1px solid #00b14f;\n  background-color: #00b14f;\n}\n.tab-navigation__action .cv-builder-style {\n  padding: 20px;\n}\n.tab-navigation__tool {\n  width: 100px;\n  flex-shrink: 0;\n}\n.tab-navigation__action {\n  width: 300px;\n}\n\n@media only screen and (min-width: 1441px) {\n  .tab-navigation__action {\n    width: 350px;\n  }\n}\n@media only screen and (max-width: 1336px) {\n  .tab-navigation__action {\n    width: 242px;\n  }\n}\n@media only screen and (max-width: 1024px) {\n  .tab-navigation__action {\n    width: 450px;\n    position: absolute;\n    left: 110px;\n  }\n}",
        "../assets/scss/pages/_home.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.box-card {\n  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);\n  border-radius: 5px;\n  background: #fff;\n  display: flex;\n  min-height: 719px;\n  overflow: hidden;\n}\n.box-card__container {\n  position: sticky;\n  top: 0;\n}\n.box-card__item {\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n  align-items: center;\n  padding: 15px 0px;\n  cursor: pointer;\n}\n.box-card__action {\n  background: #fafafa;\n}\n.box-card__action .cv-builder-style {\n  padding: 20px;\n}\n.box-card__tool {\n  width: 80px;\n}\n.box-card__action {\n  width: calc(100% - 80px);\n}\n\n.cv-section-wrapper {\n  background: #ffffff;\n  border-radius: 6px 8px 6px 6px;\n  min-height: 1097px;\n}\n\n#cvb-section-content {\n  background-image: var(--background-image-global);\n  background-size: 100% auto;\n  background-repeat: repeat, no-repeat;\n  font-family: var(--font-family-primary);\n  line-height: var(--line-height-primary);\n}\n#cvb-section-content.has-element-selected .section-main {\n  background: rgba(0, 0, 0, 0.3098039216);\n  transition: none;\n}\n#cvb-section-content.has-element-selected .highlight-block {\n  transition: none;\n  background: #ffffff;\n  color: #000000;\n}\n#cvb-section-content.has-element-selected .highlight-block i {\n  color: #000000 !important;\n  border-color: #000000 !important;\n}\n#cvb-section-content.has-element-selected .highlight-block .ql-editor {\n  color: #000000 !important;\n}\n#cvb-section-content.has-element-selected .highlight-block .ql-editor em, #cvb-section-content.has-element-selected .highlight-block .ql-editor strong, #cvb-section-content.has-element-selected .highlight-block .ql-editor span, #cvb-section-content.has-element-selected .highlight-block .ql-editor u {\n  color: #000000 !important;\n}\n\n.block-preview {\n  width: 100%;\n}\n\n.cv-section-main {\n  width: 210mm;\n  min-height: 260mm;\n}\n\n.cv-section-main {\n  position: relative;\n}\n\n.overlay.active {\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  position: absolute;\n  background-color: #212f3f;\n  opacity: 0.15;\n  z-index: 10;\n  pointer-events: none;\n}\n\n.section-main.active,\n.column-main.active,\n.block-main.active,\n.block-child-main.active,\n.element-main.active {\n  border: unset;\n  z-index: 15;\n  position: relative;\n}\n\n.section-main.highlight,\n.column-main.highlight,\n.block-main.highlight,\n.block-child-main.highlight,\n.element-main.highlight {\n  outline: 1px solid #00b14f !important;\n}\n\n.cvb-preview .section.active,\n.cvb-preview .column-main.active,\n.cvb-preview .block-main.active,\n.cvb-preview .block-child-main.active,\n.cvb-preview .element-main.active {\n  background: initial !important;\n  border: initial !important;\n}\n\n.cvo-anchor-text-editor {\n  width: 100%;\n  position: absolute;\n  bottom: 0px;\n  right: 0px;\n  background-color: #ffffff;\n  z-index: 1;\n  height: 56px;\n}\n\n.blur {\n  opacity: 0.3;\n}\n\n.shine {\n  opacity: 1;\n}\n\n.el-main {\n  overflow: unset;\n}\n\n.wrap-skeleton {\n  position: relative;\n}\n.wrap-skeleton .skeleton.is-animated {\n  background: linear-gradient(90deg, rgba(255, 255, 255, 0.031372549) 25%, rgba(250, 250, 250, 0.8392156863) 37%, rgba(255, 255, 255, 0.031372549) 63%);\n  background-size: 363% 100%;\n  animation: skeleton-loading 2.5s ease-out infinite;\n  position: absolute;\n  top: 0;\n  right: 0;\n  left: 0;\n  bottom: 0;\n}\n\n@keyframes skeleton-loading {\n  0% {\n    background-position: 100% 200%;\n  }\n  to {\n    background-position: 0 50%;\n  }\n}\n.dialog-preview-sample .el-dialog__body {\n  overflow-y: unset;\n}",
        "../assets/scss/pages/_view-cv.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\nbody {\n  margin: inherit !important;\n}\n\np {\n  margin: 0;\n  padding: 0;\n}\n\n.view-cv .layout-render .column-main,\n.view-cv .layout-render .block-main,\n.view-cv .layout-render .block-child-main {\n  outline-style: unset !important;\n}\n.view-cv__document {\n  color: #000;\n  position: relative;\n}\n.view-cv__page {\n  margin: 0 auto;\n  box-shadow: 0 0 1px rgba(0, 0, 0, 0.25);\n  background-color: #fff;\n  position: relative;\n  min-height: 260mm;\n}\n.view-cv__watermark {\n  position: absolute;\n  right: 20px;\n  bottom: 16px;\n  font-size: 12px;\n  color: #555;\n}\n.view-cv__subpage {\n  min-height: 200mm;\n}\n.view-cv .section {\n  border: none;\n}\n\n@media print {\n  body {\n    margin: 0 !important;\n    padding: 0 !important;\n  }\n\n  .view-cv {\n    margin: 0 !important;\n    padding: 0 !important;\n  }\n  .view-cv__document {\n    padding-bottom: 0px;\n  }\n  .view-cv__page {\n    position: relative;\n    margin: 0 !important;\n    border: none;\n    border-radius: 0;\n    box-shadow: none !important;\n    padding: 0 !important;\n  }\n  .view-cv__watermark {\n    right: 10px;\n    bottom: 10px;\n  }\n\n  .paging__separator {\n    display: none;\n  }\n}\n@page {\n  size: "A4";\n  margin: 0;\n  padding: 0;\n}\n.vue-pdf-embed > div {\n  box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.15);\n  margin-bottom: 15px;\n}',
        "../assets/scss/vendors/_element-plus.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.el-notification.right {\n  z-index: 9999 !important;\n}\n\n.el-dialog__body {\n  color: unset;\n}\n\n.validate-alert {\n  align-items: unset;\n}\n.validate-alert .el-message-icon--error {\n  display: none;\n}\n.validate-alert .el-message__closeBtn {\n  position: relative !important;\n  margin-left: 32px;\n  font-size: 20px !important;\n  top: 0 !important;\n  right: 0 !important;\n  transform: unset !important;\n}\n.validate-alert .validate__title {\n  font-weight: bold;\n  color: #DE4637;\n}\n.validate-alert .validate__message {\n  font-size: 14px;\n  margin-top: 12px !important;\n}\n\n.el-popper.is-error {\n  padding: 6px 12px;\n  background: rgba(222, 70, 55, 0.8);\n  color: white;\n}\n\n.el-popper.is-error .el-popper__arrow::before {\n  background: rgba(222, 70, 55, 0);\n}\n\n.el-popper.is-primary {\n  padding: 6px 12px;\n  background: #00B14F;\n  color: white;\n  width: 300px;\n}\n\n.el-popper.is-primary .el-popper__arrow::before {\n  background: #00B14F;\n}",
        "../assets/images/box-type/png/Audio.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAHwSURBVHgB7ZjNcYMwEIVffu5OCXQQd2A6iDsIHZgOTAdJKnBSQeIKQiogHZjccrM7cHaH1YBBlhACnAPfzBvZiIHHspJWABN+3OCyhKQl6Zd0wD/gjhSRNqQ96Sj6xAWZk9Zi4nhGO4wIRykkPeE0SlVlpIT0PpbBgBSjiJLO1F76YnkARWIzeIvuhKQHFEkeaPpz0pb0QfpGx0HQ1SAneVQ7dhAjylSOHuhqMJCWTb3BM0omfF4xw8ZiuMN5yKN7YTvR16ALag7kvJ3jdLCcZWiDIQpD3M41/ZwSRqN9G+Sb8aheSKu7eYpiIKVyztp0wT4MhmIoFNXhKHGufklbHUhLWPA1GKE53TCpGEpFnenrFZui5IWvQTaUwDNKJq7hB6+hKQbE1+DgTAZ9mQz6MrZBXvoCtCwUmLGqmRWKFadaMORoUdSOYVBXfTMB9FuFE4Y2GKE0l5JeUJZYXCg82i5gM6gudC+/f+C2cigDWzQrF16zZ7BUNCaDnDcJmgltrN9qqKJhZunP4UiE5kab97W72vGNw3Uy+R9KW/3SEMGRDOWGOqj1xQ4GmWec/+TBekUHbE+WORgEmhFTH4widMQUwRU8Xg1aTC1tWEKfg9XvLjrzoxKjOSiqryfACFxZ+gOUe1qeKtQ8mGJioh/+AG5wnvRX1sAcAAAAAElFTkSuQmCC",
        "../assets/images/box-type/png/Banner.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEeSURBVHgB7ZeBDYIwEEW/hgHYQDZQJxA30AlkAx3BEdzAERwBN1A3wA3cANtwDRcEDDmrNbmX/KQtLffh2qYFFEX5b0ZGW6MZwuRqDZYImIiVz0YFwiAxSl2lJGUIhwzka4zAUYNS1KAUNSily2BslBtdqOyLhGLkfXGaG3VMg1x7Cn/MWBz+MzLW/mLwxNr28M+excvRMNiWYv6rv3GQ4DEeXR36UuzzKJbiTYqjlkH2K5aoUh2j46s+xJVkY6zREivqGOhM+sbGmfd10I1aitSgnaMr1JM7Rb2o3LMEQiQn6iONPZAh964JtZXUZygZelbxEG6oJvqZ6gXV76x8gxC9k0jgKd4YLRAGiSsEf3G3BndGU4SJeIEpivJrnjoxVh2HWy9eAAAAAElFTkSuQmCC",
        "../assets/images/box-type/png/Blogging.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAHfSURBVHgB7ZiBTcMwEEU/VQfIBngD2ICwQTegbMAGdANggpYJKBMQJiAb1ExAmaDYoi7m4ia/50hQKU86KUmt30v8cxcb+GHqYqOMlYsi0jLba1q9myA0ikRL6DEuzsW5gZ6zcDBO/Fi7eACHf2p3HWP80/gExy3EjaUSXLtYgMOgO8Gli3dwXEEkOMI/Z0gwl5QHDb5LDkNBjJmAf0kaevsSnKM/7pFBPMU19NhtxFoWel5xLJyIc98NGF9JLJpPrMDv7nIIVeriDPreuUGzF+dozYJQ7ME19KxFgv7cQs8uFznFBnpBeYMFdHbx2HAwxmGkEsnFsgP9Vwfjj5LQMi4+SL2XNqHYg9rpSCE92UbrOOnBEt1/zBZ0A87TNfq3zcCOoZMoYxaERkI0B7mqy+E0HKQKdeXiGhwGHXXMcQm+GD9B2GJfJ7HojxX4VV2j3AyLplyOclXnTToHB1Mz/aKJbWVGXhjv+dMp8ogTmiCDOEF/p6fQ4ROqonPr4lGp57XYzau/J+7FYWq1vXghrk2h7ygLJGqxn+Kc/hl3gDJTa/eSxh6sXFygn6+Zehvar/RnHAvSg10lwb9hS3CU4DxYgez9rAdLQsuA99tbm1Dc6iy6YXcMDtlZaN3J+gIjefD4K374CQAAAABJRU5ErkJggg==",
        "../assets/images/box-type/png/Button.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAELSURBVHgB7ZTvDYIwEMWfxgEc4TbQDYwbuIFuoG7gBriBOoFxA0dwA7oBbIB30LN+IKSIAT7cL3nQtCW83D/AMAzDMAyjBcRKWCmr6Fnyz4v3UMuelQ1grE4HNTX5Mnf265x1Y71YDv0wZ21YK4QIHtWTbGjkUjSEuAcIobzEkxgv866hJQwPIQTsNOPH0h9cEZfSudevuIhzKTEpu61saPR2iOOOPzVAAzu9P0V7ukRPyNtclhQ7VHlfRn6zRrdadRF3Vv4tkwQnhK4hDA8hlIM0cJmysY4Z0kEthZv4tWM9WQ+0rJeOxhaomkNr/DOoFTFZjEAZGjqdUM3DdABjqY8YwTAMwzAMI5Y3HwHEf8xv88oAAAAASUVORK5CYII=",
        "../assets/images/box-type/png/Counter.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAKfSURBVHgB7ViLkdMwEH1kKCAdZKmAdICpADrAHXBUEFNBTAU+KghUEKggoQKLCnId3GlP0mmlk+TkkjgzN3kzm8jSrrz67M/AFcfhDU6DqabPmsg+by0pXBhzTWtN9xniMcKF8BXPFeotxf03GBlSuZ2mBuaYHbhdI1T2C0YCWaXcjpEY29i+qeB1Su4QLuJs6OB3hUQ/if5Z1O8W1GAEuB3pon5CWkFGC7+LZ8VcKFFFY4S8glVhrIgJDoO8Q32Br46elWi/wwE4VMG7gTFl2w1C1zKKcbgXlXwbwd9RucO1kDu7smv4KJECwRiFXEA/IHNSVPC7sdiDfyH4a4wEGX9zSvJRLgVfhxfgpdkMv5yjBtlnpemPpn8wxvIeZrfcfePM5iPKRnZy8Mtvkc9kHLUY0YpTIBhFN/DRgo2CFatwxYVxipSfc8N5ZoyN4wcuCMKwkcxwBN7iOChN32DcSgrsdv7jiivykFbM3t5ZJLc5LP2GccJDqDR9grdmpek79ivcK5iKj+zzT5iwqSQTT+wKm5g6lEPVAnkLLmU7POc6I9dDuC5CWL+uYMJUj+FMpEZYH3dWXsrmivYO4ReI1srK+Ugy7vDc4bbIF0lAmD3LXSaEsTkGiXmbaEyeZitfktqlqWCOd6IaUF6OxwtvCsoH4xP4y/k3wciGsrXtnDNm9Ik+JdrxHSb7v0UayslN4JNIyjC71ccRQSafqVKSkMdWzJ0ywA/2X/GPrPrjo1gg/ZnDwR3/Jhrnl8r7GaMS8y6jMXkHH68dIXQxKyu0xrAV3yB0DSvLK+erM7K3kewSoRX3EIueI/1dz7mAkh9skPeDTUGuVDI8naaMJATv1RkK3qsPgawyM/vMWcyvPWVrmCjkohfLthi5wHq9eADRliQhg3u7gwAAAABJRU5ErkJggg==",
        "../assets/images/box-type/png/Custom_Product.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJTSURBVHgB7VjtUQIxEH04/EcrIB2oFYgdaAdnB1oBWgFSgWcFHBVwVuB1QDqQDjTLJbCETXJ8/ADn3sxCJru32WySzbsDThwdI5dGbgJ6bWVXxHwSSjQEBTg3oiI2V0YWdtCh/ZcwNVLY9sTIQ8TnPQtyGBn/i35+EzKwxlnC7ps5nidsM2t3kxq/y5y+sAwoIzNsorDB9rENyvBU6B8befcC56iszTVkTLveIBphkD7Dbkj5JDzHlBc4cfAM3rG2dBAU6n3GddrII+qlkkBLlyEMhfpA8RNPWX8D2xpND8kD4hue49BDsgqOysyMBeFDoy4JmgXpZzcXnqN9NYIMytBtwmdh7Vq0aJFCx/6rgH6B/U+TOobPFJvRqEuCc0jlI8RmcqxLxwjxK4yzmSwy/vICOLRQOymY46aFepCw++FX3ZgNQlmaYHs2ZWS2pdD3ic1CPhN80pghcjvuCgEgEIRGvTS7QCPOnmnrPEb058VmFNb7TQm21Pfh6VwGNGT0Eb7nHWaCTyLPpetoekiygF46rUdjM5RBjXjN0rZNm/kSm2WG9LnwXIX4i1jF/p8E29w1Tr5Qt2jRIoEmL02czUgvOA4lmrEZsuGvqgMk7vezYTM57Nck1FkaCTPXgdlShiuhn4Lm32w+PH1lJcRmlpP2ZwUbhJ/BXeAy+Or1S2NFcVZspof18inBlvpo2f27mJiHhowe4ncyYYjtVSKfqy1zimxmtVdTbAbYZDPksOfpi8AzCmG4skVZoi9ZfU//5hod60gFHFXYn3kMEA6uwn/BH2h8OpHE/IMkAAAAAElFTkSuQmCC",
        "../assets/images/box-type/png/Default_Category.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAIPSURBVHgB7ZjhbcIwEIUfiP9kBHeCskGzQdmgdAPYoBt0BBgBJiBMUDoB7gSECWiOJshEd75LQFWQ+KQDxfazHed8FwcA1oUdI7YrbASeqaI9lm04XGF7RUtzUwcgmwiDaDd3HoRhYhl7EAgWhW1qncxhY1PqQ94KS2HjvXadlnoMlEGsE9wx2hR2FkzZaYJ9dJzHBG9Bp3cxrWAOnbxheYi/RtvDX8BMI42oo6VQ56Dv1iXkyYwLSyLaLboOrSDdwUhpl0XqRoivQnaF1tMPBVnNWVOhg0+D9kPQjg3anTXMSD70A52kYZ8X9Mp/F2mTI96ZQxwfqUugPOJBi041tBtqrOWC7drWH+uD5NOJQTuCwd/7QmcONg5MmWVysXYuvKgCtas1ogBpfUzpDbU57iE43xWPTIIbZBIHHamNtvLEi1Bu2e0uTHWzwp5qZmXFaJcN9HXtrKoIMwltcY927BntAXZ87focph6HpmsJH/EQ9hRXJ2G0Q9hxMW3nT3UeOlJu3UDnWyj30PFVJtFiko/UObTXamO3fa/8P2gFU8TPth781yfCQT/bLiCv4lTRnoL9Du03ycKglTKKJRfvKcxQmnqFDPlBJtTRy+Uz9BWUtFtFu0LXqXbxuFaewRYGOG21MhZSXEYB9jvQF/iTmYU5eN+xvEpJPjgNG1Gg5oJtBhtcEPaw4cG/xWRhwS/LAzy35W8c8wAAAABJRU5ErkJggg==",
        "../assets/images/box-type/png/Divider.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAABESURBVHgB7dBBDYAwDIbRDgVIwL8ZJGABB7Alm4Gd/sN7yddem1YBAAD7Wu+cJXrHuHtfaM+xrkzV5r4qU/TzAAAg3w/Triqd12W5pgAAAABJRU5ErkJggg==",
        "../assets/images/box-type/png/Google_Map.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJ1SURBVHgB7ZjtcdswDIbf+vy/ygTmBnYnqDJB0wmqTtB0AmuDphOkncDtBPYGSSYQN0gyQULExAmmAVlUcnJ++LmDRRP8gEAQpA2cOHFcPuD1FEF+BFlEIXyQv0E2sXw0yLD7IE+GNEEucSSWiTHrIHWUVaJbYmQqMflNEKe0cVHH7S4wIg3aJSxiXYWt59axjKhjI+8xEhdovcKb4hr78XcddaWoKzECV2i9h8Rg8t5KMYg9foVMJsiHl9THJ3vxIch5kK9CVyZtPyKTKYZTCMOYRax3im40KK9x0BdRtFxIdS7quS47J6YeLHEY9gpNXGEbV9+D/MKu52i5PdodzfUlDrPRKjn4c6RJxijRLjPTDBi31gxcDxjo0LJVA8f8pw1202V9xwtxrKVQHXtvldRbebGGvjIvcKcK/XBoN8da0csVcaJebpr0+KuEbm8y6626uIR+IViiOwQsZ8ikP5OKEvvHV1/+iL7fsL2CpcddXwOdZYe0PBdasgb6Di+MPty+VnQ7xvNRJ2/CucicBzHOOYadJD4+HX1M5BcMv557tEbKsoVM9pbuJQan8kvgEcPxQT4lk1iwXrs83GG7omcQBvKb3MKmgB1TWlv0MFDDx+ecPtjAPjFoXe1fg1PqvNRNkkYeOgXe3jhrPund2TSZ2HK9XLKf6A6FFLrl0ArR+fo7mcsr7eXYZ9NkcmtiJ8ob5Bnoo4EPMK5RSntmMUF+DuzbjuHM4NAfz31kDPqODk6Uc5NvV8471GdGBvbJgdrvj9zJcgy8i8+dGKSkWRsdPouy1cZiHp9FRl922pz+3RpyQRgN8iBt/S94n/zHiRNH5hmTAAUlaQV2AgAAAABJRU5ErkJggg==",
        "../assets/images/box-type/png/Heading.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAFNSURBVHgB7ZjRbcIwFEVvKv6bzyRfjMAIdIJ2BDpB6QTtBm0naJigdAIYATbgL/kjG4RrYVAEONg8QAi9I1kG83J1wAheDCgyokOLSZL0OfVbrsvLslwgAGZ2OQ1cr0dRNCuKYry73nEUT9BOj+MFATDzF+1vuuLwEyQ/dV0/2+DuJoBrlV3LEc4/R8yMmNfH5nEzk4xwCmmaTjhqbtEnzoTJspnHdgoPuHFUUIoKSlFBKSooRQWl3Lxgx7eQHcij7enEmCzfWm9BMmTwEFfmfrYY6yb2G2fA7sSbT623oOl8Q+9DXPC7XFHSq1Z/ZqSooBQVlKKCUlRQigpKOfiPnWXZB5uDgX26PSprjBEPG4M6G55mmfPEr51Mw8LOY2a+w0eQYctGwB6Un7KzeUKY4B+OHHpScM/H1W69UqIHNzkCYZ75dOYtJVMoF2AFqXtcliuvx4AAAAAASUVORK5CYII=",
        "../assets/images/box-type/png/Icon.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAHmSURBVHgB7ZcNbcMwEIUfhEI4CIVgCGMwM1gZxAxaBimDQgiEQiiEQNhyql1fPefHl2TKpHzSqZWTuzw/O44N7Oz8X6ou7l0csUGoi28fDfRw585d3PwvYSFqRIEcBuV8JjVCVJgJZYqWukgit8XTwQfmdfhFcI8LXpVFnRBHiKJb336BEhKCXBcHUbTExavPuSftjW+voUS6R77NodzFk8gJqwDhvfPFUE8BjYsyJ3RYzkmCgpx7AYdyF4+JsCDOQAFh2H7tXKQurK958nWK4IRKPDznXsDhfcgsViQVFuw/jeTc8D5kiwvtE+Yw3X6DuFwsJnQJYasJ/VpYWIpBXujkXVCbJH9geQ4ZkZM/ZywoXY+4mMF8clMn1CcUYrGc0CFhBjOx0AtdVdgUodXA/YT1psogNnkw9dxX/bUwifzW1pnrhNiJGmUYxHMJh4USh34XK4w7nOOM/LnkAcVb3uciQeeeFNf63CYRWfyxcPjtlMY9EjnXRIjBjJ116iJB517Y8rfIu3RBdLEYh9hDOUw0vcTr0NT0XLeibjHpeULz5jpEB3NcRq5PfoDGPcagf/En6JesF2Pr4hTkG8v/HZ5TJtRVn+4CvAu6zSjCnbwjvw6yOIuNYPF0kIeVBfP8I+zsbIQfHFcpGcx2jb4AAAAASUVORK5CYII=",
        "../assets/images/box-type/png/Image.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAIFSURBVHgB7ViLUcMwDH1wDNANEBt0A8IGsIHZoBskTAAbNEwAG4QNMkKzQboBWCS+qM7HSntpCpd39y6uI9svkqy4ARYsWPC3cSXaK8tHS8K8KCw/LfeyM7IsLb8vhDtUzvr1INUd8gnmBNVX9uADN7ZoVK8xPwhNNDOIHxtcDhJUmsprVJuDsQ8MYrvYMkf1ZAbToXBr3kAPFiVTILK8t3zGhLhW2hk04lLLd9EfYUJoBTpxX6g8ZtCkxKQbSxvior6ua66gz92T4YqjGbAhdBfyHaZ58xi3hjbEBarQFl7fE4YLO3ubH4xrLeFIaDwoEUGXd4TKw9LbBjoYMW60QA0IjTg/NdibKygFakMsEWHYg7x4hiaknBp3aFLBoD4IaDHGg7Gwj3tsPoRN4t1L6vsk+rgdeXzFESGWgxxzb7F4QJwPHpchfPQKCuSQbYUdT5qifXaT4t4QFqc5f+5CAllcLmxScW/TM2mOMJznynoeqmnQUWP7BBIOy0TSsZBvoyncq541Xc1szdNlTApxvp1GnBvj5l2LvrJvni6BqegfOsg6uxL6NwWJuW/RrpmtEtYlkNs5wjvb2Y2payTWjHAYqc766lyb4DwgNILkTjZ9AzKMD9MpILR3vukz5r+d7FYW6d6PBaYHifYLFNHjHJK5cC4mIWFzfvoocFj4FyxY8C/xA2TrHcdy/hMrAAAAAElFTkSuQmCC",
        "../assets/images/box-type/png/Progress_Bar.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAFNSURBVHgB7ZftTcMwEIbfsAAewSMwgkdgg8IEwAbdADFBswFlArpB2aDeoN0A/BKbWpWbSDjkHOpHunzY+XE53ydQ+ec0J+/aiyQHJx+ni8bJzslnIUJd7qhY45V7x7RsevY0jqf4xAuVm9pCBv20/rv9FWR8Tg/sr/1dUUGL6bED+4vwnYQPJqM04saJ8s/3YfEWZUXx3skjFWt6tJdiyMKVyqTEQWLQ5R8NWRgkb+iqyQ8rlJNi4oZB0YLMN88YjxfkpQmDYyVpedli3D9fI58lomZh7MR8jXw2/v4nzYJFHjRYcLnvZoHlbYvxOHj5LQqJZsFgJs2CgTy0vkXeKVTmQ+yDjByNQhvWB3SRU0oU7xAN7nxYQYaUtTQKGNzjfJeiRVSLNeQ45+/ig3vAnllfhH36IGfiV8iQ8sHk4L7EDGqx8tpLUwf3y+IL0MRh0QfZh9wAAAAASUVORK5CYII=",
        "../assets/images/box-type/png/Service.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAHTSURBVHgB7ZbRUcMwDIZVWMAboBHyyGNGyAbNCBkhG9ANOkLZIDBBywQpEzS88QZxziZCyIqTwtHe+b/TpSfrix1LlguQlJSUlHTRuhV82Fvmnl1v7xAn09u948Cxv8rlvTW9fTDbElgSBrhmIbeXuLUQSK0NTGZ3+qRwJxcjLa6dmHNNg+lCChjTXLExE5jk5GLRWcnGDFsgHasdYwTO+ocUaruUk0VWxF8Tv8RlZLwm/pL4S4FDGLOyoV+zhbAaIaaJ4HYw1qPm49q4mPYGxq9/VoBX90TiQzYm6UXgfLqPCnfwnF1gJ7yE684934ivYxNqXCdwqHCGxvpU8UMA5EVSzfg0fBWzwEnlQw9eFlic5x6tI4dwD8pJMD9ECGMxty5W4vghMowrGLeXPqCGn/2L9zf6Iq8qgqsELhe4lvlqDpUgN0++O3O4QuGyAOd76qCVABYOtgVqT9MTxCmHMSXncAeIv8f/X3YHDeitgupIfi/lrBDiNOykVAch2xB4N4NrCPcwgxtukqWK3T0rWlMrmKFzUmyFEKcOvi8S47ArOiwIei02CqtxoevTah/D+Ro0MP33XNJUeSwdQz++Yk4MAFrzxD/g/CWRlJSUlHTp+gQjCQ5qn6WfUQAAAABJRU5ErkJggg==",
        "../assets/images/box-type/png/Testimonial.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAINSURBVHgB7ZhNTsJAFMdfW0gKC1JZAat6A29AOYEu3SknUFculRvACYQTKCegNxBuMDtYdocbUv/PDKFpaOnMiELSX1Lm69H+5+vNh0WGeKBerz/EcRwgGcjsOdKj1Wo1JkMsMqDVavmWZc0Q9TNMBIT2IFSQJjYZkBQHISGevnwm0oQr8E7/AVrvvt1ux/J5TJdzXl55UbRbEC1zJ6PT5XI5TJfLvFAmr0kTky72ZRjm2ExTtsoYjcG/wESgkGFe9/2UYdII0kRbYGKmBp1O5yVdLvMCmZyQJkZ+ELNzlhAhtqIxgbrbfHY/8IM90uQ3HPUnol6GSbRery8jQJo4pAEvb81m8xnRMWWLY9xqtXrbaDQ8x3EWX4AUUW7B9PLGXYj0AuE8ZcrlXZQFMq217FVIkYQ4/mAfHwzz7JMVQviGUGk8Ks1ifCygXcsNDoljuMW4IjIZyHccRyBa4EpGI5WtlKxIlHpHIVT9oM8/e8ZbEUTyHUVREghhHukjSAPVSfIKkTFcxogUsW17sNlsuJuHVFJyRli8rrque0OnSVip1Wq8G/HpNInYDwo6UTQXhJLzInPDyocejAG+ETBZf4vAy99g3+GfydwsQBxvi44tjvHwrcyja+ZmAX96ot3NwFHBUeWDSkpK9DC++qDd3UwWockdtfLBPcmBC/Qt7IgvSBPTC0xxyMB0R/INlNHTK2OP2N0AAAAASUVORK5CYII=",
        "../assets/images/box-type/png/Text.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEXSURBVHgB7ZjBDYJAEEUHsACOcKMDW8AS7IAOxBLswBKwAzvQEiwBDwTCCU8kJICziSbEwO7CgNFk3mVI/gQeZJdkB4ChYeg0OY4TYPFgfuIsyyJZg1IQ5XzDMC6wEHVdb/M8Pw/lKxhB27axLMcXsbHYmr2eqKZp2rK+UYJ4Uz9N0/tQ3v3aql7XdVvQwIQf5/8FLcsq3tdlWT5gZpqmKWS5cg0mSXLDtXXANVUIYD72uJHWVVVdZU1a/0FdPn5JnmyT6MKbhAoLUmFBKixIhQWpsCAVFqTCglRYkAoLUmFBKixIZdLBHSdTOyzhQOy9atyTicnECQ/0R9Bk1PitQwjqiWtvjuMOIbmsID5kgyWAaUTAfJEnN9JOFU2pCd8AAAAASUVORK5CYII=",
        "../assets/images/box-type/png/Video.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAGmSURBVHgB7ZiBUcMwDEU/XAfICGaCsgFhAtggZgJgAsoEsAFlAsIEhAkKEzQjdINg1Urs5riLHTtNOPLu1Mp30lUnS7JdYGZmXE6UPCm5xjTJKcAKE2Zh6bmSbzc3ZEoE64+ePqWS1w7bJaxdrVgk3Nmyz4ujfeLpI2Hi8g7Qdj7v4SM87b0D3LD9B9yps5c72ku2r07hRwqTta46sn0E68/wxDfAjL9LJWtHn1vLp4Ani9aPX3TYS0t3bZC6G3cePqJW/tQcLFmmAI2lZkL0mYNDI9Gzi4/OvwiQxggNYupQgQEIqcHE8ifZIk4tS0SqwaS1FtCZjJbNmDV4AzOmJPRZLRFIzABLJWcw90MBnck7BDBEF6+UXFrrDAEMESB19Zu1fkcAC8RDQNddymu6HNB2e1+xbGIGaN9UChw2TW9Ct3j3y/oeugZLRCA0g/U2XrEeJWtt5ttMD5oTigIsWA+aV5FZ8vcXfaxgtvkB40MxNGVHbxJKJ82v+opdKPnEONCjLWW9hD469wiYx/UUZMMx7V91NhKHfwwdG6o5OhrXmJmZCD/VoZAnhrmxgwAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/dev2/activity.png": "https://static.topcv.vn/cv-builder/assets/activity.d4122345.png",
        "../assets/images/template_cv/dev2/additional_info.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAACICAMAAAD9Ldb4AAAAaVBMVEX6+vr////u7u4saaVFe7Bgjrt5n8Xh6PCTsc/H1uWtxNrt8fV7ocfl7PSwx92Gqcugu9U5cqq7zuFThLXW4e3K2uny9fpGfLDK2eiVtNJtl8D8/PxHfLCivdc5c6p7ocajvdg5cquWtNKKyp7AAAAFoElEQVR42uzPAQEAAAiAoOr/6IYgD5hDzS2puKa4primuKa4primuKa45tmvwxXHQTAKwxyO/tMvRI02wSRt7/8iN5GsHTrTkd2FzAzsC60STOABK81/eCs7xDoN+JPiEI7RPl07uzbcDMDoAARzZA0HoBQWJZ9C/YS3XWjKKHzcppXF6bXhF1rYAg1aa3L7ChUevVjv8HFdsoh+bcHn/ivcbbjRgCgcMWFrh0eU6ohYhyPDhyi+h9drj/HE2vAsgF+f4evCHACryTwAU5oXZgu4bTDJYSstTDOSwSVdNXmvcOt9FHaeWY4nBCCahdnhrNpwOXb6E1zJSA3kfpzVLUDTy7qbqOZZUcqdmnMA9YbdVvWMB9xmBsi+sL8BWTnX3yIMO1EMOKk2fJqATuH9VocnHO+7pYOmBfqEeTePlMdWL/AR6DgccE8BhNeyIMplH4PlBFyS4JzacEsB8vUjuCbGoqHf50BKO+EFfPwNX6iP33hZYDudFg5lzXm14XIr5/rncP0GbltwKroH3GY1X6ZvCNdrOddfwIV3IHCt8JGuBZ+iutkKdxzL48pWt8bhlNrwcqxleQXfDOIybYVbZpFc4dfhPdxsH13hgX64LxygeXX++xxuswIc7Ss4rCd7QYVDFHt/wIOi+QiOjtffcIxkv1JgJ7KfcU5tuO6AbsUnRfu8SaLhUOdoFu1j8hd9k7ezmLtt5yr8sP4djlGR+sv/e58Mr9v7x/WLHTtGARAGgig6RTBRC+1z/3sqIZDFQsFK/POrQNjisd36EEHLcFqG0zKcluG0DKdleK/qt9UrnMHu9AjHuJs8wDnuUx7hIPeQR7gQBThp4VIdcNTCJcMNh2S44ZAMNxyS4YY/t5ey5/Za0qqzqfSfnLLelOY2vemmD8APduxut20YhgLwAUyKonihP1/5/R90jBx4bly0zTos8ZoDRFEkMfBnX5kUU6AZgGXBG3gQfANuTw9XQKvBUtQrvBUBoKUBSFaSAT6KYkQFaOIrxYcmpY2T686opJb8SxpENSo0zjjmQfAc9/Ax9FAoDXjNoc6IVEI3TByZIRRiDVc4WSITysHHukTq7GdHZfdKAVFcOpSQqlexfxSHPAau0yRYk6fOACdzdFrgCRnIGSQAF/hBqYiOTmG7a6TIwSdFJqBVIPGojKOaFDaJ0ljNy1g/5DFwY96m1C7ChrYwbZef2LW4eF3mulB2cKs+485M4QJX2sN95nBs8BieCb4P6YUmQrK7/LLCc34PrpUMSxERO8LLmeC2ZMwODevlL8CSwAlGusIHIQfMAsAohYzIgMoN3JE9nQZeiSLcWok7PIGpskGIqeAKRybqAdwwboBV9ZXOt3DqlXEW+BazbSrraPtNKxkk+/OCm4Rogi/lqeAfZaYSSazgg9zzZE8Dh5Qi+Cw646s5DfzJ84K/4D8kL/gL/kPygr/gPyQv+N+Hd8UT50/g0QC0A0viyNwSIBzngmM0YUsMuCdPAJ/k3RdKS2nhlEQLLEtMeCdc7X+AW0nXdvreMuvYMYiuOz7OMvaFcgGsma/74fv75w/tq2/w0SgXJCqhb/AxCMVA0MqRElrNoab1T4IyIJf1iFjv758/tK+OiTw1YimuXEAKLPMbOLuTVTtQ1h/LCqcZTpXJ0MhLz9CBMebbJz7ESpgwsofXzlyTMpDCRYsw4EoiOTt81MVwBrjnCG+Adkx2gFMTETvAQ2fmen74uPIMjjDH7eE5O1kGfPwwusBlFLKeHm6BaGunv4HLQp3tChfqxA6/ttILnxb+O3Jspx9b7gYBNzxZvgcPGZ+n9RJI8GT5Fy8pGn+1c4c2AIBAEATxGDz99wllfLKzHUxQiPuz17T8zsAjgYNHAgePBJ6fWEae3IzacL4gv45jOIeSC7wWeC3wWuC1wGuB1wKv9eHRHn4KjHZ4b12HAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/dev2/avatar.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAAEsCAMAAABOo35HAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAxlBMVEV3eHhqaGZdWVZHPzpYUk5kYV1RS0cvJSAhGRUkHRg7My0pIRxxcG9COjQzKiQ5LidMRUAnHhlmV0fAtJn68dTTyKyCc15aSz7n3MBzZVKPgGqfknlENy1OQTWwoolQRj02LCaVhm/568740bL4x6j4wKH3t5n3upz548RvZ1x8c2nm3cKupo0dHhv55sj53L1kWlFYT0Y/PDQ+NC6Hfnevq6fMzM1HPDSUjIWhm5W9vLm3t7fCwsMQEA9ycnIAAAA6Ozv///90pjrHAAAAAWJLR0RBid5sTgAAAAd0SU1FB+YIGQYdLjafHIoAAA0VSURBVHja7Z1pd6M4FkC9S3gD2diAjTFTS6qcrlQ55Thx0t1T8/9/1YCXhEUCATZCQvdTn25IW/doeXpaaDQkEolEIpFIJBKJRCKRSCS1pdlqt9udLuufwQM9AE8o/Q7r31JxWgMYYNAesv5BFaYNIyhSF4k+jKP0WP+qajKCWIDs6+O0IImRbItRxkRZcNBKe7nZutBkXY4y6MIk2qS3em11PAg/q4z7muBNd5QoC9dzddtJlbEvsq9xsiyoaGFTIyXlBQjEHUjTig7h+KM76qWpPb8hau2iKPslRO0NKB4+obEuFjNZ/oRR643oVXn0WZeLnawcCGnrVrKIUQfP3EwWFLCXB8WtEACsi3Z96IKBXIgXb7WLSyExZl22q9O7nSwo3OS6VdwJEY114a7ODWWJ1w5vNxxChXXZrk6/uBQiInRa3WBi84bDIUzNtFaeU/LgPevUkbKIDN+jUHAqSng4RJOpruuz+XV6Mo11aYvRDSZa+n5jDOWVDVM/Y11DFt+T6W4kKQxGIVcL/YMlqrmsYXLrMvQgM7WwLI11gYuQHCYgMyRLNydFZfHcwTeTi2bpUYo2RZ5lpawRzmKydNMuJIvnoDQ5d7XScSyKVC7WBb6drAVWlm4auV0NWBf4ZrKQTsLJ2xZV1gUuQmKfZej6tXVxHWYljoZTXb+2Lp4Hw8Q4S9VTmE1wEa1qzB3vP66wf5PvzXBD8haYRZosj6llf4yN9spavtdGB/cneV8L00iuEIWr0+Do+ETbLFYW9yv4pMmhRSsLzxL3N7nu330IK1/RaWFWLCFlEbaQFqxYuiGkLHwSGRSsWDo2sOB9JWyI35E2LehKx9dXvkMHwoSHJmzII4vvnSGtG7ma4mVxPZHGVizkFHaFD7Mg32ll3NxwVbRvT2iGUOG414rH76h4E0ySxXOSJtYKUeFh8AxxIYjfxEOsKNHuajk5lhqtFhkbJ3EdiNs+Pha9h+N20wJwZS0dx1ohiKwkXc7S8ghMp2ckWdyG8dHoPTwhXCD7owNbAIiWeFGzSaDN2fPzkhAxN8hrHx/dXLQOVivbDrfJOX7C6GdMkT2xjhi+NuOoixQ8cBs+RFPwgd59qsbq0RTF0/LmBIJ5aFBwJuAkdUWSxWmvFRkMlUATNDA91AzBecSVamMi2KWtmkm9Fp8nLSKyxh+u5joOr26FapG5IgT7jh/ZEvcoaazLfQ1ZHyvQpAnPIryMMSUOkKYn1SQtXfOZXY7Iokj42Vkm2aSqxWdaKyJrkl5+B9r0smYiy6LxAHBba0isai5rApcUT51ZiCQrEpQCqn4ow1IGoR3y2cFHI3iK8juZ1n3wi5Ia63LnIppUpsgsZJOFnyDyGZRGE6UU+eRMwyE+eOB0utMYZJY1LS6L1xxNZMfRnKL8xWXxugk3stGBpjsqLIvPsdBjmC5rGmmbWFlTQureEqhiNRpqmqwJhKqZJssg7RPEyBqxLnJ+wonleHA+jTnEyJoS+7u4rAGnSeUjofHQwZfWTpEVf+hCfHLI9W26oS5ev7asWFDKcSP0CcxIMP3O3P/3qxRZ8YdIsgDPjbARmvJg8lkzFO3KMLLiD12I5EoVPic6AT6WeHCZqiVA4TES195iD70/LFCHdeT9MGvS8ZNkWeSHQ2isi3oFzsekKbeRgtyyuA3d47ZcynSxnUWW32choVz5N+WP/0NbfntF+6SHZc/nBlIEctWDaoZdWXbmHfKmBRXuj+2c6VD27Lll6bqDEOcB1pmhkqUTyidLX3K+qftCGxNeffr85evdty+fv2eSlfTWitdccpix1whnm839X4FC3134+p1a1qcv+Ld+bDYLPzHBf0Dq4c1TpoOHh4f+xdbPb3cBfsVk4Tc7kN7aen/64dELz3jNvAdpQUf/PXhcDB5+n2tIqNR3d9G6ZWNXNUhv/fBM3fcffugrl3VJr0DXk6X1db92neKHz+FS332lkkV6S/Nr1fJhplsiyGrAhX7/8JdfBzbH4n2NFPvuZ0SWatv2au6Eh4VvhLeO9XU71sWoWQ3gReSPP7wi/daOxYuW+g43uMUgvPXjwf/L2lSQPquhXUKH5e8byDp3hLrD6Zp9hI+g9CTtS6TU32hcEd+6DLGqy7qc1yEy3fkZKfZnKlnRtyIRh8HxkZ0wPRjax/0rh6vkt0xDkNnOyRYInmP69S27q4S3zDlC4rhqNJo7CFXbuMTmn36duqCvnz9Ru8K/Za1sFcIdvyv2eF29tgqCN6p8+v4zgyjCWw50++2OGNmZCN3iFxREsBDrMt0ORLM/Kws2x4d801CzpNcpMAUaBGNoSduVSQtlCYtCC473YqXSTDoQYOA7tElCP2cIskqBZ5CwdGGqFu5fJp17QhrrAt2SUdIZC1NVY2fzUdLZqKXIrTAteDBtGMr8zYzkRbSV0K3Qa4fJp+gsL9C/nK5fGim7m00hNoIkMEq5FnHmX7iGbNufxEA7OYad835bVhrd1ANys/lpNx8w0o5jqAJHpCcATVxqOhTzIkeMlcIkelkOqiZiiLEGncQQFb1G8tJcRe/efUZFLyg9YwmybyaR5hUu/NP9Ox2EWPpKY0dzUjq9YokdvV+4StUy0Y51OcphV/j229pULL9qFR4Qa1Ox/AGxaKxloZpULH9Bv2B6ecbtmfEcdLJcoYJhxeu1frlQCzVEUbYmUzJUUj+NQsZU+LyYJzfdTGe/wgzE2IqVgR7s53Rl8H60NwdKztu7DZ5vT84vC6o5evk1nNRQlp86RpkjiDVcmDWVBeEkU1Ocqv5HCmorK1PlmiPg5+brKwtCm/KLFlMb2sd6WGdZdLpmH0uu9ZYFIZjPUlWBi9K6y/KvXpmQ6pe5sENDQZ1SDgRZx/ZoOdHRcTo/XmQU3F8jZb2DbMPyP2vhf7Ridb6XJ/z5GTGONF1FFkZf5EsgtpRFq0rKIoLbJVk/WV0KUwC/+bZ+slpwkFKniNuU6yjLmS0mhA8N2ZNlwgTbrllW2Zd1qjgzZ25N7HcMK3qSHCPLZf3jy5el58WQsugR4wYHKUvKYo+UJWVVTxZk/eOlrAqj5Zc1r52sdn5ZjpQlZUlZ15GVf3+WlCVl3UpW3Xb+FZJVtyXpArKmUlYGpCwpS8q6CqqURc9YyqLHLSJLY/3reZJVtyVpt8BpVikrAzXb7DDspNwNlYQzFuR7RBQ0e7vjBhrVynNrqbk4fuXVHYl5lWuQYccX5T4+7Z+f1ggCY5ntZNjSQPDl8Px6vwYQgrbAIURTA0dRb89nDo+uvw9rQXc4bLbwTLmb/fnl/b1nW9n1RKxg3dEAopf7S1EvvD35wpBtLRLb5HRh+KI3kddft97LfcF8+XUKrZ+e8bwdti+uvyvSNqyFE9qeNXMcyzpeabcL1Mgg+82L74t1Ca9Gr59g6p3D03a9czHbAHe77f1r0pv7jQuVvgjZ0+ZIgbv7tzRVgaZ18Nj6PHn/sKd7af8IIOC9erV2ED1SFrggTzuotDnuvTouBFkqVUH23vDI6zcHegO4S+2prsvblk9dLQB3h3JV8aqr6zJRddbFVd813EFQcgMM64IKNyOjpqANO1U++xfochF3eS1wXd4ISOIA4Kj6bbENAaPOKsIWDiqelGi68JF9tTrx6lY7/dxRKlKtTmwhqG4UsYMvValWJw5Aqeg16EMAGQ+Ccd5eqnkzWVdBr8VLd3W2sF+9UbGH3Go1wQtPCFTNVq9q3dUHr0ipVoDag2vWTsjs3UrZqrQrr5uvkq2Ku6qUrcq7qpAtDlwdbVUhmO/y4MqzVYUIoqm4rD3Q8Ypc1q6GY1DV+CrKgfnMZ1fJOQ6eDeOPi/XgPWsFGXhh2sk30QtrAVl4Ayw/tely02GdODDMnWqwSnlRGh6ZHVUcIi4irCBvwGUka4f4aoQ+B0YfVmlVL4tMwQubT/a4gHXB87Bn0se3uOvdTzyyqFrujnWx8/HG4JObLchwn0whtuVXrT6XPZbPvvTjik2uJoVh1mV/gLrNYYx14bXs7MOAu+A9gFvuN0q7kJ80VpwNLLWLH3Hbvfvsy53zDB5ZF7gQuzKPwnY5jd4vbMq8gUtDrItbjH2Z42Gfq2wyBlDiQo/CY3ImyNotzRXvXdbz8315nVYHsi5sUV7Lu/unzcmKfQLlRVp9TlNZAdzSklrulnVZC/PiliWLy5WKMNvS1qa5HwzLjOEFkHWQsqQsKYs1UpaUdRvKmxwKIGsrZQkg6+9/Sin/P39nkVXaQmtGWf/2SpH133+zyHIrKuvP/8qR9UfKkrKkLClLypKypKwMD++kLCnrNrLGUha9rNKWwqQsKUvKkrKkLClLyhJAVnlHwwSQVd4RTSmrZrJK2/kngqzS9pRKWVKWlCVlSVlSVkVlvUlZ9M8epCwpS8piL6ssV1KWlCVlSVlSlpQlZQkgq8QrQ/iXVd6ZgQbcHLLwp5/p8by0/tA/uy5RVjb+zfh8TpQs/5+8Byz+D84Nlkw6pOswAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDIyLTA4LTI1VDA2OjI5OjQ2KzAwOjAwZg6JMAAAACV0RVh0ZGF0ZTptb2RpZnkAMjAyMi0wOC0yNVQwNjoyOTo0NiswMDowMBdTMYwAAAAodEVYdGRhdGU6dGltZXN0YW1wADIwMjItMDgtMjVUMDY6Mjk6NDYrMDA6MDBARhBTAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/dev2/award.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAADACAMAAAAeJl75AAAAbFBMVEX6+vr////u7u4saaVFe7CTsc95n8WtxNrg6PDt8fVfjbrG1uU5cqrl7PSHqcvU4OvH1uVsl8DK2umgu9V7oce6zeBThLXh6PCVtNKivdhShLW90OOvx91hj7zy9flgjruwx92TstA5cqvy9fqVY0/+AAAGfUlEQVR42uzY4YriMBSG4TnznZ9NSkMIDUlTqfd/j3uSYB2lCzs/dshu8oKaHiv4aC3Uj89O+/ikLhvw3hrw3hrw3hrw3hrw3hrw3hrw3hrw3vo2fL7TH6QUNd634Rb+HWkSvedZU9tdw60hWgOVZr1tVhElt5Bk2IrVfXFZKHpvXpja7hJuhKJg6nqalgXHLHBLkl4TybrCDetreFwStd0l3G5EN6YSZ5aBTGr310/IFvjLdDV1N6PpTLYb6xLOkcjZk5Yxcs9yCw7YFCkuKM+YWOB6AisKHPLIsFEbwMFaz35CnuaBZk8NdQW/fTnSPc63i02mLvjyaOvPH3sUuItahhE3ohWTJsYaGU6tYL/ioDzwcqOGuoIvC5FmKq1FI1V4VKI4Kvx5qM8y5Afc1OmMpWyQQyqD0DxcIQrEU8lnDTNQ4GSsY+Adrl7hHoHypMJ3qPKMaR5+O+p5vRSgSdorfIaLhv9X+J4xG9XSdKQnXGfJ7+G+wCtRYTvhBvofgKuCi49ND/ZxxVTgHovReMIVXDjhM9j4qbz6uAWHeMLroHW4Z6IAdW5HBrDPBZ6sLB3SAy5onHBxYlqyVe2y8vSEKwb21uG7JtL29YojneukLq9Gzievd7uTSu2f1f9CizWB0dQV28/ARQ0O1FI/ApdSU1/3+Aemwwa8twa8twa8twa8twa8twb80S927G61cRgIw/DHjqQZ/WDZCMXgs9z/Ta7Hpk23oauzBkd6DzKJrQieEIwx3rYneB9s7Ru8F/bev/B+3EC3cHyF9+QGBhx/unIDAz7gnTTgA95JAz7gnTTgA/49mZyVYzC0OeqLc4xL14SLSQuFc0w7P5EFmMJGBVeuCbeUMdHKFLGQn8Oi8JsBUsCVa8K9QMWW1uM3wKxwEci7w/cqWZzweMK1iQRXrg1HTgue4Pd9XLo2XNLmgUL586/+Du42XAxZZok0VWNwwNW9MbPHhWvCmTSGJTL5Ax5IW3HhmvBH176YjVvWAR/wAe+iAR/wThrwAe+kAR/w/7ZU/Nj9Uo9dW/DHM3Tn9f0NqIxHhLMpiPU4oxVaNB7PsTsHA7Ld8bLa8LvhuATAivo8EMsznIs4oExf4Sj1Z3itumPJeFVtuMmATxnVA9XOQI7YizIXAcgX9oAvRRCXEA941mMSj6XVV13nuQif8Fk3iRmQUgGJs452vw2fE87Mis0VU2Ad9tw2ueRBwS4BYuyUfA0bH/BNj7GDLg1hcsbvwwY64MlZw3AWdSsuHJ/TC+RtuAHyPPsd7hng5QNugRuDBJKQK+BYz2iUIfQJL4DJxy4nfAFq0K/fop7hAEwO7V4BL3/bu5vdxGEoDMOf5GP7+EdJo8gZKTvu/ybHVqCNEFOmUSucnvOuIITFs6mI6EdcThWOt2mleIN7IFY4GhKXJdIH/M8e7gFKjccb3AGcG9zEGLNvr9ge4cEEANTgnBn+IdxPAe5T+LKHjxs8MXPoFo7ogJAbfMwBw0P44BDoDt6s7gYPmVE2OAVcXIPHAfAdw4PLCw2ocAw5T/QIzkRrdSTjPuChHltvcMxmWTf4uhJxgzMt5NAvHAj8/ijgH/GD13n/LPBI+3NbY8CRTvVZfXWeLO6KBf/fSeHsbUJP6dWZwoWkcIULSeEKF5LCFS4khStcSApXuJAUrnDdnX2yO7uYGEXuzqwDiHDmDu3OWpwdztzR3ZkxdOotzuHdWfL16Jk7tjvzCYgGZ+7Y7izmUmjBmTu2O2MyJp57jnV0dxbO/adNP7IqXOG/PYUrXEgKV7iQFK5wIX19d/ZL+pbd2UgMfPzbeZzxIEqoBReAy/r6a/nv2Z0Vu4cH9wl8AMaZX/+DSd+zO+OEBt8mZe1EHzi1WVlTlnFEjcrsGfAASntnYT8zDtXP7sxHNHibkCVQauuMtzxZshjz4MiiRmQdBRhgcjMl0Fqf40gd7c6u8KkdfoejHZ5mwG3wdB2xFGqvXE/DgTranV3hbg/feEvawdsjA0sxLtQ9/Mnu7Cm87OHTDIN54lr38Pvd2VN4s/I7vB1bNvgArliDlBlc+off786ewr1ZpnyDB6pt8GnJFjCApYVS//Anu7PH5++fhGm+f/eIl/fTn9ULzRfiu4Opg2+ffhqO0c5dfumiV2cKF5LCFS4khStcSAoXf2s/uXARcqn3LZV6i17oTZn1NtziUri0FC4thUtL4dJSuLQULi2FS6vChfYXRbKezVWxkrEAAAAASUVORK5CYII=",
        "../assets/images/template_cv/dev2/certification.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAADACAMAAAAeJl75AAAAaVBMVEX6+vr////u7u4saaXh6PCTsc95n8XH1uVfjbutxNrt8fU5cqpFe6+Gqcugu9W7zuBThLVGe7DT3+pslr/K2unl7PR7oceVtNKvx92wx92TstBHfLDy9fnk7PPy9fpGfLDX4+5umMFul8EdXyifAAAHHklEQVR42uzYwY6kIBSF4T59NiQEwQSuGLSs6vd/yBHGVNvTZlLJTCca+DeAsPkCK9/eK+3tHVXW4LXV4LXV4LXV4LXV4LXV4LXV4LXV4LX14/CAc/Y6PPjpOb+F26unVfI4Y8dw8cBgUbobpUxY1/wUiJ7x94QBJa8Nztgh3HNG2JxW64diCnv4yDtehSvBKTuEi1pxPUqpnwFPKfAbSlPIegtsH7ZxNy/wG07cITxFwAlylmV0boWLZrrDLx1gF+viIg/SAOg03ceCknekBAhNOR2Wc770Q/i4e+kDR2Cb9XGggucARGoF0kRHi5EuColcWE8ZKghdGQMv9NQ/HoDp8Q3uAccNnj9TAXZdOc5lJ2fyKVkgvAOLvhQ8MAKpO4SrP+BlRYeyg88BwpAXl4KPOntmlCI7rHVDBXAlgCj8bmKeBaod3ADdHu70BKjdU+/kivBAD6SILcNHjInxCZ+YbEx7eMeHH0jkPJ3vqK4I73rAcn6uB03qEU84VqP+2MNhyD4RJduTar4iXBnACHaFgC9NYcKXblNA0thady9Qhv9rNo3WnPVmfxI+C6nNJe75v8Gv9bzbH5gGr7AGr60Gr60Gr60Gr60Gr61v8F/s2MmOozAUQNGr9vPwbGwz7PL/H9o2dFVqUDe7tCh8F3nYiUAHJVIEP7Zv8Huwe1/gd2G3PsPv44bbwvkIv5MbBpxft3LDgA/4TRrwAb9JAz7gN2nAB/xrkp2VfSg97/uLa6tLdwqXKW0mHCM3fjIW1ITZFK7cKdyalWxEjWcz0Yetw+cFUuDKncKj0MXWyH4P8B0ugvx0eKs26wH3B7yXjXDlzuGsaeMb/NHGpTuHS5ojFLO+f9V/gvscLpOxquJNrtPCDu/uWVUjF+4UrqanWGOW9Q0e+t61f+Sn8GeXdo6/rAM+4AN+jwZ8wG/SgA/4TRrwAf9nW+WvPS712PUM/nyG7mI/nqEqzwxHOYiN7KntFewGSI48y7JavlbtHqzZ6Z+1yvuFy0rLysvhj0X9Fv5cujN8+Q7XIg5KpuVVTdEKeYX4Cbpu7jvAqyarim+vbga3qbol7heeM5sF6sLL4dMKMa3UCNV6WD0tL74ImFg0Qixt4bfg2TOd50uFqLTE98W+FYk17gspVTx7U5+zAqHibJ8l9pNEE30CXH453CeOJmF2ZSpYR8vN2aWICXYLyGRzijXM+oQ/luICYo6TBDsp2rYWpC9sG9kl94Q3I2DdAd+sn2n5SPLsN+HV8AVW72ODRwXd3uAWZu1ESawVnPZ3nnAvfR7wjihu30oiTVgXnIP8AX58UgPOef9IooEjm+nH/wNe3O/27m23URiKAuiWOPhyfMW85f8/dGKnMAQy6jQadaA++4ViMHSpbkUjbeE0fF3L2ZsFbgFzhz++41s2fgenkM0KN4BVmyE91ckYD/A4Q2WlQkHKv9fcbIHvhS8r0Fc4OYJ9CbczH37iJgI7uBkBv8DnHRyuPH6Z1YgacgxgLvU2baV/MxxGAewqvDhGeAkPCuyf4A2jd3CfUIYFPhpAbeHjzHXGAocJQJwARN9O+244K5d9ADwhODdPr+DkfTYBelC/4XHwxuknuF2GKpznKectHMF5l7DCyUw+l7boEmq+GQ4wrV8x/hA6Hmf65LN55mrcz/jkCtd/VtdTvLkvyH4MHBQj4+/zc+BfisAFLnCBC1zgAhe4wAUu8E4icIF3EoELvJMIXHpnf9M7uw3GdNk7GxXgJ1w5b/XOasgpXDnv9s6GYbp0F+ft3pm299Er573emdWAGXDlvNc7My4ln3HlvNc7Iz8M5tp1rHd7Z3ztP23yyCpwgf/0CFzgnUTgAu8kAhd4J/l67+yH5J/0zspEAGhsKeQ1ALs9iwICYZ+xRQNR1aP8sQe+1f0S280t9jlT7yyNANja2VhLlQmkhE2CijjE2pCtLVDGRp9Ag71vbyAfkp0KDQzAHOCn6p1RG/romLCtB3RB5T922I5lnYIUKTFqtFnKdNrd4Y9tVI8rmQjQQNjnTL0zazZwr6LXHwULMwU1cRuyUFObEvJoHP2Gh4B7HDV4GRoYVBANEBUOOVPvbAvnVLcL3AK+cGoEFeoUHgg8bOCPM72mQeuU1bq62TF8wj6n6p1t4bDG+BWuKwlpHTK2XhBHuLvDlVIRKxxzLBOOOVXvbAPXE2N8htNEsAu87OHRoF6EaUBLm5lCPRoUXuREvbMt3GZgfoanDKgFXq9FWzi71GYscO2otdgA5wuOOVPvbAvn7LwxT3Ce70P5Aw7r87yFo3jvDK9wjL7dEBgzjjlZ72wb5k+GWq92G2Ic91/nws/qs7I54Mu5Prw9Bv33yH9nAu8kAhd4JxG4wDuJwLt/tV+/8C7kvb63tNdX9EJeyiyv4e4uAu8tAu8tAu8tAu8tAu8tAu8tAu8td3in+QXOtJ5Z5cNregAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/dev2/education.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAADACAMAAAAeJl75AAAAn1BMVEX6+vr////s8/7u7u4saaVFe6/h6PBfjbqTstDt8fV5n8XG1uU5cqrV4vNGe7CgutVcjLuGqcu6zeDy9vzT3+rg6/nK2umsw9qkv92wx9+txNqMrtLH1uWtw9pslsBThLX19/xQg7a80eh7ocf8/PxolMHI2u6Yt9eApcxShLXl7PTk7POhvNZ0ncbk7PS90OM4cqthj7x0nMaApcs5c6o2g9IPAAAIyUlEQVR42uzYsY6cMBSF4T3aI+Fi5krIkaXb4MKdbYVByvs/WzxmN6MMKNtMsY79FxTc6gMDFm/vnfb2ji4b8N4a8N4a8N4a8N4a8N4a8N4a8N4a8N56KTxaNNMr4ZErmukcHhxgqsIGRWkN6Qu093E2aKdTuGNCpEPpJwNKhg7/yokaiWioU3jYABUc4RZ71uK5P2caec5P4aKADwd4/kWG4oob6SNKVzGAK4fVk1uEk7nMmljxZ3B9rPQCX1wp0EHpNXAB5JLzRSxKcgNmuki/Zm5wRZ2FV3z/zuDLUjSCD/hHDv6WgIlxZQZUqs7czwuSpnoRHAOQqfj+ncAjFZD8Cd8+7zg3VNUdW6tjE+9YF7yQBW4AbRWut/29/tcz/oCvD3hp8sorrvTqpHX4FOp7/QCXmy0DJmV+fNgNvexjtA6PFaFHeObiDBdYEV1FdrglZ9TR3PpSzwKsTEc4zIWcLJCElB/Ym5gKP5SJZ2waPs3AHHCas6jZiKdsU9u2A/yL1jb2Jq+Hp+DwvzR+RPTWgPfWgPfWgPfWgPfWgPfWgPfWM/w3O/baoygMhQH4pDm90WKBgaiIF8x6+7DJxv3//21PKy66cTLiuhtn4E3s9DrJQ2sEvsGXzbc/4f1gB/o1vDdukl/B++MO8hbeIzfJb8ChF7mA92nDactbeK82HGCAD/CeZIAP8J5kgA/wT5PVG+uQt9UXga9Y56y+AvyNPZC3jnDn4J3kVsGf4RJCFCq4HbXU/9fdyjvBBaK5bGc8h3PKBVwm5eIMzxYiHd+4iLTYSf1/z3mbVRd4hDYFyEvhSk1NEWEqoHKl8DyVAZhMuwwouUSnuaxURY3K94lSlH5i7jLjp4gFptqUYErtysfhDWMbU1Fsi6bZVuPt71axDjOpI6QLnMvIalBoLUpvtcizjFqjHA5WYgQRchvOtaMhwS1NNJAix4Meo+W0qkJL85vFJkJacqAlf7fhcb2vd1TOkpitkyR08B2jbDbHJLSmbJYc64Il++O+2fL74RXODc4JnsPSAmVMLD7SwkqtDCy8QmgrgUI14AcwmFYY0RI3xjnN0JL6lx5OfQYCPKf/8Xff8NmOFZxt1myyZ7stwSczFm9oYE1FHVOrSBhn7OdkemRUCXm7Hx6hyYmlUIDEBi6I5SWl5BY9BHgLl0DDNKn54zv5EkBewwXIh+HsnDhhfru/hxpte7HbNyNJMZsw9sNXv6/D8WgG7oYLDNFXcB3gS9pWsXgPPocc0zN89E/gBY8Zb+HFpuZxPJkUdBpmzMORJu2O4fRPu8JLVMYoVJdwJaStFEYZpjlHfQnP9Amu7aFK0TTwFF3Gg9PR4qfBN2Rrdzwc9TrAyc2aHd/WBQsXoitcogDQdtnCBcc5fVBqvUB7QNHCDaI5wSHjaB00cE0NgjeLnwXf78JB9uAA/7ljMWeUcOAne+r0V6Jxd/uO346gj9bQlJfR4mLWxVguBF823c+6bZv+SJJkGycbsnkjITfJhAYKpIFJUW/4mtV1kuzXfua0A/xpMSgtZv/oPj1uq0Uob7c6/Jw9U66cgOeFPZxP/pDy+C3rJ4c//JAyPJZ+WnhvX0T099VTj182DvABPsAH+AB/AO7U5QNGVvpSzuFGSuXj4DpVGtEalwNFCXiVfAznahyNcmhi3PtwMx6jG2dwlWzkzEKCklTPUcOr5A64IZLVoEtVAeTmBM/CKagUMWnEN0JQ+LYrBYlPb9S5v0bW5JbMaQQvk7vgoThEjpegogA/pBFJUql4CmEka+GCp9FIAB+paKQFAiXX4ZBwAy+TD+EpLqXfYj0GGC/OcOcVYqRBW1PSuIlauCeqKCilq0ZwipNA9dfJh3D9i327200ViKIAvGP2/LIB4QyhWsVqYtWL3py+/7udPWpBJDbShBMaZl10YODm62CLhCVyj8khr5RQV7i3qahU502dAaeBk/Of7DM805LgEkPGjuhKf/JSlyhlIqG8g2/8Zq5tGy48XF3hBg3weF59MZ6/6U/CTZWBIwDbhhuSIFFGZCBVDTzLAKoUhAYjIrC85xKejmgDI8oTcBJsYAsJtWnBIRcbUQLoZKNkAzdVIioAUSnSvGcTQQ44tIYRpcedm5TQSdR5ml4/bRcRDz5mTFf4T+A260zJh3ck4/rf9V/v1fNRLnT4khLgAT6RBHiATyQBHuATSYAH+EQS4AE+kQT474C3X/iZzMs/b7eSCb3u1VrtwV/wk1obHpZ6DTdBe3eWSuEu43P3e6VzhehNAtVDuLJgTho6GdV1fslbL7iqf6a59FWy1DDcLR2YNJWQU5KbZQRLt9ISwCyXq6WBBxmsa3aeLmbvPByKrriIL2MfeIUGbCIUaDxhYkpElGilSKQkjlNIiicASSBGIFAQD48yVNdMzM6llHkx822rOsfryIfOeesBT0kDrYnha0h9vyaTgIrdoEgasnBtoWAFOa5z1KC/gQ/SNWvgvP7FCy/7+24Rz3gg7l7xZr3if3rAdaZylKjAVYIY7lWImAEQKYWqhlt/skYH5TfwQbpmDVzE8fZlvojx9XXOMwt6mR2Ph60/dEkfeIQnBR6YyPQLTicGUlKWZX4PjwaEP+6aCe7bbD384xDv9v6QuP4+4ngn4h/BgXDNcIPKVV9wK+lkMkxX2oGgVQOPUK2qweCPu2b1is/3Hx+vt/Dj35efwjUahvOACtMrHFLMjEVMHG9RA/dnnQaDP+6a1fBPf6SBF37c9oJ3Y0xnRnbmnTEWHbQzeNesgRdiv1/U8Pk+/uTPwLuHD9w7OyUbzKCTwbtmTXa3U3G9P3TvTJY6ggEyezr7or1/2P3q3llrySfVO2t9SZlU76wln1TvbKoPIqb76Mlnog8bAzzAA/xfe3dQAwAAwyDQTP1rnI6FwwHpm5Q4cd2Z7kx3pjvTnenOdGe6M92Z7kx3pjv7A3HiEYgTj0CceATXfvkzx8bkc9jqojdgPjfcjtd7EK9BvAbxGsRrEK9BvEZZPMoBpp4Cy0BTqHcAAAAASUVORK5CYII=",
        "../assets/images/template_cv/dev2/experience.png": "https://static.topcv.vn/cv-builder/assets/experience.462066bd.png",
        "../assets/images/template_cv/dev2/info.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAAEQCAMAAACqb0liAAAAb1BMVEX6+vr///8saaXu7u7h6PBFe7DH1uVfjbqTsc+txNo5cqrt8fXK2ul6n8VThLV7oceVtNJgjryGqMrl7PS6zeBGfLDT3+ptl8Cwx92gutV5n8Sgu9Xy9fmivdjY4+6Iqsy90OP8/Pzy9fqjvdjX4+/oOKGeAAAOFElEQVR42uzY3WrkIACG4fm+khMRfxCJB5qkO3v/17g6GWRm6sx2KYR29T1oRI3wECm0p7dOO72hywa8twa8twa8twa8twa8twa8twa8twa8twb8bzkZ6/A3/ilZ98v4hVOPgGsJmA3Aoq85TYm9RUwBL4pqvsdR53fOAPSkHuTm5lQRcFxtuKSDowSwWGvJ/GOp8KiCUxvard7lDfoDXKoEJBvXObbhToUln3pYbbi2QJhwjR65Av+FvfKsg/rYdznUxRt468UKr3MH1ob7ACj9CNeCfskOS3oJzD7liezc8kP7DTmfhwleQ/pz3mYqXOZpbIrUEcmfy0lXePL0W1bPLHNH1YaH/aY/wqdgaAvOpEkssFRBZ5PjlNLEgFywTAtoIZl3CcYKpykbw5qf5nKS2uHlZSGAmSZMIuKg2vB5BtYJH686FLHRIDvWDHeA8EgMBRDqVd/hBlgpb+D7mhUw+0n1qpeFhRrYmHBMbbgrCJ9acEuYi4aqjAHv88LyBG7u4YrWWkF3mbb38EBlreKKY2rDgwAk3Wu4vYG7z8G90KXYhludCzimNtxqQFs8gYdCWqgr3HD7HHwua4howSU1jqsNd5QZFJ7B4yTC5ukq3NGH4Cv8LJ/BJf22WduEw3KV5qhf6214moCN7hkcTpEioMIRJgp1hS8T9TN42Ui1tOFOk2LFMbXhdgVWjRdFh/tc1JR1jOc592Jtifhc3+Svs+hXacSEr6b4w+AwE2kdvlpa8apvCL9c7x/X+EdEbw14bw14bw14bw14bw14bw34tffTf9v7I7wP9iM9w7txF/ktvB93lt/CO3JneQN+6qIbeE8fvHzyCu/qg59OAz7gnTTgA95Jf9g5F922YRiK3hikXqzVzFPk2knbYf//kRNjx01Xd82ALmhmX0AiRSqPA0lAohBZwVfwNzI2VK9lPW5eH4O7akYOt64PwX01K4Mb14fgdh7c4sb1IfiEGqdOFXDjuhh8t9mV/un+NMaN60Lw8Py4edxut4cfW14U+Fk10yEsCfxV6d8MuCQCkJvaQ+UAXzcEiBsjxgCyF/U0cczLMe8EF+oLgjdcGYBCZ9goWwvPqQuCtjHRociSNBwISEPCxdRYoO9Na3G5rg+utNu70u3mwDtR4K4trQbQe1iP0igAEgQgC/HCBLTdsXEGQkaVIRUu01cEBxS8cUCKgMRh3LvMmqLieoyeLZ6rUQ2uNUiMy3V98Pvdbvf4VLpvs+AjKGBYj+9pLMEgK2OUEVyh0dawexD7ktRDcqm+3hk/A4+ApWncVdEGQapxAhe2HB0y28gG7KRjwcW6PnirK3735xV3DZAsyAKIaTjOQsTFMxM4QNImNQhEQaMZF+trnnETBH0znGdXQzQGih7EOAMXx0fTNJBAoIpwmb4sOBqOlsCiWByD0zh3gPdn4Ptg1bSsac+WO1ys64Mf7h4eHp4Opfux2Q3gcxICjBt9mcI94V0R/kLXB493k54X8lk9VK+1mG9ni72IMPPgN3/duF42vgsO//tuD/bmrxrXHxRW8BX8f9cKvoIvRCv4Cr4QreAr+EK0gq9VT+tFxFr1tMzLxt+Al1f1tLh79bHoafsiXhD49593k77fLQh801aT7jdvwInxouRfTE7q7s8LoIwOhtQUo+ZoshqVeG/wB9VC1ZXAv/OJO37/ANx0J2NssAAam1yx3BjrQJw80ynVN6Ztjin2oNCp0Qd0vreEd9XQ1cCfDu243od3wI0BkitdNjB5T2qMscBY4JQDQAFNA21DSirRlopbht4ORVONQxFZAYyjJJJon2BKQ+k9AX5acaOvOOa87L3o1M8E/7bdbNXZbh7nt7ouY6w73sPV6ENtigGO4DrVpsGVvgN8O6bGShBfqzsUVHhQDWmsQ+fh2PXBUGgdR+t4j8Rdz4KKFHzYG2dR61qdVn8quCJzeNg8z5/xxATxynQEd8AETkdw74/g1BXT2zGFYEramEDYVyUeOAJNQt+BQTVKHFzAgRSOz20ywHkCz1xaBBvAOlQZVJEGPxN8+He+n8XOgYfglKW1bI/g/gxchhUfwSVytKcUfBXbQHAcW0bmTO0eloQhFtIqnYLzWEVmdSvYypzANYLxBbq6RKFh+mzwatfeh2oevEq6doHg34KjEiCazONbJNH0kIIQsRrx7VAfyIgwLbJFrt+C61biM/A4gAvg/g344eF+0sPsGU8sOQiaGXDrQJWI7ucjrGeawCHRAQpG6Cx0hqVCva/hPaIHhXPwttPACJ4hTJqxrnj+n4A/b17083kOXJGbwG18C56HyqYuRCXesyVM4KwZmGANID3HSGiMsG1i3QK5BF6BJ2Yb0gCeK4GPkTOoBB1ewK//WV0EsyK5rMBJdEa2AA2TBYSQ/1gkRUMv/8OXlC4aIq9eW3vb4jf9x1VP5Oo6QZVcwiutFxG/2DsXZaVhIAxvM7u5thHa2FJAD6O+/zOaTVqpUu+CaPPPQDeb0OEjnB4m/GyK66ksNhbXU/lCoYAX8AJewAt4Af/fVcAL+EZUwAv4RlRcT2UhorieNr7YeGV9vd/bDbqeXtXcW/ttuZ6EOFTnfe2HQ7XbFvibacdN8VJt5Yfzk9MpyYpI/keLXAmEn9DjwevLeS4A81LtfhJcNt8Fp5/if6jP7aV6e3iV5/7tDbhEAAOA8jYA6DUZCP0JQerAqcm/pHmQ6E/GOSNOLvvbTjibmDA+JORw1uPBuQTK+0ua8H1VdTfguoVeSGj1HLRjCxiD2AZ5JA2KGtmq0bdgbKMpgGFDkwHh9aCcFi0yNzUjSdAx17BZQJOPYw3Mejy4rYaI3O1excPQrcy4h9Zr8L0kGGOgJHLQxmDyPih2eWHyhcVW24A3wDd2Ktn8js82sNAgN6yUNjYolwxb6sFe1h3jpx16xeVyAw7W+V45ygFxQKh6AgszeOTsB68Y/Frda/KtzOCtnofDcZSUQx4/6/Hgu3QpPzM4xdsN+FErUCd2JXJgOGh9zAxLcJKAn8DtGngLUcHHu+FJwO35DeNXB2G7TtyCG2tA28BGvBHG2AA5BQ5zwa8YRbrTJ3DVgqMFeB7o4NS45PrD5wAX++pC8Ro37N92r1fAXQJwOeAbONunYBgjIDE4aEuDcBM4kvdXcGX70cc8eYWTS+pJwNm0XB/OdVW//oWPrHhrinIx6eVyhOMsTq11PR6cNbypL2/2f8r8YxpzJPhF/dOuJ6lHB7+kshBRXE9lsbG4nsoXCgW8gBfwAl7AN6ECXsA3ogJewDeiAl5cT2UhorietrnYKLLsPmtrridfTao35np6MwEP1cbADxP4voDDVblmUz4C5M3t5hJPLI1gNIsb0gCmhgRs5+pP6TAPNxJW9YzgUx0nZTmtfRgtphJPlLiFjLjGtCo2kBQ4E0USSUuvIVCQJKct8ZhbaFjX84FPdZxQIqepT0aACAMCE6oE1tHw3ZHxOQuyTS4XbZIX4hhxvUkOoH8HPMwlnXBKM3Uq5cUhJvDcMI1U11chWQRYynDkqAe2Tv074CaBYwafeXpLNsSQvU8zKnrM4EgQ1RI5xrac89a2qeO5wLtd0uEb4C6Dz7V9Bu0COSTM4Bzw+5nBUxDl+rbhrt6fQA+uJwmETwY+1S78sAp+reMkchOntjfKEll7iqgRUQoiEsTjkHnzlQGTw82nLfKM4OENfEOPf6sPr+grb/Vcx2kGR48wlSwjyZGSecKTpJr/tIN3YDzwpB9btkHBYGL6yWY8gu92+3XwqY7TDM6TTA2EZF6awU0DC3DKvjby1INT3isEjMOVezrwl/Mh6dKtgLNwvcTTt+UwH9x8+J4eD24PddJl2MxH1rLD3dYWIorraWuLjcX19J+pgBfwjaiAF/CNqIAX8I2ogBfwjaiAF9dTWYgorqdtLjaKqyxtc4e74dxRJB42sq4uWNP+T13nxVBtDPxN9SLspXp59bvgeNTP8D/hB8Ft/W6fp/3tLfiatSlboFbVf5bXSeFTk3r4TDJMp0KSy53ktAMwnML2juDUzTUxXqp18Ku1aW4BCliTaXuFi6Zp7XUnPxy/fLl0A9Op8DhlRJicJ9pFfKfvB+67KnLP5G/pBvwLaxNoIgcocvUmk0s+Sb7HACB1DxAw9kCSJIhtnsBIkbISwwm/BHdGy5wh6zK41IHz9wM/v60Wezl2l1vwq7VperaqzXVOlFYCTMMpaR2MTdqVLoCi9khX8Nkclqs9HX17tO4LcO4yOdO2aXDrtW9i3/3ALRshXrquq30Et/YGfGltys8NrUSRmPoZnIf4MNV3UQHA4pfgLqSBxxHAy+nUlqIEcNfY5JO7vPWXdRCje4ILBq/r3e68E2tX9aW1aZ6mkZhYxdwn8LFBgtEq5SkNpxtwMEpR3jZMyS9mPHDXlAnkBCZ33WDuD74TolsHX1ibrs9WDZHYL8GdPUX6AaO+Ai7JgV4HR0IwMzgMbQT3saHC3wS/sTbxc0Mrsh2KJz6/JkpI6GMKzQ24CpEOjY9Mn8DlEpwxj83i5Ohsz4+5M7j9EXDTLC/Fo4iB8EPkJyIfU4a4jxTdgoc40KIjS0pN4EhLcDfELr84OUIgTwbuCm7P9aF7ezic3x66+qc+uTnX02yAml8YXB14s1edVN/dP0/e/6cZ9aw3r38GXDUn0lPsToTwEwrfHY3CPavrCY2WVzf/M61elIWI4noqi43F9fRfqoAX8I2ogH9sjw6KAABhIAZyUs6/SXiWWkjiYCfCIQnHw3sQdcBRyzPgpOWdcJC8mXCOvPngGHmz4Ax6kwVHJpyWcFrCaQmnJZyWcFrCaT04tAuT7Boyp5VpzAAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/dev2/interests.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAACICAMAAAD9Ldb4AAAAeFBMVEX////6+vru7u4saaXh6PCTsc9fjbqtxNrt8fXl7PTH1uVFe695n8R6n8VGe7Cgu9U5cqqGqMpThLV7oce6zeD8/PzV4ezK2ulgjrzy9fmvx92VtNJslr/G1eSIqsy90OOivdhGfLBHfLDy9fpumMI5c6p7ocaVs9GSqADYAAAFKElEQVR42uzPAQ0AAAzDoOX+RV8IxQE71G6k4primuKa4primuKa4primme/blYkBoEgABfUqS8SFGKroPmf93/D3ZgJyJLDXp3dumib00ebJvktfB3xWfktvJglNKX4uxJpz/rJM9x5IBXAb6qxclY3tCxHeWt54J1Ej37yCPcUCD1eHJzSnuKit1vm3MCtDR8EdwpEg0ATgMypthwYtwqnu+BrMwFu+Ipe8ghfImAPBFoAY/r25J3LNCmAMnOf4XiejFf7RyU3QapnvQzBJ3h833QobcF3Tme0tAJAJmqEo42ZWtsvu4kvKhLP1aKPPMG3DcgGQMjk7gTCDQiDornqIzAPtUgswGuW+o5boo88wIURWKZrH5VLKDwryxYuwMxa1P093LRjeByuuY7VC+pwixWunw7X45rriEwAClO96hjsM/x1gqMLvcOF/prrCIbOx4UeylQ2xvdzW0ILl2HxcTfdd3wyQKFU40FymIBw1PVKJqWFoxhSpXu4ZiAf+PEpHiTgThD8iAh6y/9v6V/LP/yLPTpGARAGgijKQoJCJMEipfe/piGxCNsIChb++dU2WzyGluC0BKclOC3BaQlOS3BaHl7tt1UPZ7A9vcEx7i6f4Bx3k89wkHvIPdwQTXDS4GPyC44a3ExwwSEJLjgkwQWHJLjg95UYS+jXkldrbdFGIQd7Ujr6924f9AKeTnbstrWREArDMA9zPB7U8Q2ZT7P//2/uGYUYmrJbmjJkaG7oYLQWrxZKorEhbgCkdOeEB8K3GnB5ebge02WBWOOgKbylg+xSA2AlWQH0SQ49R0AjnUn6aJRa/86x0nf6ZhOBGsg54+DMhif6WXgxGA04vENdk7fQQi4hbzAxhSpY2DCD/Gryip6LYqOQL0GfeTe+svGp76y6k+Cj2StchM26i/XL4SudAHfLQhiVpTLAVhRtd2ihAKXAE8AJC4EyjKLtilEx/g/KqoNEC9AyYLnvNH23rspCLvbZsvf5r3QCXJhvQ98OYUPb2d+Ob1m1OLwqU11Id3DJOuLKHNcD7uKE95HCcYOb9ZXg9+kxlUYU6e74acBL+QzuchTsiYjkEZ6uBJe9YFNoGMffgd2CLUTXOrwTyoqNAJ21ocCwkukDXJHVXgaevTdQa/ZcoQWOmQXk2ScMuKqjryu4of8CJDudqfwR7mtmXAV+S+Q2pPGU+0VJ/R/eTAgfCkYIJ3TiW9YtJuNJEv5ZMDixU+CglAj/y204tfeHlDf8Dccv6Q1/w39Jb/gb/kt6w38eXh1euO/AjQBoDywyva1ZgNhsCY85O8dmxak9D18In32gFGt3tpZcghQyFp/EWTC6NFySndfp2rBsrq8IyI0VfW6EI4olAdLkmDerMxtO7ol79QnvF+UEG1Oo6Jl1PMibEOEyG2/RcgnZjh+yOgbomDcwud+fn9sz9+pYvJYN9qTKvV+Y7RuACWd1snMVSOPFPuB+g1JpEbSoW69wAzPv1edf/BC7iAUYTXiuzNk6Bux6aBE63EWiUhTe95n1CvDZHbwpoGIRjCbcNyKSB3iozJyvD+8nL2ADOXCY8FKUTB3eX4g/4NQ3srs8XEL08zodmHDaY2UZcF2vng+4ZWiJLwuf0bxO/5DIHILADS/Wc/BQ8P9aTSESXqwzPqT8becObQAIoSgI5sQlOBSS/tuEMkh2toMJCvH+/uf4XsvvDDwSOHgkcPBI4PmJZeTJzagN5wvy5TiGcyi5wGuB1wKvBV4LvBZ4LfBaFx7tAEWKiQ0vaS3tAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/dev2/name.png": "https://static.topcv.vn/cv-builder/assets/name.492eb416.png",
        "../assets/images/template_cv/dev2/objective.png": "https://static.topcv.vn/cv-builder/assets/objective.6ce10c2c.png",
        "../assets/images/template_cv/dev2/reference.png": "https://static.topcv.vn/cv-builder/assets/reference.ae608928.png",
        "../assets/images/template_cv/dev2/skillgroup.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAACwCAMAAAAVBFM4AAAAbFBMVEX6+vr////u7u7h6PAsaaXH1uWTsc9fjbpFe69Ge7B5n8Xt8fWgu9U5cqqsxNq6zeBThLWtxNrU4Otslr+GqMp7ocewx938/Pzk7PTK2umVtNLl7PS90ONgjrzy9fmivdiIqsyGqcry9fqJqsyyCxaCAAAKFklEQVR42uzYy2rDMBCF4Z4ym1kIhIMG6y6c93/HynZj7MbQbIX0E1A4WX1glJCv7077+kaXDXhvDXhvDXhvDXhvDXhvDXhvDXhvDXhvDfhHLQsu+QWLR5Pdw40FXEAtGQEQjIMjzhxwKRoYjSa7hVua4cmiNpMBvFIzYpDocG3SpCc02S3cREAYL7hnCm8PPfb8dahHI93CWQBtDrgmBxhOQOS0bmwiUanKpyJ2QGFX30zAxMSGAxroDi7Hk77Bn6sbjnIdH/tGRTRZGCo2bqeWQhGeVc5Mgga6gz8qrzB+4YoqGUgVJrtpXv2BHKzsp6EJYN4/l2bhngTg/IKTVsoDiCrV13Hh2QqGezBvcL/BC9mW4aJW1vyCcwqkAWTKFXyBP6mEfIFPLcOj2e/1A1lBBUhKUbjCSdfzBM+UG4Zv1xrLGZ543SIxrnCtJOgTPCkWafZyywwEms/wquRUR/MHPjGpQvGAI9QhtgqPBSgG7wnZt80nnFvqkKnZ7/HblsCM/2Jjs+IZDfQx3JIK+C9hotjGj/eP4ZgSPsgntNH4I6K3Bry3Bry3Bry3Bry3ftijQyMAgSiIodEY5O+/U8zNsCBxXDYdvEnhtgpfDds2b7iDvegJ17hhHnCPGybhInfIA46igJuGw9xw1XAovHBJhRcuqfDCJRX+BX6c/LaL/bJbchuEobBmZEAgMH9+gX3/l+wxJonTtNl2J01v9szYBukg8yVOxvoKuNqwMUG53ILB0hMtPC7N8zVk/NngKv1Kz8t/OH4ruGx59Q2DwH8CHj8mOLTaX4Ab9ym4ifSoFjm+E9wknOymlUgzh2NfGeBZiaqy4ZjHtnJre647Q0uLleGvEefMuAD88BHbVAGeEUPOGoIv7pNZec7nZIhP1Vozto0kZx3Zus+r4ngF+GZpSlMkiBccaXxTOW0hWRJDtLDx3Uokg5i3e9KVSkux3RGLjb6ReKRggG83tH2tKyihVEKUCN+2wQdlH2HFuj1pUSSMaEJUWWCuZGFeDFlv+3iuZo19vLwA3CwLX8fiAx/gXi8/0H4FT0RrR+zy+NuAcNv9nBGLZ5+7PPQuEhWj61gbNqwaqQJrb81gVBU70KKX++U1YGka5cMBmnh8Vgi7l4Grc6dZC4s5wMdU2oCcQH4AibkDZ4BjWJycfeYGXnEYMr2IG7jsT3+KWJcqbEMTELTDYC2GlhMmwvN20IvAzzIZpy18Bp4fwBFWCs/AGUgrwDOC5YYYu8IAtim5guuiP4PHfwfuUTNslBrFA3zbSMXurHwFR4zKPThG8D0Db0lpc2Q7UQgEub2ywZilYh2K6I68R3MuStbRAX4kea+WmKIb8xeDkxWXHJNN0g9wliLOUlxKv4KreBE7uJYwwVlE+vYAriJ6gNM2amrw4vSo7CRSEykOF0zWeb+E0tYXxxMcyVKATCPsed+MezE4xEqQ6i1AI9DuTb3So++sxzDzXHJ/K773zbyeyimSSU82bu97VzflNs4+fnimv1XY6Gvqobq7tWv5T02KsVHpjco2f3dn3+Df4N/gfwyeDdHo/lamewlPh4UqPWoNl/4dyvRcbCGmKQ364HgzeHQgGB1A+w146Ou65ifgvKxrFPtZswtTyhfw7dSsD70dnBPQfKTmiXS0wZmjkol8BbfDl4mamQ010vkMTsil2UbzblLSOl2t5bHCj095BqmiIGM0mvWpt4KPb1pWR7GTERs8k6TQZvd7AlcxLIa6ixJpRTr8BL7MNtoUIlgMSsK1kZWeL+DZjaYb+Mvs10ezPvVm8BCxR6+9UqmYjVdtPbrfaUgiwtj5x0bzBVwaadIbuDG5hGO9paTGOdoiCe8u22frY0yVOBoNMQCf/ToqTr0bPIYf7Z3pspswDIU1I294t2Gmv+/7v2QtowBtmqZrGorP3AuxJTN8IRAUDoPyoGVjEXirtDEc93HF8+Agziup1lrIHdxa6x0IB5Rgiy3G6bpmVWV5H29JEmTuSyTw6R+D10nXRt9Qw3fBnTFyA8cmt4Pvvx/4GaI1TqkJMPQsBmfASrPZvwM4hAkAw9yLY8iFwLn6dfIA/mHl5FyDS7kX4gkaOCKDb8V1ASc0bV+A9hoKfAnuggQ0uIPXfwc+W+iHI8Ccw9KhqfqdA8pp28ctTgj9UEXFMBodFIHbcgBH08bzT2YmAWft4F21V+A7uDP8yXo9OOu+siaye+GhjAYjH40/Zn2/82vuNzhljc/WyXl4V41z9QF+EQ3wAX4RDfABfhEN8AF+EQ3wAX4RDfABfhEN8AHO+ie29Tg/jHy8AbhyAKicVfdmJ9IMXsID4fLgvXMASqPCrccrUnFb5MGKsFC8AFwgoPGwgS8OjvLz7OCB3DfAPzzAgpA8Hsel6EWMiQZEj4R/pyjUq8HRdDuhXF3kSgJpN44nAJQ060GJKwn5yTGxzZzTqF/PsrvL++iEpeCBxRVK2V3u4HypCbr0oimIFEbRAn8FfFE7eM3UsKFbzOduD29Sxqog4UNHvUAMVpnSZsqG0rdrVrn7ONm0HsmJ7roRTycQ2MZ5k8BMqnUzOE+09UaCyWrOAMaqzEbSCVo3O91RzMpYuNMf9asLLZBNiLmx0UajbjaOR6RVipo6KE7/BIDgCHwzrdfVpN4aare2rij+CN6XHme+LJ+m7khnp4la1mwjUeCzC6u/71cX1k9uXWFdyGKeKba5aeesN3CBlMMHQMbzZFrvVMru4D5onddtuKgvwNW0RQTSEAY0BWtwffGG3fN//+Cmlxs4igryCG7kYYuHG3idGJxN6064lrAcwGds+ib4FqG0DVwGrbUpLwZ3xjM4venqAO5a1G/gfEmcr3t3cData88RBq8BAQu0iCPEA7ikSGJwavhps/t6/WJwqKGu4Gwx38C7jV04BkeT84oXw2pmZ9M6XxxfIx+0SNXd6Gbm7h0cVMimMjg19NTfSexT9yrwezn3uO0AISd+tRkEeOaOA7jfyNa6Ex6X7qJ+k1PW7yjaYicgaVvyAk9l5JME7b0p7w9+cK1HJeG5Ej5JwLacdylSTqkBPsB/QdE6OJt+AlxlBKgK4M5RjVrC2fQcfK7b3dqKpt8ATxFOp6fgJS8VkyxcRqNkA1vBBl59Witr17+HUoXT6Cm4MlbKoBXflh31as5c7OSo2/i1su5n3OF/Agctb9ZxqMGt4NYDqCKnXihLBOi+1vZ3Hv0Y+MS1osEVPMvbPt7auGQtEIK072vg/B3wBQDCDTwdwLXq3nWl2uQ8+gHw1MG5EI77r0yFwU2CKhCk0HAiPQf3wTdwvi2bwd2cjQUGj8LoIHttfiI9B9/ra7zvPAZO9Un/c+fq0lo4k/4YePLnOl8f1dkAv4gG+AC/iAb4AL+IBvjlHyVwkU0+HhcyHhBzBfJP4yFQ47Ffl9MAv5oG+NU0wK+mAX41DfCraYBfTQP8amrgF9VnFDLFA+DTFGsAAAAASUVORK5CYII=",
        "../assets/images/template_cv/dev2/thumbnail.png": "https://static.topcv.vn/cv-builder/assets/thumbnail.e0cd6e9f.png",
        "../assets/images/template_cv/outstanding12/activity.png": "https://static.topcv.vn/cv-builder/assets/activity.d0946d2a.png",
        "../assets/images/template_cv/outstanding12/avatar.png": "https://static.topcv.vn/cv-builder/assets/avatar.0dedce68.png",
        "../assets/images/template_cv/outstanding12/award.png": "https://static.topcv.vn/cv-builder/assets/award.67c339ce.png",
        "../assets/images/template_cv/outstanding12/certification.png": "https://static.topcv.vn/cv-builder/assets/certification.04c6e064.png",
        "../assets/images/template_cv/outstanding12/education.png": "https://static.topcv.vn/cv-builder/assets/education.16d6ed26.png",
        "../assets/images/template_cv/outstanding12/experience.png": "https://static.topcv.vn/cv-builder/assets/experience.5a6dab27.png",
        "../assets/images/template_cv/outstanding12/info.png": "https://static.topcv.vn/cv-builder/assets/info.6d532e6e.png",
        "../assets/images/template_cv/outstanding12/interests.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOYAAAC5CAYAAAA8skOZAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAyZSURBVHgB7d1tjFxVHcfxM7uWdBoI2W6D1IWIsS2+oIAQajHSClFobRNRW6JVUawGo1LjU4xWjUYir9RYDdFoweADaqvFRKT6Ai01AYoJLSWBsttX7VYk3W1asEMineH8zuyZPXP3zu50Z2b3v8z3k2x25s59mjv3d8+5d3b/t3DN26+rOACm9DgA5hBMwCCCCRhEMAGDCCZgEMEEDCKYgEEzGszKm6905VUbHYDJzWyLueA85waWuMqSt7pOK3/j96588x0OmItmNJiFg3tdYd9DrjD0pCu/9w5XWXih64i+C13l8AFXeGSHA+ai17l2mH+uq6xY4yp9i517+aUQvMLh/XWjqBtbuey66uNr1vrx17rC3kxwiudO2tXt+du9flq/nOJ5ricNnQ9iWfNT8I8NuYpvlQuj/3GF0ksN17HHHyDciefH18234oUn/EFj9PnaJGFd/Dx6/HBgJrUlmOUvb/et3+Lqjq7W6qbbXM8D23yLtTO8Xrnx46685hNhJw98AJ0PQF1wNF7x3BDYwAcpjHdiPCguBHNtdVlJMNXyapkhVArm8uuq4yloWoaC+9kf1a3jGa3j7ntc4e+/DKEM0+tgkgSzomBqfIKJGdZyMCuXvSPs8AUfGrVoUvahcIefrL7uWziFUt1KjaOgqCWq+PO/8ge/5nru3Vqbl4LV+91bxqZb68of8q/ff1dogVsRQqlW9u7Ph3mFIN94mysvvcr1+mAC1rTeYvodPniDv6jjf9SVTLt+odXxget54Me1YeqGlnURSAFWq5hpOZtR6UvOTzWPRuOpmzp24IgB1wGg8Lu7Jo6s1r6vQ+e9wFloOZiFp/153fCGavfR/+jczg3tr7aevhtYGVgaxpkwnR8ndDf1+tm2iL7FK3/zD02Ou7i6vMw5bx610BOkXekmnPnBIw6vXb1fXOVmQustpi6OfH9z9TxN3Vpd4PHniWUfHnUdQ2s4f2KLVpmklWtqmX8eb4HVUlem+n60iZYwHkwiXTk+WzP1weG1rfWvS7TD+x+1euqu9t55i29BB2vfVdYep8FQUFdtqF4Ams75ow9m+Nol/hzc23DU0Fr78XWumwpd3Mww51vVdL7T6WID7dD6xZ94cUc787HB6tcSvnvqhofC6zqXq3xmW7gA457Y7S/+vFi7slq4Z6vrOIVYV3N1selL28NXImEdV/sLUKX/ud6n/+UAa1rvyv7bh61/cfUcM37V4Vuenvu/Fx7qQkvP3Vv8+dvXnfNfSVTi62NXSGdCuNikVlPLv3lLtSXURSqtI60iDCq0s+ZPPG8sGN7ZtY6W1w+Q9vzlz5i5sMMTSswF/NsXYBDBBAwimIBBBBMwiGACBhFMwCCCCRhEMAGDCCZgEMEEDCKYgEEEEzCIYAIGEUzAIIIJGEQwAYPa8o/Si/r73cKFC11PDzlvRrlcdidPnnT/feGF3Ne7aXtOtS26VcvBfP0FF7i+vj6H5ilw2mZnzpxxx0dG6l7rtu052bboZi0fks8//3yH6ckLYLduTw7u9VoOJt3X6evt7Z0wrFu3Z9626GakCjCIYAIGEUzAIBPBvGL5cjcdS5csca1a+bYVbtnS5uaTrueCYnHa6z0XTfZeu2k7zJSOBfMLWz7X1LAb3rnajZwYrT3v99/fXTQw4PJkd4BrV65w06FlrF+7xq3zP4NDQ+65waGmprvh+tW1x6dLJXf02HDdsE7RgWPD+99Xe671z9uWndTofeoAtWBB0aG9Zq3F1M4lD/9zjzt6dLgWRg1XWNUa6kNPaefQ8DS4GkfPs61nNtzp85IP1aHBaiBHRkYnjJe37DzF+UV35MhwWOf4fqYzn6loPQsF30MYa9m1fe77zW8nLCtdBw3Lbhs91+NGPQ1Nn06Tt+7Zba0D1BH/+cX5xwNruj5564fJzVow172n/hZ4Gz8w3iIU/RG4vz//Q9TweIQu+h3hox/Z5C66aMBd6nfaW/3jKHuEj/PXzqFpNJ+L/XS3f2pzbQe8/ZObQ+uk19LhedTiXnnF8jCuusOf9uNH2fm0Y4fc8cddYZkbfct5dHi4dkBJ10OB1baI7zduG72u6eL71nONm6X3sS6Zn9Y9zi+8r7Hn2tbp+43bVgHU8Di9Pg8tV8+1rfW8HQeqbtDWe5ektDOmQYnDmqEW9LHH9+W+lg7Xh6yWI+6kzXTvtOPt/NOu2jQ64muH1O+nDh50j47NX481LI/ex0K/49336/FW68rLq91szatuPk8dDIH42c+3u1Zpnuv9AW2HX/+89Rj0zzf4kMRlxff52OPObf3qV9xPf7G99lzbSr2VLIU+XXfNL84/3W76bLX8kdH6HscRP/1f/ro7PFbP5Aq/XeL6ante7p83+mwxrmPB1AeW7rjS7vMiLSPtiup53s5Sx3cJ02mG/UFAO4ta3wM+UNHp06WGs9Ayjo5139Jlx9eeGxo/Z20U7rOl+V7rQ6+WU+ebComGab11sBEF4R9J2NL3qfXIdtvzHB+tn6aYtHDNTJ+OU/LbMN1Oo/61hf10Z5sxa13Zi5NzvvQcrTTJjlw6i5083aHSZWnnWJpchdURXa2ELgKtXDF+MWmyLpfGT+eRXrDSfNKLVHqt1IZwKnzqHRzwrVg839R6yIMP7Q4/8Xy9Fe1e93YdmLpNx1rMqWgnUguqlkYhii2OflfPzzaFLtVgcsVUj3Weo6PyzrHuUSNDY+NqxyolrZ+Wq/PbcI5V8fM8PBR2dtFyb/3wptCqap1+5YOQtpzq2un1R/ftC92xOP90/XWhJm8+rdB5pK4Ax9boQd9V1LLVI9F6xO2o9/Pwnj3udAvh1Pm7zgt1nq91n2o7ozNavnHtWy691GH6nj10qO75bG5Ptcrqhg82+fVRu2W3RTfjL38Ag2atKwt7dJ4KG2gxAYNaDqZKQ2B69F/7Wd26PfO2RTdrOZijo1N/t4V8J0+dmjCsW7dn3rboZi2fY6pOi/77XCUxqGbQHLWKoydOuOPHj094rdu252Tbopu1/HUJgPajiQMMIpiAQQQTMIhK7BlUBocFVGLPoDI4LKASewNUBsdsohJ7A1QGx2zi4g9gEMEEDCKYgEFmKrHn1djJq9eap9H0wFzVsX+UjvVwRLVjVHdH9WiyxaJU+U31avKKNsXyjCOTlDucbHpgrupYMBXKtHzlgrHizPov+RhOBe/4yGj4V6dYka1hQP2PxktLU2qecfp0WKyQ12iagYGBMDxbSAuwonfg4jd+27Vg0aJFucNVFjJWn5P/v/KKe+aZZ0OFOg1X5bdly5aE4arUfdO73xWGp+USw+0Srl9dq7yux+fMmxfKNmr+qnRXerkUpn/TJZeE0pH6/TF/AJh3zrwwjQoka/xTp16sm0bVxK+++qowTiwDmcUfGGC2dKTFVMn8ZUvGb1kQW061hvG8Ma0gHiuD51FrFit7q1Tjnd/5VihrqYD9cNtPatPHyuCSVgNXy3jtihVux9FdddPI+rVrHGBRR4KpauHqImYrsccq6epOZqt6N+pOZu/EFbvB2fE1PFT5rtRXA9fjYnKvk5QCXOSiEQyasauyCqNK++scU6FKb1aj15Y1uAOVLu5ECnb8r24FKr0SqyLLU5XlUDc5LlfTppXXAUs6dvFHwUlvKqTnuq9GbM3qKoi7xi2mWrW0qnmsDK7foSq7KrnPr953RPPu72v89YputrMhuatYeq8SwJKuqsSuVjK96qtbAez34WxUeZzK4JgtXVXwWTfiWRm7xmP3LZmt2wEAk+mqYOrrmPQrHMAq/lYWMIhK7A1QGRyziUrsDVAZHLOJSuwZVAaHBW25+KOKclSVA9qHiz+AQQQTMIhgAgYRTMAgggkYRDABgwgmYBDBBAwimIBBBBMwiGACBhFMwCCCCRhEMAGDCCZgEMEEDCKYgEEEEzCIYAIGEUzAIIIJGEQwAYMIJmAQwQQMIpiAQQQTMIhgAgYRTMAgggkYRDABgwgmYBDBBAwimIBBBBMwiGACBhFMwCCCCRhEMAGDCCZgEMEEDCKYgEEEEzCIYAIGEUzAIIIJGEQwAYMIJmAQwQQMIpiAQQQTMIhgAgYRTMAgggkYRDABgwgmYBDBBAwimIBBBBMwiGACBhFMwCCCCRhEMAGDCCZgEMEEDCKYgEEEEzCIYAIGEUzAIIIJGEQwAYMIJmAQwQQMIpiAQQQTMIhgAgYRTMAgggkYRDABgwgmYBDBBAwimIBBBBMwiGACBhFMwCCCCRhEMAGDCCZgEMEEDCKYgEEEEzCIYAIGEUzAIIIJGEQwAYMIJmAQwQQMIpiAQQQTMOhV6mAINLXSr4gAAAAASUVORK5CYII=",
        "../assets/images/template_cv/outstanding12/name.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOYAAABJCAYAAAApIFqAAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAu6SURBVHgB7Z09kBzFFcd75hwgGwLhhI9QR3ZUgQsRuHQiQ4cTyVUCS46scyaZo8o4MJLIADnBVRJGmSVHRkgO5MQyyqxzhAKoQhkHGRKRFKDiSG6G93/TvdczOz0zezt327v3/1Vt6VY7Hz0z/fp9dL83yf5fLuaGEBIVqSGERAcFk5AIoWASEiEUTEIihIJJSIRQMAmJEAomIRFCwSQkQiiYhEQIBZOQCKFgEhIhFExCIoSCSUiEUDDJzvDIo8XH+54/NW9IPT8xhGwz+QtLJvvtaf07+fSGSW7fMPnBV4356nOT3F0zZJjp1ph7ZNTdv2Tyfc8ZEi/50gmTvvOafkxiTPbrFWNEINNb1wypZ7oFc/2hyZ9+xmTL76mQkjhJ3/mNSb6XZ/XyCWP2PmHSf75n0k8uGxJm6n1MPODk/j2T7X/FkEgRYcxOnTf5z59U8zX70yUxZY8aEiZhaRGyE+Tzz5tk7bPi78efMObxJwffyTDjB39kNNQb3ZFERkygfqGYoo3OPyJ3T8+LRvzWmAffBjdz0b3GY9l2uvM3nlPM4kTaZn54OFI7BudAO9YfNp8Dx2vbTsjlmKW21G2D67emfFMb3Xat96ByHc6H77yfa4PfN/K8HAvwvg+O2/W+1D2jGWNswczEsc9HMCPn/niw2O/UBTVr5j5cCW6bP7tosuNvmfSjcxrJqwVmkphGeJBzZ35l2tqZXr9gklv/Cm/30qsmP3SidE50FrQ3EbO5yTcanEOCHElDx3LXlXyxatLLZ8LbSafOzl7VdqA9Q78vHtXASr7nsdL/QxPp9hUBVV9cmEMQpoHqdeQvvlJ8v3TaJHf+H94P5qpoQt0P37Gf3Ms2XJ8Y3BeJ3KZXzgW3HzyPwH2ZBcYWTNyc6kiav/y74gFd2f6blrkHjwjtwoHGjqPbH1kx6VocYXp0RPhaTQNFcN9jf5aOLwORaCfsn4gQ5pgnlE4LIdqQwSqVQa+P60yvf2A2FqStR14vnnXNoKODBMxT9fnLA4IOZk2WRvVYEOi7X27pvswK4wvmGoSyIpgyb6U+xKc3zLYz/1wxL4aOI3NjbYKp7Vt+1yQfvjFSZ9kudKD4Zq3dTPTAwAeh1EFRhMZp58T9/r9rqlHwUe24Pqa5B5dDhAuCmck9HrIaYLKKpYFBotaiwHzliP7kVu7LLDHVUVmdw8QAcPu/Mrpe0wBD22qS5M6q7gOTadK4gUtNzL0d/XSY7kvLhRDA3K4ROmhJCKyayev9+GCYc0y++bJYGFBpK6wWpy37ACY+yPGM9naPX8wS0y2YB4tRWn0qO1kNM6gJ1TCyPYQ4O/y6mSTQBtqZxQzPRIt3AT6w7tsiBCm0ac9RT9w7besR775BW8o9V3/vdj8WEqwe1dAYQDvel1ljagUTmhGLCwYdFOYWBA6BqJbFBgl8XxFomF/QupNE52FFQ+hCiS4DhbUI0jurZqfRgQRuA3xjG1FFwEd/63nBgN4XPM+u92XGmOxaWXm4G3+9ZbaCakuDzrKpFXSUhW+FCGLDci8EJxBhRDQXvswc/OQO/iYijBsdooyjgiDZhnRAHSge3GsMekCLqHkaMFHziunX95TCIBCE+wAhDQR8fLKT54O/uYhs7bnEFN9481JxXxAMEpdltzBZwYQZ2mT+QCvK6DyEZz75HWIQMZTorGlZh+n8MA1oyKifvv/7Vn9MTcOmYIScFyP8yMh504srJpNOmB1aHitqnL19tfS9bYpnZLxAECLAwYCP3wY84/tbCLThvmAAxWDrgkG7ZNH7ZAXzQfNDhVlaJ5j5/OZEdVbRYFiep0Eg0cZtET1o1UzmCqF9YS61Tu/I8RrnMTGZvhXBNFaLyxxrdvx0ETXGQFG7XXF9aq7XDCTpxTc221PRVMn6d90GDqt1Q3Oxet8QeIMrcf1vpg0Nzm3R39UB1A4ETfdl1phKH9NNWqsAYs7L//y0mGyv1bQ1qC+DaCP2nfD6zUF0GUGPE4Ggh50OyqwpP3QMEQD3GcJqm7ZsHBVeaLgmC8Iey3cltguNCLv7cmzy0fSdYOryMdGpiimS8KqPjXf/UwSBoN3apgtgmokvk79Z+JuTXr8JHy6DCY+1pTJfOfS7XDf8XPWxMd0S8o1rpo0wPaNWiHxC1oQGw7DcbQLBpSb0vuDZdxxwp52p05hu+V9TIACjq4b1Oy4VdMEgPT7MxAnjosa6sqcK/K6PijQ3jYjWzPNpYvKp4YCLRlWbrAMMCNYa6TvK2gcYQDWavguEc7o0pg36uLnLEDB9NHraIQjkcHOK+TZEXUfFjxrX/o55Phu42pBgzyAo5ZbkQdtCsGquRa2Dk0UwJZHoqpGAikZtoY3soJRg4cL9/lZF6RLNF8LTUum/P+i0EELviwxKus56xpkqwcyfPaD/to7mbk6zYxDIAX8zC0WCdxg/alwHBp8cq5gO2SQCp+kxwFw6o/OcdVM72rklAqz7QTDdfhAMG9zq25xvs0Lym5cbF/376ADacF9mBeZjzgjF/OZ3nTv4YD9Ed/c8ptFeEg8sxjUjbFWwkobFCmRysHwlIRFCwSQkQiiYhEQIBZOQCKFgEhIhFExCIoSCSUiEUDAJiZDx68qiMh3SjGwakFZRQzEllFNEpgKWUNl1l+67FuytWfamic8y2V1NaUIeoS5ar5kIH8rHRFu8JXi5twZ06FxoF9ry4pLJn3qmyA/1Mjb02u6sbq4bbdhWi2TJNQ1VTsBic6+yXFa3FhfL5FANwBYXG7Tx/r2iCmEE1fzIzjK+xkQ9V3/dIjqiLYhVWhCOjnu8yODQZOKFA7WHwxIx7Ic6qe6T73s+mJ9YXXSOc+i2tu6PCmXgXNqmtz/WgsnJ15/rPhunLmhBYd0XA4QTFC0s/XeTzf+ivK3N0kBxZk3mraRquesptTdQk0jXvHrpWlowDFkifGHSrmNsjamZHOjANqNev5+9anIsEfO1pa3/iu/5PlO8hq1mMborqe/XpEWxKuRYBtvgHwcL0U+eL9c/DZxLtZdXlQB1WfNP6hdUa2U40dpz/rZYSL6wOKjniuvPXnrNpFiA3lDfFmlpoewNzRzxyq3otbTUMCKzx/gaE5kcYu4NzE98R84fqnZ7OZOqBbdaTAnpTCOkIWn6VpdcTAgg8hm9nMbaReBINxPtVRVuzdTwBcbmSqpl0Fc9VLgI1Ji7jl4WsUO7adFi13FFC2lHFgEF6ueJXkn9dCL5v1JNmko9ndJvYlqO9I4K+GT+i44C54Jfl8mxNacRbRV/TgWt4tOpFq8WgfJemOMXiFKNh5o4rsBXDfmxt4yf0oPE6FoNCuHGax8unzVkd9GPYLrMeJf7KEEMmGPOnNRSFlVTUvMNvUJOEuApHfPKXza/2Mz60Hszhnjk0W7nUg13zuQoZIzykdJuCCm0Xkm7O83qkSHX0/qv6fvLpd80rxODwWGxGm4Om9DJzX+ULABfKLVCvKsSbyvSJXaAI7uH/qZLRFMUSbtF5BU1WtScdGZgtUwlOh2iju5TEbjSb6g/g7dOLXRMYEaxKT85uu1cNrFaXzkAv7ESMU6sOekXscL1zEGAA0KDmqgquHUlPPy2VNK10AbUWnVvLqNQ7k56E0wN90PrYIrBTm2gglqmmm7MjHhoK5iNbdoS0xmLR/XdHloXpwVoNB1InIbFvzhXjVmJ0pJ4l8bg3Sg41+E/hLPzXU3U/eFXAzaC+4fBLYJ3rJCdp79EaXQkaBtEEK0vqb6nTCmkNe9j1FfFVQI06kdaIc7Ofry5LaYzYNIFKrcNqrlDcBGBvbhSMg9D50pWr6mWR7BGNRe04t2viho0FTDYwE+GL53s+Zn+nbSU4fBrovrgnZclpK1176xUH1gGDgxuvRZtJtHD0iIWLYnJ8hokErgkz0KhJDFBwSQkQiiYhEQIBZOQCKFgEhIhFExCIoSCSUiEUDAJiRAKJiERQsEkJEIomIRECAWTkAihYBISIRRMQiKEgklIhFAwCYkQCiYhEULBJCRCfgTcduypuLHMSAAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/outstanding12/objective.png": "https://static.topcv.vn/cv-builder/assets/objective.a96c5fe9.png",
        "../assets/images/template_cv/outstanding12/project.png": "https://static.topcv.vn/cv-builder/assets/project.7a219ee4.png",
        "../assets/images/template_cv/outstanding12/reference.png": "https://static.topcv.vn/cv-builder/assets/reference.992992ab.png",
        "../assets/images/template_cv/outstanding12/skillgroup.png": "https://static.topcv.vn/cv-builder/assets/skillgroup.41fd3f9c.png",
        "../assets/images/template_cv/outstanding12/thumbnail.png": "https://static.topcv.vn/cv-builder/assets/thumbnail.11c5c048.png",
        "../assets/images/template_cv/outstanding13/activity.png": "https://static.topcv.vn/cv-builder/assets/activity.c3652993.png",
        "../assets/images/template_cv/outstanding13/avatar.png": "https://static.topcv.vn/cv-builder/assets/avatar.a0a06787.png",
        "../assets/images/template_cv/outstanding13/award.png": "https://static.topcv.vn/cv-builder/assets/award.36bfb1ef.png",
        "../assets/images/template_cv/outstanding13/business-card.png": "https://static.topcv.vn/cv-builder/assets/business-card.5908d125.png",
        "../assets/images/template_cv/outstanding13/certification.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAD0CAMAAAAFS/xsAAAAmVBMVEVSo8ISFRYZJCkfMTkWHSA7aXorTVrviWgqTFgUGhoSFBQiPEYWGh0cKjAUFxgWICQUGBsSExNNncNOn8JOn8ROoMUVGhpMncMAAABOo8QZJSoREhJNncNOn8MSFhlNncJNncNRpsJMnMMWHSFNncNNncNNncIlPEdNnsRNnsNNncROncMSExMSExYhO0MZJydOncRNncMREREPatv3AAAAMXRSTlMZxm9SjCc1jDao1ESaYLd+qeLiNlI1qY0AJ27xxm+3cK0Lb4t+8VNEYETU8OPURW8ntZEnmwAABzpJREFUeNrs1NGqozAUheH1DImyG4iYIypqb2a9/8uNK4Sejl71psHBHwzsGOGjkOKx94PL9CMvLkUubFzNLDUeuFwPXO6HxhXJd3d3/3G2oH7Dh4pIQ+0GuoBPsvroELcWH2XfNf/pzFYAXdcCvuv0BI3BnvuivUXHRhtblMoQXu/zN9/LO+4ZQA5AQ+ppNc7J5Rc9HbBO3BuhytDB66Tel2++VuLWG9mc0RuNfAZktGPskyblmPJQCx3INd/9Mzp1nqS9oSYuAF7DUAstJbDYckbPEPoZhBq5AZjngL2RTqs1ddGK3GLcjuhEE8oY8cqEVp6MMbqqaHVEez7HgjaSwxGtqqJH7/sjGokuozd0cTqjZ+/Hr6NXMgAW3y7i+o7WQ4c+O11GlyHFpdq/x8RGmu4XHcgmKzIaSehVewWt7VXLXAsNI+NE1/6ikfJWyrq8OCCSuqULVKTTN6iGlppxxRs6JG2FgkaiK3vTCFUOtNXQynscCj7gvOf/PXB3d/eXnTi2ARCGoSjooDggMGEASjb4+w8HSkcPkot3xQEAgC/NiRkAAACAPzS3h7/PbSnSNQ6zGHepNMssVFd5OfeqOim6tkM3O+ay4zYMQ9FLURT0VrzxIgGymUU3fQD+/49rKMttpmnTKdAUaesDRFYoyTzgGEY42SyEp4ZxOMkSgFMFwywcI1BPeG6Oi/WLBWgC/BTwnoDDgqcmnWaIPsonujhPDr3Szy3tT0u2iU4tL8ZPS7DFLvllCXhm8nJBdZeMpvMg89O/PTZE0Pkr3tM7Ozs7Ozs7Ozv/MEnG1eG7sA4lyHWIcR+f0Cnu6pBAkaP84EzBW/AUYxDLUDgLvqtNUKquyYGIHFK2t9YnN/YqbKEYa0UvNE3EBwfFlhnf8I7iRCa1tzk7wDjLzEACkEuSo1srmaBwEZBovVI3/9QLInpAXI9fDki3iVWlR4DtWGR0rAEOjvWbW+/W51y2PFZviKSn7mMaFFtbtiDAV0RrJgHZRgFAnwjNJjJIK1Kh+NgaOY62RZ3P0Wg0tKzSPppLYCySmV++SmczW7xUMzdQNbUgh0ZxSPdP7KnuYst6YSB26YAImAsAq3TJgOA9UCzo6x89F4AzBy1edauR+s4FBHJANmORnYvyRZohJASgCjm8C7pJXktrqrdVmoFpSJNKW+5zoJXVBrxKex3UBvCVrc40pxnSEh1hDayLZC8M6fUY+QCd9WxG/ehKeqS6hyYBkqzSVcBDWgvcAtZyuytp0BEQ1yzQhlfmyzik4Ylw0MDVouCVtEwCIXRp0XH6RWn4SERulS5TyEMameocei4K9Vraz3SuCflcK1YvP53rvEnD6DN9rnlIC53JvpYGU4hplYa95PzFSisit9M+f5dvgiNwsxcv/HqLVnvgEm7w13s94Tdx0LcD3oRQe6mvAuf2MmMjF9yhhSMV/C74o+CNeP54G3grzPv/hnZ2dnb+P5hxQ0rY8A5/mkynSIIfkAq+01cVh2KwYQy+gyEAdiI6y9ag/U7IQRy7JEAavc7WarkWEuSYtiaINYgUmhMHJ0e3SnNB76rG2KHMgDX9c+gN2u+WNpQTud615N5W2VZJ3Q9kPLUcjZ+spaBrWsTAxoyuTL82Syhk5ox0GS0ucOC8/Rj1Fcpvl27AkAZKKxlgGj9xD0mTa+LoRh9kGSoNHdEPR5AAM4+HQFUxSX88To4t8Ahps0mTiva+cZOuonI+oK9dSdOQ1mHtsJohrIjacq80V0/AY6S1ou+GNAfAbNK2AIefS1en5dVKS6++90xd+l1dG7T0CGmOo9VSUQptk5Z6rvPPpT2daxuj3lMHsZE+VNcbNEp4CK9aLR9u4/fhO5tF8HCybeTwizyqlnsLtLOzs7Ozs/OZfTPWbRgEwvDd+bDAGFMvGTp0ydAp7/96DXCVLCGiDihL/0+KFdt38A/I030AAAD+BJQRKCMjoIxAGXkFlBEoIwAAAAAAALxNGbE6ax3gHcXuWWv0kcbMV0aEz40XSfSLLuOlj24xkfbqNuyar4xYyqva0VrLqJNdn8T6cyld6lZX6kSiTTzVJ+aPrI46JiojFlqEzl02V25D3ndKxQyp11zVCvLBc1YW/9Dc6rj8kUOV66xTsE3vLPu2Usc0ZeQams3MUCHi+uqI7NrER85NYbDppz1aXcqiZaMSUhdNtilxF3qWMtKHFmm3FlqXjRru8FylhUV8sGOvkeg7iFi17cGeTUDpmKaMjEOvRI+q6bSDHhJpsS8uoXeiu1jotQRtnc8A7uxCT1RGxqE9B5thSnXVk+r003EJfXzx7TrxZJ3x2dkdj7nKyJhEBT+YiqrJXbep9fDblRFjczTg9fd8CZ8fShOVkZl4NxROPAEAAPhnQBmBMgJlBMoIlBEoI1BGwE87dFAEMBDEMCww8l3+JFsauZEQeAwAAAAAAAAAAAAvusy5NHOazq2+pmvV16adyr7+PreEuYn9mIDAAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding13/education.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAD0CAMAAAAFS/xsAAAAkFBMVEVSo8ISFRYWHSAqTVk7aXsfMjoqTFoSExPviWgiPEYZJSkSFBQUGBsTFxgWISQUGBsREhIfMTcZJCkcKjAWGh4dKjIUGhoWHBwZJSwAAABNncNMncMUGhpMncNMncNNnsNOosROn8JNncNNncRNncNRpsJOn8NNncNPosVNncJNncNNnsQhO0NPncMRERFNncMb0t/LAAAALnRSTlMZxow1J1I244xEb9Sot32p8VNwYJphqZpvAOLFqIxvUic28amaDG/UNX63YUVE3zk3GAAAB85JREFUeNrs1kFugzAQheF3jdgaPDYuxiD07n+7MoYuIrVr7Cq/BLGSWXyaJErwOvvCMH2ZF0ORbzZGM5saLwzXC8MtGiOSP3369A/SVTFc4lYM1eFzdAuG6ki1zOghXRYF4rK3s9QVVqgy3VJ75W0KYQkA9mXFU0UyABMdEB3PKgCxg2uoQK4/95lU2ENSwHPCI72jHcs0m+4gZXL0ONNkuMwCG7Cz2aUX9LVNT0HmBuxMsDzzfQsktwudtBO0XTBwg0NFFGeVDtqGMrNpDU15Gl28d3RNBwi9od8GNLStFwbPYOgtJX0Y3XKQ39Fw3IWbTSZbtqFnoTyM3mOsf2/aoJ4LUFmCMDW0plQ6+UwnABu388pA9F5hBZb7K9oKhoaQXaDVTtFxsW1fT7U0kaUNbvPsmBtaUx9oZNInutVErpCCK09m3G9EZWpoSCdoU9OvAA5HJsFdbSOeG4BABkNfPzp9tB+40jjM32ZhwXDtJePTNzt0kMIgDERh+JkxpLa2FSTqKXL/4ylmEYUsXSj832YWwzCPBwAAcPa6MQEAAABP05mewEyFbwZVtMN3347avFNUFr2KOFZLWFpdrvukFA7vnDuF7X2e80+bf9hPJlMWehVNUIVLpqut7JnbjtowEIb/sce2bMcmQEi42Eeo5v0frx4HussWbQ9iS6vmkxjsOUifRhEXwYdxMUEiO4vodJe2nZw9H6GcxVjr/JldvEi3Eztm7VBpd16d+OxU2vU5f44xIkYtGolnh8dSJQFOJidJV2VERklexlEMAC8iZjeOATKs0j4Ee5C9WztCiwHaOLZEH5fA7SIjgaQV2bQoD7aeJCKyDKs0ywuqSr8gd5m9VN7Jsr9Kj80ZKq3GhJAxiQU0+rGNF5ykFr0QSI2jkZOX6dGbNk7oumkvBlGl9YKGnnYCXKVFMlbp1KXp8syWgMt4MyS9EIi0U+s6/Eg4yDDKaKNMxzFgDG76SHo8yXRP2kg9SkDo4+1S5TOl4UlEMoMkhIAUJH8kHVCl3pHmLCMFxCBj1UWE8ROlFWaXLeAvN9ylRnwMX754vfwBGD/AC+HfY8/Y2NjY2NjY2Ni4vPTwEb9CYlxghz/ESETmm8ARgDP32iwAwh1Mr5DQ7AdciRrY4pNQkaUC8WgjLHfpdgb46LBGJdPay2erLu7YOx0iIjoB8AO3wV5edHCKbJ2uoaUtP1qaCeblQBlmryrB1AKf65zhqc4zGqVOALXsYc6JyVSyaHEeQK/SmuaDAYh1POBQ6lJwpMMcLB5HGskC5Angq/QLUFjTJu0sVgjLEQTNTiklIJZkAHcr3Yr7Lo11/FD7Weftwzed46DHi7QBdjb3E722cbakajik3kbmBPgb6QEwF+l1/JCu5+nh0lNiYvjwVnrnWtybFuOlzROhZ9NpAtKLa7F+L63pgHV8lS4WHOyDfz1CBRIN5WbTPpdiwKWUukprD3woZUlYylAYC+2W76U5lCFgHV+lI5VCFp+Bu/+mmhk3cFvgNcsR9/B4P+hRGJ9BZtwynfAdXKopuBILfoY4nHcGT8Tvv/ze0MbGxsbG/wSzRrue79XxWv9bXlIPlCt8ninCk0HjSHgDzeHc6oUsIiWgUjZ4MqcKBJCFLzga1fH0VjpVcEBudYIzCUwA/QUL9xkZQGYcjDpbelcnNdWeg0pb/hv+fil7qMbOqrR+dSm2ltHJ1g8AqEtjIprwdIxB16S+aReGYVRHP88JylDxZtPuBVgcnow6g/ozuz4e3pN/Xy+tXlbpAdjt8VziSETWU8kWLoSEBuEV1+uRhl7PJxiip/96XPE/rG9sbGxsbPwXFPxr8DnGe2mn0R/75wYf7/7DpUR+bfmA64TFrzPRmInNaQZQ8Q4/dIsKXtJt0Rm8xdhLdyRr9lB4/qbjKRNZuEA0AF4cACqhAoj5995c65D9yr4Z5TYMAkF0dwFbmECb1MT98BF6//OVZeO2/kjVWvmK5kmlJAvWCKJIm9GoKxVSt7OcWlTmYn3bVbH/d2/UiyY66NQcLudNdGSvXkCgm1tmpHMrlr5HKk3XuXd5PmnJUeBjomW9XMsgo9y8LTZvaxraPFEQXZBiqwjnSwomOkvhSNzGE73YSatmklwWaeNlTtSp6/ftlEpM2dv5q2j7+zfW9OmTmMzbahrMnBqyzoN4di6etJIc1dIFqMM15Lq0+SaauYs+E1nX+Uod0R5exAWWOblhJSnbDdMicV6PiLYW0HrDzXExF0sLKjomEZm0wn2BDlL1kIpK30SPvswmmoe8NRPWD9VLPofr+cPTS+KkhVlImZaDn2mfPHmmn6Ln0MYv0V5P0O9Fh1kvXruvaRPd5su7iaaxu2Udn6Jeg20k1n4uWhdn90OHRFPl0xh3os3F2kTrghz2oknae07H6w/RPjkTHVt1pFJIC5kzR9s4TX23dXmvThvOB3Zbfv+4eu/3NB9+eWRcb0uHO9/VD8VzEd69pj1/c7jeHB0HhhQAAAAAAADgqUBCHwl9JPSR0EdCHwl9JPSR0AcAAAAAeEqQ0EdCHwl9JPSR0EdC30BCHwn9z/btoAhgAAiBGDYQcP4ttgYqgGmigOG/ACj0FfofFPoK/U8KfYU+ACxT6Cv0FfoKfYW+Ql+hr9AHAAD4rcucSzOn6dzV13Rt9bVpp2ZfXw+d/uqLgQioSAAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/outstanding13/experience.png": "https://static.topcv.vn/cv-builder/assets/experience.bb83d4d7.png",
        "../assets/images/template_cv/outstanding13/info.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlMAAAAgCAMAAAABtg2cAAAAeFBMVEVSo8I0ODtFdok1PEA+YG45TFQ3Q0c0ODk3Qkc3TVM5R0w1Oj00NjhCY203P0M4Ul4zOj08Vl7jbUA2PUA1P0PvaTXLdlU3QUMzNTbacUfwaTSRi4ntajffbkPVc0zoazvmbT03PD3qajnuajavgG0zNDSygm/xaDNtK9O/AAAAJ3RSTlMZqSeMNVJvt3BTYZrFNn5EmkSMi33jUH3Ub/EnxX1gqZqat9Q25zWAZ8D9AAAFy0lEQVR42u2YiZLbIAyGhcRhg+3YiXNtdrNXW7//G1YC52yStmk73Wn5ZoOxAFnAL5wNZDKZTCaTyWQymUwmk8lkMplMJpPJZP42i+nbBv4vviwW8MHYTB/f1vCvMAzDFP4k6+nIB1mzzeN2eNg+f6hE+jQfmCn8IzwMw8Ol9bWt5tJLgbNWT5RqudojFzOlNPQa6rbl29oDF+bWA0YgkhwoDHAMwfcwRBLSOd5wjD/D+/yFt2/+eOTZAzMBOHbEtrpjSwPHNBr+BM/DfPo8DB/t+HRwH4/D8AhnaAC/FI/1qowLiYqF0LH1swamJqhdCQ5ND3VFwIWFa6znQ2S+hT2ax6iJAUCDiDDRoNAAIldgYhCQu/CHr9IpmqlEfihwX+Q2w9fd6EIDm0USBmKT1nCdzXq7WK8Xi/UhkYxlZ9qhbtmd4WeyzcojgS2EMUyNMQyaGA2YTHyVCFNhMJqZsT/ItKQeO8SpXSfK6X14Ok463fawp6bxpvFwiuGufkl77zhTdjco8KBrLvWYH7aDiO/OMgfbHuE+noZhA2coDjX4ivewEE3xZiqYrTTUDccuSrOyxxKQBWcIwPnrmpov3gfmcTs/1dSqeDWGisoWwTuomiWZyjucvXpXKo6B/dY0m1nSjs1Wz2ah9x01dqVds1SFMv61cLYoRVNsNrPXosKxCa7yxmcUC3w6PMMO43yFRVUW/OCmcNgggCSKBbaExhJUvnG68hwTcayrZmnryrfKlFBIrFXNZuQp9OyMfKidV75gr01DMdtVnNqtl8VWsnt6skCTpMt46xsr0iSYeMK9pne7lSStDTBVBz4koWuDScwHl5PRZcwWzl42dVqG8kSiHWHMnNj5TjYPwwuc0NGKvOw2KtNbEBzrCZWudBsTD20vmopSM6bFmfE9Xs/Bp+kwvLB2z84pLkW8tui4HlVkeWYBuJA7cKD0iqjSPVtaCFwazy1Bx2ZjHYBPmsIAbJfbsennNCXPlQhIfJh+f0yNluA9e+WYDQt8jJUrmDTVGGMDUUyE9AdNx4OSS46R2216xFUe07vvy/ECNcWyZ106iea1dDJN6jjHQtK0Y03vNMXJpWKOjtEHlECkSxLziUsVXXrnY3644nUFn4uZH+3kCtXFllDwLt/JVr4cbt/Xp+cUaV6ZhpzSEqOGDnlGvMGBA2SBBdFUXSF4ClVnSbnuqqZYUOv1y3BRUyia0sea4kpTjsoI4KSzmAkVOp0Wa6cpHm0PmpImW35XU9vp4on/X1hMFxc1hXKXjql0JS7E5E411Uw4o4znWJHXiIftBCXVxnD/5FIBVxV8R1OfHgbm5XiBsCISH6SjMH3UlHYiWMXzDTzpvaYqyTwVV7WwgNwvyr4DTGt6wSWQXELXi3fHjaNdBgWZJbfIXO5kymn7wB/YY4H1ogJAiseulOpcyxGncGat0pNVBatK9Ukft3ZxYB7Y/yVN1RWpM015aqvSKqoAnAdL7XLUlG8MP32pwmqnKY4pvfuUnqlgDbUBvqupzfvby3w+fZtvLmlKOVLg9scUFxQLojNN8f4EKVQJPILnkczeShUVKZ1cch3I3tYU8yRfODcnmgp8GTc6ZkvRjSd0Egxreq+pWEmawhaWfQVOZG+gPtWUuDzRlJIhDtSRpnhQOLTczVPc8Xe4DR5Xf4L5MDK/7fVgCjqZ1VGH2hnTyC1i+GY0il2uPzbbNb+OhzVcQkVf6Zi6HSbq2ia7LQ8d4vB7FutR3nwnSTdTZMaN7kLryi5QpZeqpZ2mlar7FHPniEZNgVftZw/LQFH2SVNNt3PZ+lNNiak60VTg7BlbwhLu59PzXE7eD0Gt3DgV7OGYskQuDQUPv8Zi8fx27VdPgh+FF//wHfnX+fQwhTPwXJiHgkHdWQyXhKvZnAzNaLblhX6XLaTx8PxfXugP9SPg/8cn+DlE0zXCTfzYXsMPYxEymUwmk8lkMplMJpPJZDKZTCaTyfwWvgI2bkwv2Uy1kgAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/outstanding13/interests.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAADRCAMAAABSKmjpAAAAmVBMVEVSo8LviWhMncMqTVk7aXpMncMSFRZMncMUGBsWHSEfMjoAAAAWICQZJSkiPEUfMTcqTFoSFhYZJClMnMNNn8VOn8ROo8QWGxwUGhpOn8NRpsIcKjEREhIUGBhNncMSFBQdKjBQocJMnMJMnsRPncMTFRVNncMYHx9OnsRNnsQUFhkSFhlNncRNncJNncNNncJNncJMnMRNncME2kA6AAAAMnRSTlMZjIw1J+PFxqmMUgB9b0RTNsZwbzVSJ5qpbwtg47fx1GA2NmFE05qMfam3t9R+t3BTqLV3VJoAAAOPSURBVHja7NTNioMwFIbhbw4csuiyGnAWgUYRBfsz3/1f3JjUxSDW3RCF80BLTpvFG1FxmX3jNL5TL06VvGTjbM2pGheczgWnu9A4Y7Ix5uDqe4XTaUPw+KgTwQF1uhetbHBA7dgBdYVNwiNd6HiXKxKfFp5paN5atE0H+Kbx8yqdppa8uWtqIP9ZxsCZVkAX0kL4AsA3haMAN7KCptPIslnoACgFRXiyfypHeKW76zxhJjKSIsMquiZl3twXjk4dwJOKKzVP1Z/fsYoeOQItQ+HoFCRIHnzkjmEnOk9RxBeOhpAqfslL36todW5aovMnEwbnHCkopFFSq4/RyUZ0UjA6Zzs82G9G9zG+NqJdjLHcg/jTAy2Jng5AYLtzT09p6pxD+bdHhSv5Xgyk34nOBxuopaO9Ul3gmPo4kYKd6FugTuRQOho3R9J5wI9kGLAXjU7znuLRgI9+tdgRI4wxxhhjjPkPXwcGY4wxxvyyR8Y6r8IwGP2kWFYShTSwJBIgWFCl9v3f78aBiqq9U/928xlc23HMoSiKovyOZNAYDd7p3juWcBBbliKOn2fIBZx4wpeYjAQM3S7Tuf84XwkvkIVBZTVwF6lns3u5l6srTqzBl1g22qX9CIBGY4hM9AS00ouJR6xxNE+tccwAjA3RXeq5DFDnq3SUsX0TDAHxWNqk66TMtWfIwKf0a27Sc3CMtR/yYga+BpaNiUMpqFWxyDls0uMhr9LaIoCVy+rmkB0YkYfi/FKvohL6oXTyEfpjqUhbeUbahjJd/CSDH0sjBywYgqQsVkZynx/fs+tqZWMBCBUxl/dMLFXVErMFDJZhX6SoyCnJ0bG0SdfSdbealosMSvapNDj2GDpJl2Y6jECaATy8EO3qsJMKR9e1i6f0BN5r7/Zbye6n59IjeCfH4SKD9i/SaVsO6dmAJjNkIAQAzgPRS2WJgUQACGn2VuRfpNkA1KSPD0ImdKDlWCrSQf7t7CX+WRp+OqQj28JmYHvrm+B8vwXku80WYbOzkZa9rbhyLV6kE9fhh7Rs4khssyy9F27S5c5XpOlu51P6G4yAvABhh2gPQjpbUrxDeCa1cKbn3WjwXWxs0j8l/GJ/IiiKoiiKoiiKoiiKoiiKoiiKoij/2qGDGoCBIIaB+YfB8gfawrhIMwgsAwAAAAAAAAAAAAAAAAAAAADwosucSzOn6dzqa7pWfW3aqezr7wNJolxoleTGugAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/outstanding13/name.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAaEAAABwCAMAAACAYz/OAAAAk1BMVEVSo8JNnsRNncJMncNOn8ROoMRMncNNncNNncNOo8RMnMNNncJNncNOncMfMThOnsMSFRY7aXoqTFcSExNOncQWHSBNncJNnsQZJCkWICQREhISExQUGBsSExNNncMcKi9OncQUFxgrTVpNnMMWGh1NnsNNnsRNnMMUGhoUGhoiPEMVGBslPEciPEdNncP/h18RERFQ5F6PAAAALnRSTlMZqXDGUjWM4vEnb1OaRFLixic24n2MfmFvffHUqeO3YSe3NdSa1NO3qahEqUREoHpQcQAAB7NJREFUeNrsmtFu2yAUhg8GDCRGvrHsuyjS1PaO93+8xQH7t2k7s8xsTOK7KSHmGM4HBbZSpVKpVCqVSqVSqVQqlUqlUqlUKpVKpVKpVP4bJFUKRSrHJAnXUaVMlHvAleNUKRLrHGPuQUOVIjGMEUmuWvpjOs65DyP4A0kv07gZRntk72a6F9pnRooZG32W9E+Q4olBjfU1RPNS1IbIlxwdchcAyG8zbLWbEcUZap1bx76O313oJO5cKZUcbXRPJixCX3Ejmp4/Jd0HX3GIcABc4gzHDZQp05Br8xiS725moAQgpCOP9xK2sd5tkGcbQuq7Qg1pk8OQVM71HSbAIdzNcOw+ECKhCOHOM4RciDINufZcQxAkqUX4xN4YCvxwM28+GnMefqXzDeH174Ua0uZ0Q1bPgsI7OvqNtIqvf+vJqWXdaIlyGaKWPbBlGnJtgqH8aPQFWb7Si2BALDXD5Z22V0PalGDIv57vtqGeqiFM3NiQGBnrpuWmghuKwZXDLnWWUCnIcx+7R4CL3N9v5vq5+rvha/LwfTLkyI6DpRuaOsZCMIx2Hu6dAn5Y4QVT3F6gfU5gSJtPhiR3T5S8PX8ga9dNX/czf9yU52YeJjc51zToEJcizG4jwln7geUJwdINWeVbTfDDl0y05AlDaZcsbNuHi4QeKDMw5NrYkFQuoH78whBmPr4f0H4dHr5to1qA5tiG/DMXnRAs3RBfw4k1E+DdwJBia+22vcLhIyKfIW0iQx8O/NJQmPkWe70NgoAyaA26r/tz25T5agtwOgh2aAgovDgO5SIGtI/Slgl0DEeojSHh0gztZr7F5s4cCNGJHw1PfL0cSbkd4iBYoiHEklGlgSHA0T7ylgkY6rQf4c7QLXSradiRoXYtjWtJojmyzpfKsUd6ANZgVJzCudtY344dBDs21I/LsBi2z/5KV420Ow9bX2C+an+jbMBQG37sDG3We3dgSPjvV63T2obBtdidzgwysYOt1QLLEcGCqzc6CHZkqJdz1DhWg9mGDLSYbnbfvkVaMgFDJiwiGNrt0+LAEOlliqmlQD/8g2g+oDWS3lEEgo4ITy2fEWuuFB0ES7oPWSxuxmdg4AZDktbRXDbt4Y3yAUPrTxb1hFOSIRZWiUQj9D7Usm1rzNUIs2YNyxHA0EGwJEPmU4Yx7sgQ+2QIDxjKBwwtiyj0BDtUmqEmhJnCakEmMZK371oDvEBiXW6QVjQHXUk2NBMbukshumRDeCAbMLQWYkPtsSHMxlsYiMUvSfXEF9OS2oYeWJ8pZK/1jbMZure+n6UaCovotvaEJRvC/d7/uu7RBCQbEqH+gs0fN9aMhgbtXNGGQsm9YAhxLGpeNkTaP3wLy9EzOJfPUBhA6YaMftUQnvjA5v6aISTDqHU54tTUd82Yx9AliBkbVqyhUHxlH5rZ+DVo0jdgSkgqvsANCAnqDZHMY4iv56KmXENG7wyNyWc5ZAKDQyZBYlKNb4nluLlc5TJkQq7LNuTLr9yH8AGbu8F6SjeEhwIUwKc8hmy4DxRuyOitIYkUbw3dYAGXfhjB5s5DZI+06YZaLMe/ZUj8H4aQmgt2Fo7/k1Do6rtZ/0qTRTO/30XWwl81tDLJScUho9kbmmMNedYQ/nG82BvrsohgqPNl9cG0Q1rGUGaLEYZI+LwJxhn7mItdclJx6pC024eUP2mdbQidVU3Dyz1th08wJB1AWoyLYNHMnxB6j0g2xLAcEWtPnrMceCvUkNEwhLTAEJbWjN4PXkdng2jUvUw21Hz6T1PTuz3yZENWR2Mt1NAi5RKdoPnGEJI1oK94mhPoHOAyddpjnV5RZftF9A+/Uk82hLMo865koYaM3hqi5pkXPYiNIZJBhZXoK8Y40IYrX/w0yadtPKZRgbdK/CXDiYbwh01dCDuUYuiIa9NMBqdtj5yaxn5zBIvqzSNAM50wBrw1A3iBof+Tn+zcQQqFMAxF0ccvsXxFxYniCtz/DhUUAoJmFif3LKGhaRseXbyBBenOUUhkrS9+HJmo5+5HouaIZsoHvz/FJ9oipPDMaS1b9evyk/l4lNLk0rW3SGJwBtHk0pXb7CCu0Mj/MKmu4I9n/MMKdUIum8+ESGn+iitUeuEDZqYX/jClPgAAAAAAAAAAAAAA4MUwSOukvZ06Wm0YhqEAer/ASBYCy/YwCXlIu471/79udtoS6N4GKR3oQBxzFT9dnJiwqQk3ptrw20eAe600ga8Ndnpq6EOtqDf0Bi6CIAs+DWwJqGbtUQXnGZzSzD0PX/iyNuItAregM8YZ7jODO05mNQKFKDoRalHRx2WhhHJaBeV8mxcb8Yg45tOaGbKshJpXuOOUM50LMtr43XE1BNkbCqXvZjWWccsa9XiMJ4syxj1A5qpwB1qsoKYCFaLrXBPidW+oZaIcAoUTqFCRHqcJUB0NVU23M4rd95vB/5dogvVHpxgjRkP50VAJjXrIkM+Gyfr2uaHtjN+hY12y4XI1BAIC6oJU7g2ZIGbuIWp/LQt47vGIqI1VWshA8IaOls/9CcAiZUKlIm1rKGeaAZVCjEZAFBLtDY1oRcxUaDtD3tDLMO/rHkY8RN6/i4J4H7u3FAXurXGDc84555xzzjnnnHPOOeecc+7PfgD2fjqQ9OL/BwAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/outstanding13/objective.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAaEAAABoCAMAAABv5r84AAAAVFBMVEVSo8IfMTk7aXoZJCkWHSErTVoSFRYqTFgUGBoiPEUUGBoSFBQTFhYcKjEUGBgWICQTFhkSExMWGh4XHh8SFhYWISQdKjIXHBxRocAWHBxQo8IREREPteAkAAAAHHRSTlMZUidvjDXFNqhEqdTGYLd+t+KajMZ9YZo5min3zBzz+gAADmxJREFUeNrswYEAAAAAgKD9qRepAgAAAACA2asWHTlhGGg7jkNgCa/C9dT//8/aCRSOwq0qVduq6kiXM36NnVl2/x3Q6OCvAfXw54EJr/3nixrhJQh09kSCeyxbjv+pUbTT0SdNyuatpfnLWdpcHvyafUiiCHjTr1CfnQh3aK3t9dLo1cKJTs2yu+0IjqB2IXgFcDjzMMI9pOwzpYlOdch2Tv6TJl/soBrALeNFmN7cnFV2di4utbCjHqfrftbRw44HZLh3uEEYT5N72uZ1HgJPeGZwCMRTq1mw432Z4bfhK9yjfp9tRsTtk+EZIZqLfGyLxxNsOQJ2xnwtUUMWR/KrQkgRShnj2nFNQmv6Re1S7PwaKVlGoE2iOopCFLMrWoOSgwtEK8k2gkW0n8sZrY/7Co99qiN5YbE/bEu19cqbCpR5c9TC9n9n2N3YoLXw27AvUSg8SAD4MXUN2bLi6gFDZSM7mVigzR7bIXVvDFK55OBh1xiGTouCdFxzUahypmBjZZxc9sIwOk1qpq6uoGE3kBa3Gpw10jXcpXlVt/ZcuSZmhUii4/VlkuTSAuN7Jw+Q2glCpfYAisZIjGps8niFkDdC/kAO0CmV+LHqpAGFuLe2bLptZ6bYTZjry85Q3EI8sD8MK/gKhZwDicAOIL+04gHSppA6GmjMk3dY9NESNFoUSjpprKOGikIqkCnElscIlmUmdM6uGiuznckr3vvGnkYESvlatSupO9qTmyWqi0CgjBQrLYZghbBwtotCpGGy6/62Ew4boWN17ORgVKGy3ciqyTbbFcIytWPv2WWFdobNnQcyh47S2LCvUKgRGRjYA8QKyli8KZQvvIF9Bw0L7AppVo1C608QDuI3hWS/sJxaYy77sio0sMIia5YZNcZGvc4UaqwTz/laC6Pj3EqMy7ksvCKBTZDgmjDyasd1ORix9sjrmhDqPh4UMi8jJ2aO5WljiJt7VYiXGUMe9gUKhSqEMACPAJlPUJfHILZ5UUi8es4KNZZeFOJWz/IOBfE3CjntP+8KWU/6oBClCqghM7P4Quqq/Q+FbKJlVSjKj3fIAwkMpI8XhMwfyBWxV5Yf1VqWyDY9KoSjBXg5MtDmXhWiJGCsAC9QKE83Iqde6qyY9FWF8KZnUah4zgrN/ZhWhSj1/VgU0ly6Vkgb9m+7Qtqzd7tChqRki1Q9Qs5B0WCJFMapqeZVIbPH8h009uIgSpWGC8LEH8gNgirWUKopVX1rsX07OyftRkGq+sCwuY3fMDow1v4F79AGRqDVDPn0fg8GqCOcQHS03QLPQIQMO5DgCuH0E3nDCBQeq1HKLglvyemY4v1lYbhMPg/7UoU+wvFmUdWN7/AJxo4FnqHuOvHH5whPcdu1G53c1z8nP2/6F+CpQoE+ieHnt0Eafw6MBL8Gum+LeG72nPzvxlf4j+/sm4uO1DAMRW3n0aTpY9oyRSv+/z+J7WZS2i2wYlYsYi1AburYDpcR4DP52Pap0Ee3T4U+ur2HQk37gajFBzODz1VI/xpdHZwML8SJDAos7dfsfAQUPf0sD7rXa8X+TAsO3TXFN3BYlNYuej7WKznPRqgkJHs9vNEi8dHWZ36GegdWOhqlX7trlMAs8Jput+RoNgj7DfEOJYHXlcZXIHA+ybK4CpNqjAz5qxVasa729P8k7u602LTxav54Wlle3MWcZTsQLOsCbzKTPOAyxicqFMPd1cE7xITMFEjpAmDfv8APjEEc4Qy8qPP4HMCr1mzPviIC3axAoAAM8SUkenY5Jr4GDRQARKUVkePMBieihNYCsogPVOKo+gCymzcVqkBSdGuBdpBEIsk1oUASqVMq1P5Jcp/wjJIbyauRTzHjAyookCHYONnoB0s6LbktY4pNssoYRpm+NWkcBwthGT13xfP41Fp+PZVnQQS8OXSQWpMQJk6hI/5hnscEHJ/IpJmP4TVmfpRp0hY/kM5bI9MKYReOe065uKP86xCUL/Bipgce+s68JGezP7Pfcrzwk7uilJZHQzTopG/8Gja0wZO6Rdv6mkzj5cQBmIZg42cz9SDWDsbPnAdzSn/EM03GGRMyjRk4cjDwFLPIP7IkjzGlj2X6aHLVocn+jDMCjKyQjvVxcM7cNwiZdESw3jVBRQSYFYLsg6QA2CrlUhw/3mtNjbHIAy9rmxJvLLSYS9yic17ZBa9y6qBMQVmDEAudGnJ5a6ovsACABKWoQvxri+2aczpBG8DnLG1Zw/4cm6CAgZsh/5iErMPGYMAf8IwstmiNc8JkmvBMhWCvkNsUYiAESefz7UauQMf6hofxKArJD09lwO9hhwg6focPzqCVBFkAx5eaGlPLPJAAeQqcP9lsnEuyamqLkqKrixwIAteQ/U58za/v/aYQ+uze5pzT6VhWf2n5SaiKEhgFDM1cUkg6DPykkMaY6iuYghFbydu691VI6QLOAGvQfq3dOJ0RB3McQVXI9rxhrxBTG3OpkMafFRoZX1aFQKDgF6UVVaEAYOaVmcJRocEBTZtCXnwAXgSnv5vzyhwQvDXSMkFVqEjbPhRSwNAkynsOCglhPOAZkf8mRwB4b4WULsjE3Wm/1Mo0P9vXWzsIAOioKpRf+xfYK8Sb75cK0cDxR4W0zF4hmriE0oqq0BByX8IUjgpFH1qvCrHv+Syyuy8oJTDTwG+OWw7zQSEmKUNViAFD33Q+JCcaVIUaf8IzWmcQcjOQKvRcc8cR/JkxGNgtNnDecF65LhevKMXvLDeXoc0Pvj/1SvIcrvYTjCtUWzlWtlu8rFPxDJVe38Va/NUEPzl4nt0NvLNhMO3ytrOS/DtsZ4nKR+G6XcUzf9+YMfxj1uAVY4tvOCU1v6zz7/3WfNqnfdqnfVxb/0+m0HyESxe/xR8i4umlqyihLhXDE5eoa/2BRwBhxQa/QQlQSp1aYe+aJFwbwnpVtEen7R3s+mhUklI9mga8g11+8V/N9ADrQloft6ULsIB2t2buZdnXub7Y8ppEpptSh411EPXM4VsPcaZDKzWrIo7UBfc6SbAHf5ktvGrUjv2uPZKSnO98tC+FXJS2WleOVinHU40H6O7ii//8JHcZHpcN3GwjOcw/i14CDTSyHAP3IEExhc++HkPfGCYErvqgZlFqW6PJWWnHMdoKRHBUbmUUIpDys9lIArkKHRSERGlNfQI0pFckynUJCd6etD24wi56tEhfyMgDFjjROixHq9H7nX9qyJP83Rf/x/0X/63cEjAG/DIOHUcPgzH+RcYdQLJ1smYi8tl1j/sP+9sHgd/wjB/rjD+N7WQwFT+ZqlDr9CMo+zqwgh2yzdKKRR0OYQojawNrADae+HsyftxgQEIFIegBMKgvlxXShgXUz+bNuHCtJO2VIZJn7KLMhGnLzerR7AJpZlKi4MNyE+1sBu5QkQU3kkyTit9a+DPT/tPFF//llgArtCpJ0M+wCbtJGMFUOEUcyv2Het1htBjK9YX5MeO/OZ5PYmCfdbUnhbSv2BG7wzY3p51C/Mj1Rt3KGe1dYYAnBgOVpLRR/WaQFIIFNj/bFLUW+Z1CZsm+rzxkVIUs52fKsi68qQkKJCQzFEhT8UXL/p8rVL9kPYFFG+oX/+UdOyoAPBQyKo4cvXAK3AJwSq7ePigQAl6b8aNlfxL/rJCW5HhZ0laqQvJYvzCapNvDXQ2uijMlUB9n3qNDZ9kflJr7XmpN2l7FLr7ykGjlaKymTILz+5JE8nWyl6Nv3KvZ+U9V6PjF/3JLwMgfd3NSyOTgqEdiEmBCuf+wv30Qh/OMf0b5DNnqAz0UQj0wyl0HmgjI11YsCi5E1ITlDhBJllUUEtYwFYVgGA2orylUIRrq/QfqOFv5XZ4KdsFQeYgVhV64mCjE7++ahH5UyN4rvrAGYH62QvD1OztnuNsoDATh9QKLbQiFRCS69v3f87B3qdmSkEYtEqfz/IgsUxO3I9p0Pga58b9sYNLY2G66hiKGOK8cCvH/H3aDE3c+nSNctA+YYGiHcJiOiEP1NL4VppsdcpFZAAi8MGQbN2+Fqwm9nxzykQhEekPUBWpAF1AwQBwyA4CMi8Z6uYagoHC6SE36S0ApXcXbW2CXxEO6VO1gmnKhs+eTVNohxhdp7Ev4bQl1SGE8pekkrNSsHn6du3dEjb1ZTqBeXa+2Ij+tx5ykhr4CkbMP3rYG0k0HfTq3wi5J683p99Ard9WbLfrTnuhA8v4Xt7L9693ZN3951rG4ptM9OL4qTrwuz6WQXeUMws6qjXt9K1h/94zu59+Zcf8PsMl6qHfIOrayQ1lZO+uE69vn3fNsX3cDrkt6UM+H0Oic3lWQ9bocraZs5VJLoMS72f5NoQBapO/oTSIOKqevy2zRC2KmgDNd4Nhc4vlTJzOAhdzNr7N9ZCTgwgJxCN2ygzC9Go7l2aGU+ycGkD+QfoPdEfRCF2IB4SzxfDfGGTs6KrydZgKhGKdywRDYRzmUKE9D6t68lfyYKkYA3EGom8J7Jg6TOKcXBmBl7AfI2hSSogstxOySk/VBYmOq5iCwkUIB08b0NCQOk6nuEIoxfVkfrGTiwP/eY1e3XxjAB2Rtf9om7CuhC/yS4nniGY75x8gkIrDx7BBH/x3Q/NeHGsujQToIBJ9pqSxrnf1kAK3hVkHWtkPGWkh0oYVFPN/IDLlp1jA1aqRQEMZIgbIBGbGA8FKyQ9xBiGjBaYeQcGYAbeQBH3D0h1Fsa3+HYKg46lcOQTHH+y3f0z+CLhSEMVyG0CSgW0jw+XK4jeyQo96Hmty0UDvEuT87FMcE/RWy3p9Dh80SgUNdKFCtaVKr1fJ05DEDyNfQb6Q+3twvFGAbHPpJO4FOkCUO7VYocIemG/+IcnJ6dGWHjq785KWjKzt0dGWHjq7s0NGVHTq6skN/26MDGgAAAIRB/Vtb45tQgTpDdYYAAAAAAAAAAAC4MDR4lyjnweqBAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding13/project.png": "https://static.topcv.vn/cv-builder/assets/project.a9633192.png",
        "../assets/images/template_cv/outstanding13/reference.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAADRCAMAAABSKmjpAAAAmVBMVEVSo8ISFRYWHSAfMTnviWg7aXoUGBorTVoZJSlMncMWISQTFxgSExMqTFpNncNMncMcKjBOn8NNnsQZJCkqTFVMncMSFBQWGh4iPEdOosROn8NOn8QAAAAREhIhPENNncJNncMTFRUUGhpNncNNnsRPnsNRpsIREhIXHBxNnsMWHBxOncNNncRNncNNncMTGBhLncNNncMRERFd7Ye+AAAAMXRSTlMZxoxSjCeoNW+MfbfiNuPGYDWpcDZw1JpEJ29SAPFEU/HTqX5hRAvwmpqa8NO31LhEodFLfQAACPlJREFUeNrslMFq5DAMhnXYiy42DuTguDAGJ4WQZtj//V9uLUWbKUxLChuGDfiDAUuxrG8UE3qrvNNleBdfupSyadPVnKt1labL8UaXGzRdUbnRaDRewsDjwY7AHOiYvtDLCBkHSh5MxzBcRy9jyr6qp+8nKM7paNbJ8XQf6CziMMRqNYyyLtur1tQ4TAmBkqR40ZwVMCfxGNJW0lNEL5EmN+JUD9QzaKpPwp5N1uvfCNBRwclQUSlEwE1fewHNqPDda04IDtCSDp2VOMZNI0lu3BjOrg7DU29ZWdfAnSC9xE3a4aPvJDLpj9z1AFeRPJm0pF0/A0mlo4MvDpjJpEfmjJU5PElzJZwoDVbpBAQx73fpUqNZxud1+rZ9kmdFNLW/1mmk6AFET9IknCm9RJEueth02yfNFFWxx2LSaqibNs0Vq2qW10t7cJXWPsoubcNPQPwrPQKkqKYHm9qz9OK9zw/pGvVnSt+wjCbNAPgL6WDS0l5+6A6llV1a4DOlwwxv0oPPn6V/w6Tp86RHn016xfyttAsh3B/SNYqnSscMuO3qklPpkUgaRiCRXnaTlr8Rq6ZJzyJBGePr73QgBpyskkrrNyOouYen6NDt0jGDH9J6cQoQfyhdZC4z7qdIxyw9VsB/AEU0vGZoAlxdBZOu8LbJvsweqAHTsbSrTNJH9p8hbT1iByAXaZkBH6gyurqa6CGtzzLbbGOnFcfSyk2Py0znEsJj8bT6MhNDpJ+QkhXX/VchAiNdjtUHajQajUaj0bgkv/5jqNFoNBqNxh/2yG3FbRgIw/9IjCQkGQQJtm8cSG6y9KYw7/9wnVGdQ9Num25DS8EfxDsHafRJu7Gx8S48JRfxLu+0PP4ph7fTZ7xLWOqPtHkZGX8N/l7Bh4h3afD3Xd/WILqIVzIIAaj1oeIkYiCRmvENM2XCjVE8nOSrtDjcESqMedQ57bXS/dyK6DnxWskmPdTF5dFZAz7at0cpQlPfGMp+qbMEbVgNKHIG2M+prdKDrtY5n1w9R3Bq0b9Kus76M3G5SMtBpdP6guYvzotTpzjJInnQjxCMrFsjguiupL8iHl7Oi7gurcGZs3a0OA1VlkVeJH1azpVM+pNfK59qVVOnAlRr+yqNeh4k6LP6sWoAOqOjd8BFOklcSP0+oRJg5dgkBTnY0JClgV4l7dSqS8drxUuVmNW0TXKRzhLEa4PopKl5Gk6W8/Wl6zlUYa8RrdLQxOYgyTQJI7xMGgd8lR4CrxUnErlKyHVR+TxpiRcZ9XNsLt6kByEvhMmWJC/l9Fnco7TNmZYlNnGtvk4aq3STdqmQROxJZDyAq5CVnMpAj13SVZr1TniTfKhSJIUzA3R+lMZ+FKEDdOFCgpezf8h5f1cOdU2e2PkAMwzG32ZYAv472DM2NjY2NjY2Njb+U+b4iiGMG9zwchYiuhP1CXe03tkVAFwjnsV5GLG7n/zdbWhcKOMODnZ+3zAlPAsBvmDmBk4e4Kh5A3o2hxxN+qgNt1hHa7o2acgW21r7covoM9Bjpy0zXNPIHOeGjg+2tR/UN4UE7JunbvI01KfXKc+0OwXsEorLxMNxd3KJgjfpfOQhhAhyWZeMbleZR5dLwBQyjWhlV5LNAGBjqh/C+t5e06PfkXN0kR4oZ2J/DPl4GMpqwdZ5murcsZk6RTtnl5qLUXXj7f+8S8lRDDGlfujYKz3u7zbiGONMIBi2sdykR03J77JGF+nJ6x/Xtxbv0MkOIeJpRu8ZXbrr7ZIrzjlPuJcGJR3qGqA2ZBXrzGHnTNMu7vJF2rat0tdUJ+D60iXamK5LA6HDFj3N7Sg6AEHH+wlgjYDhJq2EaJ28Srces8ZD7a/Ll0kHe4ih2HuvD1+/lXYZyMkT+gtoh3XLFNJHpPdUSjZBR6Hw/qjZgzTeKLyt0ngrRWNXw0Q46NbUJ/UxIXht23dNv5XmU6ETfKFwjNifqNg9fcXHYLYnsKBn76x4iHkgc8PKNY7xkv54jHdrh/f4Q3yJ+B1ySNTwI5LDzzDpf4b3jA/Be2xsbGxsbGy8hhbxERi/YvjCrhmsuA0DYfifGUYSkg2CGNmXGryXXXIp9P0frhlLdqDbQ7O7JXvQRzJxJkP0RRDwHyfX+1cyUilOEZjfr8+4EwYiBhere0IdKCLuzdptI0r2pgUARwAhrBH6EuM9JVsJn3T2QPDQLIBXyUcWBSBFFm+GdpwUqCfYNYmJWZrA29FtI7SYKoBdf1O1zJs9vIuL+VKs0pL9YivK4z8yhAi0OJrAKb7NyBZNTYwHDg7IDkDyZ/5Ka5Vu+lpat40Im+o9rQqD3WVbM7kM86X1VqxHBS5daGYmPATnM45y5gAQqD5vIUyrb2njjucrTmkYw95Nx4gOpmpkhlshrOS9uDMGTaSXMBKgxV7PCSh4iEus0nbILIe0O6SF7e3vOx1lxV1a65R1zxHM4tamr2SDy8bM4ZSGpEtYZgBk64izg4fQzQOLJgGcNGkPHQ5pUAw10lipC5/SwVauOueIPVaHllZtpxXQuzTiFqw3Dh+UxlSIyNdUW6VXckSndBywEykR/yENplQiWreNABSOmdcaBjO5JKd0nQi33gd32lBt9WQC6Snn7t2/MP3bdf2M9yi+EHHBMQ6cx+dRwv9mkgknKzqdTqfT6XxXVGv9tzY8vgFMP2erxJiJfqi1GIhpb+8V4wCDBCO90NpGgEx4CqMD3mS51sjjTCgS73Gao7oavGiX5k0w1/PfXEx6TE+SjhmQGQolgM1wScLIsX4eYFDMmWySWYA9rowkDCj5J0mzNLs5QPmy+ZFUuOULAMx2I2BpyXQkf7uZtPN41k4H2+ldzsg8k0tbuETbciBegcG5wXlKbqMMLR7RRqLc+q8Oz0AS4DLiC6DRPoNO0+WqSgCH+k27dcqkt3rNik0A2Mh0qxNNeApMxNBfRLRycXRk1ljSCzAUogzgvFIeX4lSG6n956D6/tDof5fudDqdTqfT6XQ6nU6n0/ndDh3UAAwEMQxcIHmHP8T2YESaQWAZAAAAAAAAAGBIb04vNyeXudXNZa26edFT2c3vA9nE5eomsXOfAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding13/skillgroup.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAD0CAMAAAAFS/xsAAAAolBMVEVSo8ISFRYWHSErTVofMjo7aXwZJSkqTFgUGBrviWgcKjEiPEUWICQSFBQWGh0fMTcZJCkUGBgSExM7aXYUGBtMncNMncMYHx9NnsNOn8QREhJNncMUGhoUFhlOn8ROo8QAAAASFhlNncNNnsRNncNMnsRSpcFNncNOnsNNncNNncNNncJTo8ESExMSExZOncNNnsRNncMUGRpNncJNncMRERHxxh4FAAAANHRSTlMZxow1UidvNqiMYER+1JpTcLfiJ6mMxYxvNfHiqbdSJwC38aipYQuaRH23cBXj1PDT1KdTiGSypgAADUBJREFUeNrs1Otu4jAQhuG5CVszsmRXTkIOVALU7/6vbT2TAVaN+LXKtpF4VYgLJHniHOijdfqkg/R5OjUvNTIdKaGGPpi5dWpoOlwfdLiJpkY+zD346Ijkd+/e/foGzvSqMhThQt/SjzLTDyZIQq/qkWKi72UsnBL9YKkKvSwyR6ZNISEK/e8KhzD5qXZUngM7ZOBJ33jg4Xn5TP6P0HPBuhD7oswhZNozSWgF2y9g+wpo+YUSEUiALgNFB+w/EP2KVQiM1AI6ooxEJNW3uF89ruewaqPtSmnj+Yb4QPd6BBUzcTM5urujGbisaMiKTm2LI1BotwowGc2GhhrVqzPr6AywQiNFdHc0xNELKvKK7gw92Wm4YaadMpxel2EgYiwJcj+CEO7oZNRSsXIc3Tm6YkRY0RBFDzbz05fQPjnaW8A9gqMtQyenjria3tBLhRg6I6pU0T06HZ7ba9Nu6IrpjLhBt9h/ia87umt/hu4xUoUoeqpgR5/3vBMd7aNLHoCyQSckH+rS0aXipuiEOScERUvAzdFDrHuiJ2VSiIF6WDMtGIkkRlmli/is9eieaAp2BjKsaOhSoWBA19sTXezeT+D2Wvr+ikizGhiXvx55l7JBq5BpROr7BSiKpqDoAvCOaAcgViTJgKxPusZJ14rwQGcgbNAUYEc6290wG1rXJBqBeAVm2rERQJza4ka0TpMkoJrZ0Pp2KRt0E/IEfNnhRENT8Ae9rb9vIpuLRsq/bvHdu3d/2J2DFISBGArDz+Yl1SmtMAy48Rpz/6tZdVCkdOGipYv3QbLKDxEREZH/XA4MIiIiIiKymZIdH0GsmhiBZlH0o2EPpT5d44avesaqyNnQLIr+fsIeUjfWqTMjjB5De4HJAI/3DsOMA3wehtFAS8kBvCL+Fk6LBLTLjZT6YMfcdtSGoSi6j+/yjTggIUXwMB/QPlTK//9ac2wHmhba0tJpK7GlMbbPxQvGE+1B8gAxT/OssIgnBD/P8yjtuLwEAGmEmXdL0jQL2zKAVhTXiokrVE1BnhcJNP1B6OW8WKELyoxx3Ns5x3mHHRbFWdGIKUExtEMaG7QHTZgTTrNOXOHUnPEhcYp5D2jYdsrsljWPmGiZNOnJzQZz5iTOow6tWy6/58kBH0jNZgmGZQzvD02TybMxc/YOrDyPfElU3kILP6YOXStig9YTZ747tE3znJl1pvaXuGwjjDNtoad5lB3a0jwXNGiENJ2WtHdX9Dzu95vNzYpRLxvbXBvqhX9v2TnhB2Jo3BY/PQjvL7v/ccoO9xR2AS+99NJLL7300ksv/U0pVBmNLq020fuyAV8r+J85UeMq6/GQMk2JNPXj6NLGoUsAhLvSJ/nNlogK35fROMgvKrJReEwkAdKemyiFgMBz69oOVFL6yygCz2vEy7oKgO6H8isHNFoXaK+0rJGlmKvrKpCXB3nZ6a14fAg6nYakQMdIDikvc0siJg1AjEJ+GRVuKBGLco4kBQ35IwINJwHApuGUNedJ+5HrLUVxaJEYCQQMBkBMORzKUAzvKFE7Bziuewga8MJnQLk6j7YAOdTwJsr7IM3THsSE9axz+0IKCKXVH3aAYGhhgP0Fmu/GIcC6Bs2dNbWGD0C34sgNeyO+02JXw5toyBWun26pJvDYU3sVtfqz5spGCWyhZYfunalGHofm92ruQfeoJt1QebB6XFYjKAAaQFZA8JnzWr0wQGbouAwBCchb6AQY7rzMAzd8HBpHcqe70D3qyaWARcfkigzkyghLb+cIQCd+zW+u7Fu9Lm/netuXTco4vh3KFjqmfKqdi+zj49rvvxtVYNnL+rraXxv04bJhzDUiw+0Ttepdnq9wwqM6REG4yrs7nR3+Ie1f33289I8pCNyUUPibsuGWO1TrpsEt+XB7X3t8R15ie8YvS4lb7pBWk3mTwhzz9nyRAdgR+oj7MtnA6M0ZXeFxaPmlL9RS84SuxrKbTECyvVz30baDb9BTAA4jH18ztFQcW1PrVGejA/Fe70gt81ee0mrMkUJzh7xMOSaFUQxJ23SMB4ExD82kllhcboYzfwKVIR2Ogiq0KfCZAIKn4WQGyqp52DTEzKYzKUVOmZQVAKpWd2TzqgTY8D2o6lZKc4e8LIAuSEA0xlSnQ92FCFNTcsheyrMkCe/AmRwXkfa0Or79ENE8LMbQjtDETa5uz/e+FVr+0p2m5g7XZbfr7IbVCl2HNj9nIYQkDl7taDJYobkWqnlYeyJfTeeHLbT6PWhiX9jc4brs0FEA4ga08IDGFXrjB4sE5IKpWyO9TEKd3oYOGRgfhy7lS1+oTuSSbNDIb+dyA1qf3ly+B23J1c+2eVj2psfW/Da0Ht8cSTwue3WH3MxujOPjFtZuJi3Vfi/91xXcCv3/SVu89NJL/4hswPekfqGjwhM1EVG4Z1jp9n/L1EGW2o8adzWMRHntaNbJM+ip2U4g9IbKyxUaRdePKPrqMZvlVP4C7arz0VzWUNjJNmsamgXBSUEb1SLaSMgswpOgVYE56nSMhLwMcoUWCmbSIG1TPCUMlEPOA6UrtMpLaKkgjcAuU7ghBZWc79CHHX+n+glKIIlhVL4U/5TrkYGYF2wD7EOR0uQVWmWQMJZAEhB+iBVUr9BJiCSz57wYkQyKJilD9V8MXUROrVQxdH0bg3nW9YCefDPjioQQfoXGqIQuxnTbOpjuXTs07Xb7aoJs4ayiYkhLuenlQ96FPYhnvEXPhj6EJE0GgiZA4wKdSSJ/lDgo/k2vlnO8Xg8giuXHgAgiSU0a0K2885Fkd/dM6P70EEdYYit6Yh+Z+Ij2WFB8bROWKHtMPjAmVwhnc4HmsgIMEbpUR3pWG2gujdhAP1FbH3nW9+woT7y561TtrbbvI+3xPXm89Lmds9txGgbC6Ix/I9tJG2+lShWVdm/2CrhA8vu/Gpmxm2zVFsqq0BbNkTYkdmbzYUCMtjkWBEEQBEEQBEEQHp1U4smY75yycGd8QTKwVnAG80Wf+TB/xOjgvvhSFIVmP9bYWawN1brl7DrMzqw1GkLfwX0hXdZMoX0mT1bH6ZAjXexYYOU78q4MUO1alg37F7gvvgw5p7KixcaiMWu/G11JgHNoFmrtdDQtNMKd8RSklNWmAIX81gP0PaVVc2jWPH1JYB8oNCSy3UmWLRqLUywkh3wcGqozG6eZ3UOEBiwr2O6+YdF+LAVfYCi7o9CLM4sl57uHnjHa5jz/iDMmffqBVyoO4KE+h86lUKZGOnF60zT/OEt8gD6KWDjzf6G8NyoIgiAIgnCJPTwoUcMpbDe4S87s4juo9CcvnBl9OYSGq/DYI2pw4YzfaxOACmeVLW0/uAjJnJFv46XM2+2FKTuoAa6KjSteUauPJdopcMeX1ummHixmrQ5mz7WzpxCr58DEeovW9iDfWm0C/cJjXGN1e0w8vKJGdi+wsPh7XAJm7VhmQJJov9BY3GAiMWEkHyHzcYJFWIWTSwsT/UhybRVt1ZgG1eTbXqdpLGvf1xun4qE6DnnlMSW0ht9Mm8COXNuhS9gDAqkEV6ACQFJKrx1pCaba2KOFw3vovda6hwxAX9Wstbl5ttMkneD8yn/fXjy0QGOoUbcVSawLvNCfazUNzMGBQJIpuaaG7uAK1gogrHG1dmuWGage9noOnZVSCXjQHsxauqJnczS1Rprk0FjLJnhMIzBchhSyebexm9/M56CBavD60LbXrBmsHUu02CTaOTRqWrhdGzS8jJn0BEvrSyI0fQef59CW5dupzGbN0m0N3RyHzN6tcsehuSbTslzpNHvEt1HT991ix3/zuhyX0BHf9g76w+AWq1nbB5johzd0QKLtEhrSLN9qT9LtHDpOD+pIg8ABjkPDNncbhJC7oftTs7ad+FPTAOHl1Ky96Cn4E/l2nthbqjkXwo48c0MQbkDs3GYLZ0md2we4MRFugV/FX/3QRRD+CT7dqOb2RHu+WY3BvcBlrDlT40PQ8C9QKzigARzmHqMLF3Zy2bydbBLTagzXuJMaxB1+gdvBPSLZjAZqaxjab4I7ZhOaW9t6Ta4YRwtsJSybxLSatpeLPe5FCeT21ka6Zd4aJk7nn4J7xNZXcmvYAvDXfpqzdY56zZ6f4VxK0DaJ+Z5Sb5fQLDFSDfWiY+1F9SE0jsoi3eLzNvVApm7v4FNwj8gPnFvDOXRQWqekQpsD1MBHOwJbCcsmMUto80Nrl2ovutQA1jMOTVUbTQaCcp/3xqtKmk9Cp1EpZegcPQI9qRk5xfDjl61LltBrrqkdEtcsoeEQuqNhugw3CF1bwyU0XdjWvvXca1KK4H0YLobmmqUXtfkodA8wtNDKTMcbhK6t4RKaG1FbQ0fsvqA+9E75Y2iDH0LXmqUXxaPQtAFMC0367ehuJDIc4z+eooWz4C9q9vbiE15Ir/qrmMt9pdHX1yzYMakR/jJ+5T9RE2VrGEEQBEEQBEEQBEEQBEEQBEEQBEEQBEH4n/kKT8dXeIen4x1e4el4hdenW+r3KfSzpX5/pdBT7Kf51/j1nfL+BGOdGWTGank/AAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding13/thumbnail.png": "https://static.topcv.vn/cv-builder/assets/thumbnail.b6956dc8.png",
        "../assets/images/template_cv/outstanding14/activity.png": "https://static.topcv.vn/cv-builder/assets/activity.3cb22a92.png",
        "../assets/images/template_cv/outstanding14/additional_info.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANwAAABuCAYAAABMWH3/AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAmISURBVHgB7Z0xkAxNFMfnvu+jioAAVQSokpxEcAIBAqpcIiARnPBW6gIBQickJSU9IUKECAQIVDkCAQFVCKhC4Kruq19Xva2+vp7Z3budt7M3/1/V1u7M9PTM7Lx/v9e9O68nOp3OciGEcOGfQgjhhgQnhCMSnBCOSHBCOCLBCeGIBCeEIxKcEI5IcEI4IsEJ4YgEJ4QjEpwQjkhwQjgiwQnhiAQnhCMSnBCOSHBCOCLBCeHIf0XNTE1NFVu3bq0s8/Hjx+LTp0+h7Lt374rfv39nyx07dqx49erVqu3UPzk5WezYsaP4/v17qI/3fvc3qINtnEtu286dO8Pnb9++hfMsY9Brjs83XU7Zu3dvqDt3fK6vF1y/HefZs2fZMlwnx7GyLHP9VXXyvVWdW7/XsNGpXXCIYN++fd3lgwcPhpuDURlm5KdOnQqfy25Ep9Mprly5skIwR48eLc6fPx/2RwjUf/HixeLBgwfFw4cPV+3/+PHj4t69e9n6MVjqiAWHsc3OzhYTExNhG4bC9SwvLxc3b97MCmPQa8bwnz9/HtZzLRyHunMgFOrPfUepKHINDOfw58+f8F2UCY76Z2ZmuoJLl1Ook2NwbtPT08X8/Hxpg8H3OTc3V7x9+1aCq4MnT56sWOZGY1CpGNYCxsoNvn379oqbx01FmJAex0SVnlcOqweR8oo5e/Zs2Hb9+vVVHnO914wHwMDLGoYy7t69u2KZa11YWFhl/OapB4FrTOvPQYN04cKF0gaDe4aA28rY9uEwGoyeG5u2lOYhEGPa6mPEeBGMuhdnzpwJXiAVG5gHLQtP1wMiQSx473EDL8h3mwtBuWfckzLP2gbGVnDcUIRWFrogOoRCmBOzuLgYREfYWdXSYhwY/dOnT0vL1GU4XBNeu9+GoUn8+vUrNEQ0hik0YGzj3rSVxgnOWsfcKwYhIZ4qbFAiBSG+f/8+hD5V51El6Lrh2ISmNAy9BmDWStn3XCbyXNlco2URAeGjwX2gfFUD1gZq78MNCgMM8YBDGVu2bOkZzlVtJ2yjc1/WV6oycgZRjNevX5cOJqwXwlaMH9GV9YnWQ9moZq6Px/eRK4+XzzVKnDvnzWAQ9wFvff/+/ZE1YE2hcYKjdSwbvYpvODcOYdroXg6MpOwGYwQY8bVr18IoW1oPYU9ZyGllzRvUJThgoIKGwcKxYdedg+tioCem30ETg3too7DcA0Z1q+5VWxjbPhxG3ssT9go7EZX1lVJxYSz2+14KxuQVblrDwGBDLjxuMgiURpL+3CBi3ciMteAIfWj5c1ifodfAhvWVGOKPw0gMHY+CGMvCSy8B0DAQ9uJ11jKkPyrs55eXL1+28je3HGP91y5a/uPHjwfRmYdCHCwjFLxXP16I/kZugIXwlvWEnbGn4/Ply5ddjZ+Gg1c//yZpElV/NGgjjevDDYL93obA6OcYiOTGjRsDhXzWV0q5c+dOMHJGNBG1/UMEkSI4zx9xMdx+BpTqgGvlu8jBevXP+mNiI82eY/+lrAsLLev4sVu0g7H2cCl1D2JIaGK96PEcIRyR4IRwRIITwhEJTghHJDghHJHghHBEghPCEQlOCEckOCEckeCEcESCE8IRCU4IRyQ4IRyR4IRwRIITwhEJTghHGiU4nqgedsoCUgPcunWrtmSqQgzCv1NTU/NFQ7h06VJIBLtt27biw4cPxTDgKW3qOnHiRHHu3LlQtzJIiVFRe06TMo9FOgTLQYL3IZOyESdwZX2cOsHK5tbFdafnQPIdEr7yXjUHnRB1UntOk6tXr2ZFx3oya1kKb5teyiAHPZmgWM/LREQmX7Josb9B9uN4f7J5kVKOvJKElBwnBsHVkTpciF7ULjgzdkuoaqnWmOAwBRHYzCpMGjjozDG2P7kqyfbLZybtAHJUxhMiCjEKah80wTPxshDOlnsxSMgXD4ggVHJG4sUOHz7cXV8VcgrhRaPS5MVhYRpiVmHZiEnW+ujRo5BeG+8We8h4aqrcJI5CeNA4waWDIUA/zNbzOfV+NvFinG2ZfiPezpDIRBNolOAYQbR8/ZZSHAHR/6PvZ3OUleWqt/0RHz8vxKm50/6gxCdGQaMExwR+ho0k8mI9ef8RYW6C+3R/hMogic2wA4jWINyMRzmF8GJDzS0gRNPRfymFcESCE8IRCU4IRyQ4IRyR4IRwRIITwhEJTghHJDghHJHghHBEghPCEQlOCEckOCEckeCEcKT2x3P6ydpVtd+w0yHYg6nDztrF83Y8FtQPk5OT4dk+Hh8S7aJ2D8fDoDw0SlIfnknjM+t4Ts1SI6SwDaPkgdJh0Ol0ugLmwdRhJ5s1AXFdOWZnZ1cs86yfEtO2k9oTwZKE1fJA/vjxI+QbYR0GZ17hwIEDoaylRIi9j3k4ym/atCm80vJss3V8JiPY379/u8skgaWenz9/hnPgnXpICkvZtD4DYabbOec9e/as8Lys3759e/H58+dVdVD+0KFD4bi2D+s4PyUzah9umZfxWhi/hV3mETBewAMSYmG4PLmNKCylwps3b4ojR44Up0+fDvWQgevkyZPFixcvgvGSIIh6MWzKLy4udg0fYbEvBs+T3mzH2DkOx6SuzZs3h8/ksoyZm5srdu/eXSwtLXXL7t+/PwgRr0ZDYh6c80XYlIlDS66P82Ldly9fipmZma5AqZNrEO1h5CkWSGkHGDEvjHdhYaFrtCR+tVANA7f0CoSGgNGSuwRvgWAJH2PwlgiNbalHYRseFxBQrk9p+VMQUlyehEckmp2enu4mleUYNBYksDU4569fv3b7a9Rn4WTZMcXGZaSCs6SvBoYYe0HgM4aJUcaJXHNhZ67OKvCE/Z4fXikVBueKmGI4ryoR0SDYdVi+FdEeGvezAEaOwAwL3aqIB0E8jRhx7dq1q+uxeI9T+qVwLYgcL8lL8xu0j0Zl7QLCNPo5NoKJ8SK4MiERotGHw5DLRv7wktRp4eAwIfwljOT4jKqynEK/j5FKQk3SsJsnR3BVAhUbj8Zm7TLx9PIC8Qw8lCVkQ4Te3mOQvpj6be2lcR7O6FcwzB/ASCVe0Ax5FKHaIAKS2NpLYwXXL4xa2m96jASqXySazNgLDhCZUpeLcUB/XhbCEQlOCEckOCEckeCEcESCE8IRCU4IRyQ4IRyR4IRwRIITwhEJTghHJDghHJHghHBEghPCEQlOCEckOCEckeCEcESCE8IRCU4IRyQ4IRyR4IRwRIITwhEJTghHJDghHJHghHBEghPCEQlOCEf+B6MMLIS/U/amAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding14/avatar.png": "https://static.topcv.vn/cv-builder/assets/avatar.fd4b0737.png",
        "../assets/images/template_cv/outstanding14/award.png": "https://static.topcv.vn/cv-builder/assets/award.af970b4c.png",
        "../assets/images/template_cv/outstanding14/business-card.png": "https://static.topcv.vn/cv-builder/assets/business-card.5908d125.png",
        "../assets/images/template_cv/outstanding14/certification.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANwAAACNCAYAAADciBTTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAA8HSURBVHgB7Z07UBRNF4bHv/5ECZVQUyXUUAmVUFMMxRAIkVANldRUCTFEQyREQiQDUw3RUA356pmql2qamb3P2dnlfaq2WObStzlv95ne6TNXlpaWTgtjTAj/K4wxYVhwxgRiwRkTiAVnTCAWnDGBWHDGBGLBGROIBWdMIBacMYFYcMYEYsEZE4gFZ0wgFpwxgVhwxgRiwU0hN2/eLG7fvl2Y9jHVgrt27VppeBjgZYH6Pnr0qHj+/Hlx//79wrSLqRUcYnvx4kXx9OnT4u/fv2fbHz9+XEwz379/Lz58+FDs7OwUt27dKky7mErBIbaVlZXi+Pi4ePv2bfH79++zffPz81M/4lH/e/fuFV++fClMu/h/MQYweHrfX79+lZ9UENqP0dBb152f75eIfv78WY5oCC0FV4tzrl+/fjbisa0q//QcjiXNKkhLowjp1B1Xh8qjtlDZ87qqXlVUtQVpbm1t1dbLjI9QweHOcX+BgaR8/fq1+PTp05mBLC4uFjdu3CjW19cr06nav7q6WhptLjSBe4kxf/z48SwftnHO69evLxi69u/t7RWbm5vntiNE6nLnzp1z20mLeuzv7xfd6Kctrly5UluvQdrCjI8wwS0tLRUPHjwovn37Vro6GATGRu/+5MmT8vu7d++KJjk4OLjgZmGsGC33Pb2AUCgvIw7n4LYqHerHZAX7Oo12r169KkcmxMVnHG1hxkOI4DBSjPHz589l7y3oxTFM3KGqESYC8qVsGD3l6wSiQhB0GogtLTN1oR4IupPYaAvE1sa2MM0TMmnCRAWGlBpYCsY+LiNj1KNsCKnbb1ea4eT+qK683e7j2twWpnkaH+HozbmJZ5q6H3CrGHnq9o0S3DfcPGY2+Vs32UBdEMugkxEIepC24JyotjDN0rjgZBD99tqcx31fHYwEo0Kzmi9fviwnSuomUWZmZoofP37UpoMgHz58WLqLnUTZb1vgyka1hWmWxgUnw8No+gEjqpulXFtb6zu9XvJjBhPD5lM3adHpx2Q6CVxGZimrBCeh9TsqMarWzTg20RamORq/h9PvS3Uu0SjzwfWqQgbZzRVkxpDR6e7du5VPpPATAYIb9DlF/c7Gj9LmchIyacLMXSe3SPc2w8D0PHlUiUHPFNb9kJ7CZAazkEyi5Ozu7paCoR6DlhdBU0Z+iqiCsg7bFqa9hPwswMiBGBg1MDZNnUsg+n1umN+eEAPuHPdg5Ed6eniZ9MmzF8EBU/5MnuSGr3s98uBDeuQD3L+RfzcoB+WiLRhJ07bgfz7DtoVpL2E/fDNy4PZh/DxQLHDz6PWHfe5PYtBvfnJh2Z7/5tVrWkyi5CAOJlUkmDQf9r1//76rsNUWPGlS1Rb9lNVMFlfG9boqRo9///419puTRqemnyccNh9Gu6tXrzbaFqY9jOXhZWhaCFEP7g6bDyKz0C4PXvFtTCAWnDGBWHDGBGLBGROIBWdMIBacMYFYcMYEYsEZE4gFZ0wgFpwxgVhwxgRiwRkTiAVnTCAWnDGBWHDGBGLBGROIBWdMIGGCq4tERYiBqjiNepVTP2kZ03YaD7FAJGK9EQYIFkTAVUhf2UREYyJVEdtjeXn57FVQBNthuyJbPXv27GwfwXa6vYDDmDbR+AjHu80IO8c7y/iLwAgpR7QrhIiYiLDMcbzqCfERJ4QwdJzDd8WIRIgIUmn18gIOY9pE44JjRCPOIoFy0rj8ir9ISDm9yFBvHEVMCI3venea3p/GcWwn9iTnko4xk0LYPRzuICOTAp8SGu7Pnz9n+xW5iu2CKMQIiliPum9LI1whxvR4Y9pOiOAQmyIV6/6tLryctnN/R5BUArKyDVdSaQnFtjRmUmhccBIb7uT29nYpEtxDXEJeaqGXwiMwtoFe66u3jHIOoxmC1SQL7ieTJwo1bswk0HjkZb3bO0Wzi4hKb6lBTLiOTJ68efPmQjpMqEi8CFAhzIcNkW5MJGMLdZ7CiNVP9OFBX/JozLgZW6jzlH6FY6GZScWPdhkTiAVnTCAWnDGBWHDGBGLBGROIBWdMIBacMYFYcMYEYsEZE4gFZ0wgFtwI4NlOHtAeRawV0mIdoJlOJkpwWpAKbQqtoBXo+aqIfuBc1e/w8LAw00krHl7uBcU6YRkPIDjWyNUtZI2GpUNazzfIuawXZDEt4vXD2dNLiOAwqMXFxfI7xsT/inXCejnWx6XC0WJUtqX7JTa2EaZB+zHW3d3dc+dzrI4nchiLVclbS4FYeZ4bNothWaOXHqe8WYfH6vOUtbW1YmNjo/xONDF9V5211k/xW4B6se/09LTY398vRzY+dB5C8Vqo2/HxcXlcVdvof2K9qMyko1X1OcorrwfrD7WyXqT17Vb3bvWlLvk1SMvJuaSn6wXsZ70j5VVbQVU6HDcpnVSI4DAcFpemFzQNlTAIBwcHZ9/n5+dLAaYXTGAELGolOliad36B2EZIB47TvmHKiCGwYh0wJn2HPN29vb1zokpZWFgo61U1ktOJsT2vWx0YL+2Gd5C3leo+KJ3qW3UNKAt2oePoWDY3NzvmwTkzMzNdr2Wbafwejt4Og8oNJu3RhwUxMzJVTVrQGzJKdcubnnNra+tCkKJxu6yUSeEDUxTFLF/xXteuiEzCJkxFCnVkRJIXMmoUbS2Fka8uCHAdCK6Xa9lmGh/hcNOqRp4UetfU0LlA/dwPKbQehpn30lW9X9X9Hz0lo2Qd7KdHTpmdnS1GAaOYgttCOjpQTkS3srJyzq3DUE9OTi6kRQdHe+f1RmTqUHDB81GO9kZwdDypew7D1J1z0+hsKZQD++A6zM3Nncsjv82YFhoXHI3WTXQYQn4PJ3p1FzBMenvOTc+pGvU0w5nmyflVrla6PxUC4DqNgp2dnVqXEugIGIHydsG9ykFwGHLaBhi9gu8CYsUjyO/LuKdC2HkbDFN3zq0qJ6hjxd08Ojrq6lL2Mxq2lcZdSgyF6Fy54ff6m5UidQkaHQOq6v3Ii5m+dHoeQ04NtQ569dwtJZ+2vMeAzoS605agILmMSClVRkn9Gfkxbj6kxblVdUN0eByjjPfJNcyvAT+B9OuyU/Y8HTqSSaLxEU7uHsbMReR/3JFeXQZERE9Ij8oF4lxGxDoUwVlgXOTNTBsuGL0tZcjdJvXiGBuzYhpBOuU1Kpj0ScuMgVaNeMzGpa4n4qBuuGKUmfJq9lZoEiV3lzFeOrJ8RlMubO5CDoOuQV7ONG/qxUyvoOPMy0Y6lDm9lqTT6VagbbQiapcxlwU/2mVMIBacMYFYcMYEYsEZE4gFZ0wgFpwxgVhwxgRiwRkTiAVnTCAWnDGBWHDGBGLBGROIBWdMIBacMYFYcMYEYsEZE0iY4OpCFdRFbmJb3TltCXtgTL80HmKBmBssr5eoWCavpfPEp2DJPPsIfEPcDZbWLy8vn4USYMk/21lGT7gAluFrH+EUCDtgzKTQ+AhHRCZihayurpZ/EZgiSCFExLS+vl4ep/iLinTMOXznOECICFJpsb1N7xgwphuNC04hzRUPUSgcNgFzGMUU/EdBhxCaIlPJ7VRAUb08g3P1cg9jJoGwezjcQUYmBIh7SASvNECo4iim4dn0NhkiK+u+LY+MPMpwbsY0TYjgEBsuIiOS7t/qQuSlL6kgZJ1eMoErqbQEItR2YyaBxgUnseFObm9vlyLBPcQlJKgp93P8r7fCAN+5P8O1ZETjHEYzBYXleNxPJk/0lhZjJoHG41IS/DN/UaFmFxGVIukiJlxHJk94fVIOEyoSLwJEiKSRv8zCmDbTikCwehdbP8eDX1xoJo1WvAG1X+FYaGZS8aNdxgRiwRkTiAVnTCAWnDGBWHDGBGLBGROIBWdMIBacMYFYcMYEYsEZE4gFNwJ4tpMHtEcRa4W0WAdoppOJEpwWpEKbQitoBXq+KqIfOFf1Ozw8LMx00oqHl3tBsU5YxgMIjjVydQtZo2HpkNbzDXIu6wVZTIt4/XD29BIiOAxqcXGx/I4x8b9inbBejvVxqXC0GJVt6X6JjW2EadB+jHV3d/fc+Ryr44kcxmJV8tZSIFae54bNYljW6KXHKW/W4bH6PGVtba3Y2NgovxNNTN9VZ631U/wWoF7sOz09Lfb398uRjQ+dh1C8Fup2fHxcHlfVNvqfWC8qM+loVX2O8srrwfpDrawXaX271b1bfalLfg3ScnIu6el6AftZ70h51VZQlQ7HTUonFSI4DIfFpekFTUMlDMLBwcHZ9/n5+VKA6QUTGAGLWokOluadXyC2EdKB47RvmDJiCKxYB4xJ36vS3dvbOyeqlIWFhbJeVSM5nRjb87rVgfHSbngHeVup7oPSqb5V14CyYBc6jo5lc3OzYx6cMzMz0/VatpnG7+Ho7TCo3GDSHn1YEDMjU9WkBb0ho1S3vOk5t7a2LgQpGrfLSpkUPjBFUczyFe917YrIJGzCVKRQR0YkeSGjRtHWUhj56oIA14HgermWbabxEQ43rWrkSaF3TQ2dC9TP/ZBC62GYeS9d1ftV3f/RUzJK1sF+euSU2dnZYhQwiim4LaSjA+VEdCsrK+fcOgz15OTkQlp0cLR3Xm9Epg4FFzwf5WhvBEfHk7rnMEzdOTeNzpZCObAPrsPc3Ny5PPLbjGmhccHRaN1EhyHk93CiV3cBw6S359z0nKpRTzOcaZ6cX+VqpftTIQCu0yjY2dmpdSmBjoARKG8X3KscBIchp22A0Sv4LiBWPIL8vox7KoSdt8EwdefcqnKCOlbczaOjo64uZT+jYVtp3KXEUIjOlRt+r79ZKVKXoNExoKrej7yY6Uun5zHk1FDroFfP3VLyact7DOhMqDttCQqSy4iUUmWU1J+RH+PmQ1qcW1U3RIfHMcp4n1zD/BrwE0i/Ljtlz9OhI5kkGh/h5O5hzFxE/scd6dVlQET0hPSoXCDOZUSsQxGcBcZF3sy04YLR21KG3G1SL46xMSumEaRTXqOCSZ+0zBho1YjHbFzqeiIO6oYrRpkpr2ZvhSZRcncZ46Ujy2c05cLmLuQw6Brk5Uzzpl7M9Ao6zrxspEOZ02tJOp1uBdpGK6J2GXNZ8KNdxgRiwRkTiAVnTCAWnDGBWHDGBGLBGROIBWdMIBacMYFYcMYEYsEZE4gFZ0wgFpwxgVhwxgTyH6xdv44gXDkLAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding14/education.png": "https://static.topcv.vn/cv-builder/assets/education.b8d7a090.png",
        "../assets/images/template_cv/outstanding14/experience.png": "https://static.topcv.vn/cv-builder/assets/experience.a441cab3.png",
        "../assets/images/template_cv/outstanding14/info.png": "https://static.topcv.vn/cv-builder/assets/info.a0ee12b8.png",
        "../assets/images/template_cv/outstanding14/interests.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANwAAABSCAYAAAA/4LopAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAkeSURBVHgB7Z09jE1NGMdn33dJ2IQCCQUFBUJDoUChoCBBI0G5q9BQKFDuKtFSoqSlIEFLoUChQKGgIEFBwha7yb7vb5LnZO7sOefeu/Y899z1/yWy93zMnPl4/vPMmXvNMzIxMTEXhBAu/BOEEG5IcEI4IsEJ4YgEJ4QjEpwQjkhwQjgiwQnhiAQnhCMSnBCOSHBCOCLBCeGIBCeEIxKcEI5IcEI40mrBrVy5MmzdujWsWbMmCLEUaLXgDh48GPbt2xcuXboUxdcWGAAYCNpUJjEctFpwDx48CLdv3w6fPn0KGzduLM4fO3ZsYMZOOaampsKuXbvC79+/gxD9MBpajnmSd+/eFecw9m/fvoXnz58HTyjL6dOnw71798KzZ8+CEP3iKjimYps2bYqf8Q6piHIQGfevXbs23L9/Pxo7IuN4bGwsTE9Pl6ZJPWEVPNfuJc/v379X5pVex9PevXs3nquCNNSRe8ry5no+gPRzXQw3LoJDJOPj42Hbtm0d5zHIJ0+ehKdPn3acZ8p46NCh0mkjQmWq+erVq3nXMFbe97px5syZ4t5bt26Vesqy63VpqsqMJ2TAMOGdOnUqtsfly5dLy9btuhhuXASHETHqY6ivX7+OosF49+/fP88D8H7ENQyVf4gSI969e3dcRCHty5cvS5+DB7p27VpxjFc8fvx4fA+s80p/ysTERFzcYRBgALEyU2eez+cbN24EIRoXHMbGOxeGmHoFm56l4CUQGx4Mr2AgSu5HgJOTk+H8+fNRmDn5NBVPAW/fvi2dNi4GlBmxVZWZ8mhxRRiNr1Kasdm7Wx1MyfASqeGm2BQUUeK92gBeGlHVlVmCE4bLlJLRH09w9erVKBgb+VNsNRJvVAfve0zT8JqLsbDAe+XIyMi887182Y7wue/x48ehH6gnXrHqmli6uAiO0Z+RHiNjWR0Y9c2bpdO9blM/8xYrVqwIiwFlqjL+bpg4+vVgpOO9r4om3zfFYHH7WsAWQWy53Qwdz3blypXCaLt5FnsvW6x3sqpVSsrVbcXTymBl6hUEVbUKefHixb7zE8OD+y9NbGGDlUO8G8aFyJhmco3VyDr27t0b/7bheyqEQ7kX6iHF34eL4KoWOMxD2NSMdz3u5WuEMhAb729MRdvyxTDvpAwaVVNE/fhapDQ+pbQvi1kMQSh4BMAQWZXES5h4MF7ExwKLfZXA/Rg0YmOBg/vzrxMGCdNkykeZqVNaZo7t+zl9DyegccFhfEwf0wUTsEUTfpeYUrbAYvfjATHoti2zV5UZD25lFgJGvMNV2fSq10UP7ud3k8P0XdYwlln44P6/BfpdXWzqFyJNMoxlFj5oiwUhHJHghHBEghPCEQlOCEckOCEckeCEcESCE8IRCU4IRyQ4IRyR4IRwRIITwhEJTghHJDghHJHghHBEghPCEQlOCEckOCEckeCEcESCE8IRCU4IR1oluKoIpr1GNrXooUuNunqxf2cTdbbgKk3RS59yT1uiJC0WLoI7d+5c3JmYf/Y5b0galx2Xq8L/Ylh1sCckG8Uu9tZ0bOhKmVMov+duytS9yjh7GYj6gaCXbGrL/pr8bUp05N2tr3i2bW2/VPj3/86cCg2zY8eOcOfOnbjx64sXL+JOyydOnAg/fvwoBLZ+/frw5cuX8PPnzzAzM9OR3kZDNpXdvHlzPJfG+Ob6smXLOvIDREEoqqo0nOfv7OxsWLVqVWnccIyCvC08Foby8ePH8P79+4580vztudRpw4YNRZmoQ3qc15EylJWXwYk03JOnp3xp/tQlTV9WvipIzz3Uk+c8fPgw9kdadq6n/dMt/7J0nKPMlL2sT9KyU3fautc6tB0XwWGshBo2aPg3b96Ew4cPx/N4NgwNQ7XYAXmnWuhewJtx74cPH2LnMRpjGBaoEYPBMxEplfswQrZVN0FyD4InDaKgfBhFVbwChM493Lt69erw6NGjeJ7Rd8+ePTGfAwcOFGXiWTt37ozl5f4jR47EY4Rrxww8KRgU9eC61ZGQXDyb8lqQE65Tdmujs2fPFtF/Lly4EMbGxuJnykCepKX+5P358+fKPTMZSLZs2RLvpa58powYOB7e8uXZDDjUmTTUizQW0IRB07B+tfrQ53hQ+mb58uWxT9kCn2eQF23JZ8uLZ1CPtE6jo6PFdvnDSOMbwdLo27dvL4JdsO05MLqtW7cufk63Ozdvlhs/W4lblFH288cIMDTyv3nzZjE9sT3+MSzSWN4Y6MmTJwsvdf369SLvuimbwTMJc5yGsGIKa/Uhf8pEwEjgOZwDDCw/Rpy58ed1JHSViYm45mlYLepo+RkYq6XnebS5xTzn+OjRo6WDCuXhn9UFrJ60Tfpsnkm+3EtUW4uZQHlzaB+2eaeeVlZrH6DPqAeDbllelCmtkz27LLzYsNC44DB4RmqmlCk0ponEouVwTCeVGQWjagr3km++pTida8b869evjvtN4HnE017e+xiNMV48hRkGxpJGzUnzyT9XXaurYzp9SsXJ+bKAlF+/fq09roL2yoNA2nE++FF2BkXS5OXNoZ1oN6s/cRbMw3HMXzwc+VUFoUzrYM8eZgaySmkLJETBodExHoRJh1Q1PEJM05POjDBdwLApZR10croIw1SlDjwiozz5mocEnk+5Ge35lwcm6Zc0Nh718zIupmhpDHaea+1NfdO2olz0EXXP0+QLSQjE2sWuM120vrZ+Ij/ySuu7VEN8ucQWYA4+Pj7ecWxTDeAvAqwbwegUpjmMeKS3kFV0HqPo3NxcPE8nkl9dFFE6m+eZITFVsQ7Gi6XTRlset2kM5SYt5zEmPByelGfn075+wWMwLbX8iM7aBJOTk9H7WPvT7kzjrH2ZAdjAR3siPuppbUzbk4apXtonefho2onBlHu5zjWmj+RF/ubhgDype5rXsC+QlOEePacNIKB0Wsc0x94zMJI/9VQLwQI3eryfDKqOYgDRc9qAxRhn9GU0Z0plL/NlL/9LjXyxpRdoM6a8toAhFsZf6eGEGBT6LaUQjkhwQjgiwQnhiAQnhCMSnBCOSHBCOCLBCeGIBCeEIxKcEI5IcEI4IsEJ4YgEJ4QjEpwQjkhwQjgiwQnhiAQnhCMSnBCOSHBCOPIfqN5U6iqtY8IAAAAASUVORK5CYII=",
        "../assets/images/template_cv/outstanding14/name.png": "https://static.topcv.vn/cv-builder/assets/name.09e2d213.png",
        "../assets/images/template_cv/outstanding14/objective.png": "https://static.topcv.vn/cv-builder/assets/objective.beb043c5.png",
        "../assets/images/template_cv/outstanding14/project.png": "https://static.topcv.vn/cv-builder/assets/project.8a3a3993.png",
        "../assets/images/template_cv/outstanding14/reference.png": "https://static.topcv.vn/cv-builder/assets/reference.0a667890.png",
        "../assets/images/template_cv/outstanding14/skillgroup.png": "https://static.topcv.vn/cv-builder/assets/skillgroup.76f10959.png",
        "../assets/images/template_cv/outstanding14/thumbnail.png": "https://static.topcv.vn/cv-builder/assets/thumbnail.1233273d.png",
        "../assets/images/template_cv/outstanding15/activity.png": "https://static.topcv.vn/cv-builder/assets/activity.38e42a46.png",
        "../assets/images/template_cv/outstanding15/avatar.png": "https://static.topcv.vn/cv-builder/assets/avatar.9bd906d4.png",
        "../assets/images/template_cv/outstanding15/award.png": "https://static.topcv.vn/cv-builder/assets/award.b23acaf0.png",
        "../assets/images/template_cv/outstanding15/certification.png": "https://static.topcv.vn/cv-builder/assets/certification.3e39e6a4.png",
        "../assets/images/template_cv/outstanding15/education.png": "https://static.topcv.vn/cv-builder/assets/education.7aa445ee.png",
        "../assets/images/template_cv/outstanding15/experience.png": "https://static.topcv.vn/cv-builder/assets/experience.7aafbfcf.png",
        "../assets/images/template_cv/outstanding15/info.png": "https://static.topcv.vn/cv-builder/assets/info.5d03ebea.png",
        "../assets/images/template_cv/outstanding15/interests.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAT4AAABZCAYAAACnvkhmAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAkOSURBVHgB7d09UxNdGMbxwzNPK2jxdAb4ADDQw2jPi5WNCLUI1KJYi2ANA/a8NFYi9I7QK/AFIKUN8gXy5Dozd+ZksxuyIYaE8//NZEg2e3bPLrOX99mTSE+pzAFARP5xABAZgg9AdAg+ANEh+ABEh+ADEB2CD0B0CD4A0SH4AESH4AMQnX9dTv99KToA6CS/nxdyrU/FByA6PXxXF0BsqPgARIfgAxAdgg9AdHLP6t7GycmJ29/fd729vW5+ft719/c7AGi3tgbf6emp01zK4eGhOzs7cwcHB65THB0duT9//rhCoeDGx8cdgPurrUPd169fu83NTR8sChmzvb3tK8G7sr6+7mZnZ93W1hZVKBCBtt/jU+Cp2lteXq4sU+itrKy4u7C3t+cfr1698hUowQfcf7ca6p6fn/sQk76+Pjc0NFQ3OHSP7/Ly0ld+PT09vr2CUA/d98vaR1gdZhkbG/PbLhaLlddZ29K+hoeH/TJVnwMDA5VjqNdv0fElt33TftVewv0CuEOlJlxcXJSmp6dLjx49qnk8efLEvx8qDyFLg4ODqevrUQ6e0u7ubuq+svaTfMja2lrV66SRkRH/3tTUVGXZwsJCZpusfms75SqxoW2Ivaf1ANy9piq+Z8+eVSogVXmqlFRJqaK6urqqqvoWFxer7t9p8kCsQpKZmRn/SKP1rU3YTtVTVoXWCrrvp0fYD9u/jl3HpT5MTk46AN0ld/CFw74PHz74YavRchv6igLPQk8BubOzUwlFrVuu5nyQaHJjYmIidTZVkyHh9kdHR/1z7Te8T9hK6rOFnvqtPtgQVX3Q/UgFIaEHdKfcwRfebwurNlGohdWehYdCQhMHYYWm9bTs6dOnfptat1M+RmJhrX6HYS16rmUAulfu4NPNexvaqlLT599UDali03sWEnrfKkNVRmnDUq2rdgoamwBoFQ3Hk6w/Nzk+PvY/dVx5Z3nT9gugs+QOPgXY9+/f/T0uG/bqoQ8li76Rsbq6WlUZ1rsXFwaLttOqj5NYeOUVhmMzfWl2vwDap6nJDRumWuApAHXBX19f+ypQQacANPU+jhLeE2zlZ+g2NjZqlr1///7Gj8aoD1bRhn27zX6XlpYcgM5xq8/xKSQ0yaCHQtDu1ykENfGgoa99Pzftu7lqo6GyaMjbSmmzxJ8+fWroM4Ga0FC/9VD4JT97p34rHNMq2bT9EnxAZ2nqmxu6j6Uwy7pnZoFgs64KG2tjH1jW8/B+mIbHnSKcLZ6bm6vqt8JQ/daMdKP3DAF0ltwVn0JAFZ3dy7LKJwwBCzHN0r5588ZXWvbZtzT6WEwnfVVM/VafNDSu129Vg3zFDeg+uSs+DV8VCvaB3nD2Vu9p4iMMg7dv37qvX7+mfpVLy/Re+FnATqE+6Vjq9ZvP8QHd6VZ/c8NCz6q+m75JkXf9TtGt/QaQjj82BCA6/NfzAKJD8AGIDsEHIDoEH4DoEHwAokPwAYhO7m9u/Pel6ACgk/x+Xsi1PhUfgOjwAWYA0aHiAxAdgg9AdAg+ANEh+ABEh+ADEB2CD0B0CD4A0SH4AESH4AMQHYIPQHQIPgDRIfgARIfgAxAdgg9AdP5q8OkPcZ+dnTW8POn8/Nyv+7cdHR3lWv/4+Ljhtnm3HWr0PN1GI+dYx9uO3wPQLk0F39zcnFtcXPSP2dlZ/zMMA9GFsrKy4vr7+2va672bAmFvb8/9+PHD9fX1ub9te3s71/r7+/v+p47j4uKipdsWhd36+rp/6Bwmz22rHB4eNnSOdbwEH+6T3P/1vOhC2djYqLzWRaHwk/Hxcf+zWCy6mZmZuttRO1UchUKhKiC1fGBgoGb9y8tLv++sNlqu9/WeXqeFrrFKR+uGFDrDw8OZr0Palx1v2AcZGxurWq7zoZ/h8jRa5/r62m9XfVPo2D7CYxwaGmp4+2nttOzhw4f+kVw3a1t2zm46BqDTtWSoqwtqc3OzUgmpSjk9PfUPVYRp1YIqvq2tLV8xqbKxykhBoxDVclUjek8Ueqo019bW/HthJXRyclLTxvqSRm2/ffvm19d+rX/aR7JC07r12Ptqa33Qcds/BKLnWqa+hcuTtA2dL9tG2BedL9v+7u5u1X7Vxs73wsKCS55nnbOrqyu/f51fPdRe29J5sP0kt6Xn4XGmLQe6Uimnd+/elUZGRkrlC8w/QlNTUzXrly+6UvmCq1pWvuBKL1++rFqm1+WLszQ9Pe1/Jtsn22gd27/ahMpDON8uTTksa/o9ODhY6VcjxxSuY++rD2qflFyu9cPjS243XDc8jmQ/9Hsoh1BNm6TyPy7+UY+dP9tmWr/C5VnrAd0i91B3dXXVD8XCoa7YMFSsGtFrVWVpQ6Pk8FHrqvLq7e2tuuek4aqGXvoZLtdz7TNNvXtWahMOT9P60qysoXW4XM91nGl91HkN19VQN2tyQ33Wsdi5yfLixQt/L8+qNP3+RFWx+mDnXbS9esP68Dn3/NDNWjLUtYkMXVS6ePRaz5eXlzMvyvCGvdZXO1s3DLSs4AzpfV3cRkPoLBMTE37ixGhftj8LJZNnRlX3zsJj0vA7r+Q2wgmgZNBrPYWUjj1sY/cYw3a617qzs+N/H3YbYH5+vvI7MtpevW0B90VTkxsKh6Wlpcpr3T/ShWTBpZ8KwnqVgdYpD7H8JIbaWyWin7o4e3p6/HJd2Fo3q7oTXbzanwXF5ORkZf3R0VH38+fPyrrqk6ogVUC6sa99hBMF2p+99/jxY9coC5XPnz/r9oHfTr3AVl8VMnbconMYbkMVn00+aD0do/VZAa7zojZarjaqltUmPB79I6AQtnYWdGpjla9Vc3YetS0te/Dggfv48WPmMaj/uj9o7Q4ODlz5Noj79etXzXkHOsm9+POSyaGjLkYFgALQKtFOY5MMN818dzKdd6segW5yL765YTPBmvVVtabKRqEnqu7+Js2YNsv6mEe9WeF2U/Cp8gS6DX9QHEB0+K4ugOgQfACiQ/ABiA7BByA6BB+A6BB8AKJD8AGIDsEHIDoEH4DoEHwAokPwAYgOwQcgOgQfgOgQfACiQ/ABiA7BByA6BB+A6BB8AKJD8AGIDsEHIDoEH4Do/A+4BsDNUj4MiQAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/outstanding15/name.png": "https://static.topcv.vn/cv-builder/assets/name.c6454e3e.png",
        "../assets/images/template_cv/outstanding15/objective.png": "https://static.topcv.vn/cv-builder/assets/objective.99cc77c6.png",
        "../assets/images/template_cv/outstanding15/project.png": "https://static.topcv.vn/cv-builder/assets/project.31c7e697.png",
        "../assets/images/template_cv/outstanding15/reference.png": "https://static.topcv.vn/cv-builder/assets/reference.0bb8d6d8.png",
        "../assets/images/template_cv/outstanding15/skillgroup.png": "https://static.topcv.vn/cv-builder/assets/skillgroup.4e16dedb.png",
        "../assets/images/template_cv/outstanding15/thumbnail.png": "https://static.topcv.vn/cv-builder/assets/thumbnail.e69eadd1.png",
        "../assets/images/template_cv/outstanding16/activity.png": "https://static.topcv.vn/cv-builder/assets/activity.38e42a46.png",
        "../assets/images/template_cv/outstanding16/avatar.png": "https://static.topcv.vn/cv-builder/assets/avatar.0fb6408e.png",
        "../assets/images/template_cv/outstanding16/award.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAADiCAMAAADQxB3qAAAAe1BMVEUAAAAQEBAQEBAQEBAQEBAQEBAREREQEBAQEBAREREQEBAQEBAQEBAQEBAQEBAQEBAREREQEBAQEBASEhL///+AgIARERGmpqYvLy/w8PDExMSIiIjh4eFqamri4uKXl5d5eXlMTEzT09MgICBbW1suLi60tLQ+Pj61tbWZgEgXAAAAFHRSTlMAECBAoIDfUL/PMGCQcK+w78CPcGR9JnkAAAb3SURBVHja7JnbcuMgDIb3IVSBOBgwPuT9n3AtIKXutk7T5aLT0XdhI4H9f+NSJzP5IwiCIAjCJ+wvP4j9i9Iv8IN4EemPEWmRvkCkRfoCkf5faZqVccBMU+u000T11KBj2Gf66rZ8ut1MG0331ilhnDRZ64CU5zyta+8oGIWqVF4ZjWbzCSzWGYMWANvqeeHjjS+avWe5gKlOLXNPWNQwaadDPa/hVdph7NIVjXz8WNpFnlmpFF6zNWKoFZ0SBkk7ndpodq/SJmd6QposT7hWZE1HmXHmKh6NU8IQaYsbdJq0tRiekIYADhM0yrXKoKYyAwHV6H9EjfSPtHEzpmekFSiuKwYTdyLGMgM70mBpwgxn6ZqU0Dwl7ftKh5o7tONWboUIg6U54b20O5I2jJ9IW8XEK2kssi5nB6onjH/Sm1IJm/TG/Zzp2096505579Un3ROG7WnXRv4u7dXBgvYZ6YCx7+mFOwcLBnVOGPb2CO+kVckg3B9K59wmN6D+9oi8l8tNac2xJIyWplXTWTrWMqF5JJ1wroVjVdNuqP1xsG2VPicM+0RcfR0sa5F2sf+VL6XbRrgbRu2AiYmg3YSb54RR0uB8uk3TzVsq0j60fs70QBq2VQelAgGjFjVPJqoyvUDFv0mIlkZJM87MBN+C2pW9OENvEuT79JcRaZG+QKRF+gKRLtK/+ecLQRAEQRCEv+zSQY5DIQwDUCdAPkNAZFrJ9z9q9VV10RtQKW8TxSsvnFJKP0DWdABlNv2cd3YyY9DkYgQLGoMx9M4eOJfziQevbqrRhR2F1emoFBxrmWLx4gY2hzmUexNwnj2QYVZYgUoFpNI7gXJ26UVTeZcWFIsn9vGlK6cA0YEeWPxTYFKwWHAsp7XWxuRqrErO1rywXmY4V+fNpZNdnbd/NDIGfoDo95NSSimllF7smEtu3DAQRF//+CelGd//rok0cQaZ2Bs7NhLEb9EAi8Um0RsV9MW/hMivy6vwCvrn75Xn67W9sN3ktaPrF7v2R6c8GyM/NFXew0hAabMDaKyHa8MID15CVxJyvgsrHo1bA5BSG23e5bYi8x7KMkhs1hTUmiBiCoiAopBNEVHjWTwL5DkR7wDnCekdaKanQjOo50abXSRCAL05c+a45jz3FnYrtAvJI2mukazVMSrQNrRQuXpU6XX4ACRxfcoBib567X13gV6jiJbpG1GiCLCVSFmPrrTSV+R9U5C0TiHW1H14XaPyBtqFYjkkwdZM5ZqzQwKk4t02W6pb807bAGIFw45jprqy1FO80lSb9M0csgJJmbdWh/E6qQB2Cl3lOrPTEhTeQA9sDLMBhbK8tmHoBeCiF+aMzd1bFfoEiB2KkENKGUnNOeglmMXLjM6JXI4hjHy0ui6vdmsZ+dgJH9VGJscxiTfgBqnK2S07mm5PAqiuuI2OhNSbkzzCSFCtx2GeE5AOSS+HOid6BWxApSh5ZEeS5AGwNewmUIRh9MkbqAKRbu2lrJW0wDAAd6hoXaWb35ytihTq8iQ9+di11wZ8t4Qkj9qlrpp/jrTCyJZ8pZZThkOIU9hbhSK48W4UeUF8WVG5m0VAFJGX3PLYVYS/+D/yF1988R/Q8u+S8iqiB/KL3RQUQPkkWueBPhYP3ONl9pLcGz/RskUNagNNfDjNQFWkIWZ3iWztZ5Q0VUDGvH8+sp/6syU9Abt4Bu98MFKHFzYjD62xJqDfJSc8qkpaUcklSgXyvmVHCwejM4/4ye6RzC4AwpyfMejxBJMqjNxU5uA2qWkO86y33HM+qiKV6ByUpgnMj5p9Bid9sJSPpgggFUqL4jUDFSAyzHnmHtsgD+AMcs+D3E/NPM9jdwagRvPsfDhbo03b0F03SMJZ8pwTSVoUG1pgZW4v34py0C6Yg/cRUNSqHAukJuXDseJVbfftIml5MmAmX3pkzE6CyFzLSgrklBnOSR+wrRKUstYTRPIygBR8BgqI3oPpffWD3NDKD5ZyRwTKWUH0r4qb39q3g9WGYSCKos9jSR7bTex2kf//1OI2aSERCEpA03DPQhi0mYUWMvZd/FyWn3f/+81NQZmuuLwDAAAAAKKpJSPSFPiX73oyIll5V2C1ZGSY90vooWvJyJBz7KFryYik6EM/JiPxh35MRuIPXUlG4h+PWjISfmgqEQAAALwEkhGSEZIRkhGSEZIRkhEA+EMycrvT3roRG0c91/OTkcPs0lBSKllKnpOrrXcysuYijdv3xS9L8lEtnZORY3VTzmanNOzX49LSOxlJq9KkbXa/2HhstnVPRmwvZT/peF7T8jX0pIbuyUhZpCnZLOnjbSgmnZKa+iYj67FamXb32QdNfnY3tUVIRn5ZtA96d8nIf0EyAgAAAAAAAAAAACCST5Oh51ca7SnSAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding16/certification.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAADiCAMAAADQxB3qAAAAh1BMVEUAAAAQEBAQEBAQEBAQEBAQEBAQEBAREREQEBAQEBAQEBAREREQEBAQEBAQEBAREREQEBAQEBARERESEhIQEBAQEBD///+AgIARERHh4eFqamqIiIjDw8NMTEzw8PAfHx8vLy/S0tJ5eXmmpqaXl5c+Pj4uLi60tLTExMRbW1ulpaW1tbWWlpY30MNjAAAAFnRSTlMAECDAoEAw33BQgM+QsGDvr3/gkI/Pfveo4AAACOdJREFUeNrsmeuO4jAMRvcpwpc01zbpBXj/51tM0nYLhR1pCGJGPn9SmtQ5tRxLFX8YhmEYhnlAOnwQ6YvSB/FBHFh6H5Zm6SewdGVpab9tN07Ne6UbaPF9knyntMTxBc5NjUxbKcU+esgL4mnvje5LZz9QeH1NjwaAU7Rd62Xe27dCRB/mHxrmMqTsGPOixgHw8V9jQ7coUH6W8CpHe7F0h74ZBgVSUSjSUGs5S7h+0pcBee+GFtkEc9RnA7Pm0zkK5FwozxIwOdprpSV6S6OGeSitijv0It2C6pTGbg7ke3kdna8sXTwJA/sf6bb3NkuvHtbNqY7zmW0RakvTpgvPpRuNtkhHDMshLhepFwuVpQPajXTsiLgvTUnM0hPuGgfMRrrtrlSRHtFspAsPpK1LWdrgWhGGKBmH2kgX3pJpLQn9QFoMaEqm6dZRKZUgMpg20oO8UkXaYjlIPtzW9HAnLSYnSbqFXvTKhffl4uRPtQ+icaU6p9vu0SGWCoqrtHWGpPXiMWd6fQ9Vv3toTEVNia20RZprZpUWZ3haZEqDi8BSaMnmPt3X7h6UIX8KoXG93ErTjBnHk6HrRZp0aZHsoUY5KiSsdey7IKNzsrI0ce5xwcjbPk3WhLIbaekgaVA0584BYuaYA4XKfboQtLa7E1YfB5p5MKnDfSD5CV8uKz/oc2uBpVn6CSzN0k9gaeLwm/++YBiGYRiG+csuHaQ4EMNAFC3Jdsvt2BLdk0Xd/6RDSCBXcEBvI9DqLyqllH6A9OkA2hz6OZ/fzozBh5yMYMPFYBxivPnEvpwdf2zFVKMICxqr01Ep2Fa/FZ0nF7B43A7lWgScew/kMGusQKUCUumFQNs7utNU3tGCZtGxto+unAJEAUqg86HApKCzYVtOG2Mck/1iVXKO4Y3P0wz7KnxxMbLoyZeCi4wDP0AVX6JIKaWUUkr/7JjpjtswDISHpw5KstMD6Ps/aUHZvQ/sLlqgRfv90NoiZ5ZijITJf/42yPElRp/f4PfgxgARNuz4HnfcGy7ow5678K28j1AXPm3Ya7sSv4sTXgbH6KXi/les3/e5454rKXzm3WvDGoVQdzvL1p/i2LR1GKpWvsRfQ29yv+NlFAfowDTnfXTnRsQGwO1uqBvuuBFA7aRVcy8Fy8C7ThcQgVcjJN5MCKtl6BbTatuVkCZKxGB3w/NZmiujaC9sEzi0tzJ04nF2mddLof2K7256zKZzyCJBlVrsUdKjdRZnqWdNQxkaneTxSAXi7IVZqgrO0T+YjAYruvB8xiWiAkyvFSzAqHDhAEYHoA2oV9wFyL8IRq02uAC9+wRSJIzC2wCrpi4LesVpTpiePgc1cLlNJE3wEtIY7DYAwTS0vCC0nn5q97O6twOrY29QZKy3Kqpq6+5tIS+qmnfBgHC51bbFB8BhoipA3ufGNLyElRZvW28gSaezAdlsqx1cKO0Jy3oDy2565pnm9vReQR1qVxXDPIDqAF5RNvS4n74030d4VPHd3TQzAR94Ga+LlgrhbKacWhg+ASEqcu6e1KJCVzwIAB+9rmx2wEPDMYORIhMqp/RbMyf01DMV4rA0PxU1JBSAHz2TBS+EmPABxkdqtulOeJJ2w/TF2/oXyuVXgH7fjys19ORf68j4/fzBv6r/5z//GEb4HE5yJRAnhJ/CdK1fDrTfQATCM7CFH+AVqF9NjzFVlYpqebjqodrwU2Km0bs7azq/gXV8Q63e8XRIF5iMAKK8YICMOSOPTmjGIDjDDcmRi809zcIFG88k8kvN5JfHdo9MkeDLP2gNosy1bZjLzlUngI3xNNahXKTvj2kqZy9o0UUAtGN6DBWo9HKOaAAsmBm9A1yANZA8tBeqMVf0syI9uEUvto83CavLNYORWJkm3GXEOc5OMlSxpEfB9If04ngaAS+EAHozBV4hGE3uaa7BJTdmQ217phBRzBAJB7QhWeC3pBVi7PMaQ43pzc6v6iQ+rxmsjSy+QBpGzUGyMwcHwQUFBhLDk7CJ1q8Zifc0lpc2rmmuvVWdJEAA0wHMXebhzPu8e+VzjoIgFFXtKQ3IqbHzra7HWn37U2+Iq0AIYzSZqtoGYIOFTx0HnkatGJZ184HpW77n03RK6zfVBu66cY95gQ0dSEZDmxQ7Y/k+uCn4zm+qUEv/AmHPFrFg103TwTWL1tbG9QXkaaxiQrAcJa9nBK9FdgtbaVVO0bpg4zKkggxMbExuB9UwBR6hQnsMJTnP4gAF+B0jyIrqRIGXOux+ZbPpGkxxnuGjZUohPAci3DQHl2e9fxKBvzIBg771/xbeyxWj1LwQl/ft3OuK6kAQBOCa7slczcWFhfP+T3rSY9RdDe7+2TBCfYIiDtLEIIOpcolvceHzO174JCIiIiIiojeyUxlZ5Y4j3/uVEUCiomN7lRFX539dD71XGXGl9D30XmUEQO9DP1dG+h/6uTLS/9A7lZH+T4+9ykj3Q98IfywlIiIiIjqgMiLNiyzHT4E9N+DqsMqI9/PoC27ODzPIq8BeHuAWP2BzUGXEVLlH6gB5itS5iBbUs3u4y6IBYq+MGZKHLQJoK3BIZaTNJGqJvawlDq7irEXd9wha0GW65Oai92orWoEhzV60+NJaJEsL4h1TGbGZrLShUgeZ/LDegCztZHYwJWHy19xc2VoMacvNSXC5xfdmwRiOqozYTHV9UDuIfkpTSbeTOcGMQ8vNJSBecnO5AGXLzSX1es/NHVQZaTOpg0RRIAX7gFoV6252tuCUkVpuLuXJw8WANvlsByPlS27umMqIiQ5ZvYpF+DwqXF1qxp1sycLotdhcY3CqS8Qq1aDLunoMNn8+HVwZka9f0fJD2C85ZI+N2AsPeqyMpPj6zTqtjLB/QvS7JPJ1PynDe6R6rdkhlrpOcIsW3/P/zl2dp3rZXkhE2ylr/8daKqrDqYicreu7cv1/rfoJPkA/VduW+i3k+eNjTm0Lmk5ti+D6vpxvolg5KGg75s6enT061yYMNUfVzxMw6aLa/yn9SN5vZCIiIiIiIiIiIiIiIiIi+gP/Aa4nDh7jJDGNAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding16/education.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYsAAADsCAMAAACyuHrvAAAAflBMVEUAAAAQEBAQEBAQEBAREREQEBAQEBAQEBAQEBAQEBAQEBAQEBAREREREREQEBAQEBAQEBAQEBASEhISEhIQEBD///8RERGAgIBqamohLz/h4eHExMQuLi5MTEx5eXnw8PAfHx/T09OXl5empqaIiIg+Pj6lpaW0tLRbW1u1tbWoPW7mAAAAFXRSTlMAIEAQ4GC/nzCAcJDvz6BQwLCAoND3jVzWAAAK8klEQVR42uzbSW7jMBCFYV+iygRZHDXYvv8Fm0qVoPSie9EWOrT9PiCBStNCP0QBAXIBAAAAAAAAAAAAAAAAAAAAAID/ZbnC+ZbLv7gSnO+KFsNAi3GgxTjQYhxoMQ60GMfntri7TGP52BazeBrMR7bwi9yk0mg+soWLTUZboN6rhQ+hHlP2nv6gOk/zSsN53RZJvCaQRN1j4U4mPRhiH4rbcyzLvhGpyyLB7tF0vyT6ea/bwrG1YNd/z1zSekvCibqJZb7dHFuuflSffWWnhznZPYqe0ff/vDdpUe2xe+Fp26Wfg8DRXhN79okrdVFiydYiosXJLWIfbIrHob4720ahjYie0xpPeo/GDS1ObZH3F0CrFJ3MsUhVbnalXeC4V/Jo8XyLNm0aO12DVOJQ9+mQv3YlzSdxS5a1hS8RLZ5vYb5azN/egGM6xKIRusArUeOmLfrWDS2ebhH8Jvz9vTCNA1Ve9cIphAdHa9EzZbQ47XuhX2y1cD6+Hk3qsUjZEuXZVGvR06HFeS1osUGrxJJ1unP+tkjJnbqJm+9uPFuLbVlDi/NarHynTRauRMGm/RFbAl2iouiZpewtsghanNeiTzKFMC362U4sj1rnIp52uXDJdrpdH/qPNUOL01p0c+GutP1DwV30v53v9gQWIGmLLqHFucK61mOqIQz4Z/FPaUFJ6KW9UwvH9NLeqcWrQ4txoMU40GIcaDEOtBjHFf8jNozlAgAAAAAAAAAAAAAAAADwi72zUW7bhgEwQIAUf01L2uFu7/+iAyg5TlwnTbell9v4tQ0p/kASPkqKG/U6mUz+TWL8sNcRTH4TvsYPRKAk+Bv8+SdMflkEb++rwMqrh/foteJ08a9Bq9u2D0x5TATvscWc/j8uaFmWkhGMbXGWnQWPDQJwSwfAlTlEUPwatNOIi9eOZbHRtJQxjWjJWikLjM2B66MoMIglBP8mdrTY+BD7fki2BzvGdEz6yEVZBgSupDF37WeVcvFg9AiAXokPCVDKyzAMCH7sH3Nxo8XTGeVrQRn4oxq0uIgDJQgCeEmAVcIq1rhLZasoThZAFm+jUSTZNES5ahcLjCgDn4SVKxhdhKs0+mlsg6MJGk1ox2eTPnLBMsAsf3CNGsWqVaRDE5Yw4iaALEr6MQGMXMNx/g12YWHCWqtkWwXiAFnbdvhSLH+UpZIdJgv96CLY8UQJurGSVtrpYqg4XVR8cGEIA0DSaCfEEgGKpIfY7sfYQNuYzSzrSFelj12c82zKDhjswK7Als/QJUMR59pwUCo8cJ5xlgjZdsHeSdFqvuhWqJDHGvFHFPhKjvyt0u3EbYd3F905S5zwqSZYKsGdazeYitNFk3C4aM65+uAiaxuC0se6IuG7C2lPY1tOrSXKHtQCCkv5pAsnuRSNRdUjJ4B6LSNQjuliLkIrwT9xYRPpwgRdsLPTzdSaqtOtFMTZ6dkQ+EpEWSCJtxOnGl65GKQhy1ojy+vzVvLNxXWTPlwMHlwYCQ4tVrDcXNxj49vYyxHYdpp1EspSxH3OhRdZ2daxOlSKeMsiSrJ+c1MvTfITF9BEpOjGCgpyRb6el7V9yVJolQW+EidXJEjS4SLZseDdhXduk0TH2l0tX3R+MBsucpV4c0HM6+264PeuC38okXq6eD/2MhodsPgswVxQ5c+62AFlhbBbPEu7uYgvLuxQKp8PmOsrF0VyLHYyXVty5QjcXrmgoJI1wFcyliaZAxYjPXleaAWZoYxD4Xqc9wpZmE4X5uanz4soAUid7SPPkDVcexObuL7k1Ox4GUTUhizy2XsUgFzR9tAto5C12sUfLmLSltZAySn5Vy4CgynzPB7WO2lLtS46XWCMTj19JSh1WViKZdc5J/yDCy/sezu+6Vl8kPRy3kHKzQWs77rYk0Kg7NJys5Ruwjmz4HuxeVnqWAURUZXhsbNPPrvZFfGZTa3tO6OEzoKHCxLr3uHk7XWBOrFpXxdOKfVNtl6v53pyUpAZvhQUpW5wKgjiHl3AdrvjI2ul3M8bq7ibC6rvuRggGMX2JdtZyfBebIUzHOGoVjx29jkXkUV24GTbBts+qofDBXjtDvTEBa12SHh8q2csVjKeLiwKR/htuARPoZzprEWCfwJFBO/PyoBc/HuxzcVzkDQqwR1Cetv9HBuG8W3Lw8bvIzM8JzB8P/57fwfyKQjh+/E/dTGZTCaTyWQymUwmk8lkMplMJpPfR5zvfH8bYgN49jOxEsbm4segxYFxNtxx2vGUJcPkV/H+7aac2xcGBWUZLriDMRoehz9FrjD5Ka5jjOAigBbgU0Igh84jKFRki+jAYfe31JOLOuAYYw2kxYC8Gy6idwBWdO2wYc5ckBaTD2nCXK9gy5uvUOSPKs5JExFLXa9Sy0WK+CCnC2RGJ/4cg8JaHJ50LGt1kyqMWvzB937hKjLvUx9xvgH14uKSoVueAzkpt5vORVqnm4u1MYJ7GYPCWiy3t3hUmk2MslDYrLB+LUAYsTaYfECRCHB34VYWS2eyK+DuwgHcXIgEAPcyRn+P+TCmm8hko5khlqXe+20If8fXSb4RF8EjVytAvZI015+4wLsL3iW/44KHi2wuWsPaupsufoUuJRZNVK1uk6vdWy4PLkp842IhrvjURZGMzTrWmHWWduTp4pcoIkETlbXgKzSRXcorF8SyvHUBTsJTF8QWysOm5Upja7r4NQhHogg//tjdM/wUpNclfsc33L496uKnlPlh7cuZK3gymUwmk8lkMplMJpPJZPIrzDej/jMQGgTgYoEfwDGEtEKPrTeIbl/w1kHx7tdZm+3hYSLdyrkAXoiXi1wuHcrugcpj5xWUzUEsyysVV7hjvQA5AYUEDINyc4HhkpoGrZdL0CJKvxkIgf2YHdoGkzcJp9yJ+jKWN0XUBocEPUc3VnP0Xpt0w+jlrJIfvcrqsHmVhNYcO8EBm5QWsVkdIWz5vMJ8BmILtWv/vDJe8MUWcN5DbGu33K2JEUNaWyyhrBka+DWzc3VPI2+lYyv7Di74NUE7kt4iQOeyrxBKYRj0FRQiK6lSTnHR8KbL4bEEkioO84cnL1y6/okAAmu01DFpJTigamnyye3IoGVOxzhttfRVcIglu11bsAZGlZQ1w9QBTxcpA4UQqLDdkjAAMdxwQ4Fr0cu8Ll5oEagBYAMGxRVtgjoeC9pcXM6+XS4XZ6ZWW9THQIayXpr2ar0H6kElEfTk2mVfX1yMuKEjqkdmvuWdQjlq/pLmC2x36sgXbP54JqcOdAUm2EpcLb+rS0mdAMdjwWurFnnvOxCrnTPpwQ11PURQP3isfdC4O1RQos1dIw0HIZoQgqCKPExOnBkI67pDrGmkyy6NzKF1nwGa/ophCR5bWJqluCfIbQnoeFk5NlCCs8Qf6nILYXcNjE2HhByHY7a5xa/ZQnAIIZYC2xp2mLwFCV4THQDfmyiRKcCHDxXZikesjyjd//XGc+bHi89CbQ35lak87l2PbATvMP9Di3+TmczJZDKZTCaTyWQymUz+au+ObQAGYQAI7r91apQGUT3mbgTLpeUHAGA2LfUMLfUILfUMLXUtdS11LXUtdS11LfWFlrqWupb6SktdS11L/UdLXUtdS32DlvoDtNQBAAAAAHiRj8EdWuodWuontNSn0VLP0FLv0FLv0FLv0FIP0VIP0VJP0VLvsMEAAAAA7HIZNYaWeoeWeomWeoeWeoeWeoeWeoeWeoaWeo2WepaWeolhAgAAANf5AJcf/3T/AU2mAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding16/experience.png": "https://static.topcv.vn/cv-builder/assets/experience.3e92322e.png",
        "../assets/images/template_cv/outstanding16/info.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAMAAACahl6sAAAAn1BMVEUAAAAAAAAQEBAPDw8QEBAQEBAQEBAQEBAREREODg4REREQEBAQEBAQEBAQEBAQEBARERFubm4AAAASEhJmZmYuLi5AQEAREREAAAASEhJjY2NGRkY5OTk5OTkSEhJiYmIAAABGRkb///8REREAAAC/v7+AgIDf398gICAQEBCQkJDv7++goKCvr69wcHBgYGAwMDBAQEBQUFDPz89/f3/fZsKUAAAAInRSTlMAgCAQwEBgoM9Q4LAwgHCQ7+BgkO+wgH9wgM+wkI9w0L+vzs9v4gAACelJREFUeNrs2Ytu0zAYhuEP+/c5ddIV2MqZOesY59P9Xxv+3azroIEhVZCAH2lrFteSXyXtLAVVVVVVVf3jXtybuhe4k3uYuns1ZGJqyNTUkKmpIb9JLDRumWuIaTuFfTMNUQEuYN/EQ/Q1qfRwpikhbQhRIHMOTGhZzptgtPhhcqMBMZx36m+E+Cx1+ZcwCUVaAFglMsF33OCTKwVJAYL4fOeb7yarRQJ0IjCiv3RriaSR7YecllPSpIZDOnkdQiVBWC+/m7wNSXFiISKtwKQnwLd+NYQ4fmc51gdD1p2YVkhMAsU6SfiFS2obYvz1lMNXBJYmEbIocojpsMUJfoHgZQmxhJ2DISrFKYRQwSEeW2obIrvV9tCA15uZwyFYdWICIbtbq725Ig2HICa1uyJCKWXHQqSnKYXwogvjUUJA3iWVAyWKbiwkT3UTCpGehpF2CBEdJbX7NotpNASrzk4nBCqRgoydl0MIYkqqFDQQp8mPh0ifJhQCYVNKXStRQhhxCLTP571bj4dAJZrSphFCNRIHNEpMctN4Z1Pf/d5ZDakhNeTnakgNqSF/2L3/7NFbVVVVVVVVVVXV3ybPHiw3m0cvTzBv7v7FeXG5nHXKU84YXDzEbD28PN9z+RQzdcLXY8+FwzwtefGbz292Jfcl5uiEb6y+7zc3l+QMY6S89YK9F3EzIMCGo5HB43vMa7/q+6ubS/IAI07JRl6RV8iIfATkKm6HdgPaQnZEEY0NVvDabSCR30ErCArUIFqiowc94qV/6vtP5ztLHCYI8IAMXvJ6+QE1lOm2i18AKAONNXC6lApoN7y2KvBk4+AMAnB85ZZ63fd8QQYbfEdrMGkbXk7bWGRKlDJ4Pm5bNQyIECOM4RVTjLJMB1ZaSigPh9wkrGkF2NFD3lz1738d0lDwDVaOa5gigRLTGJDEKQ+IIIPCSjVetNZFAnY3nik3XiSh1oIHjmx5zt7xp/3dx7flj0e4xRmyxgHwIh9H0iZIADK0kkdbSB91p3QZ8AvtHTLjSAEJWWOfAQpw3LlG4XFsD86Lr33/6ir/8PHjkSviJbRRWtu1AGAVWKshtV6TKwON1tE6Hbk6xwsLQJAEZIc8WRDPJAlHOLaz4f/h66s++5iPLk9GQqI3oSQgcx0RNQD/ALz0YUC1kDaEZxBkLA8aSxSwtnnyIh+SjN6QwLHJ+9d7kw+v+vJJWWKUwB0J+cPbpbh1eHzuZovy5SJ/d13MdgP85Pamcc7b3/1t/BPM2Mnycsi4P9et7y7l8fPNZvngbJ4b36qqqqqqqupn6vOR+nxkyurzkYlZDgH/xPORb+2c247TMBCGf82Mz6dKFeJwwQVsdwuUM+//bNixJZYlRUAraIU/abNtJrPKxFsn9RfncDs4HPEjzA9X4JdgpY5FKgDO70cGa35EaST3YJXBr/D4qdNCWGOrcgZwZj/yet/LePV2xY+w0ZCoCOBl0ZZZRwUQj7WEJUAAqL0fIf1chcdZxiaMSIhLQgQIRqES1Vgz4uokrbDfLZV8fLtf0Qp6Y2hjkmctySu1KUYQQrKOfV3CSRILCyRnHHRybasW8gjkeZsLOds2kRoIxasoKWgW2C4ckuVY47nFN6bGTymkSoUvdeC3+p41P2IRPSCsiI3Lpq2whJzV8lIITkiAEHOGkI2kzQglhRwDe4IS1KUQilLEj7MqbMe/qKMaYb/EY42f0mnV1nj/+u2n+mvFj6gAlwBPEownoxADCxBUcmCpUbjSNrBQRevojTE6a7BFyI4sFRLUUAzAcjy2wViVnSoAkgbQIiRRANvip/iR5fOxfOJX/EjOKG3vXQFZWEBnVUZbqGUvg0saWsBBEAXIFGINQW/N06cp9U10XvbYqgD2rfk0WrOCti3+OLvU4yf5kfc3g/crfkR7JQyXopiwiRYwvS3ggeSwleBJeyMF8A7YBjGwQNb1J+VsCFsRS0W13VaBbRAfLUJUFvVNzXkqYlDjvdYT/cjgp36EwHiIiyA7TjRkfjjnEPdN/LE/Qz3lfH5k8Lt+ZBjShSz0s03WuSA/Qhjwn5iu6UemH5lMJpPJZDKZ/OdMP3JZTD9yWfyiH+GL/87V/cibz69vd3c/8SPp0r8EVz9SObza3dy87oPxuydrkiMoRQCiAo4OordVlajw1xl+5O7mw7s6kL2/+bziR0hSSNiYZCPElO8G0UMfRC99EN0yjDJSRONvM/zI7vB2dzjsdofdylBjJNaFPOCK3gKa1wbRkwJgiEwfqMff57Ybq9oaN/vbm1crWiGLEe0S4FJ3M0cH0YszxBYoCn+d4UdGIWt+hAWwsRRAlFGg7ZFBdGLoZLCYEcbfZnRatcd6XU3o7vb1ih/xzWfItk1AiGIs9UF0e28QfanFKkRP6GbkH/CoO8T37/b7d5/2b1f8CAjMDyet0cWdWxY/8ubDq6rdDq8+LF3YdV5vdT/y5t3r/f7tlze907pOhh95c7dUMeePXALTj1wg049MJpPJZDKZTKYfuS6mH7ksjvuRK/Mkw4/cfvx0WJ8/wtTgXgMruRe5f+8rq5UkOnIYuKeuZJ7oR+72N5Xb1edrRWNeGuOApw4UrGIMVAC2BUJoGP0gaVOTLL4nRCxoAzxOo45g1Hn8SL8V+0OtZbf+fK0oAHMkQGUH8DiYKbMkwLIicG+aqL5LioEU+lpeltK2bXjOBb2VySkGcaRT/Uij3Ux+V53V+q3YukBZcRYuZK/7jfEV0VYD0Zcy7pNnKUbuJcH5YgxsMRbBJKv7bIzeJBYtyRWSZBJagE7UCo1X9wu5xQOMQ9oiBhJAp35jfGUjVgHOALbfJ68TkO8loTyvWewQ703U6IXQSwXYlkSRXWDPCPEMhVTx9rHOVrhbL8RGhAiXnDXGuOXgA4ielEefyRADIFHi/SQChEdWYPk2OaBCog2WJGoeKY9WPr3TuhtzFRae4QEbYNnjXIACuxzt3hQmj51NoA2CAiUmNLgmwbYsITwee9pnY/RDI9STPBBir5DO8Hyt21rHvjbImh9RAhJAmKwJGhL646aKBsh31aa8CdI9kJOR1Ls14SxBTPc/fmjubQKUaUkBNgTrZKlwE09/vtabffUj9ffP/QhHBkDHz5MEUFqJMXA0icAjXM7xfK27V+/q8gx+xOFPITrL/JG7F9OPXArTj1wg/4cfYR4dK/W3NNZxBK6q8qIBeIYqaLgNA8WBQmAYwvUgEWALRN3rsgkQAmXHuKY6sCEiF2CLkV6XBzbQoq2OAddD3IiIz/1qvOJRXAzkAWdcwvWQCwBR2Zpg+hdcEp1aCTkXhevBOAAbttxf5QSIVa08T3JNvZYlIFpsQ7BbAEEB6uW4pLe4Qh5cjXO5ptb4CXxNn/PJZDKZTCaTya/xFRFeBMVmcF63AAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding16/interests.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAADiCAMAAADQxB3qAAAAeFBMVEUAAAAQEBAQEBAQEBAQEBAQEBAREREQEBAREREQEBAQEBAQEBAREREQEBAQEBAQEBARERERERESEhIQEBD///+AgIARERHi4uJqamqmpqbDw8OIiIjw8PBMTEwuLi6Xl5fS0tI+Pj5bW1u1tbVNTU3T09N5eXkgICCQe6N7AAAAFHRSTlMAIBDAQDDPUN9wkICfYK+gsO+AsAwu/RMAAAniSURBVHja7NnbasMwDIDhPYQi2fIxzun933D2knhh6+pdDKcM/VBwVJd+uIEW+iZJkiRJ0g+Nwws1/hI9wAs1CPpxghb0kwQt6CcJ+m/Rdpq4rnliWy/oLC+PKdkyP55fNOflZUC2E9pkMScDuZiMBTLzYTAucMLAq7cazW5GB6CQitCsBFarWAYMpbyrD9oEKHF+aE/He2vYq57vaBqPiQ/90b4CCcOxchib6NnDXqT+6M3B0Zwte4yuhZ5whVp3tENH1XO2oW2g8/xGNHlEVdgTpjocMTbQecd96Jze2RpVHc3IX9FJl8KJ9khXtNEl1Qdd2WNxXdDtk55uPemcTciEvl5vGzTv6XA3GixqcPUTj6haaEZ3Oxo8Z8d6Ijy10ODqUXN/dNgx4+WbMGRzE01+V9vQ/6StcnohNvaDpNRCi8kXbXR+pfdJpXDP7WE5fiojE7S6bpbf04IWtKAfJGhB92z4z39fSJIkSZIkvbNbB6sZg0AQgGd3TTRGa8wP8/6PWv2RUijtNRb8LkN2LxPYg8uyLD9IFkxFU0rxEPwlfABDTpiA8C3jd+5SYCjEBIQGPVgVcNmh0ewV3Rio7zG+CtsajxqlgYseiYG74mBl2NBE7jWohGoMUGNlROFOGh7GJuFkzjzgeQp3lXqh4Y6tuGwbCqWvI11pYRQ8y9FEcdIXKlDN8cAQWS0DPlmlGL9u+ny8tNAADZRCAWi+l/YO3ZZ3HjejuygvKiTLLKVrSoERjlEis9awOab3JvV7eVH6P2Xe8sFpSjf1BnCTjMAWSFOMgYkn684NseUxyXl8o6LoRDCIYIxHzscx49/R2Z4Yy7Isy7J8smO2K2/DMBg9kix/2+nbwu7/UhcnYWPrfqxjoxvsQGX1saSIBIzwf/42xgjOb0T9ZwOVF1G58sTL+Jp/rSI/9RDlCZfpT9IPw1Wi8hr1EyC5QjNlDEAqobIQey4nY1b9Tsry1HN7Sv1SLPRvOzAXXsNuAjUmvBZBAB1dS/IAmhKIBoHdKLC0EJ0wDi2waLcPDjwIqqCQhu+uBOBIvorhAcpYFpaoSBnKi+SWkP5wsdInEfB8Cw9rOUlss/DRW9blmgJ3axa595KDxLpvL9zg3ItaA347Ajzl2m+A7MXCqjCwXjOP3mICHs59iJXZeA2/jcImERPIasBys9CSi47qGUyjIBmQCOMWOrRhgg4WpQEsNYkpqZ0BteAGpCniLlraaFBWsVKAmiRjghivUZr30cQ0gluoABExeHixzVJqkI/dG1DK+tUEW8icLB+gjTOZGlbAIxz9A4xcudsWw8MBtStjjC1o3rat8Bp7WjRJTeLuj5I4uksVohhkOT63fsBRuhU0hy0hkQwlsIgKUAp79A3JugLy2T9QwdINdj2skFUcIG0dj1Cc14hKHmyJOGfj4YDn0hJi5NljOl/XPdtHADxO+yDlbk7ZfRYar2XmtJtpR4D4DUyBat2WnoNbj1ISagDySWAv0vhlRJ8lLi04alwa4OOH57V8MSpPB7twWp6f+2cQm3nwFf83bkj+X4n85z9/EgUQTuSnht33X/k+HDAO1HhilCfJ3n6URBD0HEBD9a+z5LXWcP1bW3rYuIR3oqazhKp5tkyzOhuQYjNdq7UYtVjLgVi7YXF3PdcaeSdpxkBLoUPGAqECpaoLqCkSJUPqGnA7J9bUIfJOWo4B85ZQI8PuAMPu14DsPTUItcRtVjcwP8f8d2ISKpmHE86eBLRBBrzDNkLdbYq6m3RsmLI77ySj2Y0I7eoJiNMqgM0Znducjb67tQbO2N35+1D9ul5W9S84nz+3by66bcMwFL0k9bbkRwr4/z91oqQm3bKtWNds2aADtLFpyrqWnYBpeSeTyWQymUwmk8lkMvnfsHd9m7485Tfwt5aRsHbt2aNDx4Jn5I1lxA9riDlfpcaIp+RqGenWkCHaFOrmkfpCho0fXQTmr/9l+mvLSLeGdNHhOE8De5zHGbGc4TwDcziPcD7H43K1jAxrSBfNdAhCIMjJSxWeT9s8I08i+moZgc9yDtEReDn53IFyluW09bjRC6InEX21jKQz2f0mWqroDMTTLCep6KQPzNOIHpaRZg0ZotU1IpDD2BB4iK7R5Vme6atlpFlDhmh3noFAroYshmgUkfgkou8cI2P79jIw2cL/a/4MDqc7/ro/7pcxxWIymUwmk8lk8k/ApDD9LOX9LtluXzA/Gk125DTY4jex23Zum3f4IZTxyl1WGjpKEmZxdH/6IstrI99mxiCL38ZK/dnJvG29u7XnMZj1FbhltT3jCRS4p5lcmKLnm7+k6ydPgdh6KI7aQN1jfp2P8SFKArq5w6XssMkS1uRKt3qszibjtRtPM2tCxiUvjuAuMUBC1Kndsh7kpayxt/fVfBEAmipCdVTSSzvWRZjaJD6MM8mOD7F5oJk72MM6OMJLQVTRYsEHRNdbk5AKbLOLxMiebaivqAQCtx4y0w4GPYVX0S11YQu/696uA7eo501RzyRt4g/hLHrXmndb3tnVyOhAPXSx4VjWLVA3PZS4eJ3bypYEL6aLGddSUmvvszt6T2Ly+hP3bY1Xt4ljFd3mW2J7zj/E8WpOEYtLNBksGqgExiWZ3SdQ23c6SYzgQI5wWXqWlRpeSjOZtPY+qoHV93tIgY4h7aUNFLqaSeLS3hQfQW9SN3dEWSXHApNUdyUGcT5Glrwe1O+2Y3arK61jLyPUCDioGaSG19jb+5Ckf5CYGnOaKgVATqtENNNIn4+D1MO/xX3rnTVtsSv0VZxQMf4WI93iC6PjrS6mwjTyue+Okw1i+xD4ZEh0ae74kWkkXQ/JGizeJ0oWwqfDn+svecKW98nkl2DGY7H+PkTvvtfoZynsBY/FlvtCar1Lit9UqXSXgguhQ3n1eBTW6IoxWy0xbyF4Y/F1qckpMgNtU9oB6wnM9k2ZSY5Gjtdigx/iLmGXcqt8fOrmZYBuFaiWmg6+OZgBf+w+dxuvCTkLUs3B4tRnknNubhMJS4l6I8panH+QuyRp7QXHSN4SxwT1LtRQr0D1t4P0UlM32eFSun+ZBR40fCalJu5eLyxha+4MA1qNhgWfjvAwyYpVv7Fv0iq9Am2lptmbFrQ1dhSGecpku+55+Ew2M75UJa/jS2SRdPBj3CU6u41VFh20j/oosD6Po5C8lZpd+UuTpsJi2SzK8JmktujDcw4EsywgB9FT4dMxWiqaI+/CYc3BtIo0r9Qr0DBKzTWQig51O6PC3Vfuslu7z4Sc7HsTLdBSlUvI6aCHuUvoTQ3JX1eUt1LTYbDSd2vZCH3WB334X7KY3Jeadl3wXZLIs/27jt4vJnmWmZPJZDKZTCaTyWQymUwmk8lkMplMJpPJ5E/xBdi87PVBS0/iAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding16/name.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADZCAMAAABSDI+SAAAAP1BMVEUAAAAQEBAQEBAQEBAQEBAQEBAQEBAREREQEBAREREREREQEBAQEBAQEBAREREQEBAQEBAQEBASEhIQEBARERFMmqDDAAAAFHRSTlMAvyBgQJ+A3xDv4HAwUM+QsI+Qfb6urwMAAAdpSURBVHja7JvZcuIwEEW1L/HKzP3/bx0MFlcWJE7FrolN6TwQealOH2jLptSISqVSqVQqlUqlUqlUKt/kIqVU4g0IHhjFO6A8YMQ7oDy8eAvaCCfegtY1orI/Rr5ACXF97QR52qGu21ZkDOWMrKW8pCMXUZy6f1VqvEAJAUAL8rTD4YrJRQFIkeHStkyD7FR7GBGPK0MhAv17IkHNfABjGotVEQP0QAyFSAy/JUI+sujrIhbQEmgKEYwnE1FADA0gF9n1AMy5RPR0cljkLQE3Aj6cSsTfFCQwLERCBC5nEjG4PWh1QAy5iGgAmBOJ2Pu5IQJdLnJ79eE0IpNAOw0GQC5F1FRcRxORNicT0UCfSgxhIcLiWohEm+P/r0gJReRjGAGXiaRpuBQpOYiIAqDuwwGIhYia5I4lMpgciljWvAFgcpG5uNpCpDc5/UEudg/0diYCkiKPkTzUxf6JiEZBKERaAM0JRCQKXCEyKUR1eBEFoDEPJOApMtMD8vAiA+CLL2amFDGT7NFFfEqYd3lLkZk/QLTHFul4E+GtJJQiwQM4tghvInkZUWTGHF1Epf0kAjKJkD8HF9HpvkEcAPMkEvyxRTzPyqtoSCLErIhUKpVKpVKpVCqVSqVSqexBaJxW08BKcWaUxxWp2wvOLWLxITFx8l7OgP76oiUQz903GHR7H7xDt3NrTCveAHX66+NO8PAePoizcwGMAS7i5GjA3RZLOnFqgvzopz/9R/87xaVMd4a5hk3UbI3WmcXgcSNaw722bJ9upByFaFMw0slbOOWfsKn3uxEZ4ce/qsEVhirW/8IFGb0qVrSIvS+4jwzGhkevriJ4QqaV+RiKCfrnIlG9FlE9cG8UG++jdkUkxCKvvwC0+FoE424iGEsRPq1KM29YGr8WSW1Nl2VaNg2cXtA9RGB2E0H3SsTiMUxJyhURIcv+X69SfkYsoYgP+4hI1kMuoumRrT2viKjIvG4RtFgRiRG47CPSMVQu4m/Jla0mKyKiwaI0rVgT8ZrHNoqYjqEo8uj3IwPgV0TuxaXSzqjWRdgfvFmEoSjC3IgyxqyKqAjIlFMj1kXYH7xdhKEo8knX5FciLK6Gpbkqwv7g7SIMRREAzY9ExH3yaJjSmggrYqMIQ1Gk5b/+vgiLa1T+Hoci0ec0FGF/8FYRhqKIAdCKGUfUlyKcp/vFHoUSRxH2B+8gwlAUYUQQ87kI6TGhvifCrqHtIuxj30ekZaoU6VROoAj7g7eLpOKiiMofXPSMXxd56pNfv9jZH7xZhKE4a928Cvrvijhur4owttwswlAUYa8biV+IyA0ibOzcKsI6TSK8+onJGpRHkSM3ibA/WG0WYXElkRCZLd93GF4CGREYtooED8jNIgyVRIQrnxpbpJN1dihtdxtE+IG7rSIMFQH30Iptubxh0qfl1eKIFxtEWFzYLMJQ/O1HTOOJJgL5j7/g2/yrvdtBJPjdRIKfRWjirTZGD9NwGPJHS0C6znTNbdiLVZGShwgxu4gwlMtrhjjRPU4OFjlj2CJC/uwhwlCOm/of++ai2zYMQ1GK1DN6ud39/2/dKAlZ43QPDMm2FjpAEAqmpBxbMgyEblgYSxTfJIvB20OPEYlpiDwFrr53XyPdEW32rnv5DP9AbTabzWaz2Ww2m81ms9lsNpvNZ4TFrkhEW4WUUqlKpBkL0x1VlFrox1iJ9BcRuBUBRBaelHbQBUwDD6E7LpgESz/CgemvcRZhVzVkyC9F5Bv5+EmZuLh/eEUWgvhLERpkpP/kHYRbkbVHjKFbkerrSM7xJEJm1Q/2o1tSuB+m83WPsHedWUNfY3bH2jjWHZ3nkCTOPmmPMOQkwimx5gY6i1SYUa+cLmmMVFJqDcmuPVITEnDAEsE0XK4FPOmyKmDCF0CeJCLgkwhlGOIAvhNhlcvQ/fCqnZsaczJThFOwOsIQQYvETcMX9EhsdGCTkuf4JBFj6CxCBtnB00lkdQtBo5gSEUZY/RTp82SbIaKKJMjEaCMfZoz7tNtvRL4TWTWk9yIRiSwMKweYDJrMjm60ooZ5Lq2hCE8VnZWWSDMeLpKWiIBPIvML/I5IgaEKLAqxAdA6T5GVJleRMYMHFipCj6HgmEFEWyJH03YD08Chrvrsl3dEBJ0ERibaheUICHGKpPdFnEweKBKR1g0RxxJJXtsdmQYNZdyXeoC9E4kB5XoyiqVoh/4r5O3ScjciKr/yHyhCBn79IpnTVJQ5Y+C5vsNs6SeeRKIbKzMlTeUQqKDPTnWIePhx4FYkpnHyGO6RIiXBifiAtqZxYRkiZJHxELLuvK94+S7ivnEkNJ6ylmvQTINc2Ia1tGKAqzmkGxHNPyznkPiRIlQClCOuaYKjQXz9/ljo0OdVs1eRQfORlKxjpHytYgmFVGS9RtPzSYT8SnqgiFKq1Ej3RCtS6LeIVewawsoMF5EjeVi6hat8qDdexaxSyP/kyfKPsWiF+AWdPjoeyvHRL8jcDLscarPZbL62B4cEAAAAAIL+v3aEFQAAAAAAAAAAAABgCU+qxhDnn6vkAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding16/objective.png": "https://static.topcv.vn/cv-builder/assets/objective.147eaa13.png",
        "../assets/images/template_cv/outstanding16/project.png": "https://static.topcv.vn/cv-builder/assets/project.b7f08261.png",
        "../assets/images/template_cv/outstanding16/reference.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANUAAADiCAMAAADu4XKkAAAAhFBMVEUAAAAQEBAQEBAQEBAQEBAREREQEBAREREQEBAQEBAQEBAQEBAQEBAQEBASEhIREREREREQEBASEhIREREQEBD///+AgIARERGmpqbi4uKIiIjw8PDExMRqamovLy9NTU2lpaWXl5d5eXlMTEw+Pj7S0tK1tbUuLi4fHx9bW1vT09OWlpbrzMnJAAAAFXRSTlMAIBDAQM9g36AwkHCAUJ/vsK+A4LDrUAjeAAALPklEQVR42uyZ7XbaMAyGdxNCliUH5zuB+7+/RVGIQ0s3KNnZcubnR+W8NrYe0pyWw49MJpPJZDKZP0xzOhLNk1YnOBKnbHUYstVxyFbHIVsdh2y1wkTL4FalE7aALVkqX5xcppqmjEu3xEQpSQutLPAtsUqU5javp/fvVYOlbVXrTwmTEoVAAA6drQiiXXhPwLGeM29Tc1y1ABafke4T3cNrCWOUBqUL9fpSwQBQoC6pRLqqFr2a4eZ9KzcMBMqo7fY2jgUnq2rKqPDmPvitFTUW81TVKiXUh2SlnK3nB1YW2JV1soPVFRs7D6DDCIZsjvM8nViDEbHcWJ17MKg1q5QIVt+18jtYQcBKB+W075DydNxUStU1hoHX1pwqLpjVJqmR/6YV9yjzQLD+wqpBvsUB3draiPLB6pySCstvWpV7WIFgwTpwGL6wQlxjj35trUH6YFWkRHd71oovvLFyu1jBVY9w2vBjK8LioVXxyQqRf2cVolKtVhpcw+5WEzXGdK94OhTD1ooRf2UlMY4on+9V9dJv4P5WNAx091zNVuW6YtOs9p+eq251Nat6+1zF16yam1W3gxXPG6H+2RyQt1Z+tfJqaBR9ai1idW9liXHu6TWrEWk3q5KWd9arW5Ws+HbnIgD3BS+KKKk1aAa6s9KELRG8wmtWHk2H5H0r386Fe/unIdoVehUVHbe6gHrzpSKm1jRuTMIPrVppUi8LPbxkxcDLZh7etwqd1bacmxmDEJVBrNXgXCnWZah0YmzX1oxYuwuJ9wxmNU3WHZELAs9a6SFB3wSqi9KVnt63SvBSWyGGNNaymfgMS0v3CUnL8Dq2F+fPV9nqnyJbHYdsdRyy1XE4/dffoGYymUwmk8lkfrJPhjuugkAUPjMMDKCW1t7kvP+bXrR32fam+2cTs8nGLxKB4xA+0ZOTk5OfpzKHgt9GkpTwLTQZDiZnfRqk1whAyvplpeCJNRdgymPDvV/wTM0AlmzA2hSHYuSMATOe2KNMwVvWW436slKA0HVIefWX0jsBzEyb4IJDyWwNgIkl2ayevw6yycPKFrGCfqGYmGLrap/cOqOicrrRsOW6ty0Q2597tdK0KABJPTkCbWGlQegkDQyNnIZVbGG3irw7c0+BuxsnGGdxNiYwjgp1sgIzBYkm3gK9j5x0fViZWWbCykYv/RadEw4gMRnrZqXGjH4TXodVN06ZsnBGGlbaVSsluyA0pYswfixGGVYpFGTKzAkXlofVThLeIC3gkqEMOIDAObWmwgz0thndw6eVertSZhZgWKFSPaC1EJzlMffmrLDUW9trt9E4qwvTwgT8IWTK8RAr4c40rPKrFYykTFwg/6yaw5iZesc6+mRVWZ22W020idWulA/Hp/8qbVaBcE/lEKu1C4kx/GcV/MMKlZRCn2OPWrOVDkRSUdsil4BPK6NvTTcdp2WK+lsrbbEYL8IblkOsvCmAwPJqdeew0kbBEuLUo4kM0YGVF0CvZCufVpsCcGMVZ7vRrMeB9sYKi5NBUMnQIn6KkhOEM6CCjmUasI/eI/qIFV8hMhb4MTQytji2QAb8CiyVlxd9cnJycnJycnLyl/16WY0cBqIw/FeVSldbbTeGvP+bjoTDkFnMIpt0B/RhLOmgzQEh0LL8EBURQJRB+CR8VZRfph75SKIfDXh+KDfni7jxl2z8BlagtnBkkGRMJZSDACKRQXYB1SCAtk2ROZU7KAH0/hRkxu/w+HoAOW67Q94PQK12b2JgvQJP21IIqXcDwuMoI/Ci6dxc5l4TB1NKRtKMEy9XHmZeseJIjw2oDSzsFZwpoDm0DXUGV3GIW+gQ27NBw3lGkIMcZuy8XOsiQOISkysArmBad8LBIHbmpFchdAantdmq7dCiFQYXu4c+IvQNWuWdoRg1NxJ3q+JYYQRDbIjjswPMpm2DJFdEx79QGrlGBCwLs33l5VwY9kpLiDHElI/O5acHhpCyPcTgKsxV1HSeDbczRYJlF2onOOTOZ/t3pMoQAzcVlH+IooYwvcOF9w2x8H9vccyWZVmWZVmWZVn+sG9fu27DMACGfw5tSx4nQN//TVuP7uK0N2lawB8SQyIVKHTuaOVfU1wAivAOLa5XS3QnO+Ub6g6qnJdrIKACFzmTf4OEOqUGW838wBtcYqqTlaslCuQ8L7nxVQt1JIkZyBHaBJgvMK0OFcA/+JV4vlRAZ+heuHqZ6iqA5qYKAkgS8OVqibJLerU4db9GU9imYiAJ6BniUEVjE9wUaOsKD6e4nJ9S50niABDGmIKWUGsghskM6HNuGQnX7Qfhw9dxQEIddvxIg1AAVU1gAohBkqnrug2TYJ29oKAE3fadeqqrjbHwHDV+KW6LfUBSU/oCENBwFmHl25boro8jE+TR4Y2Z0xtxsEvEyqPUuMeyAwRtkwY6YqU22qAsPEeOgJTqMPXqiPkCscGxZ5KzPgFc4xBRDrXxBgQNQDqr6kqQJFd5JgRC/oSggAY09UXWpc6YUp3YeI5oQOi1o0lM6VMxSA7ECWwVgK2CJMkdLua8KcVkhjYwh5Ig14nDY0TEmJXeCQC+wBbaFCkLAYKSnSepKaeG2BoiBtWpFpICMTl1sNPFcoqEApd5z+dVuoVsgqQ1B4GWlEMN0Cub5VU1VWBqIB/cU15CWbgKexb94YFcV8S4mHBS4WcCk18ZEX4lOj9QRfjr+tFlPvga+Q1T3hX/mb/HCFz+uyent9vtdrvdbrfb7T8hXoCzaSkHDqrs9MtQ2F3Rr2HeX/Yam02joikvaWPLIeTMrq2hgdYJqoUNCYsVkFQAxp4zh2BWQUeE1VKjpCUIlKSAhs5rzMCb+AI6KzwcVSCuaMCX2ekDZkyIE9MyA9TZacuslAHQx1yIA51JwhSpFgBGEl4jNblaJZhDUKyf46s1RhEkIOgaoRiwtQBogLbmCJDAPy8zAR9A9cSLSA0mmJ+VaOI0n28NACV0cLOrnbZNR9gHVC/mV614KNAtX3dpi2XhNbpCW5gBSeALp308rnk1QRSCQO70EDcr5ze/6owVtA6lKLwpWCGGWFfhJcwhLhJAQ4OpoQqQlOzHnByBGo8YQSkxrlXgUSj1qJPaITjHRAMwg8dom/ASxdZ1lZ4sWDyLrBWgBZuAhyOzmbmE1RpoAo6CYAaW9VgWBN+XlWI5dSjGzpRXEeFXVPme6O+W/Y+HO2+32+12u91ut9vt9i6VT5TvCKrX6I9Pg/6aILxCXXLOzneMR+EQ3mtOcZI1et34FVkIvIIVAFHfXyD7RQlXz9m+CRbnHKqCaKx6Jkw3izVCcRRVR1332T4RA1B3zsiVF57rg4goadS0Tkk3m1LxqsajAT6PsbAHXUI9h6a1I+Zp8SPRY20ya2YdY508jdXWYdQxBWrvFdg/267jop/y655/qjKbWSwBkmI4uvrUvXKYGmoSoFctdPMF+nmMEFNJe6K5wZAaB5i3ig/U6MiMSe2ACRr3fI1t4AsEnirW49rOvWQddcbK1OHqkHltDfrUlrxOUwMwqJ3EkajejK1VyQ6mj0KLeC2WqxEwARLAnq89O63hg6fKHeDzXh/bt4PVCmEgCsNnMo4xRm3y/i9bQyy9my5b6OX/FoNyBDkLN4O5h7ny3ebZdUrHuR5SlI/x1J2n3ZosW2kagRf12tZ9L9v5HG0fxU6/x17a/ECztC7bIvM08mUU/1UR7m5f71rytuXiCh2XNBrKyzyi7r17TdFjvUcPlVxnIDuOda+y8NaSaxarscV11tLkp2p0l3nPJcWT6y8lU/phlWkakc3L72BII6tzbf0SpZeb/7oA3d0vvZ/En58AAAAAAAAAAAAAAAAAAAB4B586knXmGl0sFAAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/outstanding16/skillgroup.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMMAAADiCAMAAADEUYMLAAAAh1BMVEUAAAAQEBAQEBAQEBAQEBAQEBAQEBAREREREREQEBAQEBAQEBAQEBAQEBAQEBAQEBAREREQEBAREREQEBARERERERH///8RERGAgIDh4eEvLy9MTEzw8PBqamrDw8PExMQgICCIiIguLi6mpqY+Pj7S0tJ5eXlbW1u1tbWXl5elpaWWlpbT09PGIR5fAAAAFnRSTlMAIBBAvzCAz9+fcFBgkKCv78CwsOCQYEfPoAAADTJJREFUeNrsmd2S2yAMhfsUOSsEGGP8l+T9n69YKHYyqWd2WrfrtpyLdYQMOR8S7Ozst6qqqqqqqqq/SunjvEqfZPi4nFcfleEUqgznUGU4h45kmDr7y35oyj86+iqGO9rP2RxdY9MOrg2dbaL9KgaTET6jdHNxH7dPgfs/2UuWaPvcvyT2t3J5j36qz8geztAwgOBII5MeidnkhOnWF9kVDymRM76MOTNpMpHOL5swmFbj8aIDsittAJC6Yxk6xHaaHAwVUwEPe+Crvya4tctYEEykCwVjZfKaNeDiGV7jYEuMWZeTyXBXf4toj2QglKPnwSVsQzHT6vcM6FYGRciPm2StBCUZMCtDgbs9YgRaGRilbCP8gQwO6oJh5buphS329Exg3BgUIYsDLZzXrUh5ZGPgpGVrZFOUoYF7LOoOZAj8Eia+eNniSe2plKEPUZF7cC4aPyUp8MpAuGbAXuKuVMRBN0xEdBxDj+E1zM45SCv5d4Y+aC+UF0bQM2D2qgxiltAWhrygLQwcjr5btdRvnSX2B9AbQwxRzrLIxiBzNwbxmhk0klAYKIyFwRg5YZw1/rY6GG6aZsK4gPRvDEj2lnMqj/jaaOJVGCYMeR0HXxjyYtMTw+yci+Y4Bru29Gz6fKKLgs0fO00wr3WQlpg1JLhXBqmgMIwoYmW4pGAdlvFHFcfjGLTgWbI+R1o0Y97g6Plekhbqdxiykpngl4ysw7DCIOVeGOa1+8yRDF4tNnCrKxs4M+nFNMhzs+lh7C6DB2eGDl7XboVBKhSRHzGQXghHMahHM93v7XJpuscZWDqZIlxDzYhhs6kThh0GSeap66+WEB4MNmJhoBiGO02Mo86D6haRxZR9pLU42SY5ZIX22aaIcd1hEK9+u+uGJejKksKgiybfHcag6r23Pxq33vc5cZx0Uap/i17Oq8pwDlWGc6gynEP/E8O/8L+sqqqqqqqqqqrv7FgJktQwDJTkS7GdY67y/39KWzEQjqFYYNiiSNeOFUttWW2lZr174sSJEyf+JcyTQaZ8cJaJ6UfIDj/fS/Y4rP97uDcD368HZ2yOfgRO9+m7yfRjAk9/Fa5NfQwUglT3UYMrTCR5ikywFbNuHRtTSieyg5+G3/h3RQabV+6jmJcwYtELMTS0CyrYWsu7htSaCmm7ty1Q2TYY+BnU0GbeNt88LU0bjKVIWFrovsETibVtMHVk8e2uWHjACzVszJvuGiI9WqlQxKhSVXizYv1GuXH2TKlBQ0Z9bCk6I+HFtAy3xljuanvA1IJk7q9puBClocFRbXVpob8fAUUM5OZ86q+Yb10DmENDJEzlrgRVtCFRabk2B1MjDP1NDf6oYe4atsRtRk2FAGlry6g2Bv+NhtsnDfcEl2mAqbkV4nfT4NoaHhCgWzAS4BuK9huLfqlBg9sSDQ1zy7w2HhqkaUzvpgG2NS/ECsPjZUp9aJs2OWpYtSl/1CATCJWGBio+ZezxXpDozDJ/6Wb56hiifME4zniqZK/jO4Fb/blWRnqO1NKmTO8Glj9AczXQiRMnTpw4ceLEiRO/B3bh6yu/POPKPoZP8wOT6SnCNwmZ6Q8i+jg9YDl+9t3Ck//u+V1ukuGqmXbMQkrPwNM3nnkV+nPY8LmzsJMQHAEYfT85YYF3dwgMQ4CKYzgK0x5bSmCrSZkvO7liFCwxGF1AtyzAsOywAUtgo8h4H9g6HOjN0MwY50JO17r3xV8oCcVSdJ4milP01x7QhdM8a3eo1NRjaY3a9/QaO/mKWE2OEfOjxymUFNWxHy4/IUOGq5BiMbOPawpjXykzUaI3g+fkub8kORPg0Pc8SyK45kzh6i5QiBAeqSCoVIgTLxUOUaGb29+pTr6QI/YOMUrSu4N8wbE8SnflTnzgE1Swjy0O2Fg2Au/Suf0or/RWFEHyKylZMdYQysVZsV6oxIitl491osQLr9dZUSMcoPUHIxi5xzastNPEnAC/LikYi0YmnDZKdXbmGyElfDEbl+0o3wiPpPWKE2QV01BJlJGx4oXC1OWI0LHO2M9qxEC21icxR0EzOPVZuXbVqHKtE7Edh8t7En506UtFHrkQUkfQCNvIoytSR29F8Ou6sui6JpuzX9NGVScfA+rwIur30C2xFV50mtLegVsgPABp3ckZsa2PK8Pbs2bBBsoFCdm2mxLTY/WRPBbPlNWn0rlpTZV0nTb6BTB/+duBx7fHQLbzPEKE+GmyajH+OBWbyNE1UgBjH5XP3Ex/DqXQQPZ2gj+Lmd4EtN0f617oNZDj5B/LfuLEfweR8cUqX3vNMvDtxXlYiz2FLT4kfBnsF/2iRHU6ekvcbU7LshT6Cjrq2pYlRXoKf12uOmp/uJEQ9o+DE/GaiJTFhd6NIOI4jrpvzjj2ExztQ7iQwcHKZr5BEbGJSOBxq78WYmdB7k72jl4ApVo9lSmkuGa6TUvBwyYjGJiFksQodnmOU0zyqUmwrD2g5Jmbo8SPTqjed6kJnOTs/i1pv6ZHXegFwP50E8/KJEoYvT0YePPeZ8p+tntldivzUmY3mpS819AD17CEvNYajRBmE1lscb9Kwz+LCi0uYPYCpFqRfOL+YiS52P3941ZltwVt8fvfKcuyBH9oElGf3UIsHu3keO2EZIQ5I7xrj7nul8Qa6RW4e2yXnCTsN7uZwkq0ZOK9DALY54gyKeScQSJv3zKjWT3AStXXkiLlShIpWQCqxwunfAv7NR0tfAV8RF0XfNB5iYXosa7qnFoswVk8i4rzU4JdfUWTPGjWsE+36aLklIkTCG6ywGZjX5Khar+mL6C+EiKHB/m26WyDkR58DDyf0FjyPnAf2jkX3bZhGIpeUtRbtpM0gf7/T2fS2itLBqzDtmzTAYICfESkVbdMoGvGc9hhMplMJpPJZDKZTCaTyeSPwzkACJmfeBseILFseB2o9wZIp8fe6/LIWlxwwMt8Q0O9n9h64Fbh6JOQzAWr01uQU6e52BE3h/311l+lCeqp37QHTiouCSj91JNH6NdTr0PHs+6eLqYZi72pkXqMmfAaUM+37kTVOwW3HqhHk4mFAN/Dxx560zb1x+1jD/IqHVgPfEpWIIN6cL1ozeRzOn3Rg9mkA+7oQV8vgxZTVDCqQjLXg+/FZGIpVX/fw25Ge9EeTDHmegqpBz6pTOzMfUO476F12UMa9+huL9cDnTqhiZQe4A8hWe499+3rHlA0xCRnyyv18AmXPWpvn85tesI9dQ8p3QH8OvfzV3DqsQs+861EmvaQl7z+TyVg1U2V2GQymUwmk8n/gv8bTmR7R4+lYWpydcETmJ82yf5HTw0xGO+G4hJSAF/wNRmsSqDc8IzVwagV9yxPegj5SRP5IoR3Y7qqEzGDnf+s3vCRmbU+BrP3MMzHzcEiIznbqUAa4r4I8VXjzDtcQ6DmHH+OJY3QMAIxdivhfbSMHVOSSUhVZWFRDRJLKZCQE97s5OtOziHCS9ty9gCftiCMGErCIouFaHqGScuCBJP2hN0V9tQsC5mjmAGgpDKzKkEixKNJ9ngfSwOJbBByxKGtBeMYaMObKwW4sp18He1WFoI7Y5xJLIUr+4TdWLUuk5BxhY+UANs+qXCLpq5VvZHe1AAMoZpmnpHsN/Od2KogfZehARs9vHlExHWHLhZgq1jltrrWry8v63KotCqAK3ZaXPOlLjhIQLBjvUIRQOQIlAZLoLO9XfBndeC9NNHqFq/vRhFCoISdCD7jynC1ChA+LppbHk3irYATJUIYCi5AE2pR4VXTS72xdq/xmnrSMv2Zz3aBYDuweAGiq0HXfj+3lGWrNXDctuSP06o7KavwK+aNw7bJgh2SnLzpxaBsNzu5untzK0Miaaqysm3xpo4yTvAnUJLLBU29bsgpx97dRBK73ZHxEzAxlDsNmOHJJHL8leyMMTA7saUNmA47D++gjK0k3FEJdLbYX0rET6NXW/AIJ1t80S/cvuH5hf5bOpj8f3j6KydzJoVtePP5Owf/6WGKW+7iDfxe/Lr2da0ClBxwD6Xw7Z9Yt66ndXUPJ/Owxriu+N348T+mVv95UGYe09QFhyqMz+wIA/cphcA4UvxIeatqIgbo7skNv5C22ESQl5D4mKFVRlasvYyEQxXmTjkLBiUANpkvCW85xMo6VTcokSB5NaH9kUnRntzwS1krsLh20+WF0EILQHTYSYQrHw9vCEGLGrw5YHWtaEoklB3gqJMTcKJjoDsy1wru+KXY2sKiqjBEbUf8mITL9Xo9eZcxNEkLBuqNiJqija2WkqC4C2ySBkLVhKh2OuPXctKicCVQdTZDr+7QGOquYCmmCjuKYsK41mqyydzq1I1pR52hoAYtmhOVL57c8Cux+9NfxtRsM7QX2bLd0Ha3mCqMbOqvR53a6pjMR51eolid2s3ioBN6GntXkkjFb4EIB1zsHnkEtScpFVjd41HOO7uvfjM3kYyHVDzhsknAY9g+DP12mN+RMp/cMJlMJpPJZDKZTCaTyWQymUwmk8lkMplMJpN/ig9rs2ulcB4qBwAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/outstanding16/thumbnail.png": "https://static.topcv.vn/cv-builder/assets/thumbnail.5428997a.png",
        "../assets/images/template_cv/outstanding17/activity.png": "https://static.topcv.vn/cv-builder/assets/activity.678f68cc.png",
        "../assets/images/template_cv/outstanding17/additional_info.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKoAAABtCAYAAAAxm/qOAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAnJSURBVHgB7Z2/UxtJFscb8aNc5XKtLrIBV6ENL1oMps4bncguWxy46jJEdpnFX4D4C4DoQotsM+RwI4uMLWwjss0YJ7DZau0EGwP7/Q7dcqsZCQlLsqT9fqqmZtTT86an583r1yO9p5Fnz55dGiH6nJQRYgCQooqBQIoqBgIpqhgIpKhCCCGEEEIIIYQQQgghhBBCCCGEEKLjjJgeMQuwSlcqlbIRXQPdnMGKC7q6UjVDQk9+PYXOy46Ojh5geTU3N5c3oitQSVOp1Cv2M5YNM0SMmi5jO29nZGSET/c21mvT09O7x8fHkREdZWpq6gD9y81tLP+bnJw0Jycnu2YI6LpFxZNdQOcdjo+PL56fnxdQ9PLy8lJWtcNgpMph9Q7L6ps3b/Lo83VsLy4sLMyaIWDE+Y431Iuw0CLGF53kZ3pyIuyPvHKWZc2Xc0RhHVsv2wHZ1SsR9bIDWWl3Hc1gO8LzesdWeZIE2dkvh1/3D739TU9tz5lJOo/fftdXLch17c/6xyXhXXNf+bhj1pfJNqsEC7h+cXFRpu+D7QhF34d1MLyX8BTPYP8KPhZZZv3RNZRfexCwb/Pt27er3KZ7QNncnp+fz8EibPt1XRtvIzuhnUs45oVpfr0RrzE8r3dsFW1+FDw0tWvAyMH+qbvJ/v5mQP4izpfD5rK91pWgyqwnJx7nb5LL+4dVwdVD/6yifzbDeraNB64dWJVNnzCG5RAXEl8wGvedsU8rynzfJjJtwqEI8jacLGxHdhcV6yd8zqPOn+iwQnDoJjpst5lV/ArZvMaqf234/IM9LkL5O1sWmeakcUOpsIumDYLzzhhrNVF+6MrxMPCzuQ1WTpIVjPwPnCegj4uhxUR5wfQpY/Rn3Ac7O4+fOtzkrF+xxWGrBi76ud0sQladVaA1pKKxDuSGT/aNSoDjlluRjY+F8Fhcbwmrklc/olWm1YGsommdLM+VZJmSsA9e1n3GyFE0V4paCq8B+8xtgJLnX79+XW6happ1jdc/dtK7bPqUbk6mYssMJdgOd8CNKNrNNCZZmWB3ZKwSmFvKptJh2TLdI7Ln3xjUyYo1EjW3yRqHvmWszfq8wDSe+KSL+s60CIccZzWgUOys2hCEp/oplO3AKkF5f3+/kiDiml9qX3THeA9CV7AuwhbbCH90h/6q6QI4Tzahr9NN6m+g/rWhH6PIYlCP7tK/0ddr+LiK9i+ZK188Ljd9SNuKaq46Kme6BBWTzn47SmAnAUcJ5d8383W/Bg75UAr6w1necDwcHbfgkJ0x7fV1S9YdcumuzNCXRx9tof2xvz8xMZE7Ozs7Mn3IbRSVzv61GbWd3Nz0mqslQiVo5ZhgotITqwC3ZQU3ltY/j3Yemg5jr6kYFM96/n9YfxXtqJgbsBNK3sMd1D+wb06Ke3t70W39427TtqLiAqtJkw5YwULwqohDUNoO7XX4w7T9xuoavhLwnPYbF9eGd5w1w4rFcvyJCv0uWNc/TA/gjbXWn8Nzx7+yhNwjDNtFv8xOeBMVlUra4mQqnlRCKcs0BvyM/l43fUw3J1Puya5z2uOTfpldRg180FgJnOUO35XyBtp1kmx3E6NuDfs+9qHdTnqf2+/Yb6/iNfvb9DG3GfpbghfPyQA2OXwfwfI4y5l2NxXrpn4dlQBPPf2uOgsCeauccGFzNpDt/LrENwLdAr50HlaO7kbGfEPQJzt+X3hsJb1Gs9a3Z7+g+xq6ZlHZCfZblkMqJhXILvEsH+tV1LnxHaT9fUDkl9EKN5Cd8WQXTI/gWwycc8V8O+IHPuwLr08GztqH9ORpymaz6dPT01pndXKY6aZsIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQiQwPz+/FMb2i+GjJ3824Zi9ImM6BJN7pVKpaGxsbCAz6onW6Ui4tM1JypxIP9hMd0yCUMJ2xqWZsfk3l1A2yxz+7aTddunAmQH6/Px8hTm7aUl5Tu7vZQy/+DbEmVKgaExElrdlxUZpxRvhsnAw/xSUsezyHz158iRz586dWCHHx8eZE6oERSvfvXvXtAMtJvNMMY8VZGRQVIG8yunpKdca9v8GpKBczM5csFk20jateMF0gE+fPuWq1WqsSFDQtbOzswIUrvD+/fs4Q5/NuhxDixvmArVlr5jT3llPJvdiOWS94D+uUJ7+u2r4SUEBcmFho7SGt8WmVd+FkvGPJDhk/6MVX9X+ucO6PS7vMv+hPMf8U04eipaMGGq6liTNB0rFHEg/2YRnjlZ81HBYrx1DS+plV74xJ6gYbFINct13NBOeTRz70lrAHLZriuW9WsokHFr186tycubJ3HTyGuVYFcPDGP/iBpaJyhDnLGUqyE7PojmBgj/JlIgZV2bz+Jds+aHN8lf3vzUTExMl+qLYT0s845UXbXnW/v1Ox7M9i78xzLzHJSzj24FmxzXaz/JQnhBCCCGEEEIIIYQQQgghhBBCCCGEEEIIBgAaMRS0/At/hiab+GeklaiFuow4zXGbv3c1Pca2tYw26CeAQ0KK8UwMoAt3zM3NHbm4Jq5HR0ezWNaShDx+/Djr/2aUysyIUyiKaZWkNjQqX1hYmOWSVIeBfoxaxbnz+/v7xaT2icHDaVKGN9MV4mbn7C/uYxiSfH5+vombv5X0Q+WLi4vs58+fM34Z6s+ibNM0gMqflOEkDPpjEF9Yh7K5JNVhVADOW2QUQLP2icFi9MGDBwy8+xPbyycnJ3Gs1NTU1AZWv15eXpaxnyHU/4cyPMLn/3z8+HEG9XadACo4o1ax75847vT+/fun09PTOygbYRTp5ORkBvX3/JPiQdjBvh+x/Bf7/4X9v+DYHBZmPvkR6+cPHz48PD4+/h3n/xn7i+5Y61asMXwax45gX8XV4T604wXbCuXkuR+gLXf89qHeb0YMHLWxmWHJtKRccFNrwX30Nb2QZYYvP/ItIZNNQCle2mC7Eoqq9+7de8rwZht4V5dux05wdr1Q51q8Eyx3HAKNzS1YzMSJEN0Kto8L/N9i3cVguPfDqHHu5YT2iQGkNpniDYUS7XAbN/QptrMNjmHEZ9o0DndOf/jw4QWOj1P7+JGjxEaV1o71lW1vby/iGkpabce/ddBdCcKod40YCuq0AcqxTqsW1KkLWTbNlTS0wPkGocw1eTadUMeAkue9sGyFUQ8Jda+nMEu+lsjBD1mG0s1gqYQJzphvCkqxxrBrbJdg1TYYymy8EGcH9pX80GnIM+3iyaizyDg3J29s6y7DqLEceu17zvZp+B9y2g1NbiUEuluhzgqjFkIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYT4Sv4C8AG41KJB/UMAAAAASUVORK5CYII=",
        "../assets/images/template_cv/outstanding17/avatar.png": "https://static.topcv.vn/cv-builder/assets/avatar.e416ff9c.png",
        "../assets/images/template_cv/outstanding17/award.png": "https://static.topcv.vn/cv-builder/assets/award.4141e3ae.png",
        "../assets/images/template_cv/outstanding17/certification.png": "https://static.topcv.vn/cv-builder/assets/certification.31a236a5.png",
        "../assets/images/template_cv/outstanding17/education.png": "https://static.topcv.vn/cv-builder/assets/education.96dd82f6.png",
        "../assets/images/template_cv/outstanding17/experience.png": "https://static.topcv.vn/cv-builder/assets/experience.7d1e45f7.png",
        "../assets/images/template_cv/outstanding17/info.png": "https://static.topcv.vn/cv-builder/assets/info.fbcf7bbe.png",
        "../assets/images/template_cv/outstanding17/interests.png": "https://static.topcv.vn/cv-builder/assets/interests.42095094.png",
        "../assets/images/template_cv/outstanding17/name.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKoAAABDCAYAAAAMPZ7IAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAsBSURBVHgB7Z1PbFTHHcfHrUMaYockIFxbSRMgMmoEHEoOJBeQSm82cMWcEqnm0hyCkcohESCQmkoYpKYXXCk92VyT2D2RSHBpOMQ5AEpkV7iJiOzYKS2pN0SQP8585vm3nn07b/d5114z+PeRFta7782bN/Odmd/Mm99vm+a+NHNGUe5zfmYUJQJUqEoUqFCVKFChKlGgQlWiQIWqRIEKdZUw+83P3StWmo3ywHPpyuPm5NlnrFCbTffe/5jOTd+a/r89bfp6b5qD+2dMDKhQVwEX3tloWlt+NL09N83Qu21m+P0NpqPtntnz4tcmFpoa+WRqamZN8X37xntGaQxT0w8nb5rmzOT0GjNbaDY7dxRM66Pfm1hoqI06dmOt6X55u3uNXms1SmNob7tre6M50/vHTnP42FZz2ZoCMYkUGirUPS/eNnt23Xbv+weeMkpjYBJ1+FinHdEeNl2/vWWH/vVmYKjdxETDZ/1Her+wrfkHMz6x1ozYAlOWn/7zTzmR9vZMmb7DN53ZNTDYEdWo1rQSu6eYfRYKyVIJw5KyvIiNKmUdY/k3j088Yi7YmWAejtjlDFrh5Q8fd38ff+2zsmMYZs4OPO3ed+29ZXZuny07ZuT9J12PynddgYLy0+g9NBmcePXb7wv2uN3z5oR/H72Hpuw5dzPPcde1ecvi5Lln3f8s3XRuvlP2/cBQh638NWXpkO8L724049YW99csO+w9JmVRKH5GOcqIQrkyymTlg3vssGVA2pXyxTKU1A1l8NHVFvNxjl6Teiwtv3CZS36y6nU5aaZAh3MOwdzA+I1HiscHhVpYSM/dzPbydIbscglDEce122WS9E37aYzZAhx669OyNC59uM6lgSARqn8f2GEhoco57pgKQpV0Rq+1mEF77bSIRq0AZNiUdJhNix2YhmNZEqL8GH7d8V+uKV6Hz0NCle/lHrkGaZGv996+XnIs38kQ3703uf/Rq+1m5IPqdUs9+uVHWuffHM/MT1a9LifNtJzensniB/R0tEw4uH+6pABbAoW5WLhZvzKp9Eqtk/ww8eqztm2jmbRD5smzz5ozb9yoeqwvUno8f1aNSFmawy6kV621N6KXPHys1eVrYLDd/S3wN9envvzPgc+oy7zQGOi976eHAc0s/Po3NnxxfVGoPQdmlny9U4Y7Ci8ZKtvMwQMzwR5F4BgWpxs93ABlUa3S6OFEpDSotCi4v312Sc7drx1Nar0PziMf5Icy6f7dLVc/9IAjH2xIrrV/pmw0aW35vky81aBRsUpzv6x3N3TWL0MXnHn9RlGs9JpZiIBPnnum4c+qacRApfkPK9Jgkwpd9hFlGu4BO5QhuXPzt6YexEygLOhFgd5c8sv39YLQSb/v1BZzv1DXI9RhOylKU/gmO0kpWAp0545Zs9vaXdhQfH7+zXAvg/3EJEiGuzwmwKUr68zkzEOLylsITKIhJke2IZ2wJkDIbgO/AWWNDIi0u4JdnJdkaJ90ZYJJAdKb0/iD+bNPoqTs0/CEKt3Dn3jtc3P09JYVNbvS1CXUk+c2Lep46U3FJmboQqh8TmWHKpnPThz5zPUaDHcUrDw0yCLvKkYezrw+YQ69+muXx8VWWvfL28o+o5FmCT4vDO+X7OxeJmnuWq63vhM83vW+dqUiRK+ZLBNqxy/vFhvDSppdPnUJNSvzoYVkfxKF2OT8oq1qbbcsO8q3zZjcbP3rJ6YSVFhI9PQQizUfWFpKV1peQisATU1mSZCJVZLHexVtUMoCezNE55awKUJ5j15tTXZeWbNrMLDy0kjqEmqoZ8AO3fdK+dqF/xQq1NMggkqFjVjoRbAVGYYr0ff7L5xpkYbr1mLn+j0YlVZp9cMfGc7/aaF8aKh5loryQuPFlqQxdG66E1yOE5hMhZYSq3HcjmRjf3jemV2yrr1SNGQy5U+isqCCKx1D5ffPLxNxXKi3Wk6OW7uNPFBp6cmfPzP2v6OxyKsw30BE5K0tC2KfnC6/F8pM8I8NUe37WhGzC/KutS8XDRGq35uyeD9sF6v9l/RAWQa/wJDOZt+VABMgaz11z0u3S1YneMojyNMqWfLbOj/rR7xZ5zBqnPU27SzFvlHSzHpVQsyulaYhG6elNTIJChn8rDti7OexIf1huNH4trKPPxOnd+x59fng+b4tmfec0LpoXhjygfTZWpnFR/8YrZRMidm1Uix7j+ovhmc9tpTPZVJVDRmGV4Ks5+AICjswa4EckWPT+6KrdI4TMrud6hhBDu7/akkW7MXsWqkyhyaNPbX0+LuToMXakNU2Kk+l7FTdVVaKClWJAnWXVqJAhapEgQpViQIVqhIFKlQlClSoShSoUJUoUKEqUaBCVaJAhapEgQpViQIVqhIFKlQlCtzG6bTbs3Nn9uIkEQrH32XOHlMcv8A5jr20EKiA7/BdJywP70N07/2v+59d7bhR+HsmccFgg65//RCVjiO/SaDaH0qOx7HOvxb7XznWh/zs2fV15jXI86yLX1Vw56Y3elN2XKPSvUsZkT/eyzl+vriOXJe/Ry6uL16rc8udYh5XC65HPTvwK2Pmmoqv4YsbigGxoN9z7CKu5oV32lxBU5DstcTZTnZ/cy4BGZwfz3x6I4S0Yb+lXMNLN+2oRzoj8y7AlaChHD31XJlQENfR08+VBIVw+R5sN/3nSx3UaEzOtdq799GrjxUDOqTzQtonbLl0tH23UC7eubzwoa9271JG8j5dBuRLrisxrdjjmoQDsg3kn09EF9+0XlyPissCPvYC74+e2uLcPdIu0RTge29fK/69k3/mksBnvs87vYWkmaRTKPEM9Z3XEEQtO9FxlEu7WSPItOsG1xr/91r3Iwvpe/LzmXAr6CVLGjTe/jcmStIvPdeUfR669xBZYYOIzofPvv8daZHHJMbVyu26bySZNiq+TVPTpT4yVFbIf4ehH7eHxYDDHxWAyIh3VQv8wofvZ5UM701l5gBi6bGVinjSQ30eRKQnjnxes/9SJXA5yfJJGptIGlgaGsxqESnUNZnCjsK+TcI5PrSocxFP13x0DwnwVQsEIBM/q3SEO4HeSkLXXL7yRIm5kIS/fLL4IhqKb4/L0Ct+9GkQsP+q1emQ0ahavAKQfI5N/CLq341aLHV5oWI3YX9RmR8HerIsmEDQG0gP8ptt/w+aGXngHIRKmvSmaTHRmDqcWTHnrrd71//ccOo7Gvr+Sgh58K1PvPPXOjdpRBSK0yTxToWWGn3sabDuXmyj2l0hZJHkFffrF1ITxgeZRQvVb8UULC9EkmcCJMhQT5Q8KMxHpssKlFYNelV+7WP479fLvhsq9rbJtZioID4RKsL2e+HWlN1LKBzxID16erPzxvTt6aV0wkvC9HSWuZT7ZS75qhQB8UEkKFSJPjzw53+VfM4yCrPa9OQH4b2wI5/IXO97/bGSCRkkM9vahjKENPSXT4NDM0N7OvRQpWt1WTuWoGhpE8LFoMJ92U4ySW+5ejJMgL5Tm11vCTSUy1fWlcSOogwnXbTt1fNbXU6oLY/+WFySkQrsOfBVOA7+/DAoyJpiV86QigzxoejHiI0JlvTQkh+BCsyKVgesLaahsUmMUx8CYdBrhvKMABFAaGKDWOjJJPwlaafzybJdPb743COTTImFwDUps32vbCsK04VBt5Op1UTN7tJiK+XxWVfqZ7X/koz69StRoM/6lShQoSpRoEJVokCFqkSBClWJAhWqEgUqVCUKVKhKFKhQlShQoSpRoEJVokCFqkSBClWJgp8AYS70kvoy/ncAAAAASUVORK5CYII=",
        "../assets/images/template_cv/outstanding17/objective.png": "https://static.topcv.vn/cv-builder/assets/objective.4a96e791.png",
        "../assets/images/template_cv/outstanding17/project.png": "https://static.topcv.vn/cv-builder/assets/project.e2b240d5.png",
        "../assets/images/template_cv/outstanding17/reference.png": "https://static.topcv.vn/cv-builder/assets/reference.9ee5f79d.png",
        "../assets/images/template_cv/outstanding17/skillgroup.png": "https://static.topcv.vn/cv-builder/assets/skillgroup.7742cf77.png",
        "../assets/images/template_cv/outstanding17/thumbnail.png": "https://static.topcv.vn/cv-builder/assets/thumbnail.02ec83e6.png",
        "../assets/images/template_cv/outstanding18/thumbnail.png": "https://static.topcv.vn/cv-builder/assets/thumbnail.ce4f52a3.png",
        "../assets/images/template_cv/outstanding7/activity.png": "https://static.topcv.vn/cv-builder/assets/activity.33d543a0.png",
        "../assets/images/template_cv/outstanding7/additional_info.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAACICAMAAAD9Ldb4AAAAgVBMVEX///+738ju7u4zMzOVlZXq6uqqqqp/f39ESUaqybW/v79qamr19fVmc2pVXli1tbXV1dVVVVWIn5Bra2tgYGDU1NQ7PTyZtKPKysqgoKB2dnaqyrZ3iX2z1b+iv6zf39+fn59ufnR/k4eKioqz1L9MU0+RqpleaWGLi4tNVE/JycmD1vjuAAAFZUlEQVR42uyYzarrIBSFu1iT7SAOHOjAKCj5oe//gtckrS209xwO2FBIvkG3LHcKH9mJkAsOyil+NE7xo3GKH41T/Gic4kfjFD8ap3hDonssPf5CcFu/d6FmvmTNaSk+dTegiRvG2ogf8DbjGUOz1o6qtogMaEh7caO1pi0/D3En0VwV3lMa4cceD96KJ1FoT+NRV+wArOIBhVrwJhDBC0/iLxcENOKT4tlSPBA1qUvVc7KcA7Dk2y1UQsqkJCHLkk5VPIoOHfuSRcCN2z94TV4jWvBRcW06JngrOVsJEHZmZg9DMYlcxAdjrVHLBT0l97R3cS+i0K2NGp4ymVIhNmexAS347KiDIxINkJkhdtubGdcxrqO+iTtgZNjEe7Fq6YlLhsFsdWICjDg04OPiUmpYs+o4WvxHXG+hoWW692gCsbuK5drTih3E50U8PonL7+IU6x/inqNx4yI+oRU7iCe67X0l8jTq84/ifeS1it/34NgDrotowA7iyspkRFR1dLy63t7ERxr/Km6Qmap45uwSiUGsmcQqNGAHcUyyHkJVvEhSbo7IpHknXtauPuOJ1GVvO/2+9zh7RSk8EwYFzYCVsv6d0lQXTblgR7wYlzjjG9hVfEgktcI3cMG+qAHfwfkh4mic4kfjFP/H/hzQAADAMAx65l/0hVAcoCmuKa5x4zvSimOKa4primuKa559OliNHIbBAPwfLAskgR3sgJ3LBHIZ9v0fcDU2DKG7h9Lm0DLzQxyhWOAPnDf81fKGv1re8FfLG/5q+RQ8xZhoVKIGT4iYISV8JbqO6Y4rcz1cowS9AbCdgDM8EL4Btx8PX4G1GkxixoS3cQVyagDEkhjgK2WMZAIaeSf50ii1sXN+GZPaxF/UQDnHjBxvuCDXwHs8weeyhaQy4LWHekPUFDbDwpEZVEKsASNrMVGj0kMxqkfUjX3vmNx8kqAajw1ZIdWn2J8VF+QKeF4WwkxfNgZYTAC5wxM6sHcUAjjBN1JFdLQEzOyxrNiDF4kW4E8FhMdkHNO6whbKOrr7ffQvyBVwY36W2h7Chnbn8jy+sGvx8LrMdSGd4Fa94o25hAc86xnulcPxhMfwk+Af/3FaiJROx08Tvvf/wXMthiMRkf0LT78JbkfHzaFhHv8OHAIWWFknfF7agBsB3pXQEdnJ9AHuyE1+Dfwve3bQ4ioMhWH4W+TkQHIgliRgs4ng5tL//wNvjGCvN8N0BsqgY96FVCXQpwUhx+CtRrEGzwlY+D6wgCx7hxVe1N4nBR5RfwAJsVxJ/D/cpsA4C3xLZPtI61H+vSmuPvCeCWFfAQrhCFX4W8reaU/isKuF4xi9Dw5yjvCqmHGM+iblanX41erwq9XhV6vDr1aHv6EUcZ6+BNcC4NGwSNfyaABinR3aosGWVjhOX4Lf6MMNpRgzszEUHWQibYA2DvIb4OLMNk5/WvJQ7whoWO+UYyYskZ0cIKMs17Ua9FF2pZ/O1Rt4HZQTjHUqbfB6IK+VxxBYW4NxmbobLE0qMkDLdQ0dlA5HeQ68nKtXuC8FjdkB+g98BOa8g7MBOA4JcOvJvMJ9RqHSTfCwZekZJjDC3PzjNta54Q1LO3hIzMEMDBgFmwFV4YMlmu4FXtdpdQZ4qYWPBZBwkwZuRyKSBq4SM4fzw+s3v4M1xOcdfLoDhiq8nohf4FQXcjw9XJT32zh9B6fZJ5YVDrLJ8wI3jJLj08KfUTtOb0fuAgKPOHbfhKs7XvdITtljvDb44U1K1E5w8Pru7Gp1+NXq8KvV4X/bnwMBAAAAAEH+1oN0BmmOa45rjmuOa45rjmuOa45rjmuOa45rjmuOa45rjmvkOCq7K3saq3fMigAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/outstanding7/avatar.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAAEsCAMAAABOo35HAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAxlBMVEV3eHhqaGZdWVZHPzpYUk5kYV1RS0cvJSAhGRUkHRg7My0pIRxxcG9COjQzKiQ5LidMRUAnHhlmV0fAtJn68dTTyKyCc15aSz7n3MBzZVKPgGqfknlENy1OQTWwoolQRj02LCaVhm/568740bL4x6j4wKH3t5n3upz548RvZ1x8c2nm3cKupo0dHhv55sj53L1kWlFYT0Y/PDQ+NC6Hfnevq6fMzM1HPDSUjIWhm5W9vLm3t7fCwsMQEA9ycnIAAAA6Ozv///90pjrHAAAAAWJLR0RBid5sTgAAAAd0SU1FB+YIGQYdLjafHIoAAA0VSURBVHja7Z1pd6M4FkC9S3gD2diAjTFTS6qcrlQ55Thx0t1T8/9/1YCXhEUCATZCQvdTn25IW/doeXpaaDQkEolEIpFIJBKJRCKRSCS1pdlqt9udLuufwQM9AE8o/Q7r31JxWgMYYNAesv5BFaYNIyhSF4k+jKP0WP+qajKCWIDs6+O0IImRbItRxkRZcNBKe7nZutBkXY4y6MIk2qS3em11PAg/q4z7muBNd5QoC9dzddtJlbEvsq9xsiyoaGFTIyXlBQjEHUjTig7h+KM76qWpPb8hau2iKPslRO0NKB4+obEuFjNZ/oRR643oVXn0WZeLnawcCGnrVrKIUQfP3EwWFLCXB8WtEACsi3Z96IKBXIgXb7WLSyExZl22q9O7nSwo3OS6VdwJEY114a7ODWWJ1w5vNxxChXXZrk6/uBQiInRa3WBi84bDIUzNtFaeU/LgPevUkbKIDN+jUHAqSng4RJOpruuz+XV6Mo11aYvRDSZa+n5jDOWVDVM/Y11DFt+T6W4kKQxGIVcL/YMlqrmsYXLrMvQgM7WwLI11gYuQHCYgMyRLNydFZfHcwTeTi2bpUYo2RZ5lpawRzmKydNMuJIvnoDQ5d7XScSyKVC7WBb6drAVWlm4auV0NWBf4ZrKQTsLJ2xZV1gUuQmKfZej6tXVxHWYljoZTXb+2Lp4Hw8Q4S9VTmE1wEa1qzB3vP66wf5PvzXBD8haYRZosj6llf4yN9spavtdGB/cneV8L00iuEIWr0+Do+ETbLFYW9yv4pMmhRSsLzxL3N7nu330IK1/RaWFWLCFlEbaQFqxYuiGkLHwSGRSsWDo2sOB9JWyI35E2LehKx9dXvkMHwoSHJmzII4vvnSGtG7ma4mVxPZHGVizkFHaFD7Mg32ll3NxwVbRvT2iGUOG414rH76h4E0ySxXOSJtYKUeFh8AxxIYjfxEOsKNHuajk5lhqtFhkbJ3EdiNs+Pha9h+N20wJwZS0dx1ohiKwkXc7S8ghMp2ckWdyG8dHoPTwhXCD7owNbAIiWeFGzSaDN2fPzkhAxN8hrHx/dXLQOVivbDrfJOX7C6GdMkT2xjhi+NuOoixQ8cBs+RFPwgd59qsbq0RTF0/LmBIJ5aFBwJuAkdUWSxWmvFRkMlUATNDA91AzBecSVamMi2KWtmkm9Fp8nLSKyxh+u5joOr26FapG5IgT7jh/ZEvcoaazLfQ1ZHyvQpAnPIryMMSUOkKYn1SQtXfOZXY7Iokj42Vkm2aSqxWdaKyJrkl5+B9r0smYiy6LxAHBba0isai5rApcUT51ZiCQrEpQCqn4ow1IGoR3y2cFHI3iK8juZ1n3wi5Ia63LnIppUpsgsZJOFnyDyGZRGE6UU+eRMwyE+eOB0utMYZJY1LS6L1xxNZMfRnKL8xWXxugk3stGBpjsqLIvPsdBjmC5rGmmbWFlTQureEqhiNRpqmqwJhKqZJssg7RPEyBqxLnJ+wonleHA+jTnEyJoS+7u4rAGnSeUjofHQwZfWTpEVf+hCfHLI9W26oS5ev7asWFDKcSP0CcxIMP3O3P/3qxRZ8YdIsgDPjbARmvJg8lkzFO3KMLLiD12I5EoVPic6AT6WeHCZqiVA4TES195iD70/LFCHdeT9MGvS8ZNkWeSHQ2isi3oFzsekKbeRgtyyuA3d47ZcynSxnUWW32choVz5N+WP/0NbfntF+6SHZc/nBlIEctWDaoZdWXbmHfKmBRXuj+2c6VD27Lll6bqDEOcB1pmhkqUTyidLX3K+qftCGxNeffr85evdty+fv2eSlfTWitdccpix1whnm839X4FC3134+p1a1qcv+Ld+bDYLPzHBf0Dq4c1TpoOHh4f+xdbPb3cBfsVk4Tc7kN7aen/64dELz3jNvAdpQUf/PXhcDB5+n2tIqNR3d9G6ZWNXNUhv/fBM3fcffugrl3VJr0DXk6X1db92neKHz+FS332lkkV6S/Nr1fJhplsiyGrAhX7/8JdfBzbH4n2NFPvuZ0SWatv2au6Eh4VvhLeO9XU71sWoWQ3gReSPP7wi/daOxYuW+g43uMUgvPXjwf/L2lSQPquhXUKH5e8byDp3hLrD6Zp9hI+g9CTtS6TU32hcEd+6DLGqy7qc1yEy3fkZKfZnKlnRtyIRh8HxkZ0wPRjax/0rh6vkt0xDkNnOyRYInmP69S27q4S3zDlC4rhqNJo7CFXbuMTmn36duqCvnz9Ru8K/Za1sFcIdvyv2eF29tgqCN6p8+v4zgyjCWw50++2OGNmZCN3iFxREsBDrMt0ORLM/Kws2x4d801CzpNcpMAUaBGNoSduVSQtlCYtCC473YqXSTDoQYOA7tElCP2cIskqBZ5CwdGGqFu5fJp17QhrrAt2SUdIZC1NVY2fzUdLZqKXIrTAteDBtGMr8zYzkRbSV0K3Qa4fJp+gsL9C/nK5fGim7m00hNoIkMEq5FnHmX7iGbNufxEA7OYad835bVhrd1ANys/lpNx8w0o5jqAJHpCcATVxqOhTzIkeMlcIkelkOqiZiiLEGncQQFb1G8tJcRe/efUZFLyg9YwmybyaR5hUu/NP9Ox2EWPpKY0dzUjq9YokdvV+4StUy0Y51OcphV/j229pULL9qFR4Qa1Ox/AGxaKxloZpULH9Bv2B6ecbtmfEcdLJcoYJhxeu1frlQCzVEUbYmUzJUUj+NQsZU+LyYJzfdTGe/wgzE2IqVgR7s53Rl8H60NwdKztu7DZ5vT84vC6o5evk1nNRQlp86RpkjiDVcmDWVBeEkU1Ocqv5HCmorK1PlmiPg5+brKwtCm/KLFlMb2sd6WGdZdLpmH0uu9ZYFIZjPUlWBi9K6y/KvXpmQ6pe5sENDQZ1SDgRZx/ZoOdHRcTo/XmQU3F8jZb2DbMPyP2vhf7Ridb6XJ/z5GTGONF1FFkZf5EsgtpRFq0rKIoLbJVk/WV0KUwC/+bZ+slpwkFKniNuU6yjLmS0mhA8N2ZNlwgTbrllW2Zd1qjgzZ25N7HcMK3qSHCPLZf3jy5el58WQsugR4wYHKUvKYo+UJWVVTxZk/eOlrAqj5Zc1r52sdn5ZjpQlZUlZ15GVf3+WlCVl3UpW3Xb+FZJVtyXpArKmUlYGpCwpS8q6CqqURc9YyqLHLSJLY/3reZJVtyVpt8BpVikrAzXb7DDspNwNlYQzFuR7RBQ0e7vjBhrVynNrqbk4fuXVHYl5lWuQYccX5T4+7Z+f1ggCY5ntZNjSQPDl8Px6vwYQgrbAIURTA0dRb89nDo+uvw9rQXc4bLbwTLmb/fnl/b1nW9n1RKxg3dEAopf7S1EvvD35wpBtLRLb5HRh+KI3kddft97LfcF8+XUKrZ+e8bwdti+uvyvSNqyFE9qeNXMcyzpeabcL1Mgg+82L74t1Ca9Gr59g6p3D03a9czHbAHe77f1r0pv7jQuVvgjZ0+ZIgbv7tzRVgaZ18Nj6PHn/sKd7af8IIOC9erV2ED1SFrggTzuotDnuvTouBFkqVUH23vDI6zcHegO4S+2prsvblk9dLQB3h3JV8aqr6zJRddbFVd813EFQcgMM64IKNyOjpqANO1U++xfochF3eS1wXd4ISOIA4Kj6bbENAaPOKsIWDiqelGi68JF9tTrx6lY7/dxRKlKtTmwhqG4UsYMvValWJw5Aqeg16EMAGQ+Ccd5eqnkzWVdBr8VLd3W2sF+9UbGH3Go1wQtPCFTNVq9q3dUHr0ipVoDag2vWTsjs3UrZqrQrr5uvkq2Ku6qUrcq7qpAtDlwdbVUhmO/y4MqzVYUIoqm4rD3Q8Ypc1q6GY1DV+CrKgfnMZ1fJOQ6eDeOPi/XgPWsFGXhh2sk30QtrAVl4Ayw/tely02GdODDMnWqwSnlRGh6ZHVUcIi4irCBvwGUka4f4aoQ+B0YfVmlVL4tMwQubT/a4gHXB87Bn0se3uOvdTzyyqFrujnWx8/HG4JObLchwn0whtuVXrT6XPZbPvvTjik2uJoVh1mV/gLrNYYx14bXs7MOAu+A9gFvuN0q7kJ80VpwNLLWLH3Hbvfvsy53zDB5ZF7gQuzKPwnY5jd4vbMq8gUtDrItbjH2Z42Gfq2wyBlDiQo/CY3ImyNotzRXvXdbz8315nVYHsi5sUV7Lu/unzcmKfQLlRVp9TlNZAdzSklrulnVZC/PiliWLy5WKMNvS1qa5HwzLjOEFkHWQsqQsKYs1UpaUdRvKmxwKIGsrZQkg6+9/Sin/P39nkVXaQmtGWf/2SpH133+zyHIrKuvP/8qR9UfKkrKkLClLypKypKwMD++kLCnrNrLGUha9rNKWwqQsKUvKkrKkLClLyhJAVnlHwwSQVd4RTSmrZrJK2/kngqzS9pRKWVKWlCVlSVlSVkVlvUlZ9M8epCwpS8piL6ssV1KWlCVlSVlSlpQlZQkgq8QrQ/iXVd6ZgQbcHLLwp5/p8by0/tA/uy5RVjb+zfh8TpQs/5+8Byz+D84Nlkw6pOswAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDIyLTA4LTI1VDA2OjI5OjQ2KzAwOjAwZg6JMAAAACV0RVh0ZGF0ZTptb2RpZnkAMjAyMi0wOC0yNVQwNjoyOTo0NiswMDowMBdTMYwAAAAodEVYdGRhdGU6dGltZXN0YW1wADIwMjItMDgtMjVUMDY6Mjk6NDYrMDA6MDBARhBTAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding7/award.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAADACAMAAAAeJl75AAAAk1BMVEX///+738jv7+8zMzOWlpbq6uq/v7+qqqpqampVVVX19fXLy8u0tLSAgICqybXV1dXU1NRVXlh3iX1ESUbm5uZgYGCz1b90dHTf39+In5CZtKNmc2pra2uKiop/f387PTygoKB2dnZufnRMTExeaWFAQECRqpmAlIeMjIxmZmbZ2dlMU0+iv6zAwMBZWVmqyraioqJF0RlQAAAGV0lEQVR42uzXzYrkIBiF4T599oJ+IGgWgoguEqj7v7uJ6Uw6VM3QvTFU0HdR+LeoB0wV+UCnDXhvDXhvDXhvDXhvDXhvDXhvXQO3C37Tgqu6Cu5kflqx/oHnHloeuKZmcGuS1m4dRFF1OgVbx/Y44GnwUmHGNbWCW6FOUm1lg2ddyXFWqCX5N1zpy9yt4GZjaSrsWZzS/IKfF33ZT2l1Om7RqFZwYf3KefLbVX9oUjKQpKKUhHXmOWkGA8hUl2JMKIEhLlwkaTICiIFJC1rUCs4ZexMVZhYvtPsNsE7olF/VpS5Sr3BSK0ftJrIoMjqhh/laQIsawVXVZGPMssFdxqpwO/z7qiPS7/AJENm2rGICHAskWEBuBbecV5UEug1uTarjV7g5wW0d1JV1UuGm7twNjhDqp9vhEoqffoIrJtwfHplxwDeS+R88zMBSrSFsW+ov/I5XHSow5iLMFW4p3skJnugeB1yz5LlaC5OP6+CAm7pwrx+3Va5JSkGFb/9TieaAZ9Id8EXIabXWGZnsNxyR1OFmcMAqiyNln/aA183XY1bVJ6FFb/1a6sTlSIMWvTVcTWRo5H5r+PZINOrN4acGfMAHfMAHfMAHfMAHvF/450eXfQ54Zw14bw14bw34H3brIAViEAagaJhIN6a7gAcQQV1I73+6SSozGz1BzF801N0rbfW0HH5aDj8th5+Ww0/L4ae1gXO9A7+DQItRL7fcWWqFcy4J2xxV+AUDAGEb+IChVnjADhWZMELCT2xJ4SMDlAaGWuEfBhUH5PcZQFQ4M7B1uHSJdcLjhGtVFgy1g/eSYIEHGZbawLkMWXuw/191g+7tXx0DEUesV84w4eIeRGRpy1/hhBqJFXP/wRtKpj7yCd9nyelHVoc7/MuOHewqCkMBGP4X57TltE3ZNLAAAw/g+7/eWIlXM+LsbmSi/wZoa5MvXRj4sL7wT+sL/7S+8E/rC/+0vvAXzZGX+f/5g/MevIg4QKzdDxAd9zq2lqzebmNKq5+M55xsFwc6eI7SDtwH188ZvDafQZ+e4S6pQFoe4aT4Gh5j2zGNHKQd+DSC1ZFoEH2BsXCpaEkKnSVnYCkpZc7lCh/bmG5Lo8W2zs5Jzxu8tE3KCJoiaCmXy9t7hpfKVlBWSSHhhUuyLlKNLvs5o5NfqsW8uit8bWNOaEtzXmQy8snn7gqv4oNDPHFNkq/P9f3yHXhoB1eMoObAzTe4h8HRKVoZI4hrM9uJo90PPEEYr7ts8Blibj8f+jbjTrC8/5PtPjxJ7QlKmYfpdIM7yBc4DYlf83SH6yPcQegbTze4gNYG73LO1bUZf0S4dQaEBtequF24mw35J3x4hI8bvFdVOyycLGC1wcdqLLvwRbCnEx9AbnCrStzgk+GlwfMC7sBwk7pOCwRlqXUOe3AN03px9J3c4RamYbjBSd06bPB1mII2uIZ1Eo4LB9OfO+NFujOvj0+mY7iv3RqNo9Tgv9Ig58nzV/n9f2O/Dlfnew7c9+3sT/tm15owDIbRl9k00aTYm2IvkmEZu/DC/f+ftyRSKOJc6DYW+jznzrSvcIyU+nHQoDgaFEeD4mhQHA2Ko0FxNCiOBsXRoDga7M6ed2fN7nKB7M6aTiSGGhuisDvLjU4nG6K4O4uFyqYug8XdmXVxdUMUdmfOphJJNkRhd3Z5b9u3D9kQRd1ZfjV2l03lWMXd2cumLm28ZcWD4mhQHA2Ko0FxNCiOBsW/INTzt9uZ/+zORqMkohvJPP7K3fQSOaSn0ZOSyljZnVk9i9/knoifRUan6intftadqbykc1KWT7we1DFlZcnSjmMWt65V8YiI2DRp1dXVs/Eru7P2NYunhKzPW7tXxyFoo2Uczo3Xed7oxscBkdC4FPdM8bHUwrrubBYPeXkWl7QcXFqb3+o5YrEmHulup1Wz5eu6s1m8WYqbLH7qF+I5uhLtu24y1Ys/7s7Kxe1SPLg44IKKVC9e1J0txZOrmsXz2ukmfhbl+zjQD0qUrV/8vjv7VrzdT2GYxQ/Ge3MTD9OgJQ1oP/m+fvGy7uzx+fnBIbj76Wqy8b+7V7feaXO/r319vzf+uriM2tXTE/LTGcUpTnEwKI4GxdGgOBoUR4PiaFAcDYqjQXE0KI4GxdGgOBoUR4PiaFAcDYqjQXE0KI5GFAflE4Chl3PGx6ntAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding7/certification.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAADACAMAAAAeJl75AAAAnFBMVEX///+738jv7+8zMzPq6uqVlZWqqqq/v79qamr19fVVVVW0tLSAgIDV1dVfX1/U1NRESUaZmZlVXljKysrm5ubf399/f3+KioqqybXMzMygoKCIn5B3iX0+Pz6z1b91dXVMTk2ZtKOfn59uf3R2dnaMjIxzc3NmZmbZ2dldaGGZtKKQqpmiv6yAlIdmdGtmc2rAwMCqyrampqZ/k4diDSxzAAAG/ElEQVR42uzXy2rDMBCF4Z6eFxi0EuiCjVaOb5i+/7vVchrXDZR2o9w0/yIio9l8oI3fUGkKry2F15bCa0vhtaXw2lJ4bT0wPFoU60bwocVetPGf24NIRKEKw9vOGAdAiEvL3xoRnHNsUaiycM8wGzY/4JNY/NEFbsWhVEXhCyUCiW6DR2zZfCaLfRBxKM83eETZisITewBWEoQfgU3EKAPQSUsnoyE9sKxHMjO21qXgMzwFdhG99ChVUbihxTlh5zp6eLZ5HMbTKlyZERPTemOQc9vWuG87PulTP8KBSHOBW5zogcQ2D7ebXBPyzwxZT8vuVeC4hud/J6bzDb4PiGS4eV74nJlYvPsdPrwkvN9UjukA73/CIw12sQQA8/j8cDScnA9id/iJTet5gMMw9dMX/INTm+hfAG5nkmbADkcixRzhVsgLHJ5keoGnvhZtvB5cb8S4sMNXNuI23f3rzEvfN3S4dXeHW0OGETfv7vDt8d+hB4D/M4UrXOEKV7jCFa5whdcLf3+rsneFV5bCa0vhtaXwT3brXgdCEAbgeGMHh7pAujCQsPAx+/4Pd63mboF7gdL/YCPbz6iwWw7fLYfvlsN3y+G75fDdWsC5XoGfQaClpJdL7iw1w7nkhv0dVfgZAwBhj3iDoWZ4wAEVmTBBwyP1pvBYAHIHQ83wg0HFAfl5BpAUzgxsHS6dYn3h6YVrVRYMtYKP3GCCBxmWWsA5R1m7cfxedYPu5V8dAxEnrGcp8MDVHYnI0pY/wwk1EiuW8YV3lEx95Ar/lyWnH1kd7vAPO3aTozgMBFD4LapsV/yThRUsZRMp4gBz/9NNQtTQjWnNilG34C1IXASsT2EBvFhv+Kv1hr9ab/ir9Ya/Wm/4N7XKt7nf/IfzI3hW9YAakBeonlsDR2sSZ1zybi/iGiCzcWuWyXFfdZdgmtVzrL1cN44TgBO6ngx3wY8tcWy9Goyxh/soCnEGGL0foq+wTmBfoFPTDrBfX5z35O1Rz6DNew122XiZaQ6oga5nw8MEViaqQXUZpgyQJUeBwaI3sLgtckuZS4MAOVawPwCSt8UxMqzaZSGxSuZSGIHFA6miDkjRBgEbbCyAznQ9GZ4LR0E4awwRpwB6nrUYQ3ItIcGtxWo6+xvchagJGY43Obng8dsoICW54LbDrEWv8N0IOD3gzeUFYDTKiA1C17PhAaacbYObB98+4A4WvxOlMFVQj1Nu8FH24wHfEVEvo7KNjBpQhfUT/LjSn1DN2RXZzo7cvE+7/gc8ahk3OLkt4fQB95A2OMgA7pzCHVzmJV3hJ/D6aZQDyYPr4LGhi+o8UReOxkLzdD0bfnwCww6XIviHcN+su+Mpwh08OQgf8HYHp0yAzqhjT4oBbYLkB6Hr2XCSgpUdPhVjfQhfFbu74zsm38FDZbrecZdAP8Nds/0VH3DSDDGwPyhdz4eblnOY2eCspbTwCC4hnNPMOOgNHodwKuMXuD9GB9xaWJbPcNYSSuUKl1MIywTYUOl6PhxMrmfGN0n/vAldX0Zm6rqNuvU/+23f1ccQXRF+SP8RjsRo/JTev87+tm8GPW7CQBj91LWxHRvQ1jJokSoiFCnX/f+/row3pLCoBfVQtsw8KQIGTPRyQOTwuCHi3BBxbog4N0ScGyLODRHnhohzQ8S5IeLckO7sz93Z68v9zrI7ew3A9YoTsbM7y41OwInY3Z2NhcqpHoO7u7M3P05PxM7uzL9RiYQTsbM7u/8w5vodJ2Jfd0a/xsv9VDnW7u7s26kebfLKyg8R54aIc0PEuSHi3BBxboj477uzc/J33VmyCoAqMknZGoCZX6U6dAqfKTI14DWddXRUgnboOPmPNgsbHNqdxQKAM6YNxiiogUYRMwbtscKYoTcmQTfG2wh1MeO2gLJdNDap3ISEDfGDuzOVR4/GxL3TiTKB9OmARkV6LkH0KjoQZTPFdHU1in9svc53ylGL2lGjHNmdmWYmbrW39SOwCLbT1uWRgbZ5ydAXTaV+iQ8dRiqVxdMlC0Ml+JCbrS2O7M4W4i7SdhI3gE0uZgXd0RKK5+gziT+utLW6lGW8aVqTcZWDjdjg0O5sIQ4Tgn2K16SE+BwFQzfEWpwiHa21x1McrU8WWxzVna3FS+phl+LKKphJPH0W9wF0E6cuyOSVsQPqMGhscVR3thY3PdAuxWMP6Emc7qXm4q6KecUkXlcqV2xAZRM2OKw7W4u7vrJNWIi7dhz1D3EYe2vn4kjWVo17iqOw9IW002Mfh3Rna5zbGOWudjFwWB3v5r95V2/1+63DF+NfiCMWNb4a8u+MGyLODRHnhohzQ8S5IeLcEHFuiDg3RJwbIs4NEeeGiHNDxLkh4twQcW6IODdEnBsizg0R5wZncab8BEDAobnT7JUaAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding7/education.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAADACAMAAAAeJl75AAAAilBMVEX///+738ju7u4zMzPMzMyZmZmzs7NmZmbm5uZMTEzy8vJAQECLi4umpqaAgIC/v79/f39NTU339/fZ2dnl5eXd3d27u7tZWVmRkZFzc3Oqqqpmc2pESUbExMRVXliioqKz1b93iX07PTzV1dWqybWZtKOIn5CQqplMU0+AlIddaWFufnSqyraiv6zNpJ6RAAAHzElEQVR42uzXS27DMAxF0by8ZYgIKMGW5N/+t1fGaRsEaDOLYFi8ExPi6FgDwxd0msN7y+G95fDecnhvOby3HN5bx4LrgDYdDR4q2tQCnoPCChPeFyWu9Uw3HrhreMO7NNw2iWhVe7ji0R9Xq8+hQU3h642UAmBKTPGxFQVmUQ2JEu+j7WTFh2sDL6N1hwvjJNyQOeeZE6xsD7VdYBwrR9xYc+CMD9cGvme4wgUYGVATgBpgabqfZ5SyvwSDD0ASfLg28Px945EjdpXNz3XSYFiNsyRGgwOQk8AHWE94fYGPLDIDM2OJZ4Vng2FlgCT8ftg1VeZ9jXxWuErKpXLDxDAuptxbSAWSreSscAyVTBlAJLng0cgAwNQpMJwJ/tKw/QyKl/aTdjWH16Q4Ro3h04KDdKzf0v9zuMMd7nCHO9zhDne4w3vrcr102dXhneXw3nJ4bzn8i/267W0ThsIw/Ijj43dj3hJCpCgf+v//445pM5I2WSdtmZjCrZZggytdwmrLq7XBX60N/mpt8Fdrg79aG/zVugtPCQ/qA+NzzmCOiXE/Hj2elK0AdLZD6fq0sj9H3Q6Std/CByKFq7LrcUlPuC46e4HnyUaNLyVZnMyT4NVBH05y3HOFHfM8EU+Qzucjz6M37Pl46MD6qL+DNxQi0GubtAcwNBQtVNK28DgDKvuUIfWGkndGsQKgytygrS439imrXBZPFL3SUNonjb/d/oQu4ryD0jhZBtQe1RnATg6HSkYdQyxavR2B+B3cmSZ4MIVAplgDuZxl1PYYg6EaDblADCDJJeuC3KgQydHoNQVHBopksv1YrBqSJWNZ8verGOVxH8uZgLk7abzH3V4BNaTjbt4e38AVafkSeHFC0sJyrR+C8awwFYX1wUCSM7gRiqKiGkxJk8ZE3sj82EJiUpjhPVyLv14XK8QF3p0PsaqU6oD9HgU+ATgdIZ3fvoE3pHphMVkY+oAPwioSbVwoCsAtcAO5LDddPmTSjYC5hVuYJ8DPYuMFXrb6ocCLGx9PfDh0QJn4NXygOX8D9zN8VFTb6RFco6d4gbf/Bq5P80YWcIHP4ypCmje80mWyOlSL+zFcmKwUE1/D2Zogc3Wm2Dvy1/Ds3+E+jCqS+oBHSlnwUpLFT4O/1cxsKz6LrRgFeWYFoJvkguoO57jD4cCsd+XOt1/CDVlAGAt8cKTlm4z3E4WR7AJXROodjuwoJHzAvQxce1m8wJ/TtaHDdd0f/udmAXiPn8clb6/uurrWW+vGy+I1VuBPSJEJlLHingSH4rTOJ729pGzwF2uDv1ob/NXa4K/WBn+1NvhS4usXjKwhGY07aS4l3KZirYHUQ+LVvqncgTvWTdv/ZKTHcKU1JZ1xU26TmgzYAOjJY6XdgyshBQ+vWQG9eofnZAuVC9PrMpgjW8ZJWxFbXT6cBhBUH8Qca6y1B/ByGOskCK5n+BgbkUTDLmK+khf44GLTWriWm9YPBKn3MHr+KWvtKzzSaESqvQb0dIGnohhaDx+UNoCqF3ghcj0rTVIt3ksGcr7avsK9ywWTkSfjzAUuNiPi+ZQjpAUeeiC3MzzyEPCeD75Z705/tNUHskNroT/Bx3Kaub6FuwI3H3BPHkCcn75b7e/0R3A/RfQBaG7hPlgMZFXwSGaBxwhMCY7hZW0jo761gAoj1ts9eHBiEEtwZryBI7vRaYDb0dgF7qfWTYCbTGAZNa0LPaSgsd4K/FHW4ksKJf/pivfzTpGPkl/xDv8teBPxuYE87rfqv13P/V89/w8PentJ+cG+3fW2DUJhHH/E4QAG7NT4NZaQL/z9v+NwstZdqi2dVHmr4K8oWISbn3JjSz4FnlsFnlsFnlsFnlsFnlsFnlsFnlsFnlsFnlsF/lbPbAEoVngXNQ+ndI3zez9bJgz2jsEyhNv17SMkPhb+DJdEu6ki/Vu4bmAnxj9qm8d5wMgLI0Qe9w0174qBASxDWIB1lIc34p4ansH123d9MeiVqW2Cd6qDrWuDi2svVkmoTrIBrFJSWZwWG2wLfNINIsZxXxHjAYcBhi3BxLDdQLNBkBsgwhP4lSxe2kqDaaLWKiIy1PRVa3qX6jQ53VMDchWRREWVS8uZRSnm+5CRHNOqwioPuGDENXIYOa4jEOK8CZZqTD89gdeO4ZRLcIWapCJvQDq5oZ2xrkGlcYNfcSF1IQafC09qwQdceJ7DIIfhhZn9DvdGjHEcMazA7WgQ0j+Hs9cXMqTRXSu3wyVARB5wTmvSb/BmP8zUQZ0KFywS9oCzQBwHuR3/eLMsy7bD+Q4Xs4qfgUuaNHZga+pXuJsS0LVKqcsjXJ4L392AD1iHO3wWkArAAU87IbyDbwvMZ+BwpBLcku6ur/Cmd5P1VEvuUDl5wCVpeT0TvnpmRvSscIdvvMziF3i/T6K9wsOsgue1+QycySZ4WkhT/ROOmrx9IWq7dOUO+H5qIonTC+8Vj20PJ+Xf3blZ+2HHfNjvrN1HZv+rxIhfW8PX37JO7UQe360vgPeKv9UrAeUhBVlW4LlV4LlV4LlV4LlV4LlV5s7K3FmZOytzZ2Xu7Ef7dkADAADDIMy/61/GEloHCMB35jvznfnOfGfjfGc1wmuE1wivEV4jvEZ4jfAa4TXCa4TXCK8RXiO8RniN8BrhNcJrhNcIr/nwqAPmmKaiC3SuVgAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/outstanding7/experience.png": "https://static.topcv.vn/cv-builder/assets/experience.cbc278a5.png",
        "../assets/images/template_cv/outstanding7/info.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPAAAAAhCAMAAADQ6dYqAAAAn1BMVEW738i428Sw0byqybWWrp6Imo6euai53ca01sGkwa+SqZqUq5yvz7qOo5Wmw7CPppeMoZSYsKCZsaKy076dt6a22MKpx7SoxbKjv62LnpKsy7ehvaugu6qbtaWtzbmas6N8j4OGl4yClYl1hnt4iH5lc2qKnZGInpBtfXN+k4aBkIZ6jIFxgXdpd26EmoyJoJFgbWVbZV9XYVpRWVRITksvmzcBAAAEbUlEQVRYw+3TR64UMRRA0eecypVzztW5SftfG/1FFA1IDEAC6kwtWb72M+x2u91u93tI8pM1F8GPoMnhDQCkm4APTAvgTJ+WvVwY34EmXWmpPZBV7gvu8bYwkS0SeEKucw0fYP9I4IuEwFdwQDP4SmUT+LnlEpAKPji64HgfN7KtsS4EJQrgk1ITeMjsql7SAvhK8uZi7e1w7A6mb49QH+6GXxb+5lrfkpdgN3CCshPUd3zm0ESpaEVDciqkH4e+A0/UAfB07ZdoPrjjVGv4LOyboS44LzyHDVg7ceP4g2sHyzBlEWUScsbdlccrKyg8eyOXumPXHPD1fF7OcTfDCzuC8CTYc8QUY7kTmMi4TGnWAbhhmdetVzzOXn4OXubFvi6XYL5MVw32YI568vprehYfX6IMcNDgAttwnBEVUCDqz1kx18MZwxP1dny5u2NwfnVfJgJfYENVrk8UD15WNFlhIy+IuS+HygSneGRSeIIMaLR4TRg8ad/VV327HXro83xqpvuHkaThgIgB0A1jhRgDwuqwmD1mJROPYBUYlw7a4u5LcPvWf21eXfyJv0Ng7teznnV/JXMlPgRLW9crBNyPiJ9oeASjyoPUr6jO4IlaqvxA+6N3mLZlUuqrYB2o1X0JfhwyzAtWhauJrWS5P+hHcOT4JWdksNhHDJ69pYf6+IqdYbsfJz5tWwwPKpgjgwG0LJhOZ8rHaMpYmlq5vgQTa+OBau9LsIiRm23XQ77F7gRQbnFKqjLnURyjjz8vCzEHGSrgbYYBUiFjAVwiXiN4greti51ctZ6nOtV+FYw4wW1QOcjFdioNDevEzHkpMuzUXetmEcFhigOHoFRk8GzzIqI7Pwa0NVmp0vTj3KdQAkCLZKbWWdJYMiBhSlAmIMKiaaKmy8qkhK/x2yMEfAJ/hmwqIB0HVIUCfoXTws+09KUgdWG32+12u79Fcwzro3Xu/S2CZ4I2KG2gpqQ0BHGJTI66MIqpTHXp6BK+lVaZW2UAuYYHHBME34Ui+CLLARz4M9Arfht7b1KvGteFJ5kXqGoAmvnmkcdaXhs3NjVrNSO+X67wrbqfzmf3tnXL0bnflPfGNEeiEwBInQbzNI54nhKVxKeaViarKMcmjEeaXpBQ1Mmp01BqCPw+3WG8LGpJFidK4AnnVZwMAMa1ARNhm68sTZg8NwWjJ4/O8C3n1eVw2JbXt37cXt2a4zV+PV8kPLhrT7l/8vSq2SqI5ymu7Ur6MLVB4JNeSI27IRp7Z0wL+G2iY/n6PHrzI1h+J9gNuuoRrGKBuIGwFcTHIQHcxSg0SeY/T8zr/rJsF98b75t3uB8P1RtNHQEA8hSeZBGeVFgwg1rjlYXrFdHJYB001jkJ6clsRacTKqICfp/mQqv5joSWyoUnyFAhavBsh3UCRKKARNa6KgQnRJGW8CTIVIfGPu37iI2E5149KYoAQCjEhYtcIUmLq6RQsvJ5lfDIH91SST8jru/kFnORJzn8w1odwG632+12/5/3+iBjFpbHLYIAAAAASUVORK5CYII=",
        "../assets/images/template_cv/outstanding7/interests.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAACICAMAAAD9Ldb4AAAAflBMVEX///+738ju7u6VlZXq6upqamqqqqozMzO/v7/19fWqybW1tbXV1dVVVVV/f3+AgIBgYGDU1NSz1b9mc2pESEVVXljKysqZtKOgoKB3iX12dnbf39+fn5+Kioo7PTyIn5CqyraAlIeRqplufnSiv6xMU09vf3RmdGvJycldaGGkOWH8AAAEz0lEQVR42uzXu47EIAwF0KW6EiXYQjS88lL+/wfXIZlVimmDVoErjcdm0hyZKfKjOs2A95YB7y0D3lsGvLcMeG8Z8N7SFG5m9W/SFF6IzG1M7jNpfT9rkCZwtzPnyjEb7iyLy5vCrq54ONUgLeAewTLqqh3/rZjWG5yX6/xV8GqekI9eupmPRsOe8Et8/XjCG1z2BnCDRWryRZkpgHw+xkIIpC28nMzn+mcGOAn8eOrxrbfY+I6l1GbDGneBSqszOBoLihO4rj8RxRxY4BTlox5OC7iagLAllYSoTKimz1WflaJQh4yolCdd/+MLnr7tTeBKRwYZBy89Q8ofXNcDGc5eUuEsw7NpADcuSZ3ge4NHrFIdVg2WhkjKF3g+wMWa98ANYXORUITjy4Z4nmIp5g43geQpetHGlbYAQhasrd9nJkDf4coRwPpNcIm+HEYbqZ/+y1PNMl5L+8uA95YB7y0D3lt+2Z8DGgAAGIZBz/yLvhCKA4primuKa25HWnFMcU1xTXFNcc2zPy8rjsNAAEUvVJWQkBzJGyH82M//f+EUNgQz05Ami9BNcsGy0AN0PvB36wN/tz7wd+sDf7e+Bc8hZAUvWsKTwJma8kw24+ngiV4ItxDFViBtCle4KDwPTz8ePsPcEimGwgnvWYGSOxBTjgl81MJRUejqK9mHrrkfJ8+d46b16D/taCmhUMLKw14FH+ECP4dFskU8aUPaSrAsS2KqoVbUJDThaLYULakN8bHtwZabn8WTxW8qZmFfKEZsfqv6N/OgV8HLNClnY1oq1JgixB1PBmwDU6iZSdFGEIjC2RZsZhPYsk7wp0G84Uk4bvtumrTYsbrtx/qjXgRPt9t9al2hdvpe7f78eHMtuHcC10m+wFMTqEutJr5FsSvcZw7nDg/yk+DXbMZpqqaX5+cTvo2v4KVZYs+qmv6H598ET/tgbSDn83fYIzWSfO+ExwqbsCqQLMogVCj6D1xgib8G/pc9u2ttEIbCOP5AzjnkEJuXGylR7/v9P+E0ldXNsW5QRpz5XwRsKPRXQcgxMgtma2SfMWcCR68gDuywwjEyZ4PQo/wBGhNGzv4znHP0OAr8PVVgje6rbjfVlQfeIyV8yogSaqjAX9LATpjU4duMoI5eBwc5R3hWGlBH7ZBythr8bDX42Wrws9XgZ6vBX1BOOE4/gosCuO1YJKWhtwAFGRz2JYv3xKCefgS/0JcHSrV2CtZSctCRxOKLQtT/AFdn13H61jJ0ZUdB3X1nXgfCEvHoAO11+VxMJ7WcSp/P1bfwMignWHYmb+DzQiyG0UUvbNEvU3eLpdGkAFAMwgKJRmItz4Gnc/UC57komBwgEzgB0/ABHiwQUpcBd7+Y7nAeMFPporgxZDrCBEa9393xRdwxLiht4TGHEG3nAWsWLUyBd0w0XrHOG8UcAT63h/czIOOiOzj3RKQ7uMne+3h8ePnlVwSB8vABPl4BSwVeLpQXOJUvhnR4uBrmxzh9C6eJs9cVTpw5WGAdpbtwWPgj2o/T9yN3BSH0qLtfws0Vz7tlZ7iO1wZ/fEhJ4hSV105nZ6vBz1aDn60Gf2t/DgQAAAAABPlbD9IZpDmuOa45rjmuOa45rjmuOa45rjmuOa45rjmuOa45rpHjqACoKmtKxduqjAAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/outstanding7/name.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA1AAAACGCAMAAADkSpusAAAC91BMVEU2QE+738g1P042QFO738Q6QE9UQk9Hia27372h3chhqsA2WYm338iHblO738BlRU+72qE2QFqz38hUm7iZhFo2QFdHQE+73re73am7yZW73a27y5U2YJGMc1NHi7E2QmqUelNqSk+72KG7v4k2Sn63r3qhkWNvushyUU8+QE+U3ch2wMhdp8Cd3Mh/ysi72rQ6f6g2QmadhlphRU+q38im38iEy8i73cRstMNLlLW7yJG6w482VYc2RnM2Q2FHVV+33Mi507Y8dqE5bZk2RG42TWs2QF9tUE9QQk9DQE+u38im3ch7xMhyusNlrsJbpL1QlLW70aO0q3eupHKsn25VRk+o2ciM0MiU2Me73bG62aY9e6S7z5o4aZRqf382S3mOd1h2W09lS09LQk+73ciZ28iP1six1cOcx79Yn7u72rhDh61Agak4cZ02XY24tIGyp3VLW2I2QGKQdVNsVVF+Y1B7YE9UT0+G0Mip0sW317+uybFIjrG72qm71Kipv6dtmaS5yJy4uYaKk4I2ToE8X36mlWagjmOdiV+UgFtyVlFdRU+Axsi72r+73b2QvrldorhUnri0zbR5p6xVkqxDhKlmk567052WnIM2UYKxsYB8gXo6WXaGiHNdcHNwdG1UY22klmxIX2xeZWVqZVmUfVeHcVaDa1KCaVJfS0+c1siRzMau3r+Is7K72q25zqqvvJdTd4i1toM2VHk9VmiLfGKXhmFqXlk8S1hJTlZdWVRkU09GR0+z2siaz8eDxMSk3MN7uMGkzb+Eur1QjK1HhKl+naKdsppFdpldhJKdqo1ohYw7ZouTnohSbXpidXaNgmZ5d2ZRXmI2SWFYYFpSVVmh0MSOxMJ/r7yx3bdhpLdYmbWIpq2OsqlhlqVwhaVdg6VynqFWhJmos5eztJNCa5NYf5GUpI1Jdox0lIKip36QimyHd19jRV92alg+Rk97tLiHlKWdv6Fli5lyi45df46ZkYlLa4JDTH6doHpld3qMenZuhHJSdJnfAAAKWklEQVR42uzTMREAAAgAIc/+oY3g+gN0YAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfjuAUFAkFAgFTUKBUNAkFAgFTcfOecZEEURxfF44FXXVeIrYe2/YUbGAigpYwIIFe0MRFRUb9oK99xob9th7j713jcYSe+81MX5xZt6uc7qncAl3MeT9vhD27naXZH/33vxnBhKKIEgogvg/IaEIgoQiiP8TEoogSCiC+D8hoRzGLRWAVz/1e05wT8OcjUcDgLHMlp4pYVgHlnBSpwQkZvCp0fsYYUBCuRyzUJCvo2uFYjUDIVtyZkMGgMbJHBcKsWyJYwRCQrkes1CW8S4WqvRkcM/BFFUHgmc/5phQwxa14Xw52VUDmPq6CCMEJJSrMQvlNwiGRbtWKJZCg0Y2DtSwQr5MDgqVxShxsR80SDsuGSMkJJRrMQs1774VFga4VqgxzWFoHWaQviJYJjDHhdLxmG0Fz7WMEJBQLsYsVN63FcG93Z9CpX80LRz8TsWxHlYYx3/PXh4K6FWgElhys5rlsKigEPqnFj/sehBiho8egOcuDpnruL3YOAimDF9ywNRpjmMGVUrAvHX8p//caeG+3jNPXSliHG7C/Ed09fX2OxtnXyjEYzrAKHEzKQDK6LdUCLIWxhe3bhzkO2XwBYouSChnYBaqZbrU66HVut+FylUfJFN3hWlQxiyUGAZ59mfIgs4yY/CYHQiI104m6AYtJvLqIdnWkdnSuhxUrst0KgE04ec+HQo6C+VLYzpDVOwGkESstieUKnh4M3aE8j8CSMRl6gpJKOeCQmXOw4I1aFzEViiPhgCbl9zY8eyQ512AjHaEYkO4BQzprokU3O24FfyW3NizYm4oeK7G7M7zY+DjpVeX8SN/9HTVioH7GobUqsB1kNH51Pkrq684c0j4hUI9Oew3emXvrccAsjU1CWUueGahqtUH2LJo2cURoaIKEySUk0GhctWTgxAlVOoSsKm9zN8mg12hZFlqNYkJateHFu3lZ0Kisfzwx70phuHey6WokRr0QmMN5mgQpZ+vRyCMChANIhRkDC/eUkxK5S8K8oyo3FqzUIpI4HdnEgovszCTTOp5SUzOCBLKuaBQrHUQ+DS1ESonzgvhg2hPKDk7m7adMdYZlUnoY9mln7QhpM2BQlXGwjIGm0Ib2naBlhhL6CdKP/fep2hDBvc1KJRR12bgTZiFUhNb+TKZhBKFkLuO1hcCr/6MIKGcCgolh/WWgkootwZoBE4Z2RdKpBW9ZDg4RD73pevpwR2+1ASFGvtromnepN8v3A2nv1SpU6CPXCisVJzuAOP+JVT2cuDT0SSUdN1HH6rtec8IEsqpKKFY22bY46FQ+MWuR3V2hcI+bNNEHA7l7cAf/+bQand15GlK0cSxDPhGTq6SkLcs+43sQcIBrIbLmULWI0tfFMoILiKxHTQLpTKOfGahpNkFKIsgoVyFEoqFBfK+DYUSroijyBD7QnGCsQD1DOLtoSwGNkgVMmClMQuFIy9cHVG6nvBScO3MxqO+IDGEMpL5UvEIVcPKx2gmoeTnGjOChHIVSqjaFSHthF9CDYTM6YwIz75Q6qkOxhEPD+lsyZY8HqFYmMZFlMWlgOwcz8uE3DsmPNzXQaEweLeX8kWK4wQJ5SqUUKzKegjZn6AKFcyFUvO5uSZjfFalhKxKiviEqtqMt4r8BsSbsOmEJ0sPYMvniFCYOFhWMfsVKooRJJSLUELh+rqoIt25I7INazHRSAhMQs0whkZhVl5jeB5QEGM7njs4IJQcYmUUH8Mppjma6Dnxko4KlT0II0MlVJ9ixhiqF62bJaFchhJKWuS+OlIK5SFqj3EUheoZhI+meFEIhTWGO9QNsnL3UML2CRcKrdgWEKZBQQw/sMhwahdzUKhq9fWUX4WBVbsYKV8r/X07Ll0awAgSyqmgUOp7PssDTZoUjMkb5meQUXV0GHMLoTD6TvtjILcC9VFp3faX15PFIxS2jEOjK2LYbrR+OPXlmFC1b2v6enluZ5SRUhjzUJ5rjNku/pcRJJRTUUKhHzCYC4Ua8QEVx/9wJyEUblnqL8tBxU4oFCo40yoLCyrn9Q6rGg/w1sYjFD71lm/NcR+HnhkKYjeE4yUTKFTsMYCp7RjDMoqLErc3AykUO6HpM9atU4rWkiChnIsSSkhTAQC4UDLzg5FL9+54tsFLX8vnJlb3Lbq64utNr5MoFI5UAELkI4xr+SLkYrybwEdj8Qolsw9vvB7K6bVk754VI0J9HmiQ78aeeITCDYbnTk7TACJ2JvvVn27hawc/Hxp5iwuFbsNmWstHQrkGJRRSIxCFwq94gdebFFIodSRiZw0NcqsVeWrvulptbnnVMf4xFFalX9Ggxx0NJCP3L2gOwGd9/y2UwrJlN9N5GgqSkN1iaEerzUkoV2IWKn0DQyjchzTz+T6chzKOgN/Z3SI6y6hW5KlVq/p+qCmDn8clJJTALlFtv3d7MS0cYuTOqdNdff2+ByREKO+Y4RfimCJ21iDNe+b8ASwDRiS4Hwq8aT8UCfWfMARgFTNjiCLWyhFJFBIqscGV4+Z0TPWIvMIQSRUSKrHwn3vvVYARHGCubUam0iEdGJFUIaESBwzJV2N0p+EmDROYI1gKMiLJQkIlGidkBN774iwr/mNZMzuWbb2lgQ/N7SRhSKhEI/1sKxjB+d/CCs7IaEYkXUioRCR21lFf9S/BzJw4yONpWh2XpCGhCOJne/f3WmMcB3D8WXMo5McFyo0S7YLa3ZSatc24YUZiZiVLJMuvWkuK1qSk+XHhRutIQrRSymqlTG7UFGtLzQXFlYRLkgvne87ZlrY/4NN6vW6ei3P97nk6n+f5fgQFMQkKBAUxCQoEBTEJCgQFMQkKBAUxCQoEBTEJCgQ1N92qKFu/YNnSLCle/9dfeKW97+JobtvO8tEUJ4d9Uh+HoAJpyufzL3ffyefH+/+uzE7syc0S1JvHT3rfjryadzfXuaorS1oK39sThaBiqdw4uQe0cuFsQdXW9DzK0vrEA4cPHd1bOkXptrP94xBULKWgCiF9r6qoWNWVgtry8f2m89/K0RwsH9s3Nl4orj19TN844HjXQAQVy1RQS5t2rB/KFa4rblS/q/s8PJgVHZ86/DKlVIirclf71YwwBBXLdFBnN5Qe+S61Xk7ZbJ5f/Lk5XcvW1JzOZbX77RuMRFCxzAyqceBhetRbvb0UVPp5UsvajqxhoisjDkHFMjOohsVHktJinOxmW0c2ZdHw/RXNhb3wxCGoWGa5Q008O5P8zJKGgStZsvVrd9oKf+p3qyFUKIKKZWZQ61rT3o6xocn9UMWtbss/VKc7VmfbpzZDqFAEFct0UMureu49L/7Ld2G07teLpysnB7v1vX9Grl8bLK3GOWYIFYugYpkOKnu9r/5BeQ5V2DHVPf3q0bmKvi8/ysPfJYZQsQgKBAUxCQoEBTEJCgQFMQkKBAUxCQoEBTEJCgQFMQkKBAUxCQoEBTEJCgQFMQkKBAUAAAAAAAAAAAAAAAAAAMAc9A8xe1rLL+TsCwAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/outstanding7/objective.png": "https://static.topcv.vn/cv-builder/assets/objective.a9ee6bae.png",
        "../assets/images/template_cv/outstanding7/reference.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAACICAMAAAD9Ldb4AAAAkFBMVEX///+738jv7+8zMzOqybVmc2pESUVVXljq6uqqqqp3iX2/v7/U1NSIn5BmZmaz1b9VVVU9Pj6VlZVMTExqamr19fWZtKOAgICAlId/f39uf3Siv6y0tLRra2t1dXXm5ubMzMyLi4uZmZleaWGjo6PKysqZtKJ3iX5gYGBMU0+Rqpnf39+QqZmqyraysrLW1tYlYSjjAAAE9UlEQVR42uzYT2v0IBAG8Hd4dISAiJcgegxsSEi+/9d7dSzZP8mhCxZ2SZ5DreNM2x/MpfuPTpoLfrZc8LPlgp8tF/xsueBnywU/W74L7hS1yV/D137dF/tEv8u+kUdqkwbwWdtyRE0HcZN35QzT3aCg6VfZGiMrIqenfjHUII3gHfyaDwYdRXEUOKuN8DZcptdpVByoQdrBYTa4e3rSqlbCuFUgcKk+9buXYVfhu1qDtIMz5gpfDTBypMCJaOAVLuXKtE5WKrnJg4OCKX0ZovN1LJ0hf9PnYvwRxny3GT5Ira76WGaJjKlr9H7awwOzE7hBtBN0LvXl4sPKPgSGkUqONQhJAZ3lXNDoblM+DYzVkNmZSiJiaVCop+xJJ+89MddVeD/t4XZBLPCEgUjd4RkKS7RglMp91Yf6sszlDLkzEYFLZ0c5DoYocZcbpSZTnsuD/iw4GfSM8jc+wcUplRe4rnA3DuzzjCldBXur8Ftd+dp4q/AENsbAfBhc+YmRMeEYPhzDB3RLdwBPx3CdM34YnALws+pJ4IvAq9eiO4SL1e7hddVXPT/CpUaOPg1OBihfwmygs2box1Jwnu3MXj3AQ7/Bvc+PB3AaMM4D7COcInQf2MrvGD4IfitOxYCGLj4Yg7K1DHCiCq93vcEXhs/te7jTgA/0BM9ywDj5ifEj4E9RLiE+/TOh1GvH7rLPNr8flaNBmsLj0M+MRF+RlvA0yYp+R1rCZUW/Jd/1QcQFv+AX/IL/Z6fuVSUIYTAMf5jCQhAkxXb+hKmd+7+7kyO7s8V6AzPJ26ikeiDocIc73OEONxgCTBYcbiyHW8vh1nK4tRxuLYdby+HWcri1HG6tX3iTBEAmOGM1SPC8fuGdqAGUP/A5ztrxuLbw/IZ3OYEwJQEptUMPXO+ul15P3LUdPFJacCqFOrhkGsiFCx3Qor5f4IxGzA13bQeXzOEfHvU+mnS1KjwEqgCaqucbnm/8MW7hJ8la9aU8MhdC5rX+WqX4ap/hfdvCMeiCJ5IWv3CtC/NT4aFc8Emj8xeu4xEqgUsfD4T/sWt3LXLCUBjHH7Y355BzIWkOIiQpFgMBod//49VktuN2MpTuXOma/8W8yFH4gUQF8esOf9vWuO/f3u5w/NzeZVuwbOfEF4M3/WhuceqOy3lX9B3+QmXdP3Mvw/F24mtZf0i5YB1+tTr8anX41erwq9XhV+sJnBVAkv3/grbEJY+B8DHhmuLwtfCbxTLuLYQmMSazSY/w1ZhgjTk5XL2hYvQJIKHyhdWndUXNSRleyxAJsApqoynTkqDeE5DIGKrHEsGB+gecwmIDgaOfR0ie2THWvG3jj/DI8wgzAWx3uOSJKbDNClcHECzHCQfqGTxsZcbsAZ4hBB0gGTAzZgPYv+AraGjh7nYGRAO3QgctA+nwcELVOakCsnEcyo/Cc/IIp6fwYuQ45g1OZYgXQE4DT4BERA/s8PTfcD8rxlPCi8QuyAIZ9Aav22ILTxGwD3BrQeEPXDKBzwJXG8Kk8EOYMr3D1YXgWrjGEKcHOLkQR36Hg3MYjw7fU62fhD0lnT3aSNFE2FNVcx54Wwp+cYRPp9H7YHCgPgmHsFe8EHl/qPuX/pByuTr8anX41erw3+3PgQAAAACAIH/rQTqDNMc1xzXHNcc1xzXHNcc1xzXHNcc1xzXHNcc1xzXHNXIcFfiJgUzqirjGAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding7/skillgroup.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPgAAACwCAMAAAAVBFM4AAAAhFBMVEX///+738ju7u5qamrq6uqqqqqAgICVlZX19fW/v79VVVW1tbXV1dVgYGDU1NQzMzPp6el1dXXf39+goKDKysqKiopESUaqybVmc2pVXljAwMCIn5DJycmz1b87PTxufnSiv6yZtKOAlId3iX5MU0+qyrZdaGGRqpleaWGQqZmrq6tdaWKa+iLxAAAJuklEQVR42uzYMY7DIBCF4bxc4HUDCAEGYyfR3v9+O46060QuUoXC8BcGpvuE5cIXdNqA99aA99aA99aA99aA99aA99aAtymY49kENK8FfLZBgdZOi9Amh7cecZmY0bwWcEcDJM7w62TXCe8lxoT2tYLPXA/zsC+Hc4OawG+UgIcUwOtDSzJHygTcKukWGEmOnAFY0jqHb9cGnqMYIEQB7tTdxqs+0WGhPIquRtVeOCFx9ZaCb9cGHikBm9YgVmxZNUIijDdApcLvQKFH3MxyFjhXJgCZc1bblqWChUC2VeIGt4CnN7zjRPAShBlAdE8wdvjC6nPd4dt6IrjBxBiARHHQdvjMDLg/+OledUUWKjlTadoOL7znxBf4THtLp/m4meezAFG32g7XDV2l+YeHbXCSG39J3GEUzHHAim/XFD4lenyoiL/90OPbNYULLT5lHBkLGtTyxg3wuWDQoPEjor8GvLcGvLcGvLcGvLf6hV8vXXYd8M4a8F92zHVXbRgIwiutL+s4thLb+YN4gr7/A3bWuARKy2krSi8wEsRZjzf+gCN5zqvpDf5qeoO/mt7gr6Y3+KvpDf5qeoO/mt7gPyTf6H/RD4GL9dUQdFz3ord0R5MhVWFch2a+NLhA39AH7aszTwXnegxcdDfLj4DHOsChYL8BPrsPwXOkW5W4xGeCzwlvtsqBSJrxvRQbwJsQHcTMJra+rVaKzm1upqnEYOA/RLw3gwvA1QeZT+kA8IYa5uxM8EW9GZ3H/bjpMhfdSplt6ZOmCakOen8QvB4BXi0NSYoEmQmv1L+plqpPljjrVzvzZjnSjBrrmqNbA02r3RwZtpELMWMKBvjUUHStW9FCaPWRI3y1wgc1jp51nU5aNPG9mlAVwzAHsjBPGRe79d/V6KHj6QHg84ROQ5nZmxM4C0FKv53BE1HYtDZ+/tajXNS/NNTipc99+dG7iB1nCX2tr1iFKS2hcykZoyDTQrLKl+e1gL45oX1viklKRj9oRtk9DFyco13FT/kETiouHXIAcQfifAV++qDs6vjSN+/gAa9M87ayU9zRenzaWJcCbEMKqLTdYK0+yCTdhxmPgx4Cfq3c8Fb9R+DtBhxlIX8P3KRF164NxXVHjJvAALYhPoPLJF+Dx98Hrv19pVQonsBrJWGrrOYMjhqt1+A6Er4HXpJQdWQ3Iu8Jcto5Y2w4YB2aiCJrtR1XIQtzBz9NKnhOhqLr9w8GJ8suuYVs4u0EvvDKzlKc1u0MLgx18Dz5Ab6gtNUbcFhl/NRr7yme2cmps+NIhXl1enEcxvMSWltUlwGOyXUFMvUyL7oZ92BwaBGCRPYCqaRcm7ZAN74r3ZaX0UmuH7Vc+8a8XLQTTCa5sC3leWf1vO7jI8fKC/2sfKVf0+YP7mptWP9QSMk2Cj1RR9ve6ewN/gZ/g/8w+DFrGMIgLHQtNsNhoUC3Cp66RA2N7suoydCQeKGn6hY8OhDokSiV74D7LYTQ7oCbKYTI9qOwC1NqX8DrRVh/hm7BTQJaPz1pLA49TkfR9HsGt93XiMo8AjWm2yU4YS6NGG3UJCSH4Sql5XFupehGkQ5oaDDqYf0JugXXb5qDo7hhb9aDlpMvPf1egQtnw5k2p2E4YNp/BT6NGK2nHFhmtISrkuWtDXBk9x66gT+NvN7D+h39RnAfsUfW4+cacNeP2nJOv2pIzGwoc619+xn2QpJkB5/ntvrTektJZueoRuJFXZpIOvg8Hzga7cwZ4COvo+Md/U7w6G0kl8EymS9Jew+BpCzjmoTCdiJ1zk15B/feR6FJSA0++MDiyslVbHeBE6aMNNo7Kjj/YfDCroAeqOkuuDDnM/gCyQ6+//8gbhQ8i7WMJt01wAdg0csW/wZwSkzYJIicRuyg4CP9ynwBXn1mEcC1tQfxRgA3ZoCfw3UgmRzlBFyMKdA1uCR05mUHL38OfNOdcSRakHhrh9b0uyUz8/lv3OtutzrC8MIuWQX3YQdHta8nhyI3Gq5rcCo9ge/gwmzonp5wcrtJ1iC71XIRo4nz99Zfuu4XP8y2zz+yho/2JJH+Eb3P6p/bN7vdxkEgjI40DD/GIGPsm6rv/5zrgYnjVZxWWylRvXCkxIExKMdK0xC+tEYXb40u3hpdvDW6eGt08dbo4q3RxVuji7dGF2+NB/H3xtbd+rSS4YG3i5MFUGQNQWVMcGQFH+EJKsMpxgKQVjTBDU+Ms3vlyRMR1PAGcU7roYddPFs44tfVwhPsiXj2222CTz8dx306Pzi38ADnJ9Z/wA30bnGFJU441hQ5jcDcg+MLgBr5UIqjAmbhPLlaJGYup3G/XseSLufRnGV3anfhk+vQUuGD9W5eoKCzBu7nshq2wkvEM93F58QNE0rEfC3x8A1CQyFC1k5ncMEQuu1AJrgyPlEqOU4JrTv0Bm0J4ukFBrWN87gAIm3dIi532niMgInWBICGEtY6wtYtSXc1rITmBeLHvPqgy2NT9xBd2c/fkOC4m/gpOc0dXOcbC0xgWXwPrc8lpC6bjqUCUVcVfxQvs7t1q/AEnEbfbpI0oVzPxsjzR3yB+DGvPhiPtj5h7Thinri2p2nXpHfxQfE58gYoen6rU7Eicxf3QeuERTzTX+KEUuHTyOz7i+jUHGyZHiU9//o3N51v4mqYJaBzyE/v4uEmPqOIS2jdckqA8kF8nTZOxfcKn7aLj0Frje7N4ha9iPNFp4O43ap+F5ctcdn3LuISWtdeKiI+BwXKAdLWHf8Sj1xZRJwbHve4r9dvFoc5zFVcIua7eImxD1bEJ0yp6rlQw+wSWpfN8VrJPCWVNDqu0n0XBwoJZxHnhsZyJadyb98hfo61T9qSIk+LPNoDAnKwxwHSj1FaglSOs5eLKvzaz+rOfBgERpuPlOFbMMLXaO/LS+iXix9S644ifM/nBF8zyTy/XfwqdPHW+Jm4MxYuzlfilBTATAAPiWqlI1ycE/F13n+tTXx/Ir44uDqP4h8pz2oZnSyj1QhMSa6PevZLXVlbWLbiMsNVeRQnNHEMmuRn2U7XpXA2aLkbfV1ZgyGA8D+Jg4636DjMwVZx4wHIjVgWyrFk1yPC1r4sT8RR1oqoqniKt7/xra1y0oOCEM1lApz/JJ5L4lzEl4O4ppJdJ8IJLsuZ+FLEZSHs7t8yORHHBeZBQRw0XJcTcR88i9ckuojbNaEBEXcD6hAB9JX/qYn4+fp6euw8Fq78ShfxnzAaAxfm5+Kf/tKf1/vqrDW6eGt08dbo4q3RxVuji7dGF2+NLt4aXbw1unhrdPHW6OKt0cVbo4u3RhdvjS7eGl28Nbp4a3Tx1mhZvFH+ANedrPSKwBsFAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/outstanding7/thumbnail.png": "https://static.topcv.vn/cv-builder/assets/thumbnail.7fd87dc1.png",
        "../assets/images/template_cv/senior1/activity.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABqCAYAAAAoaxoLAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAA8KSURBVHgB7Z1dUhxHEseregZLbx6dQI2eHA4Ljd8cDguaE4BOMHCChRMAJwCdQMMJDCfQgBwbfvOgdWzsk2idQMOb1stUbf6zqnpqvj8YPgbnL6KZ7ur67M7Oqmo6K5UShAeMVo+c9LufUt55+rSVNxstJSwUj1pA0x9+yXSp9J52WTCt1j+SkOZKWBgS9UhJq1mFhHOPdpskmOv0+zlR9lAJCwVr0PT7n6sqSSqqXM5jDTM0nG6+arczPiiVmsO0Ese7vq7yQbmMLrbZFz6E/M/fGiPzCxjTyv/9z+bQ8v/6K6U6psraVm+edD6l/NLe9vE50r6D6lG0nfIblE6YL2X80UtLJ/Tz3Lbb2/RbDycHhacrq3va2n0SXBfJWpW+WjtRWu/23ay22iQt9s7HQzf7rC98CGn1p+W8+Xs+NL9AqaSWX63l1piD/F8f6kX6l9km1fOdWlqqhDCOp/Wb8KCQcO9TfjXUjQRvOYxRIbiU9n1cDwhmQvlZaze72r6yepR/PN9Vwq0wVRfPwqn1Ph9Ye0bbKe21SA07YejL3daiowrd5Iz3SjQmdOnP6Kij/UIYhz8dPaHppM9RNZ0k79KXr7e4nhCwxP6KMhGHhOq4iEeCx5qzmwoJ696o4rQxR5ba6Yqm/Fzb6bnUO3RdZOhwS0wloHQztvzvweXH84y2TWgkfzorBFD5MSCF+UMnbMbwMWmqE58+I+1caJ8Qhm3MjDsv4l6cLdNxw9eLBYiEaT+ORxpuCxMkXw8I49aAtu3E9Y/hbl1rftisNtvIj9tu7UG4LhxHmDvTTpJS/DFeIAAJEvY/80G7nRYx207bIIq1JtzImroFrNOkgIWEhPG5Dz+O6tmyXuspf74X0q7DtGgkfP9rFLtJcoQyinyFuVOOD6ibrNF4ci0K+lbNiNZmE3MwC2FOSickLegGUxrTpX1jywlAt0xjwA3rDivUrWIcfFKMJ28AafoT67R9lq683qHfk3Fp+P3q16/Y3cef/D+/T/SOlcbBVgkTU+45zub2YlRrJ+janObNDzndGGjZ58p8s6X8TZ2SShgDYp+08R4ND3IVj2FnhHqEVkLDFtKEh1onezbqIQbhJ1GX3WEDJnUDoCHJo//nyDzp6uLpBr3FO8OwqTB2nBKarECQfLdYavi8WSvpILhTAk1pjd4Oh7jR8az9pnxqNo6UE0zM1vfGJuhM0oRbpFuDWtv0Y0qGtN6V6hp/DcUNBUpOoMNkRWHmbAxmuYo01HPft2EyVbmPfzvqMW2hh/KANGMWaeqB+Ndp2SBNKsyXaSdJbjJkzEYI8GO2oC1dd9vRkim6Yu6O45tu2ltqTvDbgs7kywm9tReuGroWXinxr9avXP3MQM2Hh5ME7u2AU60ib/PNP4pQ0y4exFnG1cJ4ytNEpht+5MZpeoe066Z170CrOEf7dWgW/x+YlMPcK6hCU9Lrnx3KZIPGeRDwIzU7KZXvNJe1aQi0SbLDOzS7pnAIrXvvSS/o6Rf1xIOUh2HHIEyS7GuXttC20PYvqtlB3PZQD26X1sdKuBUm06C+68Y4jYQO48Bc4eY74WxpTVqH/pPkckzcy2yavOB9J7RS2EiA6j7HbA7vDVO/8Ut/jJnDf7Lw6997Xvh6Ziq8tI/iDYJfR4W2RKDteP8b2h7KprBdOrevhFth5hll9N+YB/0Zm38QsM2tnqHt8n/4RwD+DYjumG5qVd0D+Pcsl+/GysKCceuf2/l/j6b0r6V7EVDqIn505etUCQvHVJOkWXBjwfYmvayvq3vATZzaDaVLdSUIgiAIgiAIgiAIgiDcEvquPqCV7yCFWXi0dvHC40AEVBAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQfj7MMlKyIVP9inTztM720T1HBJnknqKJ7n7QdOF34KLQg0HA9Z+xrrzvMZ7W6VJYmvW2iurtc0vzoILGHagqtxy3q3E2kND6ZDeOoeyTThyRVqEK62/9cuDZ/DkZo15C/cxWFiWwrE8d2q1refN85HrvPOqxnD+itWS4TEEjhIS28Cyji9erf3aWwdO85LaVmq3KM5JiOPrc4rlyb2XDjiIPYN7HL+mfspOxygs/3i+j7ZQORsUT1tlm/nHDzdZW1+YFXhugxe44vjV2vvo3FG8QvKyPwd/SGHlYtxsSvMuPu/Svt6Bk1fWQiQwweHr8srqSRGnujbS83FXPVEOvMyF4x9+yaI6VNNqZyVltIHL5TidNKFs/BZeQHxbeuPHbYn3hbth+AK2HSex7F/Iem8dEALSguzmRZUibxltlamSc+9CGqmziogttXAS68OTgCqfR0pxvrBHEK0rebOjnWeFBf/6Os///O3Il1HRxlxdXpyh3g06bsZlc9VImxbrzMNduE7YfxPVq3MZqN1BiLVzKS7cIUMFtPCdTlpFJ0l+GW4kPAV7bx09/tVrl80P62pC4MLblsunCfx3rqweBp/rPNZrF/6H1ETe5HRSU4k+SOA95OXrlNO0Kf+SPeltD3fpWk/8QBiLhy7ZQxdvnNcQ4Q4ZuQQ4C54x1U/NxlYIwzjvsseBK49Dp7jpDMZ4F2csQBgfdp0rlXI1DdYc5xcf0F03qH51CqnDma1Vpa04Gh4EeJObxjtHopO1TxdnbwbWU7h1hgpoMYFIkjdRWKd7D2F000k4j7tuOiYixX67ohKVx2kQ98WQRcu8pmuoiVtQbpFWT/1RxdcTPuFV7HYGk7IkSa4+Ra4eqX1X49wy2sihl5nMLaQwR4ZrUOc+m39pskF3R58q007ZtbYHEwt48aAxXYXibGAcx1211m9TaBuaNcNH56fmWf/MV+sLTKq467yBpzbM2F+srLZ8Xik9UNs0RMhsqeNSO/0+q9KLiB2axZ+EiRzeSljnVe5XEt4L/wbA9QJO6H019WmoJyHOYx8TkbOvuyhrZu02ST3lPaggCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIwI4tqjvtQ6zzL9XzsnwFqWFrqhO101vNmoxGO4T7bW3bmweQYrrutMduw+YH5g1WKbYfot86mxdfXVV0qvadIuzDP9V/lv6fzjZBHyL+nHrltt7c5rf7vsjLf7GutN6hOy2zEtrJah3ny5cfzLK4DjO5Cmrz5e875U50pbnVQWtqvUb74eLrCZWr9Bh88c57WHrCZcZGnXoeZNPKka7Hu23JptdlWRqeUz17cANSJrkE2rN6j2k75L4+6nl3XydcZFgJUFixYYdDYZCNHY3YorEb5PeP7ReVT+BryVwtK4e0Y5h2TJsKFxsXETaTtRxjA4eIUeelkz9sz7SN6V+KSaiCdshZf0bd8Hm8GFFMpvuqfHph8dAkQW3lqXdfaHvs6N/E1/ahMYL+kYIhXzTLflhx2+P50qDtvqlRYGvSVXdDddhXaPu564kt/Tkdlalg44CHSGg/xgY+Pa7WnkgR1gBbOOCGsBKYxn3mAxO64K7HteFf4dz+lXauHaJOx0RtpXDzN/gl+HqXBhfyDwmq0n8eZwR4J6awLb4U8BpTbogu/VVzsGO3q1GX71JuWtEtsy6+8PZFRyQnKM6ShvAAOJXf2Sw0IheKFHUwcv6W+fs2x+Ta0esrOBuQXt10Vbcf1ZOEfdj2/Nrgu1l6wjZQupwj91GwccXyYqrjFKBpcL2MybyVQVTcwp3kIFDZJ2t2sPavMERsFh3A8zU+ebKopwAWDdkKexto1NQt0Myj9F2hR22PuSxr6kOp0OCotRbLapf3cexoLUdC5DW/rX1ej23KAYYrq1p6cjX7y5JJ3qtl6HozxOmXvDSp7FrR98n75FV9GeihpKEGqOCaPDAFpqHLKq6S06SFInAJQC0yhQfE0KnR71HV0xaAGY0yFrSt4uPYivmKstE557qsb4E2ZMd7b6K6S2eU6meGmzt4ArtqblkFXiOVuoGHG4G/wZ+u75fhUuC69QjCy7BmwritHN/+s5yFhoK0LjW2ThsIyQ1i2SHUMBxeVuItXg7o8Cvviu6Y8Cm1i8J9+/3OVx0NuPaOrON2Qbnsq0G16zd49U7WsGXJlr/MRaXMSqrdR2pZy3d8GumXtHrCQHg/mGtpDwhuEanz9r69TbLxUTmR4N6DsMViUVRl+PV0XXwwjSq7evFQPLFYxf7C25s8FocxI2y68FWqXgOIiaHdhx6Qq1aFZ9dLSHzzLxKJcSbKvboGg2SeNr+Mbi0XQOuM9TGp2SRA30TWTdsnC5MwGTY32aL2l3QJk45a5SdH2sMHUuetsVPZYpryefJ8w9KChjl6isb5bFO0gtFMVE6PSwmvQG7HA70HTIeH32hZ5DyoIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgrBwPNbPuOTztMWiPMzbMawY0+rrOjwFD0oI89784mxi14cPAW+dCWvJqWyshAdAn7fjHk3T+zFt8IY8zFd8ONeXz4Cwies45IPeUXUYlMc88xNul8J8k02Ok7/qxQII/lipp4oXX7D2FF7j4FyVF2XAAgkwNeBc9PPLSJvCzjtJ7IZxlplrhR/5lVWY78KGG77d13hBhJXVev7xfKtTZtIgjb5JZR+hLoVvetgSwb88+21XX+DRDvF5kQZvU+QXNWiFOsANI9fV+Y1X6trmlFfGCzSsrNZ4oYU4PyyswD4+i/y2p/HrKcyfZKJYJGh0A3fgVFUrXXSPlyRY2Eh4P8faFzhBPt9nQzwSOF44QallrDDC4bHL7r5aJSfKLHE5GHo423GdIu2lE+ZnQfNZGo5wfsa8jb0kw3gMjmBdHrA7j1yHowitN7vzc/XvyS9Twr0ykYDCslNNi1XB6Cz3v5U4n2REnjAKg3Cx81prThEGTQlt65eT6R8i9PhyZyM5t8oG4lZ6NaF1bsCj/J62RuUn3A+TadD50NLRMjgm2g/asOs8hg/c1TvLRNK4VxgKYCMttzOB1aWyRh8n7LHZ9k300I1Pm59w95TVHQEBeFHNzlLncx3C6gSCxpcQItJkMJ1Fl1z34Vhc4TAPiz9QvOBB2We5M7ZQ6uatVYe0s9t3znsxjuzPx+cn/D2Axlz2bwHisK5jXgzh9dagtGrOdVHCg0WrO8b7Xl/23WpzYJyX2Sa9BagZN/vPlSAIwkPk/1SsZpFYu6lZAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/senior1/additional_info.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABTCAYAAAALHkxuAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAsNSURBVHgB7Z2/d9tGEsdnF9STUoVKkdhNDLly/M4S3eXyzhLSXWfqL5BcpRRV3XWmqitF/wWiqytFVfeuCiWlSBdSlyKVBeVd4VxFd5Ii7t53FgAJ/iYl0rGl+bwHAVjszv7AYnYW4mKIBOEDRtEM8R997buDhYVGWKs2SJiIVvuB8JcfQ7qDzKyD+k+CTaXtHg5dx7RKPUUnDUkYCz8X+Mran+LTLNrvW7Rfle4YmmYAGjeLzrmBwxp3TOzP0EVfkjA2ypgidu+4Y2Jf53NuV7pjKFfpq6vcsEjhzz9U+YlGPJ8ymTCtCf3H3+RI62xPOMu9vPTJ83yytsEy0jIHykuVpycND3lzczmW152ur+wJ69TKO5Nhk6TWIbNdz1q3ueL/6S/BsLw4jdv3qVd3fUfej6SsA9q9q6zhxz5qZciYgvK8YdotxLaEeEXE27DWlnH+onV1bm4XdkJgjdnBWZGD/OVnBQxPL3Gt9cQvrayF8TAVuoBYHjobd4ynrZuOm4Pw7+NkzgRxN83afc6nla+1yGe1FJ4cbfeUOJE9aZ2StsADEJcpTBKouTk33Foi1mjVJDweir8fkleU5uqKuuvlaFIe4XutMnXWv1dW3M4oTwX7ByhrlaIypcuzz4c99+ojJIMnLcSNOXRnSj3AX5/YbrS2zkE2arix8R8HOaXsrjux9pDTK6XW+BLbVGjApS4N5HPHoLhz9wPDWwllC7hcaPQD3N0szp9DbgGd9B06aUdarXUNN9K/QZ2yKCt3mm9pHFDPdmFdXZm60/RRGO8nH57TchP4fnUSsEIIT45LLis2DZTy6ZaQQWcpY88ba6QibjprkPrpyVFA10Bl2HZSrCIqb06O1p3ctsGfJdPcxL7UkUapLcQp9xuO3DBsnT3LE60XYf2wki4rp6Wuzv2mVi0ledygTgHyDkZNTOIyB9Su52lU1ot8WG/PvEeaAX0Yt7xK6ZfIuwJtHJCyG3SLmP4kKdJYZKxpPf18E1nzRdf1Sp9UicbqJWVLQk6lFa51GTJft+TOAC7TRzIx4fbbx8Q0MdVuzSu9DE0I24H+ytpe6tzvirLo/toxGwmdjIdrijUW22rDcB3m/Jw3Pi3SLOChNTENRpgf16Gz/aw/TjwYn/VkGO8sqt2JR5FkYlVDWB1hE2tSzBMsfWBM3EGJbUmiTZoSzh609pUbrqGxMIxvD03Ak4j5+e5JxNTf57I5wZOfxPzgSdm0GLf9OuMpHpF6OihPMpXWO+iUzu5HudcRVqRrcFo/nOk/bq7D5EM8T3wwG082hNTohsSTnJBYY2m9NTQyXgHFk4cb5zu0TLA92Y6mYebHNUm3H2TvDIm33oqrdWFQPLa5rTXbVpkXt+2fIRNrUDTWaXrigGGo0fexU52zVpXMYq19N0BupLHSr5L6EL+fDHjSMex1zDQw0OYoU0AjyjQpHe33BBMrZQfFq9CY9Bv+bwNTnyTZ6L0czyw3kgmGm4knr1+07dR88aQqpbE6SV5yk5uRt9/Xau3k2RlqUtZGGOJ3SPjDuI4NOhytS+ilPOnJufeerGGtmwhwZ8V/No7Lg5KaSIsGlHpnyO9MHy6vvoKG3UJnKcKQ34wv+e6vMq9ohvDwiTx5wpGj9wzyPe0Ow1D+6rZqy37cWIOqriGbh+DYNg0pmlDxjc0mtuswWdwZ+2ksvE8txOEhRR2TN467PazDT4uRE7fZ4fdu6k79P362P7eLhnjepvZzO2cuUOsFuSAIgiAIgiAIgiAIgiAIgiAIgjAr1Pv6keqH+FtD4cNnJuviBWFaSAcVBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBOGjgP1u3kXnqMJkDFw0x50n+VjsTDJeWMjHPiUFYSAZf2Wtx7OGcw5lTM5GDg6ephyUst/y9W5PwIPwnzzLcxql9R5kOsev7AhBKbWJ8/C0fjieL0zhzpIhpbZt5Atol13EWK3ZGWlou5yfWsPfiG9myfPcp7yda+yFBfdp7/Rxh3TFfo+8bIcTLK3r9opeIGefBGEEmUQbsjcO7piJDx9ounLs5jAgY7aUVgVnEVjnRuYpzc/vsZczYnfPOIbGVZTSxEsra+w8NhfH4XT1WBPvkge5ls2IVRvWjl6TIAxg5IcbXKdSqsBezDC8LyEoFw/dg9NEnn1zsae0tr/yyO8le81YZB+dyqoiCcIQRvtJYm/DnkfKYugnN1SfJRpwICrjR3HPoW0X2sGRRmZzogZtTYIwitGfvok9vWFSs28vLgJ2WhrWjkvsH4k7nP/4m1yPx2PP+TOCxpzLk2m2tG3iFc7+/nveNpub0KSbJAhDGNlBY+da2zzzVvPzp+iM6zzsYzJVxuVAzc2xv8xsV5qqch6M9S62tnPYyAvdIdL8pDxvX0/ZB6Zwx+n3Yn3Yy/ZB1+QFvSAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiB8NLil1U+e5W/y87/rpvUfBzmkDUgYSgaNtEnGBEqpFbL2zBI13A+LjcljX00W0SW4tfLGbBLZRnhyXKJrwuuWwp9/qLrj5WcFIuWHJ0cFuiFcPm3trlHqNcpe6boWYFfrWH3qefjT5PDKKNlLy6vV05OjoCPQmJKfe1YJa8et9Nzpw/9E591181fW9lwkRQdcvuTbAzgOSehBo2HKaDxep35g9WWBj9Pr3t2S4m4uL8ukvWo6yGmjrrj9wlp43ka7FB7k8ZqnVLphP4ROyewjP2suLraxD3sSugfrvFNukzvHcWVQPt3l6Cmb1oWe9Dq9iqBdN5dOqR1sr1oPD6/5aroHROiDlxxkv3gQkGrWGm//20jONdFz63n3F+/5L7P3lw4ab8Pzz754sIewrxBlDWHvEBb6vMTY2kXleXmkW2v8dvbveInxv9ARP/nsnr/16edfftL436/REmdoMkW0ibj3ISNEJ/kr2eYjvh7LWkJalrUCWYdJGf3l1SLLisu0i+tfQf6jpHzZe/49aM9/8HXI/w5hdZTvbZwnr536jqzHeb5F3AXk8U+MBBfp+iV5PVxZ24/r+RzXFK79wnm6erqyfek3fvv1x+znX/4d14nboatui65uV1ePkOZrrhvi/g1R+Isqf07qBplFrfXKp/eXLjgPEjoYuibJ8JN+clS0Rr3GU57nYdlYc+iGK6W20fAtLcjxMPxtwlTIRYlNgZccc7gx6iAtl80GXkDH13qGNmvfsfxYVjCwTNYeQjNVWse8Br/ZzBllDlyYUuuQtZXKs4Z4ddKXpWSEcF9JSdUviZuuZ1g/fOE+WBGVrZ6UDWN036XXcd3CfnVDx33K8ji9jtvJGlM2xhx0myNCxOhVnWl4ObElp2HZjtPJYjl0qiQKOsFZfIhr5w26AXb45V7Z7qZ7YVI+aKqlYQIU24/LqyWt7fPOC+16RrKOyzQNlFrjD2LwhnaSdddjMFkH5eXESvnJKRp5cUhs3OCFKK5qvp9FclbDXGj6fOhWnip1OjCuMUWLySBrRNaWHde66hlNdKZCzdn4bPPj4SBhJKM/3JCCh6+Hy6sBz0RZe2K4HXzjcPOhwfYQd4PXzVtrOj5xgyGujmv7xF8eadJ08KiijGKtmIMt+sCwGdJRJF0zdn4XnZfDeWn0LuLW+Q1GunyterJ2VYrlTPR5HqQ5iOu2DRu0Fa6ScIwyKAtr6Cp/dwDleImZP2HmXybh5kz67o+/aIdXMXl6T0xSvussm74psux6fGZqB/lPgjzsuw1S9uxN7Whaw6QgCMKHwf8BW1SZ24OczrsAAAAASUVORK5CYII=",
        "../assets/images/template_cv/senior1/avatar.png": "https://static.topcv.vn/cv-builder/assets/avatar.e416ff9c.png",
        "../assets/images/template_cv/senior1/award.png": "https://static.topcv.vn/cv-builder/assets/award.e277b331.png",
        "../assets/images/template_cv/senior1/certification.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAAB5CAYAAACtKWo+AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAA75SURBVHgB7Z1Pchs3FsYBUIq8M3MCt7OaSk0sZjc1NbGYE0g+gegTWD6B6BNIPoGpE1g+gSlnFrML5czaok9gZhd7TGDe9xpotqhu/pFEWU6+XxWLJBpAA2j0A9B45GcMWZjsb//IDLlRrFkxWavdNH/80TR37oyGg/7IfIVIHTIbwmt8lFf/7PTkZ0NuBGdWjPX+0G5snBkz3jFfKXJjDYO1T+WFjtk25MZYaQdV6ylv1tpnw8EvvSL8h/ZO9uDhgfmKkE56LFb0BepiyI1xbojXOdb6esuEMDJra0NYjuIYOtvnzy18Hv733/268LnxrG1a5w6CDJVmPD6ajqdxv/9nyzjXrCzDp0+ZaTQylHE6XRXz0tSeaypcvyOPRmNQjkdWi1pQzLGyza3XGIql87y0jcZrsRZn56ycdC4Nl9e5HMZmJ4a/qPw+nV7yl47yXjrqUcove/DT3rm46+sHeh7vOylIyrKLMtn19V9TGe9vbp1J2Vt1lUO+c9NUnAtImmMNH4/bRTyUfSoeWS35EB/Cgc3nVqMQwpF8f4VgGc72pGN0zTVz9vZNW96G6bu1bj9OByrRRYq1PfnYlLKdaBnz9Lp4qUqbfd9uSb4Hy6Qhtw+nF98YXcDIIuDx8O2bjnSgHbmgOteSjvHErJ6mWKb9uoOy0OrGjwN0bpRRyvqjfB/lacedC2nWfG6VpXMumobcPpwMvVn6goXA5IjrwepEy7Ny1Fq32u2qY9Kx7ul7tOwAj6xC8M+0fK4xrE2DuW51moEht561ugNxIdCpOibz1WJ+aU3IzBWRIfe5dKgn8g4r2p8Xv3hg/ul/uKGO8YzVLMjw7S+HlWWwdlvqda8UdNdcAzLnDYZcmjVzCWxNx70s3rmudM5d+di+sGCqYmPjhS09jwzeYzrSNVejJXm2zDUjD/VXvhnyZ+ZSz0HxwDq9bJyrXgUdeuVBOD5jwWQwR5xZgHCKuaXJ55PXA6YzpXpJyHtDvji1FjT7+7/a8swPq+DRcGprTzpUv4j3A1bYlaPYUqtkybMnw6Fa0XmWTBY8amX10diSOzv3Hzw8lg54VxZlR8PfJpsHUoNhuV5SFkO+PE4eRBeLBXmkVKyk5Zlfx+bDXmaWoVHMIZtZ6+FucaJGI38akFu+c2StfE6ZrOgFYDGNzhN38dQhT6NPH7I88zCYkWa7nEYCtrVTNwz5CnAYXrFIwRe5mF2xSr+K9fggX3Zj2PNlMtTFVbC68rfB9lJ+IT3KcqE3I+0gVE0ZnMPCBsN5phsIkqe8/2ryDiqW75fjGWlaiBvTnKVTlbdeye1F56DvZMiMe8zDOLxieB5J2NN3g/7hspmeve13YqcflfIbiIV8NLdj5B1rWA6Kzho/Jutb5IkH8Pl88QJTaZrFtGFGGnL7uLDCTMPhde03ryA/dHa9gRZ137tMGkIIIYQQQgghhBBCCCGEkL889qYcaukXSS7Dyv+4gZCrwA5KCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCHkz0edNOAikoGUFVyer7nNbrLsVv8BGTLThVanfwaxK0hmWxcg2IXC4O+0H+EzJKlRxmA/3jfjO60UJxgzMNb+XPcPxpJfR+LuBgjJJvB3397vWZzD2nsBwgcu9I1p9KVM+8PTk8dF+s2tF/gOlQ5INZorIvn0o2boTFTtxDlIKXbNJUC9obBbVhTR829ufTg7Pfl2gfQ7TtrNW/u8rEIyN13+z9aX/kfpC9dLrhU0BFTHyjVGZpzXSevXOK+Qcp242EFa+D936XxHUafISOH2Jbyf9C3lWK58XFLpkDgHKY4qbng/U4QrQPrl7ZtO8ZIKq4amc3uQOczD6v/DHp0luKCCCVCbq7X6SYluKmw6Pr5XhlWkn5VPSjfv/OXv0mb3Zx0vsL4lnfNZ6gBVZa5MP1aD05pX9ln1DThv6VrFAjUhGSQGJYvly1bVOYGTO+NYRWShsBH/xz0ea3mxaFF5A5IuWhDpZL1S+swHfxILPzRRHxP6RQspxi0JtN7RgVUm/Jtv9qz3h9PnEcv0Wo51JM5hkt3+bnPrJeJD1VnCcutr7abcUN1yHmqtMEJIes1nipTPuTQSpuHGQGs0S+fHe+oM1rndUljeabw/jufsTKXJ0vmgXQoZHYjp4rPKBEGZWs+fS6WX0ndT3jivWN1tibub9E+LNsjzasWyv071jXWYYtzMfvipo6NIwrmBKmDjHdbTuZ5ZIZCh6UNEVhvc2t1g/TLKcX2V0t7cgiRMcbc6WNkKgVe5UE+kcuhgPXMFHO5e57oyRHfKorBoeBXkwnAsxzVMGldvordv9vIpwzi3ILj5JEzzMHYnFnz33enJI6SXqc6raXFbn1sUTWONbZfCcYN3YbXkZh5oegkzUcwMeWmY98+lg1yYnhTHoRNVGoXUIMjIEtynPXyWerdQh7zMxhb6Unn6wsphWPfevpLreYR00sl2UhugXUrq0Sj7U5xbjNH74uaJ2OCemEZjBM2s1BboK3G604/Wc2hWiCrN4SJCWx1SNGdL6AeFjx8fm2/Wd/T/ScLkT0re1czXcIGm52KXAfMxaWRoMOF/pQrxL50jtdonqiYXArSenhm71jJhPJrEmXH+ECZzwqDzrMyUJHHkxtuXm+v3GJaGymKeN/yt35PzqzXy3uNGeSpWBjJ2o5j/SMpUcd5i1MLxu/XFC+U5q6S5k02lr6HRTG2AskodSu0RO1hwA1NWB2yY42DsscZvtQfxxukXx8dmxzRcPgeVjgpLuorOCr34lm00XkqzHfvPn/vorHFoeo8hW+cnGA7Li5uI3diABd02n2RRk+sW4eIZWOM6ae1FQEVdqbHiQu73UpSmLpTk7sdwdy6eJNdj3r+SFybwg2K+FMtWd15pg2ExR7NiaRuTUSC3xGp1O3ULpmiBBrDCTi3cT4st5ibla07Vcyqa/VAqK9IMzEziaNHA9Ctvz6jQV2rb3Apb69vnkn7+3JIbtB0/I85okqaduYacH+GNOGKhrVfAmg451mIVviMdNVeDMwaCql2Vx97Y6KBwspC5IH6V4th1VX0bRhEuCMI+kTwg5NU3l0Ss5CvMIzU/75shDtnAed+SY20pu9z45+ZAI7FymEa0ZTjc1OFLOvt3Dx7u4CkAOr2EHdWdU/I6xJxM0r+XuuBGOSzmX2trA5tb0O6MYmMxifQn+XxcrVLbzEE63hbqKmk3pQyPzaw2wVxRjIUMu8MzWDdY6Cqk48gQvY/jGJZlVOlUncOGDZT31Dp796y82JH6altsbkE6MotTllgQ38EoqTcz5rQPHm7J8DI0X4LypP0qca5w/mt55rZMPrPiXnddMUTqQuSayrdMuiwuBOfUl8/B/8poB110KnDNYK5uCCGEEEIIIYQQQm4vcGXD+2X23PGc8bqfNWLrMT30/xqZ3iOfEzfDpoRZEuzXm1tIsYE+y32tzCKuZEulnXYfg5tY2mKbF9fUu4uleHiXPWyrjhJLlKP8vfK8V3Tfm+fSdy5gjhvjrDwXds9z7om5hajngt5x2D6TLTf1qMFerffb6uwAFy+HffhGX7a+DrAfHePp1he29qQDnKS0cNhIzsCwoNi71v3f8/Hg/TOE066EPdetNBMGxjV6LneIxrYePHGKB8lwKYPbn82do88k32cV+T7CHrJs2R6gPtgGtd7IVm7YglcQtmKrygtvLAk/lfhDSd+X9PsxznaI/q+lcg/UGUTyl+3Ue6mc6tGFNHn5PmjbVZUvOn1Pt4Veh1L8uFULzzKE7Ud/2W5qU42vbm+fesPBf4ZF+yBP2aOH15Mc35WCtyW9LcoER2TrdxCndB3TeY9W5fRxWZya9uBPo7vXI2nkJ+ra5dx7bMHBkUE9gOQuju5m3diJM7F0rWD988K9rM5hwI93wiTtsyJe7nzRTS5vyU3Me/+q3Dk1qlzYwtVNGj3uA+/pBVZXNtljH4+TL8EADiPIIzjTle99taBwhyuXV+qa8j/L3dW6ebHCSXSPQwcZIa1+9n4H540uamgP5LGd8iiXL693qXx5m7UutsW4PLQ2k7ugzzvOSOsQ28nUgGsYXe724nnyi2ulTSfued8mSwqfg8L9T0YrdeuL571NnROswRXL2rArd1sLzhcy6KvXyrtB/1AtnLXJSUQq90dy2VIvGr0bg6bdydOGGu8a24yOFp3Z8epxJbc3/RmC/Sjl+SY5K0go8m30xAKaKs+rvBg+05+T5HUYitVLGVZ7EJXd4+Jn3ERiQV+o2533w9LxIo8QPX8wMpzFC1602YOHbSsdd9IWeXlSnOgu2JM6BlPqbLOZuNOZcjvJ6dI6IFr2qvrd6n10B68XufuKn2JIkC4mMLTjboQPZIxb+B9m37dbaeIeLVJM26jZ2w2jFC93JG4svQfsc/eyHBlaMaxpmZzbi/nuzf3pQZAhPLqgVbjwLUTJAXquN3lQ9718rhfdGDNtCxd6k7aYeHzFxeFALZ66C447CHdTPqKFp35qE3Wns1k8XHQ4m1vFTvpZzWV/n/QlWcNFPeeOZsyRNGYmQ7wVK9r7DpNs/aFUPn+DtXQ23PNG7u6GOXbBvYjubRJmqr3xxbJJ2pcaLwTM2+otg+Rpg3spw9a5H5pJY490ziVzMznXSZ6vlumluot5j8VAVy3ovLxTOZxb0EKhpdZGavEmbnew3s1KB+Si3ihf7s4W2+fpnLaAu+CB1qc0zxdj+jvc7GS4foSbItVZzq1DAK6hjHb76k7nPVzj1G+07J4X869dbLkUN7oomtvGoi5TVY+Alkh76eEkDVU1P1jLzBJch3vYMuesabPMXIF5P9xbJJxcI1f9HRMhhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCyO2Aasc3C9WOF4Nqx3Og2jHVjql2XJNGodox1Y6pdky1Y4Vqx1Q7XhaqHZ8rINWOJ0modlwL1Y7rolHtOP1DMdWOqXZMteMFz38tz9yodmyodkyWh2rHhBBCCCGEEEIIIbVQ7fh6yah2bKh2TLVjqh1T7Zhqx8tCteMI1Y6pdky1Y2OodrwkVDteEqod3yxUO164pah2/EVZ1GWKasfLn5Nqx38BqHZMCLl1/B/75VkieBsFRgAAAABJRU5ErkJggg==",
        "../assets/images/template_cv/senior1/education.png": "https://static.topcv.vn/cv-builder/assets/education.4b7e89b0.png",
        "../assets/images/template_cv/senior1/experience.png": "https://static.topcv.vn/cv-builder/assets/experience.d3b06043.png",
        "../assets/images/template_cv/senior1/info.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJIAAABECAYAAABqHGy8AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAwSSURBVHgB7V1Nchu7EW5gWI53j2+VpUmv3iIW+XZZxBJ9AssnEH0CUiewdAJLJxB1AlEnMGmnKtmZdLLIyhrtkpVHO9eLCaS/BkANh0OKskg5r4SvSuYMBr+NRqPHNV+DKCIiIuL/BrU//aVV29p+U2vsnNWarSptELVf/lyjO2Dd/dv0eB8SVL2xY8ONtfYw/fT+gDaAp6yoxtpLpVTDKvU6HQ1SpNeetdqUTCgdfejl8yNdadvhvPucdxDKk1I/8d85p/WxALi+g4vxULFS7JIxuzIopV5aZbiND32pq9mqaWvfGqIsHQ9fc7k9rdQuj/eKB/+Fx7wf2q1vbfes1gfT/jV2PrJgxv5xxnm7nPaO0BcPTmvTQwcr0hcok//7sq5VismbXovVe96V62fPd8O1b//dovJQJv5teat5NH3W2Dnxeaq1QnkuswulK6mvGsrl2+R6e7Wms5TSps+Tez6Yq2tBnx8yNP+Npne88nglZrQOGNOeXlcqI1K6IddskbhVaQOKwpbjVCa52WrmiweLINf//OuA2EpImZyCFvuKZ2zF3hqlDqmAfF5YxHDN1utJOvp7KtfGHHDCoShUbkGJImMBFBdHIe0hgy2+OQ83bNJ36Y7AFsOr+IAnaAe/uMckssZWYVU4ndtIBsjLk77nt7Rq2JYWISiCsvaEShTFI2MlecULorNsgqfbltsaz32/a1zWyrMJtThJFJuf16iimpQkGbbHUIeusKw4Df2JvhYskk56/OtWqzFv6O6A9ehZ+BX8i3usXGPNEP6FWANjuljRBOXCVsITBL/mpgnhiX/L5Q/z1mr6jMtC2fhvxPWfk5ksVUy0rzX9/Hk0cFsm90lxMvoDBWel2UMyt9diZT+Cn8Y+2pVsg6ysn0fvu0jjcQ5RHT1waAg/mHqezC5WKa7ha8DRZCVo36I+8pOZEhxT/nWWJKmSpZltCNuVWA9YF6WOMSHLtlX0S2t9hckrzWAm4k+5G25PU7qwLjjfSdKBMkwTeesUOXB/FFtpo7yltna6uBQsJz3OWOk6QelVVCJBBf/gDehps3XIkylvQeyMtlmCEBRPiD7h+zf8ZlS/TcUzb38J9ZXVZ6wMTd4KGryFvvbtpvjlScHPYiXiSeNyXbYI/eAM4+1rJpNO+rLNbG3vKjJVS0l3UX2c74zf1rKpYz1Rp15Bg++WhWtWrGHNO+8sm9EFKzv351y7ti4V+3sXsIIR12Bl6hbe4uRPXoHXgPvwJTbl/Jb1PfpG11DFBHnzcW8vO+TNNluqY/g3FBGxAGrZQ/9KjlU3Wtt/C0RERERERERERERERERERERERERERERERERERERERERERERERERERERE/I7wkL/hrgj3Xpna0lzWpuk/Zrn5y4BPdFPPrABJkvRvvcBmvS1AqV4Ht14m+evXKj1+nG3is2GMWb51JwKN6106Hr6gB4QKKM5EavlKUvJpd49WhHZcsFf5NEQiSf81q0ylaX5Vz9GxF5S/STGkPmO6RJOM83L5SY2V07JyHt9UT77NYvtBMUMaFg6ntWkJysZWrKcs7yKZ3KadTUMhoINSukOLiX6Zjx7SpxUAirZiRbLWnpPWR5hErVTDWDsGjVtIkUTgqZ2AFOnTJDpJvbFzgXIgIlqyo/TThyNYJKixZbkg7wWvdGHJJknHRzfZ8QRPKEwLfDph8WrVlPLgrim1T9++Nfm3SkmSkiM0QNADsHfJkSAyfv6SLcmvaJP7/BPq598nyBv6L+2DaTPbfxkTyJQS7aTEIgnxVCmUUyECCkioWtu9mbq57ypJ3vq6X3KdQ3DwXIQVkdPAyxkyPJv2x5jexaf3LdDJwPoBcTPIkO4BGkrkJyKde4pB8DOV47zfBCgc6NqY0LAiENQB9z7OAJgpwtGXNGOOp/RqV67LAmkrUq1pNxBmRsrbcYgcUqCAo/wICotnSus2CJOiUGDMTiYttr1SjttqyWRwGZkMojrqKYbz8X0GKfPquv/2MrQ/7f/1mG4SdBNKhrHxAhuL1dC283k8nNYTmMJYTDI2Y/axgPw4X2Ch5OScKZA8Uc+EWlbbXk6GB9IOqTvHclgViEaCVfKOO99TueAMStlj1miwV8EyrdGd8NWZWJsEU4vV+/Y6qITbWllYX0IJm2Pe5rj+16b6mgKe+TyZ4+azcrA1kTKqUiP674gwiQhWYW3GCjbyph/l2PLNRGO5muvz3LXrP1sAWMsjrfQOrQCW78+58fR8YI3ceFg2k0mtUGjp1oTFxFt1SykzDczxo6DDBajaPBFPrOJVIBE91BO2VitboplKEQxrGRDyRqlTv+p6tC4gaAVvOU7AAY9rnJ7KlgFLZcxL8ZlcgIuMvBUT3NTv6/6L1XQWK9/WPIK/YvNpz5wvZb3iu7YnYdu9EdMyOulpqyXYRVlgjftEJX/DprLN+0iGYVvvR3wPRECNnTM25a9KM2g90Ag9Izx97OW0Fu48tiz2Ec6sTlwEtoT6POkHEmWNtw1uh51usa5p2HafNltjz+1f2THVWo98FJUriUBX6L/ylg1tKnH0iX0h3Q9ltI8PxVv2UYghAF8MkVF8lBaHSgUBK2ba9v4ZAn3VMQYeb5W3tVP6wVAIdccrcW9ZJquITXEhaMMaEELR0AYRKOg2+ICsBGUvDrIlOod1Jb/ie9+MysZ8H3LYNBRFSChBXuV1thDdNEYWiYiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIj4/UO+kPQkwg4poQDhO+Hz2zBrIyIS/zH530ALwof4/PcLrqt/fELZfy6HFHGvwKLO/p1+3XSZdUN7vnrN3+N8+xQXoCddH+25GkBZBku13tj5WN/a7ruj0FtNf0jyreqaqTd3pPqPQv4Y97Jj3UvLPBN5TCld/tj5g4X5HeukV/ps63k3L0NXl0tTSyhdZSeYu/pkbnZz93eaIx0YJJaodzEeNoXRGWAmNzJI8xDi36f3bTBFrf4N7NV2/mN64dgXUJrmBl9dJe9tgTqKdS9qb+U6l5RnC//rogkqlpPDlsG9K4NO+vmTyAObuFhG6pyV08ITzHEA9KJ+3ySnYt9BkLwXGgx4bPToUZut1TvfiRquc2mitOCuy4nXwmR93g3llf3Dic/7MT8AHJ8aVlbdrbKaW11OmGIVeCLz7YE9XGjvoNjeqhBOP04Jd8zbOUKp5651SsrtXbfrygmnzfHg5gACZIhDIPLwbGI5etWXQSwBqfPRo4NpX4xpI65A2diMUsdlJ6s/Bc+P5aTdUfQtpIns8v0tyKzC1uOUG+qAHMnmGv7StRXCKlgT0Ol0PBw4lulkl5KkL0ERxsPUBX3Qwt8P3HURzNb2gH+OcM159znviNOqCMZAnpQIUiEGzukNXqU4vDjl67IuZEva6xbbK4Llg22p5wZjhNMu11qfB6tbLz/7N+Oxn4rAjZ1aZ1aK3c+eQArqtyj+N1ouQ4l9IBObGTOZ81+Vtp2L8fsXM3WS7lnub1kwCVizp1vbu7KoPBETi5Sv9kVOUFIXWQbH0l8GOcFtCfy/IJOKRAzxKwbCCo1gq9swDViid3BHrlz0kcXHqzt8zXP9Z0wulJTrOGGlWnYSeFW7eAOXq7U3C84/YEEKSTQnYAlKwQuww/eXVMpOnlTT0Yc+lJ37yX13E8YTk+cUZkItv0mTtB74QBJV0LVLctTDxLoxPg4xDhbCaH0Ay2OcfwxM5eQXzFwZW1KnhrLwoA4L6SnlAkpsBIhAosz5Wvj/vNeztTmcNd+YGHKcet+eUWaleAO3cToVqV1EGZGIImXKOXHKxUq0D4sx7XJO6ZSnkRf7UPRRfEibFra4MiIn1/MxdTEJ2gWy50L/Txi+SiGEjmNbTyZNY9y8+PgIK8EFkYBVyg3EKnO48aAEOhkoqzsSkYQHTd8JF3fIDOHo85tDTcy01oii8sZFO9Evi+3RIofWQyHIxYrgyZM4AHUXx6k2lyGZRktJJWZUAE+SbD9u/OmcvNlBXkDjHhhn/eYAy+y3efhlwV9DbKXGMv8P7gGF+U+SEfdnD36mWuCvLYV3Rr88bW4f0T3iLm9L31P3Ku3Bgadb4K5vfAvS27TmOu+tDtn7IyK+A/8DSTEgc5zutEIAAAAASUVORK5CYII=",
        "../assets/images/template_cv/senior1/interests.png": "https://static.topcv.vn/cv-builder/assets/interests.e48ccc43.png",
        "../assets/images/template_cv/senior1/name.png": "https://static.topcv.vn/cv-builder/assets/name.945ed22c.png",
        "../assets/images/template_cv/senior1/objective.png": "https://static.topcv.vn/cv-builder/assets/objective.1fa4c9c2.png",
        "../assets/images/template_cv/senior1/project.png": "https://static.topcv.vn/cv-builder/assets/project.696990bb.png",
        "../assets/images/template_cv/senior1/reference.png": "https://static.topcv.vn/cv-builder/assets/reference.d4fd9e58.png",
        "../assets/images/template_cv/senior1/skillgroup.png": "https://static.topcv.vn/cv-builder/assets/skillgroup.bf62ab91.png",
        "../assets/images/template_cv/senior1/thumbnail.png": "https://static.topcv.vn/cv-builder/assets/thumbnail.014f3cb7.png",
        "../assets/scss/components/core/_builder-action-advanced.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.header-edit {\n  display: flex;\n  border-bottom: 1px solid #eeeeee;\n  padding: 16px 18px;\n  color: #555555;\n  box-shadow: none;\n}\n.header-edit__title {\n  padding: 0px;\n  margin: 0px;\n  font-weight: 500;\n  font-size: 15px;\n  line-height: 18px;\n}\n.header-edit__button {\n  margin-left: auto;\n  border: none;\n  outline: none;\n  background-color: transparent;\n  cursor: pointer;\n  font-weight: normal;\n}\n\n.button-editor__item {\n  padding: 12px;\n  border-bottom: 1px solid #eeeeee;\n  margin-bottom: 0px !important;\n}\n.button-editor__item:last-child {\n  border: none;\n}\n\n.form-item--modified {\n  margin-left: auto;\n  max-width: 150px;\n}",
        "../assets/scss/components/core/_builder-action.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.cvo-action {\n  z-index: 1;\n}\n.cvo-action__content {\n  padding: 12px 16px;\n  border-radius: 5px;\n  background: #ffffff;\n  box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.1);\n  border-radius: 5px;\n  display: -webkit-box;\n  display: -moz-box;\n  display: -ms-flexbox;\n  display: -webkit-flex;\n  display: flex;\n  align-items: flex-start;\n  gap: 32px;\n}\n.cvo-action__item {\n  color: rgb(153, 153, 153);\n  width: 14px;\n  height: 20px;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n}\n.cvo-action__item:hover {\n  cursor: pointer;\n  color: #00b14f;\n}\n.cvo-action__item:last-child {\n  margin-right: 0;\n}\n.cvo-action__advanced {\n  position: absolute;\n  width: 310px;\n  background: #ffffff;\n  box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.1);\n  border-radius: 5px;\n  top: 50px;\n  z-index: 1;\n  height: 629px;\n  overflow-y: scroll;\n  right: 0;\n}\n\n.builder-setting__title {\n  padding: 15px;\n}\n\n.block-popup-menu__title {\n  padding: 12px 12px 0 12px;\n  font-size: 15px;\n  font-weight: 700;\n  color: #212f3f;\n}\n.block-popup-menu__sub-menu {\n  position: absolute;\n  top: -10000px;\n  background-color: #ffffff;\n  border-radius: 5px;\n  width: 230px;\n  box-shadow: 0 0 10px rgba(0, 0, 0, 0.08);\n}\n.block-popup-menu__quick-active {\n  color: #ffffff;\n  padding: 6px 12px;\n  background-color: #212F3F;\n  border-radius: 5px;\n  font-weight: 500;\n  font-size: 15px;\n  cursor: pointer;\n  display: flex;\n  border: 0.5px solid #ffffff;\n}\n.block-popup-menu__quick-active img {\n  margin-right: 12px;\n}\n.block-popup-menu__quick-active i {\n  margin-right: 12px;\n  font-size: 18px;\n}\n.block-popup-menu__quick-active:hover {\n  background-color: #364B63;\n}\n.block-popup-menu--active {\n  background-color: #00b14f;\n}\n.block-popup-menu--active:hover {\n  background-color: #01c257;\n}\n.block-popup-menu--danger {\n  background-color: #DE4637;\n}\n.block-popup-menu--danger:hover {\n  background-color: #F76556;\n}\n\n.el-collapse-item__header {\n  border-bottom: 1px solid #eeeeee !important;\n  padding: 0 15px;\n}\n\n.btn-action {\n  text-align: center;\n  background: #212F3F;\n  border-radius: 6px;\n  height: 32px;\n  width: 32px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  border: 0.5px solid #ffffff;\n}\n.btn-action:hover {\n  background: #364B63;\n}\n.btn-action.disable {\n  cursor: not-allowed;\n}\n.btn-action--active {\n  background: #212f3f;\n}\n.btn-action i {\n  font-weight: 400;\n  color: #ffffff;\n}\n.btn-action.delete {\n  background: #de4637;\n}\n.btn-action.delete i {\n  color: #ffffff;\n}\n.btn-action.delete:hover {\n  background: #fc4f3e;\n}\n.btn-action.primary {\n  background: #00b14f;\n}\n.btn-action.primary:hover {\n  background-color: #01c257;\n}\n.btn-action.disable {\n  background: #eeeeee;\n}\n.btn-action.disable i {\n  color: #ffffff;\n}\n.btn-action.disable:hover {\n  background: #eeeeee;\n}\n.btn-action.setting:hover {\n  background-color: #4285f4;\n}\n.btn-action.setting--active {\n  background-color: #4285f4;\n}\n.btn-action.set-color {\n  background-color: #212F3F;\n  width: fit-content;\n  padding: 0 8px;\n}\n.btn-action.set-color:hover {\n  background-color: #364B63;\n}\n.btn-action.set-color:hover .color-picker {\n  background-color: #364B63;\n}\n.btn-action.set-color .color-picker__title {\n  font-weight: 400;\n  color: #ffffff;\n  font-size: 15px;\n}\n\n.pt-5 {\n  padding-top: 5px;\n}\n\n.wrap-action {\n  padding: 12px;\n  display: flex;\n}\n.wrap-action--no-padding {\n  padding: 0;\n}\n\n.modal-layout-section .el-dialog__body {\n  border: 1px solid #eeeeee;\n  padding: 16px;\n}\n.modal-layout-section .el-collapse-item__header {\n  padding: 15px;\n}\n.modal-layout-section .el-dialog__title {\n  font-style: normal;\n  font-weight: 700;\n  font-size: 19px;\n  line-height: 24px;\n  color: #333333;\n}\n.modal-layout-section .el-dialog__header {\n  padding: 16px;\n}\n.modal-layout-section .el-dialog__headerbtn {\n  font-weight: bold;\n  font-size: 19px;\n  line-height: 27px;\n  color: #333333;\n}\n.modal-layout-section .el-dialog__headerbtn:hover .el-dialog__close {\n  color: #333333;\n}\n.modal-layout-section .el-dialog__footer {\n  padding: 20px;\n}\n\n.mr-2 {\n  margin-right: 2px;\n}\n\n.mb-2 {\n  margin-bottom: 2px;\n}",
        "../assets/scss/components/core/_loading-global.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.loader-global {\n  position: fixed;\n  top: 0;\n  bottom: 0;\n  right: 0;\n  left: 0;\n  text-align: center;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: rgba(0, 0, 0, 0.1607843137);\n  z-index: 100000;\n}\n.loader-global .loader {\n  border: 4px solid #cccccc;\n  border-radius: 50%;\n  border-top: 5px solid white;\n  width: 60px;\n  height: 60px;\n  -webkit-animation: spin 2s linear infinite;\n  /* Safari */\n  animation: spin 2s linear infinite;\n}\n\n/* Safari */\n@-webkit-keyframes spin {\n  0% {\n    -webkit-transform: rotate(0deg);\n  }\n  100% {\n    -webkit-transform: rotate(360deg);\n  }\n}\n@keyframes spin {\n  0% {\n    transform: rotate(0deg);\n  }\n  100% {\n    transform: rotate(360deg);\n  }\n}",
        "../assets/scss/components/modal/_choose-block-info.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}",
        "../assets/scss/components/modal/_choose-column-layout.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.cv-box-type-container {\n  grid-row-gap: 8px;\n  row-gap: 8px;\n  grid-column-gap: 16px;\n  -moz-column-gap: 16px;\n  column-gap: 16px;\n  padding: 4px 0px;\n  justify-content: space-between;\n}\n\n.layout-title {\n  font-style: normal;\n  font-weight: bold;\n  font-size: 15px;\n  line-height: 20px;\n  color: #333333;\n  margin-bottom: 16px;\n}\n\n.cv-box-type-row {\n  display: grid;\n  grid-template-columns: repeat(5, 1fr);\n  grid-gap: 10px;\n  grid-row-gap: 10px;\n  margin-bottom: 16px;\n}\n\n.cv-box-type__text {\n  margin-top: 4px;\n  letter-spacing: 0.005em;\n  color: #333333;\n  text-align: center;\n}\n.cv-box-type__box {\n  position: relative;\n  border-radius: 2px;\n  background-clip: padding-box;\n  background-color: #fff;\n  width: 100%;\n  cursor: pointer;\n}\n.cv-box-type__box:hover {\n  outline: 1px solid #00b14f;\n}\n.cv-box-type__box.active {\n  outline: 1px solid #00b14f;\n}\n\n.aspect-ratio-1-1 {\n  display: block;\n}\n.aspect-ratio-1-1 img {\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 100%;\n  height: 100%;\n  -o-object-fit: contain;\n  object-fit: contain;\n}\n.aspect-ratio-1-1:before {\n  content: "";\n  width: 100%;\n  padding-top: 50px;\n  display: block;\n}\n\n.block-filter {\n  display: flex;\n  gap: 8px;\n  margin-bottom: 15px;\n}\n.block-filter__button {\n  padding: 8px 16px;\n  background: #eeeeee;\n  color: #777777;\n  border-radius: 16px;\n  border: unset;\n  cursor: pointer;\n}\n.block-filter__button.active {\n  background: #e5f7ed;\n  color: #27ae60;\n}\n\n.block-btn-confirm .btn-confirm {\n  margin: 0 auto;\n  display: block;\n  background: #00b14f;\n  border-radius: 5px;\n  padding: 9px 20px;\n  color: #ffffff;\n  border: unset;\n  font-weight: 500;\n  font-size: 15px;\n  line-height: 22px;\n  cursor: pointer;\n}',
        "../assets/scss/components/modal/_choose-template-cv.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.header-close {\n  display: flex;\n  padding: 16px 16px 8px 16px;\n  justify-content: space-between;\n  align-items: center;\n  align-self: stretch;\n}\n\n.header-close .box-data-sample__title {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.btn-close {\n  color: red;\n  display: flex;\n  width: 24px;\n  height: 24px;\n  justify-content: center;\n  align-items: center;\n  border-radius: 30px;\n  background: var(--Neutral-Neutral-10s, #F2F4F5);\n}\n\n.btn-close:hover {\n  text-decoration: none !important;\n}\n\n.btn-close i {\n  color: var(--Neutral-Neutral-40s, #7F878F);\n  text-align: center;\n  font-family: "Font Awesome 6 Pro";\n  font-size: 16px;\n  font-style: normal;\n  font-weight: 400;\n  line-height: 24px;\n}\n\n#portal-cvo-popup-modal .el-dialog {\n  background: #ffffff;\n  border-radius: 5px;\n}\n\n#portal-cvo-popup-modal .el-dialog__header {\n  padding: 16px 20px;\n  border-bottom: 1px solid #eeeeee;\n  margin: 0;\n}\n\n#portal-cvo-popup-modal .el-dialog__title {\n  color: #212f3f;\n  font-size: 19px;\n  font-weight: bold;\n}\n\n#portal-cvo-popup-modal .el-dialog__body {\n  padding: 24px 40px;\n  text-align: center;\n}\n\n#portal-cvo-popup-modal .el-dialog__body p {\n  font-size: 15px;\n  line-height: 21px;\n  text-align: center;\n  color: #000000;\n  word-break: break-word;\n}\n\n#portal-cvo-popup-modal .el-dialog__body span {\n  color: #00b14f;\n}\n\n#portal-cvo-popup-modal .el-dialog__footer {\n  padding-top: 0;\n  text-align: center;\n}\n\n#portal-cvo-popup-modal .el-dialog__footer button {\n  margin: 0 8px;\n}\n\n.box-change-template {\n  background: #ffffff;\n  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);\n  border-radius: 8px;\n}\n\n.box-change-template__header {\n  padding: 16px;\n  word-break: break-all;\n  position: relative;\n  border-bottom: 1px solid #eeeeee;\n}\n\n.box-change-template__header--btn {\n  position: absolute;\n  top: 12px;\n  right: 16px;\n  padding: 0;\n  border: none;\n  outline: none;\n  cursor: pointer;\n  font-size: 16px;\n  border-radius: 20px;\n  background: #eeeeee;\n  width: 32px;\n  height: 32px;\n  color: #777777;\n}\n\n.box-change-template__title {\n  font-style: normal;\n  font-weight: 500;\n  font-size: 19px;\n  line-height: 24px;\n  color: #212f3f;\n}\n\n.box-change-template__template {\n  padding: 20px 12px 12px 12px;\n  max-height: 70vh;\n  overflow: auto;\n}\n\n.box-change-template .template {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 16px;\n}\n\n.box-change-template .template__item {\n  cursor: pointer;\n}\n\n.box-change-template .template__item p {\n  color: #555555;\n  font-size: 12px;\n  line-height: 16px;\n  margin-top: 8px;\n}\n\n.box-change-template .template__item img {\n  border-radius: 3px;\n  transition: 0.3s;\n}\n\n.box-change-template .template__item:hover img {\n  transform: scale(1.05);\n}\n\n.box-change-template .template--active p {\n  color: #00b14f;\n}\n\n.box-change-template .template--active img {\n  border: 1px solid #00b14f;\n}\n\n.box-change-template .template--active:hover img {\n  transform: scale(1);\n}\n\n.box-change-template .template::-webkit-scrollbar-thumb {\n  background: #c1bebe;\n}\n\n.box-change-template .template::-webkit-scrollbar {\n  width: 5px;\n  border-radius: 10px;\n}',
        "../assets/scss/components/modal/_custom-layout.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.el-overlay {\n  background: rgba(38, 58, 77, 0.5019607843) !important;\n}\n\n.custom-layout {\n  position: absolute;\n  right: 0;\n  top: 0;\n  margin: unset;\n  height: 100vh;\n}\n\n.custom-layout .el-dialog__header {\n  padding: 16px 20px;\n}\n\n.custom-layout .el-dialog__header .el-dialog__title {\n  font-family: "Roboto";\n  font-size: 19px;\n  font-weight: 500;\n  line-height: 24px;\n  text-align: left;\n}\n\n.custom-layout .el-dialog__headerbtn {\n  width: 32px;\n  height: 32px;\n  gap: 0;\n  border-radius: 20px;\n  background: #EBEBEB;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  right: 31px;\n  top: 12px;\n}\n\n.custom-layout .el-dialog__headerbtn i {\n  font-size: 12px;\n  font-weight: 400;\n  line-height: 21.33px;\n  text-align: center;\n  color: #424E5C;\n}\n\n.custom-layout .el-dialog__body {\n  text-align: center;\n  padding: 24px 24px 8px;\n  background: #F4F5F5;\n  height: calc(100% - 128px);\n}\n\n.custom-layout .el-dialog__footer {\n  border-top: 1px solid #E9EAEC;\n  padding: 16px 20px;\n}\n\n.custom-layout .wrap-cv {\n  background: white;\n  padding: 8px;\n}\n\n.custom-layout .wrap-cv #tooltip-splitpanes__splitter {\n  display: none;\n}\n\n.custom-layout .btn__add-section {\n  width: 113px;\n  height: 32px;\n  padding: 2px 16px 2px 8px;\n  gap: 8px;\n  border-radius: 45px;\n  background: #FFFFFF;\n  border: 0.5px solid #FFFFFF;\n  box-shadow: 0 7px 20px 0 rgba(0, 0, 0, 0.0117647059);\n  margin: 8px auto;\n  cursor: pointer;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.custom-layout .btn__add-section span {\n  font-family: Roboto;\n  font-size: 12px;\n  font-weight: 500;\n  line-height: 16px;\n  text-align: left;\n  color: #00B14F;\n}\n\n.custom-layout .btn__add-section i {\n  color: #00B14F;\n  font-size: 12px;\n  font-weight: 900;\n  line-height: 18px;\n  text-align: center;\n}\n\n.custom-layout .section {\n  position: relative;\n  border: 1px solid #DFDFDF;\n  padding: 8px;\n  border-radius: 4px;\n}\n\n.custom-layout .section:last-child {\n  margin-bottom: 0 !important;\n}\n\n.custom-layout .section:hover {\n  border: 1px dashed #15BF61;\n}\n\n.custom-layout .section:hover .wrap-action-column {\n  display: flex;\n}\n\n.custom-layout .default-theme {\n  margin-bottom: 10px;\n  min-height: 50px;\n}\n\n.custom-layout .default-theme .splitpanes__pane {\n  height: auto;\n  background-color: unset;\n}\n\n.custom-layout .default-theme .splitpanes--vertical .splitpanes__splitter {\n  position: relative;\n  width: 3px !important;\n  margin: 0 3px;\n  border: unset;\n  background-color: unset;\n}\n\n.custom-layout .default-theme .splitpanes--vertical .splitpanes__splitter:hover::after, .custom-layout .default-theme .splitpanes--vertical .splitpanes__splitter:hover::before {\n  background: #57D991;\n}\n\n.custom-layout .default-theme .splitpanes--vertical .splitpanes__splitter::before {\n  content: "";\n  background: #B3B8BD;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  border-radius: 100px;\n  transform: translate(-50%, -50%);\n  margin: 0;\n  width: 0.5px;\n  height: 100%;\n}\n\n.custom-layout .default-theme .splitpanes--vertical .splitpanes__splitter::after {\n  content: "";\n  width: 5px;\n  height: 15px;\n  background: #B3B8BD;\n  display: block;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  border-radius: 100px;\n  transform: translate(-50%, -50%);\n  margin: 0;\n}\n\n.custom-layout .default-theme .wrap-action-column {\n  position: absolute;\n  right: -1px;\n  top: 50%;\n  transform: translate(50%, -50%);\n  flex-direction: column;\n  display: none;\n  gap: 8px;\n}\n\n.custom-layout .default-theme .wrap-action-column .btn-action {\n  padding: 5.14px 6.86px 5.14px 6.86px;\n  border-radius: 38.57px;\n  border: 1px solid #FFFFFF;\n  box-shadow: 0px 0px 25.71px 0px rgba(0, 0, 0, 0.1019607843);\n}\n\n.custom-layout .default-theme .wrap-action-column .btn-action.add-column {\n  background: #00B14F;\n}\n\n.custom-layout .default-theme .wrap-action-column .btn-action.add-column i {\n  color: #FFFFFF;\n  font-size: 14px;\n  font-weight: 600;\n  text-align: center;\n}\n\n.custom-layout .default-theme .wrap-action-column .btn-action.remove-column {\n  background: #D83324;\n}\n\n.custom-layout .default-theme .wrap-action-column .btn-action.remove-column i {\n  color: #FFFFFF;\n  font-size: 14px;\n  font-weight: 600;\n  text-align: center;\n}\n\n.custom-layout .default-theme .layout-render {\n  width: auto;\n  height: auto;\n  min-height: 50px;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n  border: 1px solid transparent;\n}\n\n.custom-layout .hover-delete {\n  border: 1px dashed #D83324 !important;\n}',
        "../assets/scss/components/modal/_list-block-content.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.modal-list-block {\n  width: 950px;\n  height: 648px;\n  background: #ffffff;\n  border-radius: 5px;\n}\n.modal-list-block--filter {\n  width: 530px;\n  height: auto;\n}\n.modal-list-block--filter .wrapper {\n  height: 405px;\n  overflow-y: scroll;\n  padding-right: 10px;\n}\n.modal-list-block--filter .title {\n  font-weight: bold;\n  color: #212f3f;\n  margin-bottom: 12px;\n  font-size: 15px;\n}\n.modal-list-block--filter .guide {\n  margin-bottom: 16px;\n  font-size: 15px;\n  color: #212f3f;\n  font-style: italic;\n}\n.modal-list-block--filter .list-block-content {\n  margin-bottom: 20px;\n  display: grid;\n  gap: 8px 12px;\n  grid-template-columns: repeat(2, 1fr);\n  grid-template-rows: unset;\n}\n.modal-list-block--filter .block-item-not-use {\n  position: relative;\n  background: #f4f4f4;\n  border-radius: 6px;\n  padding: 10px;\n  cursor: pointer;\n}\n.modal-list-block--filter .block-item-not-use.block-item--active {\n  background: #e5f7ed;\n}\n.modal-list-block--filter .block-item-not-use.block-item--active .block-item-not-use__title {\n  color: #00b14f;\n}\n.modal-list-block--filter .block-item-not-use.block-item--active .block-item-not-use__check {\n  display: block;\n  color: #00b14f;\n}\n.modal-list-block--filter .block-item-not-use:hover {\n  background: #e5f7ed;\n}\n.modal-list-block--filter .block-item-not-use:hover .block-item-not-use__title {\n  color: #00b14f;\n}\n.modal-list-block--filter .block-item-not-use:hover .block-item-not-use__check {\n  color: #00b14f;\n}\n.modal-list-block--filter .block-item-not-use__icon {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #00b14f;\n  margin-right: 16px;\n  width: 20px;\n}\n.modal-list-block--filter .block-item-not-use__title {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #212f3f;\n}\n.modal-list-block--filter .block-item-not-use__check {\n  display: none;\n  position: absolute;\n  right: 15px;\n  top: 13px;\n  color: #f4f4f4;\n}\n.modal-list-block--filter .block-item-use {\n  position: relative;\n  background: #f4f4f4;\n  border-radius: 6px;\n  padding: 10px;\n  cursor: not-allowed;\n}\n.modal-list-block--filter .block-item-use__icon {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #999999;\n  margin-right: 16px;\n  width: 20px;\n}\n.modal-list-block--filter .block-item-use__title {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #999999;\n}\n.modal-list-block--footer {\n  border-top: 1px solid #eeeeee;\n  padding-top: 16px;\n  text-align: right;\n}\n.modal-list-block .el-dialog__headerbtn {\n  font-weight: bold;\n  font-size: 19px;\n  line-height: 27px;\n  color: #333333;\n}\n.modal-list-block .el-dialog__headerbtn:hover .el-dialog__close {\n  color: #333333;\n}\n.modal-list-block .el-dialog__header {\n  padding: 16px;\n}\n.modal-list-block .el-dialog__title {\n  font-style: normal;\n  font-weight: 700;\n  font-size: 19px;\n  line-height: 24px;\n  color: #333333;\n}\n.modal-list-block .el-dialog__close {\n  font-weight: 700;\n  color: var(--el-color-info);\n  font-size: 19px;\n}\n.modal-list-block .el-dialog__body {\n  border-top: 1px solid #eeeeee;\n  padding: 16px;\n}\n.modal-list-block .list-block {\n  width: 100%;\n}\n.modal-list-block .list-block__wrapper {\n  display: grid;\n  gap: 16px;\n  grid-template-columns: repeat(4, 1fr);\n  grid-template-rows: unset;\n  overflow-y: scroll;\n  height: 470px;\n  padding-right: 12px;\n}\n.modal-list-block .list-block__wrapper::-webkit-scrollbar {\n  width: 6px;\n  background-color: #f5f5f5;\n}\n.modal-list-block .list-block__wrapper::-webkit-scrollbar-track {\n  border-radius: 10px;\n  background: unset;\n  border: unset;\n}\n.modal-list-block .list-block__wrapper::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  background-color: #d9d9d9;\n}\n.modal-list-block .list-block__wrapper::-webkit-scrollbar-thumb:active {\n  background: linear-gradient(left, #22add4, #1e98ba);\n}\n.modal-list-block .list-block__wrapper .block-item {\n  background: #f4f4f4;\n  padding: 24px;\n  position: relative;\n  margin-bottom: 32px;\n  width: 195px;\n  height: 195px;\n}\n.modal-list-block .list-block__wrapper .block-item__img {\n  height: 100%;\n  width: 100%;\n  border-radius: 10px;\n  object-fit: contain;\n}\n.modal-list-block .list-block__wrapper .block-item__overlay {\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background: rgba(255, 255, 255, 0.4901960784);\n  opacity: 0;\n  transition: all 0.2s ease;\n  justify-content: center;\n  align-items: center;\n}\n.modal-list-block .list-block__wrapper .block-item__overlay:hover {\n  opacity: 1;\n}\n.modal-list-block .list-block__wrapper .block-item__btn {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  border-radius: 20px;\n  padding: 9px 20px;\n  width: 136px;\n  height: 40px;\n}\n.modal-list-block .list-block__wrapper .block-item__title {\n  position: absolute;\n  bottom: -30px;\n  left: 50%;\n  transform: translateX(-50%);\n  font-style: normal;\n  font-weight: 500;\n  line-height: 20px;\n}\n.modal-list-block .list-block__wrapper .block-item:hover, .modal-list-block .list-block__wrapper .block-item.active {\n  border: 1px solid #00b14f;\n}\n.modal-list-block .list-block__wrapper .block-item:hover .block-item__title, .modal-list-block .list-block__wrapper .block-item.active .block-item__title {\n  color: #00b14f;\n}\n.modal-list-block .list-block__wrapper .block-item:hover .block-item__overlay, .modal-list-block .list-block__wrapper .block-item.active .block-item__overlay {\n  opacity: 1;\n  background: rgba(0, 0, 0, 0.1);\n}\n\n.modal-list-block--filter .list-block__wrapper {\n  display: grid;\n  gap: 16px;\n  grid-template-columns: repeat(3, 1fr);\n  grid-template-rows: unset;\n}\n\n.category-block__wrapper {\n  overflow-y: scroll;\n  height: 490px;\n  padding-right: 8px;\n}\n.category-block__wrapper::-webkit-scrollbar {\n  width: 6px;\n  background-color: #f5f5f5;\n}\n.category-block__wrapper::-webkit-scrollbar-track {\n  border-radius: 10px;\n  background: unset;\n  border: unset;\n}\n.category-block__wrapper::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  background-color: #d9d9d9;\n}\n.category-block__wrapper::-webkit-scrollbar-thumb:active {\n  background: linear-gradient(left, #22add4, #1e98ba);\n}\n\n.category-item {\n  border-radius: 6px;\n  padding: 10px;\n  position: relative;\n  cursor: pointer;\n  margin-bottom: 4px;\n}\n.category-item__icon {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #00b14f;\n  margin-right: 16px;\n}\n.category-item__title {\n  font-style: normal;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #212f3f;\n}\n.category-item__check {\n  position: absolute;\n  right: 15px;\n  top: 13px;\n}\n.category-item.active, .category-item:hover {\n  background: #e5f7ed;\n  color: #00b14f;\n}\n.category-item.active .category-item__title, .category-item:hover .category-item__title {\n  color: #00b14f;\n}\n.category-item.used {\n  color: #777777;\n  cursor: not-allowed;\n  background: #f4f4f4;\n}\n.category-item.used .category-item {\n  cursor: not-allowed !important;\n}\n.category-item.used .category-item__icon {\n  color: #777777;\n}\n.category-item.used .category-item__title {\n  color: #777777;\n}",
        "../assets/scss/components/modal/_modal_action.scss": '.w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.header-close {\n  display: flex;\n  padding: 16px 16px 8px 16px;\n  justify-content: space-between;\n  align-items: center;\n  align-self: stretch;\n}\n.header-close .box-data-sample__title {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.btn-close {\n  color: red;\n  display: flex;\n  width: 24px;\n  height: 24px;\n  justify-content: center;\n  align-items: center;\n  border-radius: 30px;\n  background: var(--Neutral-Neutral-10s, #F2F4F5);\n}\n.btn-close:hover {\n  text-decoration: none !important;\n}\n.btn-close i {\n  color: var(--Neutral-Neutral-40s, #7F878F);\n  text-align: center;\n  font-family: "Font Awesome 6 Pro";\n  font-size: 16px;\n  font-style: normal;\n  font-weight: 400;\n  line-height: 24px;\n}',
        "../assets/scss/layout/color/_choose-color.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.mx-6 {\n  margin-left: 6px;\n  margin-right: 6px;\n}\n\n.mr-6 {\n  margin-right: 6px;\n}\n\n.change-color {\n  border: none;\n}",
        "../assets/images/template_cv/basic_5/background/basic_5_F1F2FF.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlIAAANJBAMAAAA1l8+sAAAAD1BMVEX////x8v/29//5+v/8/f/iXdBUAAAKGUlEQVR42uzcO7HlMBQAQUHQlQ1AEAzB/FFtvvWCCVTlpAdCp+czfvqrZ/wfqb/bpEiR+qhJihSpFqkaqc+6SZE63EWKFKmPWqRIkWqRqpGqkaqR+i5SpEjFSNVI1UjVSNVI1UjVSNVI1UjVSNVI1UjVSNVI1UjVSNVI1UjVSNVIfZN5H6kfqRqpGqkaqRqpGqmPsmVN6kfqo1wYkTqdS0hSP1I1Uh/lBwepH6kaqY/yqYvU+V5SsUGKFKlvWqRIkfqoixSpw92kYpMUqcNtUqRIfdRDKvaSig1SpM62SJE63EUqdpOKTVKkDrdJkTrcQyr2kooNUq1FitThLlKxm1RskoptUqQO95CKDVKkzrZIxS5SsZtUbJKKbVKxh1TsJRUbpFqLVOwiFbtJxSap2CYVe0jFBilSZ1ukYjep2CQV26RiD6nYIEXqbItU7CYVm6Rim1TsJRUbpFqLVOwmFZukYptU7CUVG6Rai1TsJhWbpGKbVGyQInW2i1RskoptUrGHVGyQai1SsUkqtknFHlKxQaq1SMUmqdgmFXtIxQap1kUqNknFNqnYINVapGI3qdgkFXtIxQap1kUqNknFNqnYINVapGKTVGyTig1SrUUqNknFNqnYINVapGKTVGyTig1SrUUqNknFHlKxQap1kYpNUrGHVGsNUq1JKrZJxQap1kUqNknFHlKtNUi1Jql/7NlRUttAEEXRV8ELGM14AcJkARPMApSY/a8pFFAx2LL8FJS4Jd3z599bM62WbKqUMolSnkIpU0spkyjlKZQyJUqZRClPoZQpUcrUUcqTRSlPopSpo5Qni1KeRClTRylPEaU8iVImUcpTKGVqKWUSpTyFUqaWUiZRypMoZaqU8mRRypMoZRKlPIVSppZSJlHKkyhl6ijlKaKUp6WUSZTyJEqZOkp5iijlqZTyZFHKkyhlEqU8iVKmSilPEaU8lVKeLEp5EqVMopQnUcokSnkSpUwdpTxbUcpTKeUpopSnUspTRClPpZSniFKeSilPEaU8lVKeIkp5KqU8RZTyVEp5tqKUp9MkfjZLlzSNTbN0kjhU9pFiUl2XNZ1vzZK1mtCPZrmKpnTXLFeVOFSjjhSbwhWd3rApXJE0uftmibJeMdSvavWKoX5N0TuG+hWd3jHUhyUdMdQHZH3AUB9QdcT9G7DVJwz1i3SGzy+9Wp1iqepVdIr710/nuH99Wp3j/vUo6sP9O6d+3L9Trfpx/04U/R+bub//ZQ3h/e+oagjvf39sNYxRZd89VoU3na5iVTAXBEbVmCG1+k/FWRZGlT+k1r5VVZnWPqq+a4Q1b1VFo6z3BTBrlBWPqk6+VaequqlfzVy0Gm+VU32rm5tHqqLbm8UDMCuCGaTKnUKI/wAMEip+qqowYqcKFCr2WhUqVORUN98455IqXKioqQKGipkqZKiIqYKGipcq2FMvbqrAoaRDE0foUIG29Rw8VJgvC1G+HoRPNYdQ0ub2X0EjfOG0PDZ/YQl/Fc9tWwg/yz+6Gzes1vXQCzLXyyxmeYBhNaMRNXJfX/fN828gN898BnLz7GO1vrU8wLGa9YEaOlYcqJscq/ykhdj8293qQQvy6Qpy8QYdjq3YNZ1WDCizFZ38VnRy3e2aKeyWOJ/Od4avHqz8sLTn3UWH3VeO09Kv3VksMo2IdU8m12Zv1rrf7Vczmy7aHB6Hc+0enqh09HzY7140R/nl5/7pWQAAAAAAAAAAAAAAAAAAAAAAAAB+s0MHBQ7DQADEmsQEFoIhBILLH9RBuHn0KUEQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwO9994fg2TMf/rX2jKngnjFVfMdUssdUjDIVo0zFKFMxylRyxlTyHVPJM6aStU0175hK7jGVrDHVvKaae0w121RzjalkjanmmGrWmGqOqWaNqeaYataYai5T0TbV3GOqeU01a0w1l6lom2qeMdUcU9E21Txjqjmmom2qecZUc5mKXlPNGlPNbSo6pqJtqlljqrlNRcdU9JqKxlTzmIpuU9ExFb2mojHVLFPRbSq6TEXHVPSairapaEw1y1R0mzL1Y5ep6JiKXlPRNmXqx8aUqd9apqLH1B8752LjRBAE0ba9AVAHAbCGALAhAHzOPycsS4DEcefyTuu86n4vhKfpnpovppLZYgpTmPLA1MPYYApTmPLAlAumXDDlgikXTLlgygVTLpiyYd1ngikXTLlgyod9dA9M3QHnfT6cITtg6i6462KAqfvgTp4N9zx9uDvswn30G2DqXng3Y8NbLBfe97nwZtSFd8g2vG234b8EE/7gsOFfl/dmvsvU+bifdeVpv//+MzqxsU1Nx5dW9z+iDVvT1HnW/9l3GVmTZeqoN3j6Fi0wTD3rAq7mW6Z2s27zJeqzuWVKVxhWsbVMMawuZJnSU/VZcDZMmRSvwE2eKX2OymxvmULVbzJN6WsUZr5lilFlNaoQqrylXwhVXvmFUPWHk2WKXBWxyzb1FFWZ3zSFKq/8Qkv4EDXZLTHVs6vPS021O/3a5Jv6GCWZlpnqWH+Hxaa61d9usal29TcvNdWu/jaLTbXLn2OmOuXPk2/Kp+RpzTRiqldTP42YatXUpxFTvZr66RVTDCpvUIUYVN6gCjGovKAeYlB5q78Qg8rbUggxqLym7pvqdaa1fcUUQf0Fh1dMsfr7l2lOMdVgSyF2KaY67BPH87ipHkEh4jBsqkdQuHAYNtUjKERMc4apBj39qmrcVIeeflU1aqpHT4+YDqOmWuT0K8dhUz3K78J50FSX8rs2qyFTfcrvwnkeMdVhmfyX5zlE+ZmI8nsHU11mv3FTvcpPSXyK6miEVuWnITqVn8ZosPWSZKrBzmeSqUYxXWM0alQapE9OEI3KRDQqE9GoTESjMhGN6v1MNVn6KYEejUoZtFj6KYMWW8TKoEVLVwYtsqcyaNHSlUKHlq4cGrR05dCgpSuHBildSdS+G5tpqv7kpyzKT37KovzkpyzKT37KovzkpzSqr/yURvXJT3kUn/ww9QBTxWOC8igeE5RH8ZiAqUeYqh2olEjtfRclUjt6KpPSgQpTDzFV+hKVMikd0pVJ6ZCOqYeYKh3SMYWp1Zsqu/BTKpUXfph6jKnKS2RMYQpTJus3VXbbBVOYwpQJplww5YIpF0y5YMoFUy6YcsGUC6ZcMOWyflPsumAKU5jClMf6TXHeh6lUuJdgw10XTGGKe56Yclm9Ke6je/DGwaXw9hSmeN+HKZfVmyq77ONtO6bWbqpuROdfF/4KwpTL2k3VjVO5pgqfN/D3Iv95xspNFQ4J/DvMX9a/2jtjGwBgGAb9/3WPiFVZhhcYcNShlJManj7/3Lfj0E1qefrszdgw6ia1+4ieI7U/ffb7bEJWk5oWuu1ae8jNpLY1Zbf9KynC3RkgRdFUgBREU2dSGE0FSDGuqTspjKYeveOVlU6kY+UAAAAASUVORK5CYII=",
        "../assets/images/template_cv/basic_5/background/basic_5_F2FBFD.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlIAAANJAgMAAAC61zoMAAAADFBMVEX////y+/31/P75/v9ULoXXAAAIc0lEQVR42uzau80UMRSG4U8QgQRUQUABBBCgv4QNZmwLHEwMSLgEN0EJBCAk6AA3QQkEZMQkMCz3++E2+6743goe2d4z3tnVzKnqfVb9rGKVVf+gyaojV2WrrJpnqw5YssqqebYqnlXxrIr3n6hmq6xasyqeVfGsimdVPKsOFfUmY5VVa1bFsyref6Jivhe1yqo1qw4W9VdLq6JR/zlg1bGrmP90surYVTurjly1WHXkqmbVkatOrArXrQo3rDpylYiqZNWRq7JV4SakqlgVrlp15KodUrVYFa5ZFe4EqepWhRtIlYiqZFW4bFW4CakqSFW1KtwOqVqQqmZVuG5VuIFUiahKVoXLSNWEVBWkqiJVO6RqQaqaVeG6VeEGUZVkVbSMVBWrwlWkarEqXEOqulXhRFQlpCojVRNSVZCqilQtVoU7Qao6UjWIqiSrok1IVUGqKlK1IFUNqTpBqjpSJaIqIVUZqSpIVUWqFqSqIVXdqnAiqhJSNSFVBanaIVULUnWCVHWkSkRVQqompKogVTukqiFVHakaRFUSUZWRqoJUVaRqQapOkKpOVCURVRmpKkhVRaoWpOoEqRpEVRJRlZGqglQtSFVDqjpSJaIqI1UFqapIVUOqOlI1iKosoqogVRWpakhVR6pEVGWkqiBVC1LVkKpBVCURVRNSVZGqBanqSJWIqoxUVaRqQao6UjWIqiyiqiJVC1LVkSoRVRmpqkjVglR1oiqJqJqQqopUNaRqEFVZRFVBqhakqhNVSURVQap2SNUJUjWIqiyiqiJVDakaRFUWUVWRqoZUDaIqi6iqSFVDqgZRNSnQ3Xnjdgp0cd64rkBn5m1LinRq3rYiAQ/WolCX503rCnVu3rKsWKfnLasK9nTesKY12mxIWsPNhqI13GxYtIabDUNrtNmQJeAW3ta7UPeGLvG2MGkfbLxX/VLP5k1q2sca70kCbmHVu1BP6CbxtjDpXagndJGAW9gk3hYmreE+hVX7YIO0SbwtTBJwC6s+BLrOdH2Ic53J+r1Ox2+kf34LhXypGPrNzs//rht6F+qp0/TbXZn/VWnoTbCRVbUPNrK61mjnPeurAF+iF63RznsaWqOd96o13HnvWqOd9y/mOuRK2vRZjCtp1j7YcFi0jzUcvhgLkMtflYCLNfQu0iStehdqkg4F2vr9TJGAi9Ul3mIVCbhYXeItVtVf7RLsA/h+wAOXSrqCeQIGFuvPXngQ7lnfWCrApbTpH3T+8Lf1b3UJNRU+HnjYUX/b2b/1FQJz4B/rkyh7+Pn+QfYw65/2HLd/+z28h9u//Sy9i5mfn3aV8fz70ztNeqEteoY66b934h9qm1YW6OP36YwHoqQLQdYdbdm6iagz9ZEFRAUeiemxDtG1Hx6um0OH6cL97y/UdrsXX65bQwft5TdcD17o4L168Bnp+iOA6S3s5YMHb0APHjyhkJxzzjnnnHPOOeecc845516za//WTUNhGMY/S8eFCrnzCBrBRSoYIQWv4QAFPRSMkBHSaIQ0aWADsoRGcMEKVAjbBNky4VZXj8j7TPA79tV3r/4455xzzjnnnHPOOeecc84555xzzjnnnHPOOeecc84555xzzjnnnHPOOeecc8455/6zVrfBq2yvA1e5E1B1JaBqJaKqI6pqEVUdUVWLqOqIqpWIqoaoKkVUVUhVR1QVIqoqpKojqkoRVRVS1SBVLVFViKhaIlUNUiWiqkCqlkhVg1S1RFUpoqpGqpZIVYNUtURVKaKqQKoqpGqDVDVIVUtUlSKqCqSqRqoqpKpBqtZIVYtUiagqkKoFUlUjVRVStUGqGqRqjVR1SFWLVImoKqxKboFU1UhVhVQtkaoNUtVYldzaquQ6pKq1KjlZlVpp1cxVhVVWRVg1YQurrIqwKr1nomLOK6us6nsmKua5nali3qVaNftnMkwV81kf87koU8V83s5UMd/jMN95Md8PMt+lMt87M9/Rl1bN/TuZ7i+qF/d32t5/e4hJWl9Ure50aPslpqi5pPqhP318iPxtLqi+a9jbCVjLsapHTc2qR6ornfcucrcYqTTuU2SuTFHpa2QuSbXNvbS6sQrwH66TVNubyNomSaU3kbXlBdX0C74eqQg/VpGoUtaVVY5UiB+rTVQp68xaX1BNP7M2qaptZKxKVelz5GsxUhHWezlSIdZ7l6z6EPlqklWvI1/LsQow3+szFeMvLM9UkL+wPVMxrsLmVAX5C6tzFWKQFiMVYi9sz1WIvbBJV72PbFWnKshsKE5VlNnQDlXAhdWrMAurHqowC6scqjgLqxuoOAurGqg4C6scqDgLK3bJKkW+qlMV5JhctkMV5YwVzVBFOWPFaqjCnLFi96gCzdGoklUvI2PtUYVa7lEdVajlHrE7qkjTPWJ1VJGme9/VQUWa7r+6O6hAh5nDvpOkuo68rW5DtItwn2gX4T7hLsK9incR9ol3Ee5VsJ3wUQW6z0lX6VXkThLrOLpPyNEg5GgQcjQIORqEHA0S8dQgEU8NQg4sIQeW+lh39b9VsLv6PiHHqJBjVMgxKuQYlYjnPiGHu5DDXcjhLuRwl4hnZCG3HCG3HCG3HPXxnvcJuREKuRHOWpV5exZyexZye561SpE1IQ8N81bdxBNZNeEBS8gD1rxVTx77rJqB6jqeyKr0g7tVVp0l5E2OVVb1WZV+S2+VVVZZNc6qGcx2q6x6PirmPY5Vc1cxn8kwVcxnfVbN/Xk7U8V8j8N858VUMd+lMlXxj/w9A1zF/E6G+U0R8/srpupnO3dsBAAMwjCQ/admBFxxXzgTpPJRSDK5PpOBNHlRk601OWST2Tb59rlevQnbMTF9HNNdMj0v04kz/cFj2vsr3eE1fed0ROvRq80Bs8+Q3sftfqCNlPe5Wvbn+3XPV87pAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/basic_5/background/basic_5_F5FBF8.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlIAAANJAgMAAAC61zoMAAAADFBMVEX////1+/j6/fv8/v1xWg8pAAAILklEQVR42uzaMbINQRTG8Y9bAgGZJViCQNZLmKCnbxcTdKgQ3CX0JixBQsACBLMJS5CIpJRShhoKhTqFmft/5fuv4Fd9Th3jvaeRU9WXrLLq35WtsmocrTpjR6suuKpYZdU4WnXOrLJqyap4VsWzKp5V8ayKZ1U8q+JZFc+qeFbFsyqeVeeK+tMPq6xa+k9UzN8CWBWN+ps4q6xasupsUf9Oxqp4k1XhBqus2qBm1QVXnZCqZJVVG9StCjcjVbLKqn9fsSrcEanKVl1wVUWqJqRqsOqCqxpSdUKqklUXXNWRqhmpklXRilXhslXhqlXhJqRqQKqaVeGSVeG6VeFkVbSCVB2RqoxUVavCDVaFa0hVsipcR6pmpEpEVUGqjkhVRqoqUjUhVQNS1ZCqE1KVkKqOVMmqaAWpykhVRaompGpAqhpSlawK15EqEVUFqcpWhZuQqgGpakhVQqo6UiWroh2RqoxUVaRqQKoaUpWQqo5UiagqSFVGqipSNSBVDalKSFVHqkRUFaQqI1UVqRqQqoZUJaSqI1UiqgpSlZGqilQ1pCohVR2pElFVkKqMVFWkqiFVCanqSJWIqoJUVaRqQKoaUpWQKhFVBanKSNWEVDWkKiFVM1FVRFRlpGpCqhpSlZAqEVUFqcpI1YBUNaSqI1UiqjJSVZGqhlQlpEpEVUGqKlI1IFUJqZqJqiKiqiJVA1KVkKqZqCoiqipS1ZCqhFSJqMpIVUWqGlLViaoioiojVQNSlZAqEVUZqZqQqhNS1YmqIqKqIlUNqepEVRFRVZGqhlR1oqqIqKpIVUOqOlF1FFE1KdCNceeSAl0Zd06RLo37liXgYg0KdXPcta5QV8c9K4p1edyzqmAvxx1rWsLdhlkS7jZkhXs07tagJdxt6Fqi3YaieIdxryatob4bksQb4TpA2HlfDzvsvJ/0Odh5l4AjXAcIO+9NAo5QAo6wSsARNgk4Qgk4wioBR9gk4Agl4Airvgb6nDnpa5zPmaJvwnyRTvouyH8quv6wa+N2HfU52Mlq+uNujZs161Owk7UeK9jJWo8V62QVLeH2fd112MmatUTb9yoBHytpibbvRy3h9r1JvMcqEvCxJi3h9n09C6zjUCXgY3WJ91hVAj5Wl3iPVSXgY3WJ91hVAj5Wl3iPVSXgY3WJ91hVAj5W1z/uQPlY+NffWWXW9yG+s5o26Nr5v9Z/1k3Yqq/Xgbbqf7/wRZv16s9VJ30TZYZV3waZ4Y+nijHD59q0wx/d0ofauOt/gLqrzbtNW6p1tWBLtfYY8I/yzzYetelfuvwIiJKuh1kPtE8rC4iKsu5p5w6PUDv1lfWKcad+7O1vTXdmRdtvuZ7pfL371UO90Tk7vP6Z6YXO3rsf5vjkjRAdPjxZZfefvpdzzjnnnHPOOeecc84559xHdueYiIEYBoBgbI8KF04nCA/heaQRNEELn1D4JjNX3CJYSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSfqD9+fFswq4Wk1cXQVcnSKumrjaRVw1cbWLuGri6hRxlcTVLOIqkKsmrmYRV4FcNXE1i7jayFUiV0VcDeQqkKtEroq4GshVIFeJXDVxNYu4OshVIFeJXDVxtYq4GshVIFcXcpXIVRNXq4irgVxt5CqQqwu5SuSqkasiriZyNZCrg1wFcnUjV+nqsUauirhayNVErgZydZCrjVyFq8du5OpCrtLVY19XjzVyVa5+7N3BbdtAEIXhIQUeeIhvLEEl5BqkiDwlCHJIB3EJaYIl+GyXoGZchG82ZUkmubYwp9G/8LwKPojD2VnuAqpbtUmVO22qKlc1qUqVWar8SZU/qfInVf6kyp9PomLOV6mqfY/DVDH3zqmq/vsV81sfU8X8hsxUMc8mmOc4zDMvpop5lso8DWeqmPcZmHc/mPdkPrxT9O1O0u5+bwHx3r+6OWP/mSMxqie95XfAz+W61/eoeXZXYHWFakJdm9UXqq9a56dFpylUKvPHgtN6VLq14HhU8aU1lirAMxxcKv230Gx9ql8Wms6n0oNFpneqflhkmlIFqKxNqSJUVqFC/FjDO6rr96ytV7WzwHRelf5aXJpSBWgOm0KFqPfRoYrflg0OVfxQ2q1UjEf4ZaViPMJ2pYI8wnGpgjzCYa1CNNJurUI00sav0t7CslRRHuFQqgCzX1eoCONMs1RResNCBSysFxWmsPq5ClNY7VzFKaxxpuIUVjdTcQqrnak4hWXjXIVZCju/6ruFpV2qIGOybecqyoxl/VlFKncbzypQH7X+pCKVu9l4VKHK3fqTCtTdz/8LIFa5W+9UyUKzPahg5W6b8VUFGmam3CxUjK/JE2tSodacY0R7CQ8R7iWcItxL+J4KcTpuEmwlPKpoK+EUIVuDkK1Bkki7r9cI2RqEbA1CtgYJODWYkK1Bp1COmQ4RsmFJxFlGkli7+ilCtlFJvG2OCdlGhWyjEnHuE7K5C9lGhWyjVauCm7uQzb1qVfCSI+SSU7UqeCEUciEUciGsWhW89xJyaBByea5btbfICDnK1K26OMqkqgLVrUVGyGG0btXFYTRVqVpFyO2EkNuJVH0W1cWtV6pSlapUlUlVqlKVqjKpqkDFnEVTVbuKuXdmqphfP1JVu4r5tZapYp4CME9MmCrm+SBTxTx3tktJFf/uB1PFvFPEVD23c8dGAMAwCAMZPaNng8SV7wuYgIpKwmTVTK7PZCDNViZba3LIZiuTb88zbcU7JqaPY7pLpudlOnGmP2i6lqaXmm/qO9PG+mBE+zlA/zOYDxsnyyHnyvyTuY9j2bdb6uwrAAAAAElFTkSuQmCC",
        "../assets/images/template_cv/basic_5/background/basic_5_FFF8F5.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlIAAANJAgMAAAC61zoMAAAADFBMVEX/////+PX/+vj//fs7fEl2AAAIY0lEQVR42uzavY0UMRjG8Ue7EQRQxQWUAJFLmGDGtsDBxAgJlzBNUAIBHxKU4CYogYCMGCFgl6+7RQiZ43buv+L5V/CT3/d83rvVxKnoRyRVtsqqIzRaZdU0/SeqZJVVRyhaZdU0WdWfVdeZVVbtsqo/q/qzqj+r+rOqP6v6s6o/q/qz6rqifvKyyqpdVvX3n6iYf9m26tRVzP/EWWXV1Uf9loVVp65ifivMqv4Gq05cNVt14qpqVXfBqhNXLVaduKohVbLqtFXRqu6SVd2NSFW26sRVBakarOputqq7ilQFq7pbrOquIVUiqqJV3SWkarSqu4xUFau6G5CqGamqSFWwqrsFqWpIlYiqaFV3CakakaqMVBWkakCqZqu6C1Z1tyBVDakSURWRqoRUjUhVRqoKUjUgVTNSVZGqgFQtSJWIqohUJaRqRKoyUlWQqgGpmpGqgFQtSFVDqkRURaRqRKoyUlWQqgGpqkhVQKoWpEpEVUSqElI1IlUFqRqQqopUBaRqQapEVEWkakSqMlI1IFUzUhWQqgWpElEVkaoRqcpI1YBUzUhVQKoaUiWiKiFVI1JVkKoZqQpI1YJUiahKSNWIVBWkakaqAlLVkCoRVQmpykjVgFRVpCogVSKqElI1IlUFqZqRqoBUNaIqiqgakaqCVFWkKiBVIqoSUpWRqgGpqkjVglSJqBqRqoJUzUhVQKpEVCWkKiNVA1IVkKpGVCURVRmpGpCqgFQ1oiqJqCpI1YxUBaRKRNWIVBWkqiJVjaiKIqoyUjUgVQGpElE1IlUFqapIVSOqkoiqglRVpKoRVUlEVUGqKlLViKokoqogVRWpakRVUkdPppUr6uhsWrmgjm5MK6eeNtO6ZQm4WLMEXKxF4i1WkoCLVdTZm2nFqgQcYRNwhKN24e6GWbtwd8Mi8RYrqb/taiMsEnCEi8QbYdQ+2t1Q9Fe9nVapSrwRRgk4wqyvwa73KgFHKAFHmCXgCKsEHKEEHGHW12AXaZV4I4wScIRFPwM9Z6rEG+HBADEv0iIBR7jokt2ajlfS91C/dWZdurvT0WraB7uysnbh9v21/qGb088ou36w75hdP9h3zK4f7Dtn1y/uO+Ne/+V+J+36vqfTLtSun79nCG+Y414Oj/Q11uUQmy4GefwVXUl3YNfCtzasG/RHZ8CjkjbEo5LOgEclbYhHJZ0Bj0raEI9KugM8qv0FDzwq6S7mN+DhYUEeC4fdAB7VrreAJ+jVv+Af6Eek22HRzzgL/0hH6uZVfYTALPxrXYgyw8P5QWYYm47ZO9z89m2f4ua379YTzP15sXu0pbrcasXXWqO3qE0/33jUpp+zgCjpdvcP4mOt144FRO1YT2Hj69+tl1q97TvGPfVrH/64XPebeltvuV6pv7WO6+F7XWfb37keftS19+nZ4ZK/eC9E28/Pn3/b8OevAMfknHPOOeecc84555xzzjn3hd05JnIgBgIg6JfKwQa67CAshOPxyfJystDExxQUTrmmEbQkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZKkX3R9Xjyz/184cxdw9RRwdRVxtYmrVcTVJq5WEVebuLqKuEriahZxFcjVJq5GEVeBXG3iahRxFchVIldNXI0irgK5SuSqiatRxFUgV4lcNXE1irhayNUbuUrkqomrWcTVQK4CuXqQq0SumriaRVwN5GohV4FcJXJ1I1eNXBVxNZCrP+RqIVeBXD3IVSJXN3K1kasmrmYRV8PVseXqWCBXb+TqQa7S1bEbudqujrWrY+Xqy64dG7cNBFEYXoLDAIHpSCWgCCUeF6Ena2wHjj0OXIJLcIISFDiSS3ATLoFFOPNxQFIkTqI2WvwQ91XwDbDYW9ydN8tUzVzVpCpVZqmaMItUpcosVf5ciIrZr1KVqpILUTHn9lTN/d8ZqmLuyTBVzL0+poq5h8zcb2eqmOc4zDMv5vkg8yx1gVQxz+iZKubdD+Y9mWdV735J+vrwxwLivX+1PmAfLCC+u2r/9JiPAY/Lda9vo+PcTsBa1aqCmprVVqprjfPJorOoVKrzzYLTeFT6bcHxqOJLq/eo9Nlic+VS6YeFpvOp7iw0qydU0xd8W6kID6upVYDKWlYqxMPqnSqF9qyrJ1TT96zOq7q1wLRelb5bXBZu1Y3FZVmpEPXeO1Txv2WdW/XB4rIaqRiv8M1IxXiFzUgFeYX9qQryCju/6ouFpR2rEI20OVVRXmE/ViHWwq5SEcaZ9lQF6Q3NiQpYWEUFLKyiAhZWUQELq6g4hfX3SMUprPZIxSms5kjFKSzbPKpAhdX6Ve8tLE1/ooKMydZVKsLmzPqgIpW73e9VpHK3dq8ilbtZv1Ohyt3avQrU3Us2g4pV7rZ2qmShuR6pEJvctrwfVKBhZpu3fVHRyt1s/dMk1Jqzi2gf4aDCfYTbCPcRbiPeR1giwVbCQQVsDQcVZcuvVjGOv/Yq1jg6qJCtQcjWoF0o++5DhGwNEnFqkIhTg5ANSyLOMkK2UZXA/upLhGyjQrZRIduokG1UIs59QjZ3IZu7kM1dyOYuEWdkIZccIZccIZccScCtBiEXQiEXQiEXwlmrgpdnIZdnIZfneavODg2pmnCUEXKUSZU/Qo59Qo5981adHUZTlapRhPydmLfqzs4kVal6VaobO5NUpSpVqaqTqlSl6kJnhlSl6nL+B1M1990Ppoq5A5mque+3M1XMExOmink+yFQxT3jtheQtC7iKeU+GeaeIeSuMqfrfzh0bAQDDIAz0/lMnG5jyzwdDQCNhcn0mA2nyoiZba3LIJrNt8u2zpd6E7ZiYPo7pLpmeVzCD9Qdp1zIanDq8ru8clWg9evhzwPxnCOuqvx8/k+b0n8wDJN70xEXur1MAAAAASUVORK5CYII=",
        "../assets/images/template_cv/outstanding16/background/passion_bg_1.png": "https://static.topcv.vn/cv-builder/assets/passion_bg_1.416771a3.png",
        "../assets/images/template_cv/outstanding16/background/passion_bg_2.png": "https://static.topcv.vn/cv-builder/assets/passion_bg_2.b59cbb50.png",
        "../assets/images/template_cv/outstanding16/background/passion_bg_3.png": "https://static.topcv.vn/cv-builder/assets/passion_bg_3.04065e07.png",
        "../assets/images/template_cv/outstanding16/background/passion_bg_4.png": "https://static.topcv.vn/cv-builder/assets/passion_bg_4.5228fbd4.png",
        "../assets/images/template_cv/outstanding16/background/passion_bg_5.png": "https://static.topcv.vn/cv-builder/assets/passion_bg_5.8c8d5675.png",
        "../assets/scss/components/edit/elements/_cropper-image.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.vue-cropper {\n  position: relative;\n  width: 100%;\n  height: 100%;\n  max-height: 300px;\n  box-sizing: border-box;\n  user-select: none;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  direction: ltr;\n  touch-action: none;\n  text-align: left;\n  background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQAQMAAAAlPW0iAAAAA3NCSVQICAjb4U/gAAAABlBMVEXMzMz////TjRV2AAAACXBIWXMAAArrAAAK6wGCiw1aAAAAHHRFWHRTb2Z0d2FyZQBBZG9iZSBGaXJld29ya3MgQ1M26LyyjAAAABFJREFUCJlj+M/AgBVhF/0PAH6/D/HkDxOGAAAAAElFTkSuQmCC);\n}\n\n.cropper-box {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  user-select: none;\n  overflow: hidden;\n}\n\n.cropper-box-canvas {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  user-select: none;\n}\n.cropper-box-canvas img {\n  position: relative;\n  text-align: left;\n  user-select: none;\n  transform: none;\n  max-width: none;\n  max-height: none;\n}\n\n.cropper-drag-box {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  user-select: none;\n}\n\n.cropper-crop-box {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  user-select: none;\n}\n\n.cropper-face {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  user-select: none;\n  top: 0;\n  left: 0;\n  background-color: #fff;\n  opacity: 0.1;\n}\n\n.cropper-move {\n  cursor: move;\n}\n\n.cropper-crop {\n  cursor: crosshair;\n}\n\n.cropper-modal {\n  background: rgba(0, 0, 0, 0.5);\n}\n\n.cropper-view-box {\n  display: block;\n  overflow: hidden;\n  width: 100%;\n  height: 100%;\n  outline: 1px solid #39f;\n  outline-color: rgba(51, 153, 255, 0.7490196078);\n  user-select: none;\n}\n.cropper-view-box img {\n  user-select: none;\n  text-align: left;\n  max-width: none;\n  max-height: none;\n}\n\n.crop-info {\n  position: absolute;\n  left: 0px;\n  min-width: 65px;\n  text-align: center;\n  color: #fff;\n  line-height: 20px;\n  background-color: rgba(0, 0, 0, 0.8);\n  font-size: 12px;\n}\n\n.crop-line {\n  position: absolute;\n  display: block;\n  width: 100%;\n  height: 100%;\n  opacity: 0.1;\n}\n\n.line-w {\n  top: -3px;\n  left: 0;\n  height: 5px;\n  cursor: n-resize;\n}\n\n.line-a {\n  top: 0;\n  left: -3px;\n  width: 5px;\n  cursor: w-resize;\n}\n\n.line-s {\n  bottom: -3px;\n  left: 0;\n  height: 5px;\n  cursor: s-resize;\n}\n\n.line-d {\n  top: 0;\n  right: -3px;\n  width: 5px;\n  cursor: e-resize;\n}\n\n.crop-point {\n  position: absolute;\n  width: 8px;\n  height: 8px;\n  opacity: 0.75;\n  background-color: #39f;\n  border-radius: 100%;\n}\n\n.point1 {\n  top: -4px;\n  left: -4px;\n  cursor: nw-resize;\n}\n\n.point2 {\n  top: -5px;\n  left: 50%;\n  margin-left: -3px;\n  cursor: n-resize;\n}\n\n.point3 {\n  top: -4px;\n  right: -4px;\n  cursor: ne-resize;\n}\n\n.point4 {\n  top: 50%;\n  left: -4px;\n  margin-top: -3px;\n  cursor: w-resize;\n}\n\n.point5 {\n  top: 50%;\n  right: -4px;\n  margin-top: -3px;\n  cursor: e-resize;\n}\n\n.point6 {\n  bottom: -5px;\n  left: -4px;\n  cursor: sw-resize;\n}\n\n.point7 {\n  bottom: -5px;\n  left: 50%;\n  margin-left: -3px;\n  cursor: s-resize;\n}\n\n.point8 {\n  bottom: -5px;\n  right: -4px;\n  cursor: se-resize;\n}\n\n@media screen and (max-width: 500px) {\n  .crop-point {\n    position: absolute;\n    width: 20px;\n    height: 20px;\n    opacity: 0.45;\n    background-color: #39f;\n    border-radius: 100%;\n  }\n\n  .point1 {\n    top: -10px;\n    left: -10px;\n  }\n\n  .point2 {\n    display: none;\n  }\n\n  .point4 {\n    display: none;\n    top: 0;\n    left: 0;\n  }\n\n  .point5 {\n    display: none;\n  }\n\n  .point7 {\n    display: none;\n  }\n\n  .point3 {\n    top: -10px;\n    right: -10px;\n  }\n\n  .point6 {\n    bottom: -10px;\n    left: -10px;\n  }\n\n  .point8 {\n    bottom: -10px;\n    right: -10px;\n  }\n}\n.el-dialog__footer {\n  min-height: initial;\n  background-color: initial;\n  color: initial;\n  border-top: 1px #eeeeee solid;\n}\n\n.edit-image .el-popover.el-popper {\n  padding: 0px;\n}\n\n.el-dialog__header {\n  border-bottom: 1px #eeeeee solid;\n  margin-right: 0px;\n}",
        "../assets/scss/components/edit/elements/_edit-image.scss": ".w-1 {\n  width: 1%;\n}\n\n.w-2 {\n  width: 2%;\n}\n\n.w-3 {\n  width: 3%;\n}\n\n.w-4 {\n  width: 4%;\n}\n\n.w-5 {\n  width: 5%;\n}\n\n.w-6 {\n  width: 6%;\n}\n\n.w-7 {\n  width: 7%;\n}\n\n.w-8 {\n  width: 8%;\n}\n\n.w-9 {\n  width: 9%;\n}\n\n.w-10 {\n  width: 10%;\n}\n\n.w-11 {\n  width: 11%;\n}\n\n.w-12 {\n  width: 12%;\n}\n\n.w-13 {\n  width: 13%;\n}\n\n.w-14 {\n  width: 14%;\n}\n\n.w-15 {\n  width: 15%;\n}\n\n.w-16 {\n  width: 16%;\n}\n\n.w-17 {\n  width: 17%;\n}\n\n.w-18 {\n  width: 18%;\n}\n\n.w-19 {\n  width: 19%;\n}\n\n.w-20 {\n  width: 20%;\n}\n\n.w-21 {\n  width: 21%;\n}\n\n.w-22 {\n  width: 22%;\n}\n\n.w-23 {\n  width: 23%;\n}\n\n.w-24 {\n  width: 24%;\n}\n\n.w-25 {\n  width: 25%;\n}\n\n.w-26 {\n  width: 26%;\n}\n\n.w-27 {\n  width: 27%;\n}\n\n.w-28 {\n  width: 28%;\n}\n\n.w-29 {\n  width: 29%;\n}\n\n.w-30 {\n  width: 30%;\n}\n\n.w-31 {\n  width: 31%;\n}\n\n.w-32 {\n  width: 32%;\n}\n\n.w-33 {\n  width: 33%;\n}\n\n.w-34 {\n  width: 34%;\n}\n\n.w-35 {\n  width: 35%;\n}\n\n.w-36 {\n  width: 36%;\n}\n\n.w-37 {\n  width: 37%;\n}\n\n.w-38 {\n  width: 38%;\n}\n\n.w-39 {\n  width: 39%;\n}\n\n.w-40 {\n  width: 40%;\n}\n\n.w-41 {\n  width: 41%;\n}\n\n.w-42 {\n  width: 42%;\n}\n\n.w-43 {\n  width: 43%;\n}\n\n.w-44 {\n  width: 44%;\n}\n\n.w-45 {\n  width: 45%;\n}\n\n.w-46 {\n  width: 46%;\n}\n\n.w-47 {\n  width: 47%;\n}\n\n.w-48 {\n  width: 48%;\n}\n\n.w-49 {\n  width: 49%;\n}\n\n.w-50 {\n  width: 50%;\n}\n\n.w-51 {\n  width: 51%;\n}\n\n.w-52 {\n  width: 52%;\n}\n\n.w-53 {\n  width: 53%;\n}\n\n.w-54 {\n  width: 54%;\n}\n\n.w-55 {\n  width: 55%;\n}\n\n.w-56 {\n  width: 56%;\n}\n\n.w-57 {\n  width: 57%;\n}\n\n.w-58 {\n  width: 58%;\n}\n\n.w-59 {\n  width: 59%;\n}\n\n.w-60 {\n  width: 60%;\n}\n\n.w-61 {\n  width: 61%;\n}\n\n.w-62 {\n  width: 62%;\n}\n\n.w-63 {\n  width: 63%;\n}\n\n.w-64 {\n  width: 64%;\n}\n\n.w-65 {\n  width: 65%;\n}\n\n.w-66 {\n  width: 66%;\n}\n\n.w-67 {\n  width: 67%;\n}\n\n.w-68 {\n  width: 68%;\n}\n\n.w-69 {\n  width: 69%;\n}\n\n.w-70 {\n  width: 70%;\n}\n\n.w-71 {\n  width: 71%;\n}\n\n.w-72 {\n  width: 72%;\n}\n\n.w-73 {\n  width: 73%;\n}\n\n.w-74 {\n  width: 74%;\n}\n\n.w-75 {\n  width: 75%;\n}\n\n.w-76 {\n  width: 76%;\n}\n\n.w-77 {\n  width: 77%;\n}\n\n.w-78 {\n  width: 78%;\n}\n\n.w-79 {\n  width: 79%;\n}\n\n.w-80 {\n  width: 80%;\n}\n\n.w-81 {\n  width: 81%;\n}\n\n.w-82 {\n  width: 82%;\n}\n\n.w-83 {\n  width: 83%;\n}\n\n.w-84 {\n  width: 84%;\n}\n\n.w-85 {\n  width: 85%;\n}\n\n.w-86 {\n  width: 86%;\n}\n\n.w-87 {\n  width: 87%;\n}\n\n.w-88 {\n  width: 88%;\n}\n\n.w-89 {\n  width: 89%;\n}\n\n.w-90 {\n  width: 90%;\n}\n\n.w-91 {\n  width: 91%;\n}\n\n.w-92 {\n  width: 92%;\n}\n\n.w-93 {\n  width: 93%;\n}\n\n.w-94 {\n  width: 94%;\n}\n\n.w-95 {\n  width: 95%;\n}\n\n.w-96 {\n  width: 96%;\n}\n\n.w-97 {\n  width: 97%;\n}\n\n.w-98 {\n  width: 98%;\n}\n\n.w-99 {\n  width: 99%;\n}\n\n.w-100 {\n  width: 100%;\n}\n\n.edit-image {\n  display: flex;\n  width: 100%;\n  padding: 16px;\n  justify-content: center;\n}\n.edit-image__btn {\n  background: transparent;\n  cursor: pointer;\n  border: none;\n  font-size: 15px;\n  line-height: 20px;\n  color: #212f3f;\n  padding: 0px 12px;\n}\n.edit-image__btn[disabled] {\n  cursor: not-allowed;\n}\n.edit-image__btn i {\n  margin-right: 18px;\n}\n.edit-image__btn:last-child {\n  border: none;\n}\n.edit-image__btn:hover {\n  background-color: #f4f4f4;\n  border-radius: 4px;\n}\n.edit-image__separate {\n  height: 100%;\n  width: 1px;\n  background-color: #cccccc;\n  margin-left: 12px;\n  margin-right: 12px;\n}\n\n.bg-primary {\n  background: #00b14f;\n}\n.bg-primary:hover {\n  background-color: #15964b;\n}\n\n.bg-secondary {\n  background: #eeeeee;\n}\n.bg-secondary:hover {\n  background-color: #dddddd;\n  color: #888888 !important;\n}\n\n.text-gray-400 {\n  color: #999999 !important;\n}\n\n.dialog-footer {\n  text-align: center;\n  display: block;\n  padding-top: 18px;\n}\n\n.modal-edit-image__action {\n  text-align: center;\n  display: flex;\n  flex-direction: column;\n  gap: 9px;\n  margin: 0;\n  align-items: center;\n  margin-top: 5px;\n}\n.modal-edit-image__btn {\n  padding: 10px 20px;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 22px;\n  border: none;\n  color: #fff;\n  border-radius: 5px;\n  cursor: pointer;\n}\n.modal-edit-image__btn[disabled] {\n  cursor: not-allowed;\n}\n.modal-edit-image__btn-delete {\n  background: #fceceb !important;\n  color: #de4637 !important;\n}\n.modal-edit-image__btn-delete:hover {\n  background-color: #de4637 !important;\n  color: #ffffff !important;\n}\n.modal-edit-image__btn-sm {\n  border: none;\n  border-radius: 5px;\n  background: #e5f7ed;\n  padding: 5px 19.5px;\n  color: #00b14f;\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 22px;\n  cursor: pointer;\n}\n.modal-edit-image__btn-sm:hover {\n  background-color: #00b14f;\n  color: #ffffff;\n}\n.modal-edit-image__caption {\n  font-weight: 400;\n  font-size: 15px;\n  line-height: 20px;\n  color: #333333;\n}\n.modal-edit-image__upload-image {\n  width: 490px;\n  height: 100%;\n  position: relative;\n}\n.modal-edit-image__input-upload {\n  height: 200px;\n  width: 100%;\n  opacity: 0;\n  z-index: 1;\n  position: absolute;\n  cursor: pointer;\n}\n.modal-edit-image__input-upload:hover + .empty {\n  background-color: #e5f7ed;\n}\n.modal-edit-image .el-dialog__headerbtn {\n  font-weight: bold;\n  font-size: 19px;\n  line-height: 27px;\n  color: #333333;\n}\n.modal-edit-image .el-dialog__headerbtn:hover .el-dialog__close {\n  color: #333333;\n}\n.modal-edit-image .el-dialog__title {\n  font-size: 15px;\n  font-weight: 700;\n}\n.modal-edit-image .el-dialog__close {\n  color: var(--el-color-info);\n  font-weight: 700;\n  font-size: 18px;\n}\n.modal-edit-image .el-dialog__body {\n  padding: calc(var(--el-dialog-padding-primary) + 10px) var(--el-dialog-padding-primary) !important;\n}\n\n.empty {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n  height: 200px;\n  background: #f1f2f6;\n  border: 1px dashed #cccccc;\n  border-radius: 8px;\n  cursor: pointer;\n}\n\n.ie-container {\n  width: 100%;\n  max-width: 100%;\n  position: relative;\n  z-index: 2;\n}\n\n.vue-cropper {\n  height: 300px;\n}\n\n.align-setting {\n  padding: 0 10px;\n}\n.align-setting__item {\n  width: 28px;\n  height: 28px;\n  margin: 0px 12px;\n}\n.align-setting__item label {\n  margin-bottom: 0px;\n  width: 100%;\n  height: 100%;\n  cursor: pointer;\n  font-weight: 500;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.align-setting__item.active {\n  background: #e5f7ed;\n  border-radius: 3px;\n  color: #00b14f;\n}\n.align-setting__item:hover {\n  background-color: #f4f4f4;\n  border-radius: 4px;\n}\n.align-setting .active {\n  color: #00b14f;\n}"
    }
        [`../assets/${n}`], self.location).href
}
function Ot(n) {
    const t = document.createElement("DIV");
    return t.innerHTML = n,
    t.textContent || t.innerText || ""
}
function jt(n) {
    let t;
    if (/^#([A-Fa-f0-9]{3}){1,2}$/.test(n))
        return t = n.substring(1).split(""), 3 == t.length && (t = [t[0], t[0], t[1], t[1], t[2], t[2]]), t = "0x" + t.join(""), "rgba(" + [t >> 16 & 255, t >> 8 & 255, 255 & t].join(",") + ",1)";
    throw new Error("Bad Hex")
}
function Lt(n) {
    const t = document.createElement("div");
    return t.innerHTML = n,
    t.innerText
}
function Pt(n) {
    var t;
    let e = null != (t = n.split("/")[1]) ? t : "1";
    e = e.trim().replace("%", "");
    const i = new Nt(n),
    a = parseInt(e);
    return Mt(i.red, i.green, i.blue, a)
}
function Kt(n) {
    var t;
    const e = null != (t = jt(n).match(/\d+/g)) ? t : "";
    return `rgb(${parseInt(e[2])},${parseInt(e[0])},${parseInt(e[1])})`
}
function Xt(n) {
    const t = new URLSearchParams(window.location.search);
    return t.has(n) ? t.get(n) : null
}
function Yt(n) {
    const t = function (n) {
        const t = /repeat\((\d+),\s*([^)]+)\)/g,
        e = [];
        let i,
        a = n;
        for (; null !== (i = t.exec(n)); ) {
            const n = parseInt(i[1]),
            t = i[2].trim();
            for (let i = 0; i < n; i++)
                e.push(t);
            a = a.replace(i[0], "")
        }
        return a.split(" ").forEach((n => {
                n.trim() && e.push(n)
            })),
        e
    }
    (n),
    e = t.reduce(((n, t) => t.endsWith("fr") ? n + parseFloat(t) : n), 0);
    return t.map((n => {
            if (n.endsWith("fr")) {
                return parseFloat(n) / e * 100
            }
            return n.endsWith("%") ? parseFloat(n) : 0
        }))
}
const Wt = b.create({
    baseURL: "https://www.topcv.vn",
    headers: {
        "Content-type": "application/json"
    }
});
function zt() {
    return Wt.get("/v2/cv/templates")
}
function Jt(n) {
    const t = new URLSearchParams(n).toString();
    return Wt.get("/topcv-suggest-jobs-ai?" + t)
}
function Zt(n) {
    return parseInt(n.split(".").slice(-1).join(".").replace("children", "").replace(/\[|\]/g, ""))
}
function _t(n) {
    return n.split(".").slice(0, -1).join(".")
}
function $t(n, t) {
    let e = t.type;
    if (e !== zn.ADDITIONAL_INFO)
        return t.subType && (e += `.${t.subType}`), n.includes(e)
}
function ne(n, t = !1) {
    var e;
    return !t && n.uuid || (n.uuid = function (n = "") {
        const t = Date.now(),
        e = Math.floor(1e9 * Math.random());
        return bt++,
        n ? n + "_" + e + bt + String(t) : e + bt + String(t)
    }
        ()),
    (null == (e = n.children) ? void 0 : e.length) && n.children.forEach((n => {
            ne(n, t)
        })),
    n
}
function te(n, t, e) {
    const i = n[t];
    return n.splice(t, 1),
    n.splice(e, 0, i),
    n
}
function ee(n, t, e = "") {
    var i,
    a;
    if (0 === n.length)
        return "";
    for (let d = 0; d < n.length; d++) {
        const o = `${e}[${d}]`;
        if (n[d].uuid === t)
            return o;
        if (null == (i = n[d].children) ? void 0 : i.length) {
            const e = ee(null != (a = n[d].children) ? a : [], t, `${o}.children`);
            if (e)
                return e
        }
    }
    return ""
}
function ie(n, t, e, i = "") {
    var a,
    d;
    if (0 === n.length)
        return "";
    for (let o = 0; o < n.length; o++) {
        const w = `${i}[${o}]`;
        if (e) {
            if (n[o].typeBlock === t && n[o].subType === e)
                return w
        } else if (n[o].typeBlock === t && null == n[o].subType)
            return w;
        if (null == (a = n[o].children) ? void 0 : a.length) {
            const i = ie(null != (d = n[o].children) ? d : [], t, e, `${w}.children`);
            if (i)
                return i
        }
    }
    return ""
}
function ae(n) {
    let t = [];
    for (const e of null != n ? n : [])
        if (e.typeBlock) {
            let n = e.typeBlock;
            e.subType && (n = `${e.typeBlock}.${e.subType}`),
            t.push(n)
        } else
            t = [...t, ...ae(e.children)];
    return t
}
function de(n) {
    let t = [];
    for (const e of null != n ? n : [])
        if (e.typeBlock) {
            const n = oe(e);
            t.push(null != n ? n : "")
        } else
            t = [...t, ...de(e.children)];
    return t
}
function oe(n) {
    let t = n.typeBlock;
    return t !== zn.ADDITIONAL_INFO && n.subType && (t += `.${n.subType}`),
    t
}
Wt.interceptors.response.use((function (n) {
        return n
    }), (function (n) {
        return Promise.reject(n)
    }));
const we = [{
        id: 13,
        icon: "fa-solid fa-image-portrait",
        name: "{translate.avatar}",
        type: "profile",
        subType: "avatar"
    }, {
        id: 1,
        icon: "fa-solid fa-user-tag",
        name: "{translate.business_card}",
        type: "profile",
        subType: "business_card"
    }, {
        id: 2,
        icon: "fa-solid fa-circle-info",
        name: "{translate.contact_information}",
        type: "profile"
    }, {
        id: 3,
        icon: "fa-solid fa-bullseye-arrow",
        name: "{translate.objective}",
        type: "objective"
    }, {
        id: 6,
        icon: "fa-solid fa-briefcase",
        name: "{translate.experience}",
        type: "experience"
    }, {
        id: 7,
        icon: "fa-solid fa-graduation-cap",
        name: "{translate.education}",
        type: "education"
    }, {
        id: 4,
        icon: "fa-solid fa-pen-fancy",
        name: "{translate.skillgroup}",
        type: "skillgroup"
    }, {
        id: 14,
        icon: "fa-solid fa-diagram-project",
        name: "{translate.project}",
        type: "project"
    }, {
        id: 5,
        icon: "fa-solid fa-award",
        name: "{translate.award}",
        type: "award"
    }, {
        id: 8,
        icon: "fa-solid fa-file-certificate",
        name: "{translate.certification}",
        type: "certification"
    }, {
        id: 9,
        icon: "fa-solid fa-hand",
        name: "{translate.activity}",
        type: "activity"
    }, {
        id: 10,
        icon: "fa-regular fa-user-plus",
        name: "{translate.reference}",
        type: "reference"
    }, {
        id: 11,
        icon: "fa-regular fa-hashtag",
        name: "{translate.additional_info}",
        type: "additional_info"
    }, {
        id: 12,
        icon: "fa-regular fa-thumbs-up",
        name: "{translate.interests}",
        type: "interests"
    }, {
        id: 15,
        icon: "fa-solid fa-pen-fancy",
        name: "{translate.skillgroup}",
        type: "skillrate"
    }, {
        id: 16,
        icon: "fa-regular fa-thumbs-up",
        name: "{translate.interests}",
        type: "interest"
    }
], le = {
    [zn.PROFILE]: {
        categoryTemplateID: 2,
        [Jn.AVATAR]: 13,
        [Jn.BUSINESS_CARD]: 1
    },
    [zn.OBJECTIVE]: {
        categoryTemplateID: 3
    },
    [zn.SKILLGROUP]: {
        categoryTemplateID: 4
    },
    [zn.AWARD]: {
        categoryTemplateID: 5
    },
    [zn.EXPERIENCE]: {
        categoryTemplateID: 6
    },
    [zn.EDUCATION]: {
        categoryTemplateID: 7
    },
    [zn.CERTIFICATION]: {
        categoryTemplateID: 8
    },
    [zn.ACTIVITY]: {
        categoryTemplateID: 9
    },
    [zn.REFERENCE]: {
        categoryTemplateID: 10
    },
    [zn.ADDITIONAL_INFO]: {
        categoryTemplateID: 11
    },
    [zn.INTERESTS]: {
        categoryTemplateID: 12
    },
    [zn.PROJECT]: {
        categoryTemplateID: 14
    },
    [zn.SKILLRATE]: {
        categoryTemplateID: 15
    },
    [zn.INTEREST]: {
        categoryTemplateID: 16
    }
};
function re(n) {
    let t = [];
    for (const e of null != n ? n : [])
        !he(e) || ge(e) ? t = [...t, ...re(e.children)] : t.push(e);
    return t
}
function se(n, t) {
    var e;
    const i = [];
    for (const a of null != t ? t : []) {
        if (a.block === Xn.BLOCK) {
            const t = {
                categoryTemplateId: le[a.typeBlock][null != (e = a.subType) ? e : "categoryTemplateID"],
                id: a.blockId,
                name: n,
                renderBlock: f(a)
            };
            i.push(t);
            continue
        }
        const t = se(n, a.children);
        t && i.push(...t)
    }
    return i
}
function he(n) {
    return "ComponentRender" === n.component
}
function ce(n) {
    return "LayoutRender" === n.component
}
function pe(n) {
    return n.type === Kn.TABLE
}
function ge(n) {
    return n.type === Kn.TABLE
}
function Ae(n) {
    const t = function (n) {
        return n.replace(/\sstyle=(".*?")/gi, "")
    }
    (n);
    return function (n) {
        let t = n;
        const e = n.match(/\sclass="(.*?)"/gim);
        return null == e || e.forEach((n => {
                var e;
                let i = n.replace("class=", "");
                const a = null != (e = /ql-indent-[0-9]/gi.exec(i)) ? e : [];
                i = a.length ? ` class='${a[0]}'` : "",
                t = t.replace(n, i)
            })),
        t
    }
    (t)
}
function ue(n) {
    const t = (new DOMParser).parseFromString(n, "text/html");
    return Array.from(t.body.childNodes).some((n => 1 === n.nodeType))
}
function me(n, t) {
    var e;
    const i = (a = n, (new DOMParser).parseFromString(a, "text/html"));
    var a;
    let d = [];
    if (i) {
        const n = null == (e = null == i ? void 0 : i.body) ? void 0 : e.firstChild;
        if (ue(t) || (t = `<p>${t}</p>`), n) {
            if ("object" != typeof n || !("getAttribute" in n))
                return t;
            const e = n.innerHTML,
            i = n.classList,
            a = n.getAttribute("style");
            d = e.split(/{.+}/);
            const o = function (n, t) {
                let e = "";
                return n && (e += `class="${n.toString()}" `),
                t && (e += `style="${t}"`),
                e
            }
            (i.toString(), null != a ? a : "");
            return "<p>\n</p>" === t ? "" : (o && (t = t.replace("<p>", `<p ${o}>`).replace("<li>", `<li ${o}>`)), t.replace(/((<([^(>|\/)]*)>)+)/gim, `$1${d[0]}`).replace(/((<\/([^>]*)>)+)/gim, `${d[1]}$1`))
        }
    }
    return ""
}
function be(n) {
    var t,
    e;
    const i = {};
    for (const a of n)
        if (a.path)
            switch (a.type) {
            case Kn.TEXT:
            case Kn.TEXT_SINGLE: {
                    const n = a.text;
                    c(i, a.path, n);
                    break
                }
            case Kn.IMAGE:
                c(i, a.path, (null == (t = a.content) ? void 0 : t.src) || "");
                break;
            case Kn.SKILLRATE:
                c(i, a.path, (null == (e = null == a ? void 0 : a.rate) ? void 0 : e.toString()) || "")
            }
    return i
}
function ve(n, t) {
    const e = document.createElement("span");
    e.innerHTML = n;
    let i = e;
    for (; null !== i.firstChild; )
        i = i.firstChild;
    return i.parentNode && (i.parentNode.textContent = t),
    e.innerHTML
}
function fe(n) {
    return he(n) && n.path
}
function xe(n) {
    var t;
    for (const e of null != (t = n.children) ? t : []) {
        if (xe(e))
            return !0
    }
    return !!n.path
}
function ye(n) {
    var t;
    for (const e of n)
        ce(e) && ye(null != (t = e.children) ? t : []), fe(e) && ke(e);
    return n
}
function ke(n) {
    var t,
    e,
    i;
    const a = `{${n.path}}`;
    switch (n.type) {
    case Kn.TEXT:
    case Kn.TEXT_SINGLE:
        c(n, "text", a);
        break;
    case Kn.SKILLRATE:
        c(n, "rate", ve(null != (t = n.rate) ? t : "", a));
        break;
    case Kn.IMAGE:
        c(n, "content.src", ve(null != (i = null == (e = n.content) ? void 0 : e.src) ? i : "", a))
    }
}
function Ee(n, t) {
    return n.forEach((n => {
            var e,
            i;
            ce(n) && Ee(null != (e = null == n ? void 0 : n.children) ? e : [], t),
            pe(n) && Ee(null != (i = null == n ? void 0 : n.children) ? i : [], t),
            fe(n) && function (n, t) {
                var e,
                i,
                a,
                d,
                o;
                const w = new RegExp(qt(`{${n.path}}`), "g"),
                l = m(t, null != (e = n.path) ? e : "", "");
                switch (n.type) {
                case Kn.TEXT:
                case Kn.TEXT_SINGLE: {
                        c(n, "defaultTextFormat", n.text);
                        const t = Se(l, null != (i = n.text) ? i : "");
                        c(n, "text", t);
                        break
                    }
                case Kn.SKILLRATE:
                    c(n, "rate", null == (a = null == n ? void 0 : n.rate) ? void 0 : a.replace(w, l));
                    break;
                case Kn.IMAGE:
                    c(n, "content.src", null == (o = null == (d = n.content) ? void 0 : d.src) ? void 0 : o.replace(w, l))
                }
            }
            (n, t)
        })),
    n
}
function Be(n, t) {
    return n.forEach((n => {
            var e,
            i;
            ce(n) && Be(null != (e = null == n ? void 0 : n.children) ? e : [], t),
            pe(n) && Be(null != (i = null == n ? void 0 : n.children) ? i : [], t),
            fe(n) && function (n, t) {
                var e,
                i,
                a,
                d,
                o;
                const w = new RegExp(qt(`{${n.path}}`), "g"),
                l = null != (e = m(t, n.path, "")) ? e : "";
                switch (n.type) {
                case Kn.TEXT:
                case Kn.TEXT_SINGLE: {
                        c(n, "defaultTextFormat", n.text);
                        const t = Se(l, null != (i = n.text) ? i : "");
                        c(n, "text", t);
                        break
                    }
                case Kn.SKILLRATE:
                    c(n, "rate", null == (a = null == n ? void 0 : n.rate) ? void 0 : a.replace(w, l));
                    break;
                case Kn.IMAGE:
                    c(n, "content.src", null == (o = null == (d = n.content) ? void 0 : d.src) ? void 0 : o.replace(w, l))
                }
            }
            (n, t)
        })),
    n
}
function Ce(n, t) {
    return n.forEach((n => {
            var e,
            i;
            ce(n) && Ce(null != (e = null == n ? void 0 : n.children) ? e : [], t),
            pe(n) && Ce(null != (i = null == n ? void 0 : n.children) ? i : [], t),
            fe(n) && function (n, t) {
                var e,
                i,
                a,
                d;
                const o = new RegExp(qt(`{${n.path}}`), "g"),
                w = null != (e = m(t, n.path, "")) ? e : "";
                switch (n.type) {
                case Kn.TEXT:
                case Kn.TEXT_SINGLE:
                    c(n, "text", w);
                    break;
                case Kn.SKILLRATE:
                    c(n, "rate", null == (i = null == n ? void 0 : n.rate) ? void 0 : i.replace(o, w));
                    break;
                case Kn.IMAGE:
                    c(n, "content.src", null == (d = null == (a = n.content) ? void 0 : a.src) ? void 0 : d.replace(o, w))
                }
            }
            (n, t)
        })),
    n
}
function Se(n, t) {
    return n && (ue(n = n.replace(/<br>/g, "\n").replace(/<br \/>/g, "\n")) || (n = `<p>${n}</p>`), n = Ae(n || ""), n = me(null != t ? t : "", n = n.replace(/<div>/g, "").replace(/<\/div>/g, "").replace(/<strong>/g, "").replace(/<\/strong>/g, "").replace(/<em>/g, "").replace(/<\/em>/g, "").replace(/<u>/g, "").replace(/<\/u>/g, "").replace(/<b>/g, "").replace(/<\/b>/g, "").replace(/<i>/g, "").replace(/<\/i>/g, "").replace(/<span>/g, "").replace(/<\/span>/g, ""))),
    n
}
function Ie(n, t) {
    if (0 === n.length)
        return [];
    return Ee(Ue(n, t), t).map((n => ne(n)))
}
function Ve(n, t) {
    return t.hasOwnProperty(n.typeBlock) && n.hasOwnProperty("children")
}
function De(n) {
    var t;
    const e = [];
    for (const i of null != (t = n.children) ? t : [])
        i.block === Xn.BLOCK_CHILD && e.push(i), e.push(...De(i));
    return e
}
function Re(n) {
    var t;
    for (const e of null != (t = n.children) ? t : []) {
        if (e.block === Xn.BLOCK_CHILD)
            return n;
        const t = Re(e);
        if (null != t)
            return t
    }
    return null
}
function qe(n) {
    if (!n || !n.children)
        return 0;
    for (let t = n.children.length - 1; t >= 0; t--)
        if (n.children[t].block === Xn.BLOCK_CHILD)
            return t;
    return 0
}
function Ue(n, t) {
    var e,
    i,
    a,
    d,
    o;
    for (const w of n)
        if (Ve(w, t) && w.typeBlock) {
            const n = Re(w),
            o = qe(n);
            Array.isArray(t[w.typeBlock]) && (t[w.typeBlock] = t[w.typeBlock].filter((function (n) {
                            return n
                        })));
            const l = null == (e = t[w.typeBlock]) ? void 0 : e.length,
            r = null != (i = De(w).length) ? i : 0;
            if (l !== r && r > 0) {
                if (l > r)
                    for (let t = r; t < l; t++) {
                        const e = ne(f(n.children[o]), !0);
                        null == (a = n.children) || a.push(Me(e, t, w.typeBlock))
                    }
                else
                    l < r && n.children.splice((null == n ? void 0 : n.children.length) - r + l - 1, r - l);
                Te(null != (d = null == n ? void 0 : n.children) ? d : [], w.typeBlock, 0)
            }
        } else
            Ue(null != (o = w.children) ? o : [], t);
    return n
}
function Te(n, t, e) {
    for (let i = e + 1; i < n.length; i++) {
        const e = Ne(n[i - 1]);
        if (null === e)
            return;
        n[i] = Me(n[i], e + 1, t)
    }
    return n
}
function Ne(n) {
    var t,
    e,
    i;
    if (!n)
        return -1;
    if (n.path) {
        if (-1 == (null == (t = n.path) ? void 0 : t.search(/\[\d+\]/g)))
            return -1;
        const i = null == (e = n.path) ? void 0 : e.replace(/.*\[|\].*/g, "");
        return parseInt(i)
    }
    for (const a of null != (i = n.children) ? i : []) {
        const n = Ne(a);
        if (-1 != n)
            return n
    }
    return -1
}
function Me(n, t, e) {
    var i,
    a,
    d,
    o;
    const w = new RegExp(`${e}\\[\\d+\\]`, "g");
    const l = `${e}[${t}]`;
    if (n.path && (n.path = null == (i = n.path) ? void 0 : i.replace(w, l)), n.text && (n.text = null == (a = n.text) ? void 0 : a.replace(w, l)), n.rate && (n.rate = "string" == typeof n.rate ? null == (d = n.rate) ? void 0 : d.replace(w, l) : n.rate), null == (o = null == n ? void 0 : n.children) ? void 0 : o.length)
        for (const r in null == n ? void 0 : n.children)
            Me(n.children[r], t, e);
    return n
}
function Qe(n) {
    return n.map((n => (n.children && (n.children = Qe(n.children)), n.text && (n.text = He(n.text, new RegExp("ql-font-[a-zA-Z]+", "gm"))), n)))
}
function Fe(n) {
    return n.map((n => (n.children && (n.children = Fe(n.children)), n.text && (n.text = He(n.text, new RegExp(/ql-lineHeight-(\d\.\d)/g, "gm"))), n)))
}
function He(n, t) {
    return v(n) ? n.replace(t, "") : n
}
function Ge(n) {
    var t;
    if (n.block === Xn.BLOCK_CHILD)
        return n;
    for (const e of null != (t = n.children) ? t : []) {
        const n = Ge(e);
        if (n)
            return n
    }
}
function Oe(n) {
    const t = Ge(n);
    if (t)
        return ne(f(t), !0)
}
function je(n) {
    var t;
    for (const e of null != (t = n.children) ? t : [])
        je(e);
    n.type === Kn.TEXT && (n.isReadOnly && (c(n, "text", ""), c(n, "placeholder", "{translate.title} : "), c(n, "isReadOnly", !1), c(n, "isTranslate", !0), c(n, "styles.minWidth", "45pt")), n.path && (c(n, "text", ""), c(n, "placeholder", "{translate.default}"), c(n, "styles.minWidth", "70pt"))),
    n.type === Kn.TEXT_SINGLE && (c(n, "text", ""), c(n, "placeholder", "{translate.default}"), c(n, "styles.minWidth", "70pt")),
    n.type === Kn.ICON && c(n, "content.icon", "fa fa-circle-info")
}
function Le(n) {
    var t,
    e,
    i;
    for (const a of null != (t = n.children) ? t : [])
        Le(a);
    if (!n.path)
        return n;
    switch (n.type) {
    case Kn.TEXT:
    case Kn.TEXT_SINGLE: {
            const t = Lt(null != (e = n.defaultTextFormat) ? e : "");
            c(n, "text", null == (i = n.defaultTextFormat) ? void 0 : i.replace(t, ""));
            break
        }
    case Kn.SKILLRATE:
        c(n, "rate", "");
        break;
    case Kn.IMAGE:
        c(n, "content.src", "")
    }
    return n
}
function Pe(n) {
    var t;
    for (const e of null != (t = n.children) ? t : [])
        Pe(e);
    n.path && (n.path = "")
}
function Ke(n) {
    var t,
    e,
    i;
    let a = Oe(n);
    return a ? (a.isShow = !0, a = Me(a, (null != (e = null == (t = n.children) ? void 0 : t.length) ? e : 1) - 1, null != (i = n.typeBlock) ? i : ""), n.typeBlock === zn.PROFILE ? (je(a), Pe(a)) : Le(a), a.immediateFocus = !0, a) : null
}
function Xe(n, t) {
    const e = [];
    for (const i in n)
        i.endsWith("_meta") || "global" === i || "profile" === i || e.push(i);
    for (const i of t)
        Ye(i, e)
}
function Ye(n, t) {
    var e;
    if (n.block === Xn.COLUMN && n.children)
        n.children = function (n, t) {
            var e;
            const i = [];
            for (const a of n)
                a.typeBlock === zn.PROFILE && i.push(a);
            for (const a of n)
                t.includes(null != (e = null == a ? void 0 : a.typeBlock) ? e : "") && i.push(a);
            return i
        }
    (n.children, t);
    else
        for (const i of null != (e = n.children) ? e : [])
            Ye(i, t)
}
function We(n) {
    if (!n.skillrate) {
        n.skillrate_meta = n.skillgroup_meta;
        const t = [];
        for (const e in n.skillgroup)
            t.push({
                title: n.skillgroup[e].area,
                rate: "3"
            });
        n.skillrate = t
    }
    return n
}
const ze = n => {
    var t,
    e;
    for (const i of n)
        if (i.typeBlock) {
            const n = Re(i);
            Te(null != (t = null == n ? void 0 : n.children) ? t : [], i.typeBlock, -1)
        } else
            ze(null != (e = i.children) ? e : []);
    return n
};
function Je(n) {
    var t;
    for (let e = n.length - 1; e >= 0; e--) {
        const i = n[e],
        a = Je(null != (t = i.children) ? t : []);
        if (a)
            return a;
        if (i.type === Kn.TEXT || i.type === Kn.TEXT_SINGLE)
            return i
    }
    return null
}
const Ze = new class {
    constructor() {
        r(this, "db"),
        r(this, "secretKey")
    }
    async createObjectStore(n, t, e = 1) {
        this.secretKey = mt();
        try {
            this.db = await x(n, e, {
                upgrade(n) {
                    for (const e of t)
                        n.objectStoreNames.contains(e) || n.createObjectStore(e, {
                            autoIncrement: !0,
                            keyPath: "id"
                        })
                }
            })
        } catch (i) {
            return !1
        }
    }
    encrypt(n) {
        return {
            value: y.exports.AES.encrypt(JSON.stringify(n), this.secretKey).toString()
        }
    }
    decrypt(n) {
        const t = y.exports.AES.decrypt(n.value, this.secretKey);
        return JSON.parse(t.toString(y.exports.enc.Utf8))
    }
    async getValue(n, t) {
        if (!this.db)
            return null;
        const e = this.db.transaction(n, "readonly").objectStore(n),
        i = await e.get(t);
        return this.decrypt(i)
    }
    async getAllValue(n) {
        if (!this.db)
            return null;
        const t = this.db.transaction(n, "readonly").objectStore(n),
        e = await t.getAll();
        return console.log("Get All Data", JSON.stringify(e)),
        e
    }
    async putValue(n, t) {
        if (!this.db)
            return null;
        const e = this.db.transaction(n, "readwrite").objectStore(n);
        return await e.put(this.encrypt(t))
    }
    async putBulkValue(n, t) {
        if (!this.db)
            return null;
        const e = this.db.transaction(n, "readwrite").objectStore(n);
        for (const i of t) {
            const n = await e.put(i);
            console.log("Put Bulk Data ", JSON.stringify(n))
        }
        return this.getAllValue(n)
    }
    async deleteValue(n, t) {
        if (!this.db)
            return null;
        const e = this.db.transaction(n, "readwrite").objectStore(n),
        i = await e.get(t);
        return i ? (await e.delete(t), t) : i
    }
    async count(n) {
        if (!this.db)
            return null;
        const t = this.db.transaction(n, "readwrite");
        return await t.objectStore(n).count()
    }
    async clear(n) {
        if (!this.db)
            return null;
        const t = this.db.transaction(n, "readwrite");
        return await t.objectStore(n).clear()
    }
    async clearAll(n) {
        if (!this.db)
            return null;
        for (const t of n) {
            const n = this.db.transaction(t, "readwrite");
            await n.objectStore(t).clear()
        }
    }
};
var _e = (n => (n.UNDO = "undo", n.REDO = "redo", n))(_e || {}), $e = (n => (n.DELETE = "delete", n.MOVE = "move", n.NORMAL = "normal", n.REPLACE = "replace", n.ADD = "add", n.REPLACE_GLOBAL_SETTING = "replace_global_setting", n.CHANGE_GLOBAL_SETTING_DATA_RENDER = "change_global_setting_data_render", n))($e || {});
function ni() {
    const n = it();
    function t() {
        const t = JSON.parse(JSON.stringify(n.builderData));
        return k(`${JSON.stringify(t)}${JSON.stringify(n.globalSetting)}`).toString()
    }
    return {
        setBuilderDataModeEdit: function (t, e) {
            const i = function (n, t) {
                return 0 === n.length ? [] : Ce(Ue(n, t), t).map((n => ne(n)))
            }
            (t, e);
            i && n.setBuilderData(i)
        },
        setBuilderDataModeCreate: function (t, e) {
            const i = Ie(t, e);
            i && n.setBuilderData(i)
        },
        enablePreview: function () {
            n.setIsPreview(!0)
        },
        disablePreview: function () {
            n.setIsPreview(!1)
        },
        isChangeBuilderData: function () {
            const e = t();
            return n.builderDataHash !== e
        },
        setBuilderDataHash: function () {
            const e = t();
            n.setBuilderDataHash(e)
        },
        setBuilderDataModeChangeTemplate: function (t, e) {
            const i = function (n, t) {
                return 0 === n.length ? [] : Be(Ue(n, t), t).map((n => ne(n)))
            }
            (t, e);
            i && n.setBuilderData(i)
        }
    }
}
function ti() {
    const n = it();
    function t() {
        const t = f(n.builderData),
        e = ze(t);
        n.setBuilderData(e);
        const i = be(re(e));
        n.setCvData(p({
                global: n.cvData.global
            }, i, n.cvDataBlockRemoved)),
        n.cvDataBlockRemoved = {}
    }
    function e() {
        const t = de(n.builderData);
        n.setListTypeBlockUsed(t)
    }
    return {
        useTemplateCV: function (i) {
            var a,
            d;
            (null == (a = n.builderData) ? void 0 : a.length) && t(),
            function () {
                const {
                    changeBackground: n
                } = ai();
                n("")
            }
            (),
            delete (d = f(i.globalSetting)).language,
            p(n.globalSetting, f(d));
            const {
                setBackgroundImage: o,
                setColorPrimary: w,
                setFontFamily: l,
                setLineHeight: r
            } = ai();
            w(),
            o(),
            l(),
            r();
            const s = i.renderData;
            n.setRenderData(f(s)),
            n.setTemplateColors(i.templateColors);
            const h = n.cvData, {
                setBuilderDataModeChangeTemplate: c
            } = ni();
            if (c(s, h), n.setTemplateCvId(i.templateCvId), n.setPathEdit(""), e(), n.setEmptyListKeyRenderRemoved(), n.language === $n.JP) {
                const {
                    changeFontFamily: n
                } = ai();
                n("Roboto")
            }
            n.setValidateError({}),
            n.setValidateWarning({})
        },
        handleUpdateCvData: t,
        setListTypeBlockUsed: e,
        getTemplate: async t => {
            var e,
            i;
            try {
                const a = await(i = t, Wt.get(`/v2/cv/template/${i}`));
                if (a.data.data) {
                    let t = f(a.data.data.render);
                    t = t.concat(null != (e = a.data.data.hidden_block) ? e : []);
                    const i = se("", t);
                    return n.setTemplateBlocks(i), {
                        templateCvId: a.data.data.template.id || null,
                        renderData: a.data.data.render,
                        name: a.data.data.template.name,
                        templateColors: a.data.data.colors,
                        globalSetting: a.data.data.globalSetting || null,
                        template: a.data.data.template || null
                    }
                }
            } catch (a) {
                console.log(a)
            }
            return {
                templateCvId: 0,
                renderData: [],
                name: "",
                templateColors: [],
                globalSetting: null
            }
        }
    }
}
function ei() {
    const n = it(), {
        setListTypeBlockUsed: t
    } = ti(), {
        changeBackground: e,
        changeColorPrimary: i
    } = ai(),
    a = n.redoStack,
    d = n.undoStack,
    o = async() => {
        var n;
        const t = null != (n = a.pop()) ? n : 0,
        e = await Ze.getValue(_e.REDO, t);
        return await Ze.deleteValue(_e.REDO, t),
        e
    },
    w = async() => {
        var n;
        const t = null != (n = d.pop()) ? n : 0,
        e = await Ze.getValue(_e.UNDO, t);
        return await Ze.deleteValue(_e.UNDO, t),
        e
    },
    l = async n => {
        const t = await Ze.putValue(_e.UNDO, n);
        d.push(t)
    },
    r = E((() => !!d.length)),
    s = E((() => !!a.length)),
    h = async() => {
        if (r.value) {
            const n = await w();
            return await(async n => {
                const t = await Ze.putValue(_e.REDO, n);
                a.push(t)
            })(n),
            n
        }
    },
    c = async() => {
        if (s.value) {
            const n = await o();
            return await l(n),
            n
        }
    },
    p = (n, t) => {
        var e,
        i;
        Te(null != (e = t.children) ? e : [], null != (i = t.typeBlock) ? i : "", -1)
    };
    return {
        handleRedo: async() => {
            if (!s.value)
                return;
            const a = await c();
            switch ("text" === a.blockType && n.setFlagUndoRedo(!0), n.setFlagUndoRedo(!0), a.type) {
            case $e.ADD:
                (e => {
                    const i = JSON.parse(e.value);
                    if (!_t(e.path))
                        return void n.builderData.splice(e.index, 0, i);
                    const a = m(n.builderData, _t(e.path));
                    a.children.splice(e.index, 0, i),
                    i && (i.block === Xn.BLOCK_CHILD && p(0, a), i.block === Xn.BLOCK && t())
                })(a);
                break;
            case $e.DELETE:
                (e => {
                    const i = JSON.parse(e.value);
                    if (!_t(e.path))
                        return n.builderData.splice(e.index, 1), void t();
                    const a = m(n.builderData, _t(e.path) || "");
                    a.children.splice(e.index, !0),
                    i && (i.block === Xn.BLOCK_CHILD && p(0, a), i.block === Xn.BLOCK && t())
                })(a);
                break;
            case $e.MOVE:
                (t => {
                    const e = _t(t.newPath),
                    i = _t(t.path),
                    a = Zt(t.newPath),
                    d = Zt(t.path);
                    !e && (n.builderData.splice(d, 1), n.builderData.splice(a, 0, JSON.parse(t.value))),
                    m(n.builderData, i).children.splice(d, !0),
                    m(n.builderData, e).children.splice(a, 0, JSON.parse(t.value))
                })(a);
                break;
            case $e.REPLACE_GLOBAL_SETTING:
                (n => {
                    n.globalSettingPath.endsWith("backgroundImage") ? e(n.newGlobalSettingValue) : n.globalSettingPath.endsWith("colorPrimary") && i(n.newGlobalSettingValue)
                })(a);
                break;
            case $e.CHANGE_GLOBAL_SETTING_DATA_RENDER:
                (t => {
                    var e;
                    n.setGlobalSettingWithKey(t.globalSettingPath, t.newGlobalSettingValue),
                    t.newRenderDataValue && n.setBuilderData(JSON.parse(null != (e = t.newRenderDataValue) ? e : "[]"));
                    const i = document.documentElement.style;
                    t.globalSettingPath.endsWith("fontFamily") && i.setProperty("--font-family-primary", t.newGlobalSettingValue),
                    t.globalSettingPath.endsWith("lineHeight") && i.setProperty("--line-height-primary", t.newGlobalSettingValue)
                })(a);
                break;
            default:
                (t => {
                    var e;
                    n.setBuilderDataWithKey({
                        path: t.path,
                        value: JSON.parse(null != (e = t.new) ? e : ""),
                        isState: !1
                    })
                })(a)
            }
        },
        handleUndo: async() => {
            if (!r.value)
                return;
            const a = await h();
            switch ("text" === a.blockType && n.setFlagUndoRedo(!0), a.type) {
            case $e.ADD:
                (e => {
                    const i = JSON.parse(e.value);
                    if (!_t(e.path))
                        return void n.builderData.splice(e.index, 1);
                    const a = m(n.builderData, _t(e.path) || "");
                    a.children.splice(e.index, !0),
                    i && (i.block === Xn.BLOCK_CHILD && p(0, a), i.block === Xn.BLOCK && t())
                })(a);
                break;
            case $e.DELETE:
                (e => {
                    const i = JSON.parse(e.value);
                    if (!_t(e.path))
                        return n.builderData.splice(e.index, 0, i), void t();
                    const a = m(n.builderData, _t(e.path));
                    a.children.splice(e.index, 0, i),
                    i && (i.block === Xn.BLOCK_CHILD && p(0, a), i.block === Xn.BLOCK && t())
                })(a);
                break;
            case $e.MOVE:
                (t => {
                    const e = _t(t.newPath),
                    i = _t(t.path),
                    a = Zt(t.newPath),
                    d = Zt(t.path);
                    if (!e)
                        return n.builderData.splice(a, 1), void n.builderData.splice(d, 0, JSON.parse(t.value));
                    m(n.builderData, e).children.splice(a, !0),
                    m(n.builderData, i).children.splice(d, 0, JSON.parse(t.value))
                })(a);
                break;
            case $e.REPLACE_GLOBAL_SETTING:
                (n => {
                    n.globalSettingPath.endsWith("backgroundImage") ? e(n.oldGlobalSettingValue) : n.globalSettingPath.endsWith("colorPrimary") && i(n.oldGlobalSettingValue)
                })(a);
                break;
            case $e.CHANGE_GLOBAL_SETTING_DATA_RENDER:
                (t => {
                    n.setGlobalSettingWithKey(t.globalSettingPath, t.oldGlobalSettingValue),
                    t.oldRenderDataValue && n.setBuilderData(JSON.parse(t.oldRenderDataValue));
                    const e = document.documentElement.style;
                    t.globalSettingPath.endsWith("fontFamily") && e.setProperty("--font-family-primary", t.oldGlobalSettingValue),
                    t.globalSettingPath.endsWith("lineHeight") && e.setProperty("--line-height-primary", t.oldGlobalSettingValue)
                })(a);
                break;
            default:
                (t => {
                    var e;
                    n.setBuilderDataWithKey({
                        path: t.path,
                        value: JSON.parse(null != (e = t.old) ? e : ""),
                        isState: !1
                    })
                })(a)
            }
        },
        getPrevState: h,
        getNextState: c,
        insertState: async n => {
            await l(n),
            s.value && await(async() => {
                a.length = 0,
                await Ze.clear("redo")
            })()
        },
        resetHistory: async() => {
            a.length = 0,
            d.length = 0,
            await Ze.clear("redo"),
            await Ze.clear("undo")
        },
        activeRedo: s,
        activeUndo: r
    }
}
const ii = ["https://static.topcv.vn/cv-builder/assets/background/white.png", "https://static.topcv.vn/cv-builder/assets/background/rm218batch4-ning-34.png", "https://static.topcv.vn/cv-builder/assets/background/rm309-adj-03.png", "https://static.topcv.vn/cv-builder/assets/background/SL_042620_30310_19.png", "https://static.topcv.vn/cv-builder/assets/background/SL_042620_30310_36.png", "https://static.topcv.vn/cv-builder/assets/background/SL-060521-43530-07.png", "https://static.topcv.vn/cv-builder/assets/background/v960-ning-11.png", "https://static.topcv.vn/cv-builder/assets/background/vivid-blurred-colorful-background.png", "https://static.topcv.vn/cv-builder/assets/background/vivid-blurred-colorful-wallpaper-background.png", "https://static.topcv.vn/cv-builder/assets/background/passion_bg_1.png", "https://static.topcv.vn/cv-builder/assets/background/passion_bg_2.png", "https://static.topcv.vn/cv-builder/assets/background/passion_bg_3.png", "https://static.topcv.vn/cv-builder/assets/background/passion_bg_4.png", "https://static.topcv.vn/cv-builder/assets/background/passion_bg_5.png", "https://static.topcv.vn/cv-builder/assets/background/basic_5_F1F2FF.png", "https://static.topcv.vn/cv-builder/assets/background/basic_5_F2FBFD.png", "https://static.topcv.vn/cv-builder/assets/background/basic_5_F5FBF8.png", "https://static.topcv.vn/cv-builder/assets/background/basic_5_FFF8F5.png"];
function ai() {
    var n,
    t,
    e;
    const i = $n.VN,
    a = it();
    function d() {
        const n = function () {
            if (a.fontFamily)
                return a.fontFamily
        }
        ();
        n && b(n)
    }
    function o() {
        const n = function () {
            if (a.lineHeight)
                return a.lineHeight
        }
        ();
        n && v(n)
    }
    function r() {
        s(a.colorPrimary)
    }
    function s(n, t = !1) {
        var e,
        i,
        d,
        o;
        const r = null != (e = jt(n).match(/\d+/g)) ? e : "",
        s = parseInt(r[0]),
        g = parseInt(r[1]),
        A = parseInt(r[2]),
        u = h(s, g, A, 100),
        m = h(s, g, A, 50),
        b = h(s, g, A, 25),
        v = h(s, g, A, 15);
        !function (n, t, e, i, a, d, o) {
            const w = document.documentElement.style;
            w.setProperty("--el-color-primary", "#00b14f"),
            w.setProperty("--text-primary-color", n),
            w.setProperty("--text-primary-color-15", t),
            w.setProperty("--text-primary-color-30", e),
            w.setProperty("--text-primary-color-50", i),
            w.setProperty("--text-primary-color-100", a),
            w.setProperty("--darken-primary-color", d),
            w.setProperty("--lighten-primary-color", o)
        }
        (u, h(s, g, A, 5), v, b, m, c(n, -40), c(n, 40));
        const f = (null != (i = a.globalSetting.styles) ? i : {}).colorPrimary;
        a.setGlobalSettingWithKey("styles", l(w({}, null != (o = null == (d = a.globalSetting) ? void 0 : d.styles) ? o : {}), {
                colorPrimary: n
            })),
        t && p(f, "colorPrimary")
    }
    function h(n, t, e, i) {
        return `rgb(${n} ${t} ${e}  / ${i}%)`
    }
    function c(n, t) {
        let e = parseInt(n.substring(1, 3), 16),
        i = parseInt(n.substring(3, 5), 16),
        a = parseInt(n.substring(5, 7), 16);
        e = parseInt(e * (100 + t) / 100),
        i = parseInt(i * (100 + t) / 100),
        a = parseInt(a * (100 + t) / 100),
        e = e < 255 ? e : 255,
        i = i < 255 ? i : 255,
        a = a < 255 ? a : 255;
        return "#" + (1 == e.toString(16).length ? "0" + e.toString(16) : e.toString(16)) + (1 == i.toString(16).length ? "0" + i.toString(16) : i.toString(16)) + (1 == a.toString(16).length ? "0" + a.toString(16) : a.toString(16))
    }
    function p(n, t, e) {
        var i;
        const d = m(null != (i = a.globalSetting.styles) ? i : {}, t);
        if (n === d)
            return;
        const {
            insertState: o
        } = ei(),
        w = {
            type: $e.REPLACE_GLOBAL_SETTING,
            oldGlobalSettingValue: n,
            newGlobalSettingValue: d,
            globalSettingPath: `styles.${t}`
        };
        e && (w.oldRenderDataValue = JSON.stringify(e), w.newRenderDataValue = JSON.stringify(a.builderData), w.type = $e.CHANGE_GLOBAL_SETTING_DATA_RENDER),
        o(w)
    }
    function g(n, t = !1) {
        var e,
        i;
        document.documentElement.style.setProperty("--background-image-global", `url('${n}')`);
        const d = (null != (e = a.globalSetting.styles) ? e : {}).backgroundImage;
        a.setGlobalSettingWithKey("styles", l(w({}, null == (i = a.globalSetting) ? void 0 : i.styles), {
                backgroundImage: n
            })),
        t && p(d, "backgroundImage")
    }
    function A(n) {
        a.setGlobalSettingWithKey("language", n)
    }
    function u() {
        const n = a.backgroundImage ? a.backgroundImage : ii[0];
        n && g(n)
    }
    function b(n, t = !1) {
        const e = document.documentElement.style,
        i = a.globalSetting.styles.fontFamily,
        d = f(a.builderData);
        e.setProperty("--font-family-primary", `"${n}"`),
        Qe(a.builderData),
        a.setFontFamily(n),
        t && p(i, "fontFamily", d)
    }
    function v(n, t = !1) {
        const e = document.documentElement.style;
        e.setProperty("--transaction", "none");
        const i = a.globalSetting.styles.lineHeight,
        d = f(a.builderData);
        a.setLineHeight(n),
        e.setProperty("--line-height-primary", n),
        Fe(a.builderData),
        setTimeout((() => {
                e.setProperty("--transaction", "all 0.3s")
            }), 300),
        t && p(i, "lineHeight", d)
    }
    return {
        setBackgroundImage: u,
        setColorPrimary: r,
        setFontFamily: d,
        setLineHeight: o,
        staticOptions: B({
            img: null != (e = null == (t = null == (n = null == a ? void 0 : a.globalSetting) ? void 0 : n.styles) ? void 0 : t.backgroundImage) ? e : "",
            autoCropWidth: 160,
            autoCropHeight: 160,
            fixedNumber: [9, 9]
        }),
        updateBackground: function (n) {
            var t,
            e;
            a.setGlobalSettingWithKey("styles", l(w({}, null != (e = null == (t = a.globalSetting) ? void 0 : t.styles) ? e : {}), {
                    backgroundColor: "#" + n.hex
                }))
        },
        currentColor: E((() => {
                var n,
                t,
                e;
                return null != (e = null == (t = null == (n = a.globalSetting) ? void 0 : n.styles) ? void 0 : t.backgroundColor) ? e : "#FFFFFF"
            })),
        onChangeImage: async function (n, t) {
            let e = window.URL.createObjectURL(t);
            const i = document.head.querySelector('meta[name="csrf-token"]'),
            d = new FormData;
            d.append("cv_id", ""),
            d.append("_token", null == i ? void 0 : i.content),
            d.append("cvoFormImageFile", n),
            await function (n) {
                return Wt.post("/upload-background-global", n, {
                    headers: {
                        "Content-Type": "multipart/form-data"
                    }
                })
            }
            (d).then((n => {
                    var t,
                    i;
                    e = null == (i = null == (t = n.data) ? void 0 : t.data) ? void 0 : i.image_url
                })).catch((() => {
                    alert("Lưu ảnh thất bại")
                })).finally((() => {
                    var n,
                    t;
                    const i = l(w({}, null != (t = null == (n = a.globalSetting) ? void 0 : n.styles) ? t : {}), {
                        backgroundImage: e
                    });
                    g(e),
                    a.setGlobalSettingWithKey("styles", i)
                }))
        },
        changeColorPrimary: s,
        currentColorPrimary: E((() => {
                var n,
                t,
                e;
                return null != (e = null == (t = null == (n = a.globalSetting) ? void 0 : n.styles) ? void 0 : t.colorPrimary) ? e : "#FFFFFF"
            })),
        changeBackground: g,
        changeFontFamily: b,
        changeLineHeightSetting: v,
        handleGlobalSetting: function () {
            a.setGlobalSetting(f(a.globalSettingWidget)),
            r(),
            u(),
            A(a.language || i),
            d(),
            o()
        },
        changeLanguage: A
    }
}
const di = {
default:
    "Write here",
    profile: "Profile",
    contact_information: "Contact Information",
    gender_label: "Gender",
    dob_label: "Dob",
    phone: "0123 456 789",
    phone_label: "Phone",
    email: "yourname@example.com",
    email_label: "Email",
    address: "Address",
    address_label: "Address",
    website: "Website",
    website_label: "Website",
    dob: "DD/MM/YY",
    gender: "Male/Female",
    title: "Title",
    name: "Full Name",
    business_card: "Business Card",
    job_position: "Job Position",
    avatar: "Avatar",
    objective: "Objective",
    objective_content: "Career goals: short-term, long-term.",
    skillgroup: "Skills",
    skills: "Skills",
    skill_label: "Skill Name",
    skill_content: "Skill description",
    award: "Honors & Awards",
    award_content: "Award Name",
    certification: "Certifications",
    certification_content: "Certification Name",
    activity: "Activities",
    activity_content: "Activity description",
    activity_organization: "Organization Name",
    activity_position: "Position",
    reference: "References",
    reference_content: "Reference information including name, title and contact information",
    additional_info: "Additional information",
    additional_info_content: "Fill in additional information",
    interests: "Interests",
    interest: "Interests",
    interest_label: "Interest Name",
    interest_content: "Fill in your interest",
    time: "Time",
    experience: "Work experience",
    experience_content: "Experience description",
    experience_company: "Company name",
    experience_position: "Position",
    from: "From",
    to: "To",
    education: "Education",
    education_school: "School name",
    education_content: "Education description",
    education_title: "Courses / Subjects",
    project: "Project",
    project_name: "Project Name",
    customer: "Customer",
    team_size: "Team Size",
    my_position: "Position",
    my_responsibility: "Responsibility",
    technologies_used: "Technologies",
    customer_label: "Name of customer",
    team_size_label: "Your team size",
    my_position_label: "Your position in project ",
    my_responsibility_label: "Your responsibility  in project",
    technologies_used_label: "Technology description",
    description: "Description project",
    description_label: "Description project"
}, oi = {
default:
    "コンテンツをインポートする",
    dob: "DD/MM/YY",
    gender: "男/女性",
    gender_label: "セックス",
    dob_label: "生年月日",
    phone: "電話",
    email: "Eメール",
    address: "住所",
    website: "Webサイト",
    title: "題名",
    name: "名前",
    business_card: "名刺",
    avatar: "アバター",
    contact_information: "コミュニケーション",
    objective: "志望の動機",
    objective_content: "キャリア目標: 短期、長期",
    skillgroup: "特技・得意科目",
    award: "賞",
    experience: "職歴",
    education: "学歴",
    certification: "免許・資格",
    activity: "社会活動",
    reference: "参照",
    additional_info: "追加情報",
    interests: "趣味",
    profile: "プロフィール",
    skills: "スキル",
    interest: "趣味",
    job_position: "職位",
    time: "時間",
    experience_company: "会社名",
    experience_position: "位置",
    from: "から",
    to: "に",
    education_school: "学校名",
    education_title: "コース・科目",
    activity_organization: "組織名",
    activity_position: "位置",
    project: "計画",
    project_name: "プロジェクト名",
    customer: "お客様",
    team_size: "チームサイズ",
    my_position: "位置",
    my_responsibility: "責任",
    technologies_used: "テクノロジー",
    description: "プロジェクトの説明",
    phone_label: "電話番号",
    email_label: "Email",
    address_label: "住所",
    website_label: "Website",
    skill_label: "スキル名",
    skill_content: "スキル説明",
    award_content: "賞名",
    certification_content: "証明書名",
    activity_content: "操作説明",
    reference_content: "名前、役職、連絡先などの参照情報",
    additional_info_content: "追加情報があれば入力してください",
    interest_label: "趣味名",
    interest_content: "好みを入力してください",
    experience_content: "あなたの職務経験を説明してください",
    education_content: "学歴または業績を説明してください",
    customer_label: "クライアント",
    team_size_label: "参加者の数",
    my_position_label: "位置",
    my_responsibility_label: "プロジェクトにおけるあなたの役割と責任",
    technologies_used_label: "使用技術",
    description_label: "プロジェクトの説明"
}, wi = {
default:
    "Nhập nội dung",
    profile: "Thông tin cá nhân",
    contact_information: "Thông tin liên hệ",
    gender_label: "Giới tính",
    dob_label: "Ngày sinh",
    dob: "DD/MM/YY",
    gender: "Nam/Nữ",
    phone: "0123 456 789",
    phone_label: "Số điện thoại",
    email: "tencuaban@example.com",
    email_label: "Email",
    address: "Quận A, thành phố Hà Nội",
    address_label: "Địa chỉ",
    website: "facebook.com/TopCV.vn",
    website_label: "Website",
    title: "Tiêu đề",
    name: "Họ tên",
    business_card: "Danh thiếp",
    job_position: "Vị trí ứng tuyển",
    avatar: "Ảnh đại diện",
    objective: "Mục tiêu nghề nghiệp",
    objective_content: "Mục tiêu nghề nghiệp của bạn, bao gồm mục tiêu ngắn hạn và dài hạn",
    skillgroup: "Kỹ năng",
    skills: "Kỹ năng",
    skill_label: "Tên kỹ năng",
    skill_content: "Mô tả kỹ năng",
    award: "Giải thưởng",
    award_content: "Tên giải thưởng",
    certification: "Chứng chỉ",
    certification_content: "Tên chứng chỉ",
    activity: "Hoạt động",
    activity_content: "Mô tả hoạt động",
    activity_organization: "Tên tổ chức",
    activity_position: "Vị trí của bạn",
    reference: "Người tham chiếu",
    reference_content: "Thông tin người tham chiếu bao gồm tên, chức vụ và thông tin liên hệ",
    additional_info: "Thông tin thêm",
    additional_info_content: "Điền thông tin thêm nếu có",
    interests: "Sở thích",
    interest: "Sở thích",
    interest_label: "Tên sở thích",
    interest_content: "Điền các sở thích của bạn",
    time: "Thời gian",
    experience: "Kinh nghiệm làm việc",
    experience_content: "Mô tả kinh nghiệm làm việc của bạn",
    experience_company: "Tên công ty",
    experience_position: "Vị trí công việc",
    from: "Bắt đầu",
    to: "Kết thúc",
    education: "Học vấn",
    education_school: "Tên trường học",
    education_content: "Mô tả quá trình học tập hoặc thành tích của bạn",
    education_title: "Ngành học / Môn học",
    project: "Dự án",
    project_name: "Tên dự án",
    customer: "Tên khách hàng",
    technologies_used: "Mô tả công nghệ bạn sử dụng",
    team_size: "Số lượng",
    my_position: "Vị trí của bạn trong dự án",
    my_responsibility: "Mô tả vai trò, trách nhiệm của bạn trong dự án",
    description: "Mô tả dự án của bạn",
    my_responsibility_label: "Vai trò, trách nhiệm của bạn trong dự án",
    my_position_label: "Vị trí",
    team_size_label: "Số lượng người tham gia",
    technologies_used_label: "Công nghệ sử dụng",
    customer_label: "Khách hàng",
    description_label: "Mô tả dự án"
};
function li() {
    const {
        getBlockMetaDataExampleByLanguage: n
    } = ri(),
    t = it(),
    e = C(!1),
    i = C(!1),
    a = C(),
    d = C(),
    o = C({}),
    w = {
        vi: "Tiếng Việt",
        en: "Tiếng Anh",
        jp: "Tiếng Nhật"
    },
    l = [{
            key: 1,
            icon: "fa-solid fa-user",
            color: "#212F3F",
            backgroundColor: "#F1F2F6"
        }, {
            key: 2,
            icon: "fa-solid fa-chart-user",
            color: "#FF9F0A",
            backgroundColor: "#FFF5E7"
        }, {
            key: 3,
            icon: "fa-solid fa-user-tie",
            color: "#00B14F",
            backgroundColor: "#E5F7ED"
        }
    ];
    return {
        getDataSample: async n => {
            try {
                const e = await function (n) {
                    const t = new URLSearchParams(n).toString();
                    return Wt.get("cv-sample?" + t)
                }
                ({
                    language: n
                });
                if (e.data.data)
                    return t.setListDataSample(e.data.data), e.data.data
            } catch (e) {
                console.log(e)
            }
            return []
        },
        getStyleLevel: n => {
            const t = l.find((t => t.key == n));
            return {
                color: null == t ? void 0 : t.color,
                backgroundColor: null == t ? void 0 : t.backgroundColor
            }
        },
        getIconLevel: n => {
            const t = l.find((t => t.key == n));
            return null == t ? void 0 : t.icon
        },
        previewDataSample: n => {
            a.value = n;
            const i = {
                name: t.templateCvInfo.slug,
                category_id: n.category_id,
                level: n.level,
                lang: t.language,
                iframe: !0,
                time: Date.now()
            },
            l = new URLSearchParams(i).toString();
            d.value = "https://www.topcv.vn/preview-cv-template?" + l,
            c(o.value, "description", n.description),
            c(o.value, "level", n.level_name),
            c(o.value, "title", n.title),
            c(o.value, "lang", w[t.language]),
            e.value = !0
        },
        isShowPreviewDataSample: e,
        linkPreview: d,
        setIsShowPreviewDataSample: n => {
            e.value = n
        },
        isShowModalChangeDataSample: i,
        handleCloseChangeDataSample: () => {
            i.value = !1
        },
        handleAcceptChangeDataSample: () => {
            let d = JSON.parse(a.value.cv_data);
            const o = be(re(f(t.builderData))),
            w = n(t.language);
            d = p(w, d),
            We(d),
            Xe(d, t.renderData),
            p(d, {
                global: t.cvData.global,
                profile: {
                    email: m(o, "profile.email", ""),
                    fullname: m(o, "profile.fullname", ""),
                    phone: m(o, "profile.phone", "")
                }
            }),
            t.setCvData(d);
            const {
                setBuilderDataModeCreate: l
            } = ni();
            l(f(t.renderData), d),
            t.setEmptyCvData(),
            i.value = !1,
            e.value = !1,
            t.setTemplateCvDataSample(a.value)
        },
        changeDataSample: n => {
            i.value = !0,
            a.value = n
        },
        handleAcceptModalPreview: () => {
            i.value = !0
        },
        checkDataSampleCurrent: n => n == t.templateCvDataSample.id,
        dataSampleDetail: o
    }
}
function ri() {
    const n = C(!1),
    t = C(""),
    e = it(), {
        changeLanguage: i
    } = ai(),
    a = n => {
        const t = d(n),
        i = be(re(f(e.builderData))),
        a = w(n),
        o = p(a, t, {
            global: e.cvData.global,
            profile: {
                email: m(i, "profile.email", ""),
                fullname: m(i, "profile.fullname", ""),
                phone: m(i, "profile.phone", "")
            }
        });
        e.setCvData(o);
        const {
            setBuilderDataModeCreate: l
        } = ni();
        l(f(e.renderData), o),
        e.setEmptyCvData()
    },
    d = n => {
        switch (n) {
        case $n.VN:
            return f(nt);
        case $n.JP:
            return f(tt);
        case $n.EN:
            return f(et);
        default:
            return f(nt)
        }
    },
    o = n => {
        switch (n) {
        case $n.VN:
            return wi;
        case $n.JP:
            return oi;
        case $n.EN:
            return di;
        default:
            return wi
        }
    };
    const w = n => {
        let t = {};
        switch (n) {
        case $n.VN:
            t = f(wi);
            break;
        case $n.JP:
            t = f(oi);
            break;
        case $n.EN:
            t = f(di);
            break;
        default:
            t = f(wi)
        }
        return {
            project: [{
                    my_responsibility_label: t.my_responsibility_label,
                    my_position_label: t.my_position_label,
                    team_size_label: t.team_size_label,
                    technologies_used_label: t.technologies_used_label,
                    customer_label: t.customer_label,
                    description_label: t.description_label
                }
            ]
        }
    };
    return {
        listLanguage: [{
                name: "vi",
                img: "vi.png",
                tooltip: "Tiếng Việt"
            }, {
                name: "en",
                img: "en.png",
                tooltip: "Tiếng Anh"
            }, {
                name: "jp",
                img: "jp.png",
                tooltip: "Tiếng Nhật"
            }
        ],
        handleChangeLanguage: i => {
            i !== e.language && (n.value = !0, t.value = i)
        },
        getCvDataExampleByLanguage: d,
        getDataTranslateByLanguage: o,
        getTranslateByText: function (n) {
            var t;
            if (!n)
                return null;
            const i = o(e.language),
            a = /\{(translate.+?)\}/gim,
            d = n.match(a);
            if (!d)
                return n;
            const w = null != (t = d[0]) ? t : null,
            l = w.replace(a, "$1").split(".").slice(1).join("."),
            r = m(i, l);
            return null == n ? void 0 : n.replace(w, r)
        },
        getDataCvTranslateByPath: function (n) {
            return n ? m(e.sampleData, n) : null
        },
        handleAcceptChangeLanguage: async() => {
            const {
                resetHistory: d
            } = ei();
            await d();
            const o = t.value;
            a(o),
            i(o),
            e.setDataExampleByLanguage();
            const {
                changeFontFamily: w
            } = ai();
            o === $n.JP ? w("Roboto") : e.setFontFamily(e.builderWidget.globalSetting.styles.fontFamily),
            n.value = !1,
            t.value = "",
            e.setPathEdit("");
            const {
                setListTypeBlockUsed: l
            } = ti();
            l(),
            e.setEmptyListKeyRenderRemoved();
            const {
                getDataSample: r
            } = li();
            await r(e.language)
        },
        handleCloseChangeLanguage: () => {
            n.value = !1,
            t.value = ""
        },
        isShowModalChangeLanguage: n,
        languageSelected: t,
        getBlockMetaDataExampleByLanguage: n => {
            const t = d(n);
            return {
                profile_meta: t.profile_meta,
                objective_meta: t.objective_meta,
                education_meta: t.education_meta,
                experience_meta: t.experience_meta,
                activity_meta: t.activity_meta,
                certification_meta: t.certification_meta,
                award_meta: t.award_meta,
                skillgroup_meta: t.skillgroup_meta,
                interests_meta: t.interests_meta,
                additional_info_meta: t.additional_info_meta,
                reference_meta: t.reference_meta,
                project_meta: t.project_meta,
                skillrate_meta: t.skillrate_meta,
                interest_meta: t.interest_meta
            }
        },
        getProjectLabelExampleByLanguage: w
    }
}
const si = ["innerHTML"], hi = S({
    props: {
        renderData: {
            type: Object,
        default:
            () => ({})
        },
        path: {
            type: String,
        default:
            String
        }
    },
    setup(n) {
        const t = n;
        let e = C("");
        const i = C({}),
        a = it(), {
            getTranslateByText: d
        } = ri(),
        o = n => {
            var e,
            i,
            a,
            o,
            w,
            l;
            const r = new RegExp(qt(`{${null == (e = t.renderData) ? void 0 : e.path}}`), "g");
            return t.renderData.isTranslate ? d(null != (a = null == (i = t.renderData) ? void 0 : i.text) ? a : "") : null != (l = null == (w = null == (o = t.renderData) ? void 0 : o.text) ? void 0 : w.replace(r, n)) ? l : ""
        };
        return I((() => a.language), (() => {
                var n,
                i,
                d;
                const w = null != (d = m(a.cvData, null != (i = null == (n = t.renderData) ? void 0 : n.path) ? i : "", "")) ? d : "";
                e.value = o(w)
            })),
        V((() => {
                var n,
                i,
                d;
                const w = null != (d = m(a.cvData, null != (i = null == (n = t.renderData) ? void 0 : n.path) ? i : "", "")) ? d : "";
                e.value = o(w)
            })),
        D((() => {
                var n,
                e;
                i.value = f(null == (n = t.renderData) ? void 0 : n.styles),
                Ot(null == (e = t.renderData) ? void 0 : e.text).length && i.value
            })),
        (t, a) => R((U(), T("div", {
                    style: N(i.value),
                    class: M(["ql-editor", n.renderData.classes]),
                    innerHTML: Q(e)
                }, null, 14, si)), [[q, n.renderData.text]])
    }
});
const ci = ["innerHTML"], pi = S({
    props: {
        renderData: {
            type: Object,
        default:
            () => ({})
        },
        path: {
            type: String,
        default:
            String
        }
    },
    setup(n) {
        const t = n;
        let e = C("");
        const i = C({}),
        a = it();
        return V((() => {
                var n,
                i,
                d,
                o,
                w,
                l,
                r;
                const s = new RegExp(qt(`{${null == (n = t.renderData) ? void 0 : n.path}}`), "g"),
                h = null != (o = m(a.cvData, null != (d = null == (i = t.renderData) ? void 0 : i.path) ? d : "", "")) ? o : "";
                e.value = null != (r = null == (l = null == (w = t.renderData) ? void 0 : w.text) ? void 0 : l.replace(s, h)) ? r : ""
            })),
        D((() => {
                var n,
                e;
                i.value = f(null == (n = t.renderData) ? void 0 : n.styles),
                Ot(null == (e = t.renderData) ? void 0 : e.text).length && "minWidth" in i.value && delete i.value.minWidth
            })),
        (t, a) => R((U(), T("div", {
                    style: N(i.value),
                    class: M([n.renderData.classes, "ql-editor"]),
                    innerHTML: Q(e)
                }, null, 14, ci)), [[q, n.renderData.text]])
    }
}), gi = S({
    props: {
        renderData: {
            type: Object,
        default:
            () => ({})
        },
        path: {
            type: String,
        default:
            String
        }
    },
    setup(n) {
        const t = n,
        e = () => {
            var n,
            e,
            i,
            a;
            const d = null != (n = f(t.renderData.classes)) ? n : [],
            o = null != (a = f(null == (i = null == (e = t.renderData) ? void 0 : e.content) ? void 0 : i.icon)) ? a : "";
            return d.push(o),
            d
        },
        i = F((() => t.renderData.styles));
        return (n, t) => (U(), T("i", {
                style: N(Q(i)),
                class: M(e())
            }, null, 6))
    }
}), Ai = {
    outputSize: 1,
    outputType: "png",
    size: 1,
    full: !1,
    canMove: !0,
    fixedBox: !1,
    original: !1,
    canMoveBox: !0,
    autoCrop: !0,
    centerBox: !1,
    high: !0,
    max: 99999,
    show: !0,
    fixed: !0
};
var ui = (n => (n.IMAGE = "assets/images/default-avatar.webp", n))(ui || {}), mi = (n, t) => {
    const e = n.__vccOpts || n;
    for (const [i, a] of t)
        e[i] = a;
    return e
};
const bi = n => (X("data-v-149070b3"), n = n(), Y(), n), vi = {
    class: "flex"
}, fi = {
    class: "w-75 mr-18"
}, xi = bi((() => O("p", {
                class: "mb-12 text-center modal-edit-image__caption"
            }, "Ảnh gốc", -1))), yi = {
    class: "modal-edit-image__upload-image"
}, ki = {
    key: 0,
    class: "ie-container"
}, Ei = ["src"], Bi = bi((() => O("p", {
                class: "modal-edit-image__caption"
            }, " Click hoặc kéo thả ảnh để tải lên ", -1))), Ci = bi((() => O("p", {
                class: "mt-16 modal-edit-image__caption"
            }, [W(" Ảnh tải lên có dung lượng không quá 5 MB. Giảm dung lượng ảnh "), O("a", {
                        href: "https://compressor.io/",
                        target: "_blank",
                        class: "text-highlight"
                    }, "tại đây")], -1))), Si = {
    class: "text-center w-25"
}, Ii = bi((() => O("p", {
                class: "mb-12 text-center modal-edit-image__caption"
            }, " Ảnh hiển thị trên CV ", -1))), Vi = {
    class: "avatar-preview"
}, Di = ["src"];
var Ri = mi(S({
            props: {
                value: {
                    type: Boolean,
                default:
                    !1
                },
                renderData: {
                    type: Object,
                default:
                    () => ({})
                },
                isReset: {
                    type: Boolean,
                default:
                    !1
                }
            },
            emits: ["save-builder-section", "change"],
            setup(n, {
                emit: t
            }) {
                const e = n,
                i = C(""),
                a = C(null),
                d = C(null),
                o = C(null),
                r = C(),
                s = () => {
                    r.value instanceof HTMLElement && (null == r || r.value.click())
                },
                h = () => {
                    Q(r).value = ""
                },
                c = B({
                    img: "",
                    autoCropWidth: 160,
                    autoCropHeight: 160,
                    fixedNumber: [9, 9]
                }),
                p = F((() => !c.img || c.img == ui.IMAGE)),
                g = C(!1);
                I((() => e.isReset), (() => {
                        c.img = "",
                        i.value = u()
                    })),
                I((() => e.value), (n => {
                        n && d.value && o.value && (c.img = d.value, i.value = o.value),
                        o.value && (i.value = o.value)
                    })),
                I((() => {
                        var n,
                        t;
                        return null == (t = null == (n = e.renderData) ? void 0 : n.content) ? void 0 : t.src
                    }), (() => {
                        var n,
                        t;
                        (null == (t = null == (n = e.renderData) ? void 0 : n.content) ? void 0 : t.src) == ui.IMAGE && (d.value = "", o.value = "")
                    }));
                const A = F((() => (i.value !== ui.IMAGE ? i.value : ui.IMAGE) || u())),
                u = () => Gt("images/default/default-avatar.png"),
                m = () => {
                    t("change", !1)
                },
                b = () => {
                    Q(a).getCropBlob((n => {
                            i.value = URL.createObjectURL(n)
                        }))
                },
                v = n => {
                    var i;
                    const a = l(w({}, null == (i = e.renderData) ? void 0 : i.content), {
                        src: n
                    });
                    t("save-builder-section", a, "content")
                },
                f = () => {
                    it().setIsUploadAvatar(!0),
                    g.value = !0,
                    a.value ? Q(a).getCropBlob((async n => {
                            var t;
                            const e = ((n, t) => new File([n], t, {
                                    lastModified: (new Date).getTime(),
                                    type: n.type
                                }))(n, "avatar-" + (new Date).getTime());
                            try {
                                const n = await x(e);
                                v(null == (t = n.data) ? void 0 : t.name)
                            } catch (i) {
                                alert("Đã có lỗi xảy ra, vui lòng thử lại sau"),
                                console.log(i)
                            }
                        })) : v(ui.IMAGE),
                    d.value = c.img,
                    o.value = i.value,
                    m()
                },
                x = async n => {
                    var t;
                    const e = document.head.querySelector('meta[name="csrf-token"]'),
                    i = new FormData;
                    i.append("cv_id", ""),
                    i.append("_token", null != (t = null == e ? void 0 : e.getAttribute("content")) ? t : ""),
                    i.append("cvoFormImageFile", n);
                    try {
                        const n = await function (n) {
                            return Wt.post("/v2/cv/upload-avatar", n, {
                                headers: {
                                    "Content-Type": "multipart/form-data"
                                }
                            })
                        }
                        (i);
                        return n.data
                    } catch (a) {
                        return Promise.reject(a)
                    }
                },
                y = () => {
                    c.img = "",
                    i.value = u()
                },
                k = F((() => e.renderData.styles.height ? e.renderData.styles.width : 300)),
                E = F((() => e.renderData.styles.height ? e.renderData.styles.height : 300)),
                S = F((() => {
                            var n,
                            t;
                            if (e.renderData.styles.height && e.renderData.styles.width) {
                                return [null == (n = e.renderData.styles.width) ? void 0 : n.toString().replace("px", ""), null == (t = e.renderData.styles.height) ? void 0 : t.toString().replace("px", "")]
                            }
                            return [1, 1]
                        })),
                V = F((() => {
                            var n,
                            t;
                            if (!e.renderData.styles.width && !e.renderData.styles.height)
                                return {
                                    width: "190px",
                                    height: "190px"
                                };
                            return {
                                width: "190px",
                                height: 190 / (Number(null == (n = e.renderData.styles.width) ? void 0 : n.toString().replace("px", "")) / Number(null == (t = e.renderData.styles.height) ? void 0 : t.toString().replace("px", ""))) + "px"
                            }
                        }));
                return D((() => {
                        var n,
                        t,
                        a,
                        d;
                        (null == (t = null == (n = e.renderData) ? void 0 : n.content) ? void 0 : t.src) && (i.value = `https://static.topcv.vn/avatars/${null == (d = null == (a = e.renderData) ? void 0 : a.content) ? void 0 : d.src}`, o.value = i.value)
                    })),
                (t, e) => (U(), H(Q(K), {
                        "model-value": n.value,
                        title: "Cập nhật ảnh đại diện",
                        width: "740px",
                        "custom-class": "modal-edit-image",
                        onClose: m
                    }, {
                        footer: G((() => [O("span", {
                                        class: "dialog-footer"
                                    }, [O("button", {
                                                class: "mr-8 text-gray-400 modal-edit-image__btn bg-secondary",
                                                onClick: m
                                            }, " Đóng lại "), O("button", {
                                                class: "modal-edit-image__btn bg-primary",
                                                onClick: f
                                            }, " Hoàn tất ")])])),
                    default:
                        G((() => [O("div", vi, [O("div", fi, [xi, O("div", yi, [O("input", {
                                                                class: "modal-edit-image__input-upload",
                                                                ref_key: "refInputFile",
                                                                ref: r,
                                                                type: "file",
                                                                id: "uploads",
                                                                accept: "image/png, image/jpeg, image/gif, image/jpg",
                                                                onChange: e[0] || (e[0] = n => (n => {
                                                                        const t = n.target.files[0];
                                                                        if (!t)
                                                                            return;
                                                                        if (!lt(n.target.value))
                                                                            return alert("Ảnh không đúng định dạng. Vui lòng chọn lại."), h(), !1;
                                                                        if (5120 < t.size / 1024)
                                                                            return alert("Ảnh không vượt quá 5MB"), h(), !1;
                                                                        const e = new FileReader;
                                                                        e.onload = n => {
                                                                            var t,
                                                                            e,
                                                                            i,
                                                                            a;
                                                                            let d;
                                                                            d = "object" == typeof(null == (t = null == n ? void 0 : n.target) ? void 0 : t.result) ? (null == (e = null == n ? void 0 : n.target) ? void 0 : e.result) ? window.URL.createObjectURL(new Blob([null == (i = null == n ? void 0 : n.target) ? void 0 : i.result])) : "" : null == (a = null == n ? void 0 : n.target) ? void 0 : a.result,
                                                                            c.img = null != d ? d : ""
                                                                        },
                                                                        e.readAsArrayBuffer(t)
                                                                    })(n))
                                                            }, null, 544), Q(p) ? (U(), T("div", {
                                                                    key: 1,
                                                                    class: "empty",
                                                                    onClick: s
                                                                }, [O("img", {
                                                                            src: Q(Gt)("images/default/placeholder.png"),
                                                                            alt: "placeholder"
                                                                        }, null, 8, Ei), Bi])) : (U(), T("div", ki, [j(Q(P), L({
                                                                                ref_key: "cropper",
                                                                                ref: a,
                                                                                img: Q(c).img
                                                                            }, Q(Ai), {
                                                                                onRealTime: b,
                                                                                autoCropWidth: Q(k),
                                                                                autoCropHeight: Q(E),
                                                                                fixedNumber: Q(S)
                                                                            }), null, 16, ["img", "autoCropWidth", "autoCropHeight", "fixedNumber"])])), Ci])]), O("div", Si, [Ii, O("div", Vi, [O("img", {
                                                                class: "avatar-preview__img",
                                                                src: Q(A),
                                                                alt: "Avatar",
                                                                style: N(Q(V))
                                                            }, null, 12, Di)]), O("div", {
                                                        class: "mt-10 modal-edit-image__action"
                                                    }, [O("button", {
                                                                class: "modal-edit-image__btn-sm",
                                                                onClick: s
                                                            }, " Đổi ảnh "), O("button", {
                                                                class: "modal-edit-image__btn-delete modal-edit-image__btn-sm",
                                                                onClick: y
                                                            }, " Xóa ảnh ")])])])])),
                        _: 1
                    }, 8, ["model-value"]))
            }
        }), [["__scopeId", "data-v-149070b3"]]);
function qi(n) {
    const {
        el: t,
        type: e,
        renderData: i
    } = z(n),
    a = C(!1),
    d = C(0),
    o = C(),
    r = it();
    D((async() => {
            const n = Q(t).querySelector("img"),
            e = null == n ? void 0 : n.closest(".wrap-image");
            new J.ResizeSensor(e, (() => {
                    const t = null == n ? void 0 : n.closest(".resize-class"),
                    i = parseInt(window.getComputedStyle(e).width);
                    parseInt(window.getComputedStyle(t).width) > i && (t.style.width = i + "px", t.style.height = i / h() + "px")
                }))
        }));
    const s = () => {
        (() => {
            var e,
            i;
            const a = Q(t).querySelector("img"),
            o = null == a ? void 0 : a.closest(".wrap-image"),
            w = (null == (e = n.renderData.styles) ? void 0 : e.padding) || 0,
            l = (null == (i = n.renderData.styles) ? void 0 : i.outlineOffset) || 0;
            d.value = parseInt(window.getComputedStyle(o).width) - parseInt(w) - 2 * parseInt(l)
        })();
        const e = Q(t).querySelector(".resize-class");
        Z(e).unset(),
        o.value = Z(e).resizable({
            edges: {
                top: !0,
                left: !0,
                bottom: !0,
                right: !0
            },
            listeners: {
                move(n) {
                    const t = n.target;
                    t.style.width = n.rect.width + "px",
                    t.style.height = n.rect.height + "px"
                }
            },
            modifiers: [Z.modifiers.aspectRatio({
                    ratio: "preserve"
                }), Z.modifiers.restrictSize({
                    min: {
                        width: 160,
                        height: 160 / h()
                    },
                    max: {
                        width: d.value,
                        height: d.value / h()
                    }
                })],
            inertia: !0
        }).on("resizestart", (() => {
                    r.setResizingImage(!0)
                })).on("resizeend", (t => {
                    const e = l(w({}, i.value.styles), {
                        width: t.rect.width + "px",
                        height: t.rect.height + "px"
                    });
                    r.setBuilderDataWithKey({
                        path: `${Q(n.path)}.styles`,
                        value: e
                    }),
                    r.setResizingImage(!0)
                }))
    },
    h = () => {
        const n = m(Q(i), "styles.aspectRatio", "1/1");
        return n.split("/")[0] / n.split("/")[1]
    };
    return {
        displayPopupImage: E((() => Q(e) === Kn.IMAGE && Q(a))),
        listAlign: [{
                name: "Căn trái",
                icon: "fa-regular fa-objects-align-left",
                key: "left"
            }, {
                name: "Căn giữa dọc",
                icon: "fa-regular fa-objects-align-center-horizontal",
                key: "center"
            }, {
                name: "Căn phải",
                icon: "fa-regular fa-objects-align-right",
                key: "right"
            }
        ],
        initResize: () => {
            s()
        }
    }
}
const Ui = n => (X("data-v-2d790a64"), n = n(), Y(), n), Ti = ["src"], Ni = {
    key: 0
}, Mi = [Ui((() => O("div", {
                class: "resize-icon top-left"
            }, null, -1))), Ui((() => O("div", {
                class: "resize-icon bottom-left"
            }, null, -1))), Ui((() => O("div", {
                class: "resize-icon top-right"
            }, null, -1))), Ui((() => O("div", {
                class: "resize-icon bottom-right"
            }, null, -1)))], Qi = {
    key: 1,
    class: "box-loader"
}, Fi = [Ui((() => O("div", {
                class: "loader"
            }, null, -1)))], Hi = Ui((() => O("div", {
                class: "overlay-image"
            }, null, -1))), Gi = [Ui((() => O("i", {
                class: "fa fa-arrow-up-from-line"
            }, null, -1))), Ui((() => O("p", null, "Sửa ảnh", -1)))];
var Oi = mi(S({
            props: {
                renderData: {
                    type: Object,
                default:
                    () => ({})
                },
                path: {
                    type: String,
                default:
                    String
                }
            },
            emits: ["save-builder-section"],
            setup(n, {
                emit: t
            }) {
                const e = n,
                i = C(""),
                a = C(""),
                d = C(),
                o = C(),
                w = it(),
                l = C(!1),
                r = C(!1),
                s = C(!0), {
                    renderData: h,
                    path: c
                } = z(e);
                I(h, (async n => {
                        (n => {
                            var t,
                            e;
                            const a = Q(i);
                            i.value = null != (e = null == (t = null == n ? void 0 : n.content) ? void 0 : t.src) ? e : a
                        })(n)
                    }), {
                    immediate: !0,
                    deep: !0
                }),
                I((() => w.isUploadAvatar), (() => {
                        l.value = w.isUploadAvatar
                    }));
                const p = () => {
                    w.setIsUploadAvatar(!1)
                },
                g = E((() => {
                            if (i.value) {
                                return "preview-cv" === w.builderWidget.route ? `https://static.topcv.vn/user_avatars/${i.value}` : `https://static.topcv.vn/avatars/${i.value}`
                            }
                            return Gt("images/default/default-avatar.png")
                        }));
                D((() => {
                        var n,
                        t,
                        a,
                        l,
                        h,
                        p,
                        g,
                        A,
                        u,
                        b = new _(window.navigator.userAgent);
                        r.value = Boolean(b.mobile());
                        const v = new RegExp(qt(`{${null == (n = e.renderData) ? void 0 : n.path}}`), "g"),
                        f = m(w.cvData, null != (a = null == (t = e.renderData) ? void 0 : t.path) ? a : "", "");
                        if (i.value = null != (g = null == (p = null == (h = null == (l = e.renderData) ? void 0 : l.content) ? void 0 : h.src) ? void 0 : p.replace(v, f)) ? g : "", s.value = m(e.renderData, "resizeable", !0), !r.value && s.value) {
                            const {
                                initResize: n
                            } = qi({
                                el: d.value,
                                renderData: e.renderData,
                                path: c,
                                type: "image"
                            });
                            null == (u = null == (A = o.value) ? void 0 : A.querySelector(".overlay-image")) || u.addEventListener("click", n)
                        }
                    }));
                const A = E((() => {
                            var n;
                            return Ft(null == (n = e.renderData) ? void 0 : n.styles, ["aspectRatio", "width", "height", "border", "borderStyle", "borderWidth", "borderColor", "borderRadius", "outline", "outlineOffset", "outlineStyle", "outlineColor", "margin", "boxShadow"])
                        })),
                u = E((() => {
                            var n;
                            return Ht(null == (n = e.renderData) ? void 0 : n.styles, ["borderRadius", "outline", "outlineOffset", "outlineStyle", "outlineColor", "boxShadow"])
                        })),
                b = E((() => {
                            var n;
                            return Ht(null == (n = e.renderData) ? void 0 : n.styles, ["aspectRatio", "width", "height", "border", "borderStyle", "borderWidth", "borderColor", "paddingTop", "paddingBottom", "paddingLeft", "paddingRight", "margin"])
                        })),
                v = C(!1),
                f = n => {
                    v.value = n,
                    w.setPathEdit("")
                },
                x = (n, t) => {
                    w.setBuilderDataWithKey({
                        path: `${Q(e.path)}.${t}`,
                        value: n
                    })
                };
                return (n, t) => {
                    var e,
                    i;
                    return U(),
                    T("div", {
                        ref_key: "imageElement",
                        ref: d
                    }, [O("div", {
                                class: "wrap-image",
                                style: N(Q(A)),
                                ref_key: "wrapImage",
                                ref: o
                            }, [O("div", {
                                        class: M(["resize-class", null != (i = null == (e = Q(h)) ? void 0 : e.classes) ? i : ""]),
                                        style: N(Q(b))
                                    }, [O("img", {
                                                src: Q(g),
                                                ref_key: "image",
                                                ref: a,
                                                style: N(Q(u)),
                                                onLoad: p,
                                                alt: ""
                                            }, null, 44, Ti), !r.value && s.value ? (U(), T("div", Ni, Mi)) : $("", !0), l.value ? (U(), T("div", Qi, Fi)) : $("", !0), Hi, O("div", {
                                                class: "btn-show-popup-edit-image",
                                                onClick: t[0] || (t[0] = n => f(!0))
                                            }, Gi)], 6)], 4), (U(), H(nn, {
                                    to: "#portal-cvo-popup-modal"
                                }, [j(Ri, {
                                            value: v.value,
                                            "render-data": Q(h),
                                            onChange: f,
                                            onSaveBuilderSection: x
                                        }, null, 8, ["value", "render-data"])]))], 512)
                }
            }
        }), [["__scopeId", "data-v-2d790a64"]]);
const ji = S({
    props: {
        renderData: {
            type: Object,
        default:
            () => ({})
        },
        path: {
            type: String,
        default:
            String
        }
    },
    setup(n) {
        const t = n,
        e = F((() => Ft(w({}, t.renderData.styles), []))),
        i = F((() => {
                    var n,
                    e,
                    i;
                    return null == (i = null == (e = null == (n = t.renderData) ? void 0 : n.content) ? void 0 : e.before) ? void 0 : i.text
                })),
        a = F((() => {
                    var n,
                    e,
                    i;
                    return null == (i = null == (e = null == (n = t.renderData) ? void 0 : n.content) ? void 0 : e.after) ? void 0 : i.text
                })),
        d = F((() => {
                    var n,
                    e,
                    i;
                    return "icon" == (null == (i = null == (e = null == (n = t.renderData) ? void 0 : n.content) ? void 0 : e.before) ? void 0 : i.type)
                })),
        o = F((() => {
                    var n,
                    e,
                    i;
                    return "icon" == (null == (i = null == (e = null == (n = t.renderData) ? void 0 : n.content) ? void 0 : e.after) ? void 0 : i.type)
                })),
        l = F((() => {
                    var n,
                    e,
                    i;
                    return null == (i = null == (e = null == (n = t.renderData) ? void 0 : n.content) ? void 0 : e.before) ? void 0 : i.styles
                })),
        r = F((() => {
                    var n,
                    e,
                    i;
                    return null == (i = null == (e = null == (n = t.renderData) ? void 0 : n.content) ? void 0 : e.after) ? void 0 : i.styles
                }));
        return (t, w) => {
            var s;
            return U(),
            T("a", {
                class: M(n.renderData.classes),
                style: N(Q(e))
            }, [Q(d) ? (U(), T("i", {
                            key: 0,
                            class: M(Q(i))
                        }, null, 2)) : $("", !0), Q(d) ? $("", !0) : (U(), T("span", {
                            key: 1,
                            style: N(Q(l))
                        }, tn(Q(i)), 5)), O("span", null, tn(null == (s = n.renderData.content) ? void 0 : s.text), 1), Q(o) ? (U(), T("i", {
                            key: 2,
                            class: M(Q(a))
                        }, null, 2)) : $("", !0), Q(o) ? $("", !0) : (U(), T("span", {
                            key: 3,
                            style: N(Q(r))
                        }, tn(Q(a)), 5))], 6)
        }
    }
});
const Li = S({
    props: {
        renderData: {
            type: Object,
        default:
            () => ({})
        },
        path: {
            type: String,
        default:
            String
        }
    },
    setup(n) {
        var t,
        e;
        const i = n,
        a = {
            ComponentRender: na
        },
        d = B(null != (e = null == (t = i.renderData) ? void 0 : t.content) ? e : {}),
        o = F((() => i.renderData.styles)),
        w = F((() => en(i.renderData.children, r()))),
        l = F((() => `${i.path}.children`)),
        r = () => {
            var n,
            t;
            return null != (t = null == (n = null == d ? void 0 : d.meta) ? void 0 : n.col) ? t : 1
        };
        return (n, t) => (U(), T("table", {
                border: "1",
                style: N(Q(o))
            }, [(U(!0), T(an, null, dn(Q(w), ((n, t) => (U(), T("tr", {
                                            key: t
                                        }, [(U(!0), T(an, null, dn(n, ((n, e) => (U(), T("td", {
                                                                        key: e
                                                                    }, [O("div", null, [(U(), H(on(a[null == n ? void 0 : n.component]), {
                                                                                            "render-data": n,
                                                                                            "current-index": t * e,
                                                                                            path: Q(l)
                                                                                        }, null, 8, ["render-data", "current-index", "path"]))])])))), 128))])))), 128))], 4))
    }
});
const Pi = ["type"], Ki = ["onMouseover", "onClick"];
var Xi = mi(S({
            props: {
                renderData: {
                    type: Object,
                default:
                    () => ({})
                },
                path: {
                    type: String,
                default:
                    String
                }
            },
            setup(n) {
                const t = n,
                e = C(5);
                let i = C(Number(t.renderData.rate)),
                a = C(Number(t.renderData.rate));
                const d = () => {
                    w() || (a.value = i.value)
                },
                o = it(),
                w = () => o.isPreview;
                return (l, r) => {
                    var s,
                    h;
                    return U(),
                    T("div", {
                        class: M(["skill_rate", n.renderData.classes]),
                        style: N(n.renderData.styles),
                        type: null == (h = null == (s = n.renderData) ? void 0 : s.content) ? void 0 : h.type,
                        onMouseleave: d
                    }, [(U(!0), T(an, null, dn(e.value, (n => (U(), T("div", {
                                                    class: M(["skill_rate--item", {
                                                                active: n <= Q(a)
                                                            }
                                                        ]),
                                                    key: n,
                                                    onMouseover: t => (n => {
                                                        w() || (a.value = n)
                                                    })(n),
                                                    onClick: e => (n => {
                                                        w() || (i.value = n, o.setBuilderDataWithKey({
                                                                path: `${Q(t.path)}.rate`,
                                                                value: n
                                                            }))
                                                    })(n)
                                                }, null, 42, Ki)))), 128))], 46, Pi)
                }
            }
        }), [["__scopeId", "data-v-4c38bc35"]]);
var Yi = mi(S({
            props: {
                renderData: {
                    type: Object,
                default:
                    () => ({})
                },
                path: {
                    type: String,
                default:
                    String
                }
            },
            setup(n) {
                const t = n,
                e = it(),
                i = E((() => {
                            let n = m(t.renderData, "styles.backgroundColor", ""),
                            i = m(t.renderData, "styles.maxWidth", ""),
                            a = m(t.renderData, "styles.width"),
                            d = m(t.renderData, "styles.height"),
                            o = m(t.renderData, "styles.marginTop");
                            return i || (i = "100%"),
                            d || (d = "0.5px"),
                            n ? {
                                backgroundColor: n,
                                maxWidth: i,
                                width: a,
                                height: d,
                                marginTop: o
                            }
                             : {
                                backgroundColor: e.colorPrimary,
                                maxWidth: i,
                                width: a,
                                height: d,
                                marginTop: o
                            }
                        }));
                return (n, t) => (U(), T("div", {
                        class: "",
                        style: N(Q(i))
                    }, null, 4))
            }
        }), [["__scopeId", "data-v-0e1cc65a"]]);
const Wi = {
    class: "",
    style: {
        height: "0.5px"
    }
};
var zi = mi({}, [["render", function (n, t) {
                return U(),
                T("div", Wi)
            }
        ]]);
const Ji = ["text", "text-single", "image", "heading", "icon", "button", "table"], Zi = {
    renderData: {
        type: Object,
    default:
        () => ({})
    },
    path: {
        type: String,
    default:
        String
    },
    name: {
        type: String,
    default:
        String
    },
    currentIndex: {
        type: Number,
    default:
        0
    }
};
var _i = (n => (n.ERROR = "error", n.DARK = "dark", n.LIGHT = "light", n.PRIMARY = "primary", n))(_i || {});
const $i = S({
    props: {
        triggerRef: HTMLElement,
        tooltipContent: String,
        isError: Boolean,
        placement: {
            type: String,
        default:
            "top"
        },
        theme: {
            type: String,
        default:
            _i.DARK
        }
    },
    setup(n) {
        const t = n,
        e = C(!1);
        return I((() => t), (() => {
                e.value = !t.triggerRef
            }), {
            deep: !0
        }),
        (t, i) => (U(), H(Q(wn), {
                ref: "tooltipRef",
                "virtual-ref": n.triggerRef,
                "virtual-triggering": "",
                content: n.tooltipContent,
                "popper-class": "singleton-tooltip",
                placement: n.placement,
                disabled: e.value,
                "raw-content": "",
                effect: n.theme
            }, null, 8, ["virtual-ref", "content", "placement", "disabled", "effect"]))
    }
});
var na = mi(S({
            props: Zi,
            setup(n) {
                const t = n,
                e = {
                    text: hi,
                    "text-single": pi,
                    heading: hi,
                    icon: gi,
                    button: ji,
                    image: Oi,
                    table: Li,
                    skillRate: Xi,
                    lineFloating: Yi,
                    fullLineFloating: zi
                },
                i = it(),
                a = C(""),
                d = C(),
                o = C(),
                w = E((() => {
                            var n,
                            e;
                            let i = "";
                            return Ji.includes(null != (n = t.renderData.type) ? n : "") && (i = `element-main element-type-${t.renderData.type}`),
                            (null == (e = t.renderData) ? void 0 : e.isReadOnly) && (i += " readOnly"),
                            i
                        })),
                l = E((() => `${t.path}[${t.currentIndex}]`)),
                r = E((() => {
                            var n,
                            e;
                            return (null == (e = null == (n = t.renderData) ? void 0 : n.children) ? void 0 : e.length) ? `${t.path}[${t.currentIndex}].children` : `${t.path}[${t.currentIndex}]`
                        })),
                s = E((() => {
                            var n;
                            return (null == (n = t.renderData) ? void 0 : n.path) ? i.validateErrors[t.renderData.path] : null
                        }));
                return I((() => s.value), (n => {
                        if (!n)
                            return d.value = null, void(a.value = "");
                        d.value = o.value,
                        a.value = n
                    }), {
                    immediate: !0
                }),
                D((() => {
                        var n;
                        (null == (n = t.renderData) ? void 0 : n.uuid) === i.lastTextComponentKey && ln((() => {
                                setTimeout((() => {
                                        window.status = "ready"
                                    }), 1e3)
                            }))
                    })),
                (n, t) => {
                    var s,
                    h,
                    c;
                    const p = rn("builder");
                    return U(),
                    T(an, null, [R((U(), T("div", {
                                        ref_key: "componentRef",
                                        ref: o,
                                        class: M([[Q(w)], "component-render"])
                                    }, [(null == (s = n.renderData) ? void 0 : s.beforeElement) ? (U(), T("div", {
                                                    key: 0,
                                                    style: N(n.renderData.beforeElement.styles),
                                                    class: M(n.renderData.beforeElement.classes)
                                                }, null, 6)) : $("", !0), (U(), H(on(e[null != (h = n.renderData.type) ? h : ""]), {
                                                    "render-data": n.renderData,
                                                    path: Q(r)
                                                }, null, 8, ["render-data", "path"])), (null == (c = n.renderData) ? void 0 : c.afterElement) ? (U(), T("div", {
                                                    key: 1,
                                                    style: N(n.renderData.afterElement.styles),
                                                    class: M(n.renderData.afterElement.classes)
                                                }, null, 6)) : $("", !0)], 2)), [[p, {
                                            type: n.renderData.type,
                                            path: Q(l),
                                            isReadOnly: n.renderData.isReadOnly,
                                            isPreview: Q(i).isPreview,
                                            keyRender: n.renderData.uuid
                                        }
                                    ]]), j($i, {
                                "trigger-ref": d.value,
                                "tooltip-content": a.value,
                                theme: Q(_i).ERROR
                            }, null, 8, ["trigger-ref", "tooltip-content", "theme"])], 64)
                }
            }
        }), [["__scopeId", "data-v-5cee62ab"]]);
const ta = {
    renderData: {
        type: Object,
    default:
        () => ({})
    },
    path: {
        type: String,
    default:
        ""
    },
    currentIndex: {
        type: Number,
    default:
        Number
    },
    name: {
        type: String,
    default:
        ""
    },
    disableBuilderStyle: {
        type: Boolean,
    default:
        !1
    }
}, ea = O("div", {
    style: {
        height: "calc(100% - 10px)",
        width: "2px",
        display: "block",
        position: "absolute",
        left: "-21px",
        border: "1px solid #b4b4b4"
    }
}, null, -1), ia = S({
    props: {
        renderData: {
            type: Object,
        default:
            () => ({})
        },
        path: {
            type: String,
        default:
            String
        },
        styles: {
            type: Object,
        default:
            Object
        },
        class: {
            type: Array,
        default:
            Array
        }
    },
    setup(n) {
        const t = n, {
            styles: e
        } = z(t);
        return (n, t) => (U(), T("div", null, [ea, O("div", {
                        style: N([{
                                    width: "16px",
                                    height: "16px",
                                    position: "absolute",
                                    display: "block",
                                    top: "0",
                                    left: "-28px",
                                    "border-radius": "50%",
                                    border: "2px solid #ccc"
                                }, Q(e)])
                    }, null, 4)]))
    }
}), aa = O("div", {
    style: {
        height: "calc(100% - 10px)",
        width: "2px",
        display: "block",
        position: "absolute",
        left: "-21px",
        border: "0.5px solid #555555",
        top: "12px"
    }
}, null, -1), da = S({
    props: {
        renderData: {
            type: Object,
        default:
            () => ({})
        },
        path: {
            type: String,
        default:
            String
        },
        styles: {
            type: Object,
        default:
            Object
        },
        class: {
            type: Array,
        default:
            Array
        }
    },
    setup(n) {
        const t = n, {
            styles: e
        } = z(t),
        i = it(),
        a = E((() => {
                    let n = m(null == e ? void 0 : e.value, "backgroundColor", "");
                    return n ? {
                        backgroundColor: n
                    }
                     : {
                        backgroundColor: i.colorPrimary
                    }
                }));
        return (n, t) => (U(), T("div", null, [aa, O("div", {
                        style: N([{
                                    width: "10px",
                                    height: "10px",
                                    position: "absolute",
                                    display: "block",
                                    top: "0",
                                    left: "-25px",
                                    "border-radius": "50%",
                                    "background-color": "red"
                                }, Q(a)])
                    }, null, 4)]))
    }
}), oa = O("div", {
    style: {
        height: "calc(100% - 2px)",
        width: "2px",
        display: "block",
        position: "absolute",
        left: "11px",
        border: "0.5px dashed #555555",
        top: "7px"
    }
}, null, -1), wa = S({
    props: {
        renderData: {
            type: Object,
        default:
            () => ({})
        },
        path: {
            type: String,
        default:
            String
        },
        styles: {
            type: Object,
        default:
            Object
        },
        class: {
            type: Array,
        default:
            Array
        }
    },
    setup(n) {
        const t = n, {
            styles: e
        } = z(t),
        i = it(),
        a = E((() => {
                    let n = m(null == e ? void 0 : e.value, "backgroundColor", "");
                    return n ? {
                        backgroundColor: n
                    }
                     : {
                        backgroundColor: i.colorPrimary
                    }
                }));
        return (n, t) => (U(), T("div", null, [oa, O("div", {
                        style: N([{
                                    width: "10px",
                                    height: "10px",
                                    position: "absolute",
                                    display: "block",
                                    top: "-4px",
                                    left: "7px",
                                    "border-radius": "50%"
                                }, Q(a)])
                    }, null, 4)]))
    }
}), la = O("div", {
    class: "",
    style: {
        width: "2px",
        display: "block",
        position: "absolute",
        left: "-24px",
        height: "calc(100% - 21px)",
        top: "21px",
        "background-color": "#000000"
    }
}, null, -1), ra = O("div", {
    style: {
        position: "absolute",
        display: "block",
        top: "1px",
        left: "-28px",
        "background-image": "url(https://www.topcv.vn/packages/cvo/templates//timeline_clean/assets/images/timeline-cross.png)",
        "background-size": "9px",
        "background-position": "0px 4px",
        "background-repeat": "no-repeat",
        height: "13px",
        width: "10px"
    }
}, null, -1), sa = S({
    props: {
        renderData: {
            type: Object,
        default:
            () => ({})
        },
        path: {
            type: String,
        default:
            String
        },
        class: {
            type: Array,
        default:
            Array
        }
    },
    setup: n => (n, t) => (U(), T(an, null, [la, ra], 64))
}), ha = O("div", {
    style: {
        "text-align": "center",
        "z-index": "10",
        position: "absolute",
        left: "-40px"
    }
}, [O("i", {
            style: {
                width: "35px",
                height: "35px",
                color: "#496c92",
                display: "inline-block",
                "text-align": "center",
                "font-size": "19px",
                "line-height": "35px",
                "border-radius": "50%"
            },
            class: "fa fa-graduation-cap block-info-icon cvo-bg-color"
        })], -1), ca = O("div", {
        style: {
            position: "absolute",
            top: "0",
            left: "-25px",
            height: "100%",
            width: "5px",
            background: "#faf6c6",
            "z-index": "1"
        }
    }, null, -1), pa = S({
        props: {
            renderData: {
                type: Object,
            default:
                () => ({})
            },
            path: {
                type: String,
            default:
                String
            },
            class: {
                type: Array,
            default:
                Array
            }
        },
        setup: n => (n, t) => (U(), T(an, null, [ha, ca], 64))
    }), ga = {
    class: "cvo-bg-color",
    style: {
        position: "absolute",
        width: "30px",
        height: "100%",
        display: "inline-block",
        left: "-2px",
        "z-index": "0"
    }
}, Aa = S({
    props: {
        renderData: {
            type: Object,
        default:
            () => ({})
        },
        path: {
            type: String,
        default:
            String
        },
        class: {
            type: Array,
        default:
            Array
        }
    },
    setup: n => (n, t) => (U(), T("div", ga))
}), ua = {
    class: "cvo-bg-color",
    style: {
        position: "absolute",
        width: "30px",
        height: "100%",
        display: "inline-block",
        left: "-2px",
        "border-radius": "20px",
        "z-index": "0"
    }
}, ma = S({
    props: {
        renderData: {
            type: Object,
        default:
            () => ({})
        },
        path: {
            type: String,
        default:
            String
        },
        class: {
            type: Array,
        default:
            Array
        }
    },
    setup: n => (n, t) => (U(), T("div", ua))
});
var ba = mi(S({
            props: {
                renderData: {
                    type: Object,
                default:
                    () => ({})
                },
                path: {
                    type: String,
                default:
                    String
                },
                styles: {
                    type: Object,
                default:
                    Object
                },
                class: {
                    type: Array,
                default:
                    Array
                }
            },
            setup(n) {
                const t = n, {
                    styles: e
                } = z(t),
                i = it(),
                a = E((() => {
                            let n = m(null == e ? void 0 : e.value, "color", "");
                            n || (n = i.colorPrimary);
                            const t = `linear-gradient(90deg, ${n} , ${Kt(n)})`;
                            return w(w({}, null == e ? void 0 : e.value), {
                                background: t
                            })
                        }));
                return (n, t) => (U(), T("i", {
                        style: N(Q(a)),
                        class: "fa-solid fa-quote-right"
                    }, null, 4))
            }
        }), [["__scopeId", "data-v-3795cd32"]]);
const va = S({
    props: {
        renderData: {
            type: Object,
        default:
            () => ({})
        },
        path: {
            type: String,
        default:
            String
        },
        styles: {
            type: Object,
        default:
            Object
        },
        class: {
            type: Array,
        default:
            Array
        }
    },
    setup(n) {
        const t = n, {
            styles: e
        } = z(t),
        i = it(),
        a = E((() => {
                    let n = m(null == e ? void 0 : e.value, "color", "");
                    n || (n = i.colorPrimary);
                    const t = `linear-gradient(90deg, ${n} , ${Kt(n)})`;
                    return w(w({}, null == e ? void 0 : e.value), {
                        background: t
                    })
                }));
        return (n, t) => (U(), T("div", {
                style: N(Q(a))
            }, null, 4))
    }
});
function fa(n) {
    const t = it(), {
        insertState: e
    } = ei(), {
        getCvDataExampleByLanguage: i
    } = ri();
    function a(n) {
        return t.templateBlocks.find((t => t.id === n))
    }
    function d() {
        const e = Q(n);
        return m(t.builderData, `${e}`)
    }
    function o(o) {
        const w = a(o);
        if (!w)
            return;
        const l = w.renderBlock.typeBlock === zn.ADDITIONAL_INFO && t.listTypeBlockUsed.includes(zn.ADDITIONAL_INFO),
        r = f(w.renderBlock),
        s = i(t.language);
        if (r.typeBlock && r.typeBlock in t.cvDataBlockRemoved) {
            Ie(Ue([r], t.cvDataBlockRemoved), t.cvDataBlockRemoved),
            function (n, e) {
                const i = t.cvDataBlockRemoved;
                re([n]).forEach((n => {
                        if (n.path) {
                            const t = m(i, n.path);
                            void 0 !== t && (c(e, n.path, t), sn(i, n.path))
                        }
                    })),
                t.setCvDataBlockRemoved(i)
            }
            (r, s)
        } else
            Ie([r], s);
        const h = d();
        l && Pe(r),
        r.immediateFocus = !0;
        const p = m(t.itemAddBlockContent, "index", h.length);
        ne(r, !0),
        h.splice(p, 0, r),
        function (t, i) {
            const a = Q(n),
            d = {
                value: JSON.stringify(t),
                path: `${a}[${i}]`,
                type: $e.ADD,
                index: i
            };
            e(d)
        }
        (r, p);
        const {
            setListTypeBlockUsed: g
        } = ti();
        g()
    }
    return {
        listCategoryBlock: we,
        addBlockToTemplate: o,
        editBlockToTemplate: function (e) {
            const i = a(e);
            if (!i)
                return;
            const o = w({}, ne(f(i.renderBlock))), {
                handleUpdateCvData: l
            } = ti();
            l();
            const r = d();
            if (o.typeBlock === zn.ADDITIONAL_INFO && !xe(r)) {
                Ie([o], t.sampleData),
                Pe(o)
            } else {
                Ie([o], t.cvData)
            }
            const s = w({}, o),
            h = Q(n);
            t.setBuilderDataWithKey({
                path: h,
                value: s
            }),
            t.setPathEdit("")
        },
        getCategoryBlockByType: function (n, t) {
            return we.filter((e => e.subType ? e.type === n && e.subType === t : e.type === n))
        },
        getListCategoryBlockNotUsed: function () {
            return we.filter((n => !$t(t.listTypeBlockUsed, n)))
        },
        addBlockToTemplateFromTabNavigation: function (n) {
            const e = function (n) {
                const e = t.templateBlocks;
                return null == e ? void 0 : e.find((t => t.categoryTemplateId === n))
            }
            (n);
            o(e.id)
        }
    }
}
var xa = (n => (n.CREATE_CV = "create_cv", n.CREATE_CV_SUCCESS = "create_cv_success", n.EDIT_CV = "edit_cv", n.TIME_CREATE_CV_SUCCESS = "time_created_cv_success", n.CLICK_ADD_BLOCK_FROM_BELLOW_BLOCK = "CLICK_ADD_BLOCK_FROM_BELLOW_BLOCK", n.JOB_IN_VIEW_PORT = "JobInViewPort", n.DRAG_DROP_BLOCK = "drag_drop_block", n))(xa || {});
function ya(n, t) {
    window.ta(n, w(w({}, {
                id: "topcv_cv_builder"
            }), t))
}
const ka = {
    classes: ""
}, Ea = O("div", {
    style: {
        display: "block",
        position: "absolute",
        left: "-14px",
        height: "100%",
        width: "5px",
        background: "#faf6c6"
    }
}, null, -1), Ba = [O("i", {
        class: "fa fa-graduation-cap block-info-icon"
    }, null, -1)], Ca = S({
        props: {
            renderData: {
                type: Object,
            default:
                () => ({})
            },
            path: {
                type: String,
            default:
                String
            },
            styles: {
                type: Object,
            default:
                Object
            },
            class: {
                type: Array,
            default:
                Array
            }
        },
        setup(n) {
            const t = n, {
                styles: e
            } = z(t);
            return (n, t) => (U(), T("div", ka, [Ea, O("div", {
                            style: N([{
                                        position: "absolute",
                                        top: "0",
                                        left: "-30px",
                                        width: "35px",
                                        height: "35px",
                                        color: "#496c92",
                                        display: "inline-block",
                                        "text-align": "center",
                                        "font-size": "19px",
                                        "line-height": "35px",
                                        background: "#f4e8f8",
                                        "border-radius": "50%"
                                    }, Q(e)])
                        }, Ba, 4)]))
        }
    }), Sa = {
    classes: ""
}, Ia = O("div", {
    style: {
        display: "block",
        position: "absolute",
        left: "-14px",
        height: "100%",
        width: "5px",
        background: "#faf6c6"
    }
}, null, -1), Va = [O("i", {
        class: "fa fa-briefcase block-info-icon"
    }, null, -1)], Da = S({
        props: {
            renderData: {
                type: Object,
            default:
                () => ({})
            },
            path: {
                type: String,
            default:
                String
            },
            styles: {
                type: Object,
            default:
                Object
            },
            class: {
                type: Array,
            default:
                Array
            }
        },
        setup(n) {
            const t = n, {
                styles: e
            } = z(t);
            return (n, t) => (U(), T("div", Sa, [Ia, O("div", {
                            style: N([{
                                        position: "absolute",
                                        top: "0",
                                        left: "-30px",
                                        width: "35px",
                                        height: "35px",
                                        color: "#496c92",
                                        display: "inline-block",
                                        "text-align": "center",
                                        "font-size": "19px",
                                        "line-height": "35px",
                                        background: "#f4e8f8",
                                        "border-radius": "50%"
                                    }, Q(e)])
                        }, Va, 4)]))
        }
    });
const Ra = ["drag-render-path"], qa = {
    class: "min-padding"
}, Ua = S({
    props: ta,
    setup(n) {
        const t = n,
        e = C(!1),
        i = "fallback-render-item", {
            getTranslateByText: a
        } = ri(), {
            insertState: d
        } = ei(),
        o = function (n) {
            n.stopImmediatePropagation()
        },
        r = hn((() => Pn((() => import("./ListBlockContentWithFilter.149580.js")), ["assets/ListBlockContentWithFilter.149580.js", "assets/ListBlockContent.149580.css", "assets/useCategoryList.149580.js", "assets/vendor.149580.js", "assets/propsListBlockContent.149580.js"]))),
        s = hn((() => Pn((() => import("./ButtonAddBlock.149580.js")), ["assets/ButtonAddBlock.149580.js", "assets/ButtonAddBlock.149580.css", "assets/vendor.149580.js"]))),
        h = hn((() => Pn((() => import("./ButtonAddBlockBelowBlock.149580.js")), ["assets/ButtonAddBlockBelowBlock.149580.js", "assets/ButtonAddBlockBelowBlock.149580.css", "assets/vendor.149580.js"]))),
        c = {
            LayoutRender: Ua,
            ComponentRender: na
        },
        p = {
            "timeline-dot": ia,
            "timeline-dot-line-dash": wa,
            "timeline-dot-no-border": da,
            "timeline-plus": sa,
            "timeline-icon": pa,
            "mark-icon": ba,
            "footer-line-gradient": va,
            "vertical-wrapper-basic": Aa,
            "vertical-wrapper-radius": ma,
            "timeline-edu-basic-3": Ca,
            "timeline-exp-basic-3": Da
        },
        g = it(),
        A = function (n) {
            var d,
            o = null == (d = t.renderData.children) ? void 0 : d.at(n.oldDraggableIndex);
            if (!o)
                return;
            let w;
            if (w = o.subType ? we.find((n => n.subType === (null == o ? void 0 : o.subType))) : we.find((n => n.type === (null == o ? void 0 : o.typeBlock) && !n.subType)), w) {
                var l = n.from.querySelector(`.${i}`);
                l && (l.innerHTML = `\n      <div class="fallback-preview">\n        <i class="fallback-preview-icon ${w.icon}"></i>\n        <span class="fallback-preview-title">${a(w.name)}</span>\n      </div>\n    `, l.style.top = n.originalEvent.clientY - l.clientHeight / 2 + "px", l.style.left = n.originalEvent.clientX - l.clientWidth / 2 + "px"),
                e.value = !0,
                g.setPathEdit("")
            }
        },
        u = function () {
            e.value = !1
        },
        b = E((() => m(g.itemAddBlockContent, "path", ""))), {
            addBlockToTemplateFromTabNavigation: v
        } = fa(b),
        f = n => {
            var t,
            e,
            i,
            a,
            o,
            w,
            l,
            r;
            if (n.added)
                return n.added.element.id && P(n), g.setPathAddedByDraggable(J(n.added.newIndex));
            if (n.removed && g.pathAddedByDraggable.length) {
                const o = {
                    value: JSON.stringify(n.removed.element),
                    type: $e.MOVE,
                    path: J(n.removed.oldIndex),
                    newPath: g.pathAddedByDraggable
                };
                d(o),
                g.setPathAddedByDraggable(""),
                ya(xa.DRAG_DROP_BLOCK),
                (null == (e = null == (t = null == n ? void 0 : n.removed) ? void 0 : t.element) ? void 0 : e.uuid) && g.setPathEdit(null == (a = null == (i = null == n ? void 0 : n.removed) ? void 0 : i.element) ? void 0 : a.uuid)
            }
            if (n.moved && n.moved.newIndex !== n.moved.oldIndex) {
                const t = {
                    value: JSON.stringify(n.moved.element),
                    type: $e.MOVE,
                    path: J(n.moved.oldIndex),
                    newPath: J(n.moved.newIndex)
                };
                ya(xa.DRAG_DROP_BLOCK),
                d(t),
                (null == (w = null == (o = null == n ? void 0 : n.moved) ? void 0 : o.element) ? void 0 : w.uuid) && g.setPathEdit(null == (r = null == (l = null == n ? void 0 : n.moved) ? void 0 : l.element) ? void 0 : r.uuid)
            }
        }, {
            renderData: x
        } = z(t), {
            styleLayout: y,
            styleBlock: k,
            styleGap: B,
            classBlock: S,
            classLayout: I,
            getClassGridTemplate: V,
            isColumn: D,
            disableDrag: F,
            isBlock: L
        } = function (n) {
            const t = it(),
            e = C(n),
            i = e.value.block === Xn.COMPONENT,
            a = e.value.block === Xn.COLUMN,
            d = e.value.block === Xn.SECTION,
            o = e.value.flex === Wn.COLUMN,
            r = e.value.flex === Wn.GRID,
            s = e.value.block === Xn.BLOCK,
            h = e.value.flex === Wn.ROW,
            c = e.value.flex === Wn.ROW_NOWRAP,
            p = e.value.block === Xn.ELEMENT_GROUP,
            g = e.value.block === Xn.BLOCK_CHILD,
            A = E((() => Ft(w({}, e.value.styles), ["marginTop", "marginBottom", "marginRight", "marginLeft", "margin", "display", "opacity", "top"]))),
            u = E((() => {
                        var n,
                        t;
                        const i = [...null != (t = null == (n = e.value) ? void 0 : n.classes) ? t : []];
                        return a = ["cvo-bg-color", "cvo-bg-color-30", "cvo-bg-color-50", "cvo-bg-color-70"],
                        i.filter((n => a.includes(n)));
                        var a
                    })),
            b = E((() => {
                        var n,
                        t,
                        i,
                        a,
                        d,
                        o,
                        r,
                        s,
                        h,
                        c,
                        p,
                        g,
                        A,
                        u,
                        m,
                        b,
                        v,
                        f,
                        x,
                        y;
                        const k = {};
                        return (null == (n = e.value.styles) ? void 0 : n.marginRight) && (k.marginRight = null == (t = e.value.styles) ? void 0 : t.marginRight),
                        (null == (i = e.value.styles) ? void 0 : i.marginBottom) && (k.marginBottom = null == (a = e.value.styles) ? void 0 : a.marginBottom),
                        (null == (d = e.value.styles) ? void 0 : d.marginLeft) && (k.marginLeft = null == (o = e.value.styles) ? void 0 : o.marginLeft),
                        (null == (r = e.value.styles) ? void 0 : r.marginTop) && (k.marginTop = null == (s = e.value.styles) ? void 0 : s.marginTop),
                        (null == (h = e.value.styles) ? void 0 : h.margin) && (k.margin = null == (c = e.value.styles) ? void 0 : c.margin),
                        l(w({}, k), {
                            left: null != (g = null == (p = e.value.styles) ? void 0 : p.left) ? g : "",
                            right: null != (u = null == (A = e.value.styles) ? void 0 : A.right) ? u : "",
                            bottom: null != (b = null == (m = e.value.styles) ? void 0 : m.bottom) ? b : "",
                            top: null != (f = null == (v = e.value.styles) ? void 0 : v.top) ? f : "",
                            zIndex: null != (y = null == (x = e.value.styles) ? void 0 : x.zIndex) ? y : ""
                        })
                    })),
            v = E((() => d || i ? {
                        gap: e.value.styles.gap
                    }
                         : {})),
            f = E((() => {
                        var n,
                        t;
                        const o = [];
                        return s && o.push("block-main"),
                        a && ((null == (n = e.value.children) ? void 0 : n.length) || o.push("min-height-80"), o.push("column-main")),
                        i && o.push("component-main"),
                        d && ((null == (t = e.value.children) ? void 0 : t.length) || o.push("min-height-80"), o.push("section-main")),
                        p && o.push("element-group-main"),
                        g && o.push("block-child-main"),
                        o
                    })),
            x = E((() => {
                        var n,
                        t;
                        const i = [...null != (t = null == (n = e.value) ? void 0 : n.classes) ? t : []];
                        return B(e.value) || i.push("no-padding"),
                        o && i.push("flex-column"),
                        r && i.push("cv-grid"),
                        h && i.push("flex-row flex-wrap"),
                        c && i.push("flex-row flex-nowrap"),
                        i
                    })),
            y = E((() => {
                        var n;
                        let t = null == (n = e.value.styles) ? void 0 : n.gridTemplateColumns;
                        return t ? (t = t.toString(), `grid-${t.replace(/ |,|\(|\)/g, "")}`) : ""
                    })),
            k = E((() => !a && !t.isPreview)),
            B = n => {
                const t = n.styles,
                e = m(t, "padding", "0px"),
                i = m(t, "paddingLeft", "0px"),
                a = m(t, "paddingRight", "0px"),
                d = m(t, "paddingTop", "0px"),
                o = m(t, "paddingBottom", "0px");
                return "0px" !== e || "0px" !== i || "0px" !== a || "0px" !== d || "0px" !== o
            };
            return {
                disableDrag: k,
                styleLayout: A,
                styleBlock: b,
                styleGap: v,
                classBlock: f,
                classLayout: x,
                getClassGridTemplate: y,
                isColumn: a,
                isBlock: s,
                classBackgroundColor: u
            }
        }
        (x),
        P = function (n) {
            const e = w({}, t.renderData);
            e.children instanceof Array && e.children.splice(n.added.newIndex, 1);
            const i = {
                path: Q(X),
                index: n.added.newIndex,
                element: n.added.element
            };
            g.setItemAddBlockContent(i),
            v(i.element.id)
        },
        K = E((() => t.renderData.children)),
        X = E((() => `${t.path}[${t.currentIndex}].children`)),
        Y = C(""),
        W = E((() => `${t.path}[${t.currentIndex}]`)),
        J = function (n) {
            return `${X.value}[${n}]`
        },
        Z = C(!1),
        _ = () => {
            Y.value = X.value,
            tn.value = !1,
            Z.value = !0
        },
        tn = C(!1),
        en = () => {
            Y.value = t.path,
            function () {
                const n = {
                    path: t.path,
                    index: t.currentIndex + 1
                };
                g.setItemAddBlockContent(n)
            }
            (),
            tn.value = !0,
            Z.value = !0
        };
        const an = () => {
            Z.value = !1
        },
        dn = n => void 0 === n.isShow || n.isShow;
        return (n, t) => {
            var e,
            a,
            d,
            w,
            l,
            b;
            const v = rn("builder"),
            E = rn("hover-class-builder");
            return R((U(), T("div", {
                        style: N([Q(k)]),
                        class: M([Q(S)])
                    }, [Q(m)(Q(x), "beforeElement.type", "") ? (U(), H(on(p[Q(m)(Q(x), "beforeElement.type", "")]), {
                                    key: 0,
                                    classes: Q(m)(Q(x), "beforeElement.class", []),
                                    styles: Q(m)(Q(x), "beforeElement.styles", {})
                                }, null, 8, ["classes", "styles"])) : (null == (e = Q(x)) ? void 0 : e.beforeElement) ? (U(), T("div", {
                                    key: 1,
                                    style: N(Q(x).beforeElement.styles),
                                    class: M(Q(x).beforeElement.classes)
                                }, null, 6)) : $("", !0), Q(x).block === Q(Xn).BLOCK ? (U(), T("div", {
                                    key: 2,
                                    class: "btn-drag-block",
                                    "drag-render-path": Q(W),
                                    onMousedown: o
                                }, null, 40, Ra)) : $("", !0), O("div", qa, [j(Q(cn), {
                                        class: M(["layout-render", [Q(I), Q(V)]]),
                                        list: Q(K),
                                        style: N([Q(B), Q(y)]),
                                        "force-fallback": !0,
                                        disabled: Q(F),
                                        group: {
                                            name: "list-render-data"
                                        },
                                        "item-key": "uuid",
                                        "ghost-class": "ghost-drag-render-item",
                                        "fallback-class": i,
                                        handle: ".btn-drag-block",
                                        onStart: A,
                                        onEnd: u,
                                        onChange: f
                                    }, {
                                        item: G((({
                                                    element: n,
                                                    index: t
                                                }) => {
                                                return [R(O("div", {
                                                            class: "render-item",
                                                            style: N((e = n, (null == e ? void 0 : e.styles) ? Ht(null == e ? void 0 : e.styles, ["flexGrow", "alignSelf"]) : {}))
                                                        }, [(U(), H(on(c[n.component]), {
                                                                        "render-data": n,
                                                                        "current-index": t,
                                                                        path: Q(X)
                                                                    }, null, 8, ["render-data", "current-index", "path"]))], 4), [[q, dn(n)]])];
                                                var e
                                            })),
                                        _: 1
                                    }, 8, ["list", "class", "style", "disabled"])]), D ? (U(), H(Q(s), {
                                    key: 3,
                                    "data-html2canvas-ignore": "true",
                                    onShowModalAddBlock: _,
                                    "render-data": Q(x)
                                }, null, 8, ["render-data"])) : $("", !0), L && !Q(g).isPreview ? (U(), H(Q(h), {
                                    key: 4,
                                    "render-data": Q(x),
                                    onShowModalAddBlock: en
                                }, null, 8, ["render-data"])) : $("", !0), Q(m)(Q(x), "afterElement.type", "") ? (U(), H(on(p[Q(m)(Q(x), "afterElement.type", "")]), {
                                    key: 5,
                                    classes: Q(m)(Q(x), "afterElement.class", []),
                                    styles: Q(m)(Q(x), "afterElement.styles", [])
                                }, null, 8, ["classes", "styles"])) : (null == (a = Q(x)) ? void 0 : a.afterElement) ? (U(), T("div", {
                                    key: 6,
                                    style: N(Q(x).afterElement.styles),
                                    class: M(Q(x).afterElement.classes)
                                }, null, 6)) : $("", !0), (U(), H(nn, {
                                    to: "#portal-list-block-content"
                                }, [Z.value ? (U(), H(Q(r), {
                                                key: 0,
                                                isShow: Z.value,
                                                isEdit: !1,
                                                path: Y.value,
                                                onClose: an
                                            }, null, 8, ["isShow", "path"])) : $("", !0)]))], 6)), [[v, {
                            block: null == (d = Q(x)) ? void 0 : d.block,
                            typeBlock: null == (w = Q(x)) ? void 0 : w.typeBlock,
                            path: Q(W),
                            disableBuilderStyle: n.disableBuilderStyle,
                            isPreview: Q(g).isPreview,
                            keyRender: null == (l = Q(x)) ? void 0 : l.uuid,
                            immediateFocus: null == (b = Q(x)) ? void 0 : b.immediateFocus
                        }
                    ], [E, {
                            isPreview: Q(g).isPreview
                        }
                    ]])
        }
    }
});
function Ta() {
    const n = .264583333,
    t = C(297),
    e = C(0),
    i = C(0);
    function a(n, t) {
        const e = document.getElementById("cvb-section-content");
        if (e) {
            const i = document.createElement("div");
            i.classList.add("paging__separator"),
            i.style.top = n + "mm",
            i.setAttribute("data-html2canvas-ignore", "true");
            const a = document.createElement("div");
            a.classList.add("paging__separator--arrow"),
            a.innerHTML = `Trang ${t}`,
            i.appendChild(a),
            e.appendChild(i)
        }
    }
    return {
        initPaginate: function () {
            const d = document.querySelector("#cvb-section-content");
            if (d) {
                new ResizeObserver((() => {
                        !function (d) {
                            document.querySelectorAll(".paging__separator").forEach((n => {
                                    n.remove()
                                })),
                            e.value = (o = d, o * n),
                            i.value = Math.ceil(e.value / t.value);
                            var o;
                            const w = [];
                            for (let n = 1; n < i.value; n++) {
                                let e = 0;
                                e = 1 == n ? t.value : w[w.length - 1] + t.value,
                                w.push(e)
                            }
                            for (let n = 0; n < w.length; n++) {
                                a(w[n], n + 2)
                            }
                        }
                        (d.clientHeight)
                    })).observe(d)
            }
        }
    }
}
const Na = {
    id: "cvb-section-content"
};
var Ma = mi(S({
            props: {
                sections: {
                    type: Array,
                default:
                    Array
                }
            },
            setup(n) {
                const t = it(), {
                    initPaginate: e
                } = Ta();
                return t.isPreview || ln((() => {
                        e()
                    })),
                (t, e) => (U(), T("div", Na, [(U(!0), T(an, null, dn(n.sections, ((n, t) => (U(), T("section", {
                                                    key: n.uuid
                                                }, [(U(), H(Ua, {
                                                                key: null == n ? void 0 : n.uuid,
                                                                "current-index": t,
                                                                "render-data": n
                                                            }, null, 8, ["current-index", "render-data"]))])))), 128))]))
            }
        }), [["__scopeId", "data-v-701d7d00"]]);
const Qa = {
    Arial: "Arial",
    BaiJamjuree: "Bai Jamjuree",
    Barlow: "Barlow",
    BeVietnamPro: "Be Vietnam Pro",
    Inter: "Inter",
    Lexend: "Lexend",
    Maitree: "Maitree",
    Montserrat: "Montserrat",
    MontserratAlternates: "Montserrat Alternates",
    Mulish: "Mulish",
    Raleway: "Raleway",
    Roboto: "Roboto",
    RobotoCondensed: "Roboto Condensed",
    SourceCodePro: "Source Code Pro",
    TimesNewRoman: "Times New Roman",
    Trirong: "Trirong"
}, Fa = {
    MPLUS1p: "M PLUS 1p",
    NotoSansJP: "Noto Sans JP",
    NotoSerifJP: "Noto Serif JP",
    Roboto: "Roboto",
    RobotoCondensed: "Roboto Condensed",
    SawarabiGothic: "Sawarabi Gothic",
    ZenMaruGothic: "Zen Maru Gothic"
}, Ha = p(w({}, Qa), w({}, Fa)), Ga = Object.keys(Ha).sort().reduce(((n, t) => (n[t] = Ha[t], n)), {}), Oa = pn.import("formats/font");
Oa.whitelist = ["Roboto", "TimesNewRoman", "Arial", "BaiJamjuree", "Barlow", "BeVietnamPro", "Inter", "NotoSans", "OpenSans", "Maitree", "RobotoCondensed", "SourceCodePro", "Trirong", "Mulish", "Lexend", "Raleway", "Montserrat", "MontserratAlternates", "MPLUS1p", "NotoSansJP", "NotoSerifJP", "SawarabiGothic", "ZenMaruGothic", "Monospace"], pn.register(Oa, !0);
const ja = pn.import("parchment");
let La = !1;
gn.keys = {
    BACKSPACE: 8,
    TAB: 9,
    ENTER: 13,
    ESCAPE: 27,
    LEFT: 37,
    UP: 38,
    RIGHT: 39,
    DOWN: 40,
    DELETE: 46
}, pn.register("modules/keyboard", class extends gn {
    constructor(n, t) {
        super(n, t)
    }
    listen() {
        this.quill.root.addEventListener("keyup", (n => {
                9 === n.keyCode && (La = !1)
            })),
        this.quill.root.addEventListener("keydown", (n => {
                if (9 === n.keyCode && (La ? n.preventDefault() : La = !0), n.defaultPrevented)
                    return;
                const t = n.which || n.keyCode,
                e = (this.bindings[t] || []).filter((function (t) {
                        return gn.match(n, t)
                    }));
                if (0 === e.length)
                    return;
                const i = this.quill.getSelection();
                if (null == i || !this.quill.hasFocus())
                    return;
                const [a, d] = this.quill.getLine(i.index),
                [o, w] = this.quill.getLeaf(i.index),
                [l, r] = 0 === i.length ? [o, w] : this.quill.getLeaf(i.index + i.length),
                s = o instanceof ja.Text ? o.value().slice(0, w) : "",
                h = l instanceof ja.Text ? l.value().slice(r) : "",
                c = {
                    collapsed: 0 === i.length,
                    empty: 0 === i.length && a.length() <= 1,
                    format: this.quill.getFormat(i),
                    offset: d,
                    prefix: s,
                    suffix: h
                };
                e.some((n => {
                        if (null != n.collapsed && n.collapsed !== c.collapsed)
                            return !1;
                        if (null != n.empty && n.empty !== c.empty)
                            return !1;
                        if (null != n.offset && n.offset !== c.offset)
                            return !1;
                        if (Array.isArray(n.format)) {
                            if (n.format.every((function (n) {
                                        return null == c.format[n]
                                    })))
                                return !1
                        } else if ("object" == typeof n.format && !Object.keys(n.format).every((function (t) {
                                    return !0 === n.format[t] ? null != c.format[t] : !1 === n.format[t] ? null == c.format[t] : An(n.format[t], c.format[t])
                                })))
                            return !1;
                        return !(null != n.prefix && !n.prefix.test(c.prefix)) && (!(null != n.suffix && !n.suffix.test(c.suffix)) && !0 !== n.handler.call(this, i, c))
                    })) && n.preventDefault()
            }))
    }
});
const Pa = ["1.2", "1.3", "1.4", "1.5", "1.6", "1.7", "1.8", "1.9", "2.0"], Ka = [!1, "1.2", "1.3", "1.4", "1.5", "1.6", "1.7", "1.8", "1.9", "2.0"], Xa = {
    false: "Khoảng cách dòng",
    1.2: "1.2",
    1.3: "1.3",
    1.4: "1.4",
    1.5: "1.5",
    1.6: "1.6",
    1.7: "1.7",
    1.8: "1.8",
    1.9: "1.9",
    "2.0": "2.0"
}, Ya = pn.import("parchment"), Wa = new Ya.Attributor.Class("lineHeight", "ql-lineHeight", {
    scope: Ya.Scope.INLINE,
    whitelist: Pa
});
pn.register({
    "formats/lineHeight": Wa
}, !0);
const za = ["10px", "12px", "13px", "14px", "16px", "18px", "20px", "22px", "23px", "24px", "26px", "30px", "32px", "36px", "48px"], Ja = ["10px", "12px", "13px", "14px", "16px", "18px", "20px", "22px", "23px", "24px", "26px", "30px", "32px", "36px", "48px"], Za = pn.import("formats/size");
function _a(n) {
    return un(n)
}
Za.whitelist = za, pn.register(Za, !0);
const $a = pn.import("formats/indent");
$a.whitelist = [1, 2], pn.register({
    "formats/indent": $a
}, !0);
const nd = pn.import("modules/clipboard");
function td(n) {
    const t = it();
    return {
        setSelectionQuill: function () {
            var t;
            if (!Q(n).getSelection().length) {
                const e = (Q(n).getSelection() || {}).index || Q(n).getLength() - 1,
                i = Q(n).getLeaf(e),
                a = null != (t = i[0].domNode.length) ? t : 1,
                d = e - i[1];
                Q(n).setSelection(d, a)
            }
        },
        addFontQuill: function () {
            const n = "ADD_STYLE_FONT_TO_HEAD",
            e = function (n) {
                let e = "";
                const i = t.fontFamily;
                for (const [t, a] of Object.entries(n))
                    e += t ? `\n        .ql-picker.ql-font .ql-picker-label[data-value='${a}']::before,.ql-picker.ql-font .ql-picker-item[data-value='${a}']::before{\n          content: '${_a(t)}' !important;\n          font-family: '${_a(t)}';\n        }\n         .ql-picker.ql-font .ql-picker-label[data-value='${t}']::before,.ql-picker.ql-font .ql-picker-item[data-value='${t}']::before {\n            content: '${_a(t)}' !important;\n            font-family: '${_a(t)}';\n        }\n        .ql-font-${t} {\n          font-family: '${_a(t)}'!important;\n        }\n      ` : `\n        .ql-snow .ql-picker.ql-font .ql-picker-label::before, .ql-snow .ql-picker.ql-font .ql-picker-item::before {\n          content: '${i}';\n        }\n      `;
                return e += "   .ql-picker.ql-font .ql-picker-label[data-value='M PLUS 1p']::before,.ql-picker.ql-font .ql-picker-item[data-value='M PLUS 1p']::before{\n          content: 'M PLUS 1p' !important;\n          font-family: 'M PLUS 1p';\n        }\n         .ql-picker.ql-font .ql-picker-label[data-value='MPLUS1p']::before,.ql-picker.ql-font .ql-picker-item[data-value='MPLUS1p']::before {\n            content: 'M PLUS 1p' !important;\n            font-family: 'M PLUS 1p';\n        }\n        .ql-font-MPLUS1p {\n          font-family: 'M PLUS 1p'!important;\n        }",
                e
            }
            (p(w({}, Qa), w({}, Fa))),
            i = document.getElementById(n);
            if (i)
                i.innerHTML = e;
            else {
                const t = document.head || document.getElementsByTagName("head")[0],
                i = document.createElement("style");
                t.appendChild(i),
                i.type = "text/css",
                i.id = n,
                i.styleSheet ? i.styleSheet.cssText = e : i.appendChild(document.createTextNode(e))
            }
        },
        addLineHeightQuill: function () {
            const n = "ADD_STYLE_LINE_HEIGHT_TO_HEAD",
            t = function (n) {
                let t = "";
                return n.forEach((n => {
                        if (n) {
                            const e = n.replace(/\./g, "\\.");
                            t += `\n          .ql-lineHeight .ql-picker-label[data-value='${n}']::before {\n            content: "${Xa[n]}";\n            color: #646D79;\n          }\n          .ql-lineHeight .ql-picker-item[data-value='${n}']::before {\n            content: "${Xa[n]}";\n          }\n          .ql-lineHeight-${e} {\n            line-height: ${n} !important;\n        }\n        `
                        } else
                            t += '\n        .ql-lineHeight .ql-picker-label::before {\n            content: "Khoảng cách dòng";\n          }\n      '
                    })),
                t
            }
            (Ka),
            e = document.getElementById(n);
            if (e)
                e.innerHTML = t;
            else {
                const e = document.head || document.getElementsByTagName("head")[0],
                i = document.createElement("style");
                e.appendChild(i),
                i.type = "text/css",
                i.id = n,
                i.styleSheet ? i.styleSheet.cssText = t : i.appendChild(document.createTextNode(t))
            }
        },
        addSizeQuill: function () {
            const n = "ADD_STYLE_SIZE_TO_HEAD",
            t = function (n) {
                let t = "";
                return n.forEach((n => {
                        t += n ? `\n        .ql-picker.ql-size .ql-picker-label[data-value='${n}']::before {\n          content: "Cỡ chữ ${n}";\n       }\n        .ql-picker.ql-size .ql-picker-item[data-value='${n}']::before {\n          content: "${n}";\n       }\n        .ql-size-${n} {\n          font-size: ${n};\n       }\n        ` : '\n        .ql-snow .ql-picker.ql-size .ql-picker-label::before {\n          content: "Cỡ chữ 13px";\n       }\n        .ql-snow .ql-picker.ql-size .ql-picker-item::before {\n          content: "13px";\n       }'
                    })),
                t
            }
            (Ja),
            e = document.getElementById(n);
            if (e)
                e.innerHTML = t;
            else {
                const e = document.head || document.getElementsByTagName("head")[0],
                i = document.createElement("style");
                e.appendChild(i),
                i.type = "text/css",
                i.id = n,
                i.styleSheet ? i.styleSheet.cssText = t : i.appendChild(document.createTextNode(t))
            }
        }
    }
}
function ed(n, t) {
    var e;
    if (n.block === Xn.COLUMN && n.children)
        n.children = function (n, t) {
            const e = [];
            for (const i of n)
                i.typeBlock === zn.PROFILE && e.push(i);
            for (const i of t)
                for (const t of n)
                    t.typeBlock === i && e.push(t);
            return e
        }
    (n.children, t);
    else
        for (const i of null != (e = n.children) ? e : [])
            ed(i, t)
}
function id(n, t) {
    if (n)
        if (v(n))
            t.push(n);
        else if (mn(n))
            for (const e of n)
                id(e, t)
}
function ad(n, t) {
    const e = n.layout,
    i = [];
    for (const d in null != e ? e : [])
        id(e[d], i);
    const a = [];
    for (const d in n)
        i.includes(d) && d !== zn.PROFILE && a.push(d);
    for (const d of t)
        ed(d, a)
}
function dd(n, t) {
    if (mn(t)) {
        const e = [];
        for (const i of t) {
            const t = p(f(n[0]), f(i));
            e.push(t)
        }
        return e
    }
    return p(n, t)
}
function od(n, t) {
    for (const e in t) {
        "global" === e || e.endsWith("_meta") || !n[e] || (t[e] = dd(n[e], t[e]))
    }
}
pn.register("modules/clipboard", class extends nd {
    onPaste(n) {
        n.preventDefault();
        const t = this.quill.getSelection(),
        e = n.clipboardData.getData("text").replace(/<[^>]*>?/gm, "").replace("\n", " ").trim();
        t.length === this.quill.getLength() - 1 ? (this.quill.insertText(0, " "), this.quill.deleteText(1, t.length, "silent"), setTimeout((() => {
                    this.quill.insertText(0, e)
                }), 1)) : (this.quill.deleteText(t.index, t.length, "silent"), this.quill.insertText(t.index, e))
    }
}, !0);
const wd = {
    class: "cv-section-wrapper view-cv"
}, ld = {
    class: "view-cv__document"
}, rd = {
    class: "view-cv__page"
}, sd = {
    class: "view-cv__subpage"
};
var hd = mi(S({
            setup(n) {
                const t = it(), {
                    enablePreview: e,
                    setBuilderDataModeEdit: i,
                    setBuilderDataModeCreate: a
                } = ni(), {
                    handleGlobalSetting: d
                } = ai();
                return e(),
                D((async() => {
                        const n = it(),
                        t = n.builderWidget;
                        d();
                        if (!t.renderData || !t.renderData.length) {
                            const {
                                getTemplate: t
                            } = ti(), {
                                getCvDataExampleByLanguage: e
                            } = ri(),
                            i = await t(n.templateCvId),
                            d = f(i.renderData);
                            ad(n.cvDataWidget, d);
                            od(e(n.language), n.cvDataWidget),
                            a(f(d), n.cvDataWidget)
                        } else
                            i(f(t.renderData), n.cvDataWidget);
                        const e = Je(f(n.builderData));
                        n.setLastTextComponentKey(null == e ? void 0 : e.uuid),
                        n.setCvData(n.cvDataWidget);
                        const {
                            addFontQuill: o,
                            addLineHeightQuill: w,
                            addSizeQuill: l
                        } = td(null);
                        o(),
                        w(),
                        l()
                    })),
                (n, e) => {
                    var i,
                    a;
                    return U(),
                    T("div", wd, [O("div", ld, [O("div", rd, [O("div", sd, [O("div", {
                                                        class: "cv-section-wrapper cvb-preview",
                                                        id: "cvb-content-preview",
                                                        style: N(null != (a = null == (i = n.globalSetting) ? void 0 : i.styles) ? a : "")
                                                    }, [j(Ma, {
                                                                sections: Q(t).builderData
                                                            }, null, 8, ["sections"])], 4)])])])])
                }
            }
        }), [["__scopeId", "data-v-9fca9a1c"]]);
const cd = {
    class: "cv-section-wrapper view-cv"
}, pd = {
    class: "view-cv__document"
}, gd = {
    class: "view-cv__page"
}, Ad = {
    class: "view-cv__subpage"
}, ud = O("div", null, null, -1), md = O("div", {
    class: "view-cv__watermark"
}, "© topcv.vn", -1), bd = S({
    setup(n) {
        const {
            getBlockMetaDataExampleByLanguage: t
        } = ri(),
        e = it(), {
            enablePreview: i,
            setBuilderDataModeCreate: a
        } = ni(), {
            handleGlobalSetting: d
        } = ai();
        return i(),
        D((async() => {
                const {
                    getTemplate: n
                } = ti(),
                i = await n(e.templateCvId);
                e.setCvData(e.cvDataWidget),
                d();
                const o = t(e.language),
                w = p(o, e.cvDataWidget);
                We(w),
                Xe(w, i.renderData),
                a(f(i.renderData), w);
                const {
                    addFontQuill: l,
                    addLineHeightQuill: r,
                    addSizeQuill: s
                } = td(null);
                l(),
                r(),
                s()
            })),
        (n, t) => {
            var i,
            a;
            return U(),
            T("div", cd, [O("div", pd, [O("div", gd, [O("div", Ad, [O("div", {
                                                class: "cv-section-wrapper cvb-preview",
                                                id: "cvb-content-preview",
                                                style: N(null != (a = null == (i = Q(e).globalSetting) ? void 0 : i.styles) ? a : "")
                                            }, [j(Ma, {
                                                        sections: Q(e).builderData
                                                    }, null, 8, ["sections"])], 4)]), ud, md])])])
        }
    }
});
function vd() {
    return {
        getBlobUrl: async function (n) {
            const t = function (n) {
                return document.getElementById(n)
            }
            (n),
            e = {
                image: {
                    type: "jpeg",
                    quality: .98
                },
                html2canvas: {
                    scale: 2,
                    letterRendering: !0,
                    useCORS: !0,
                    dpi: 96
                },
                jsPDF: {
                    unit: "mm",
                    format: "a4",
                    orientation: "portrait"
                }
            };
            return (0, (await Pn((() => import("./html2pdf.149580.js").then((function (n) {
                                    return n.h
                                }))), ["assets/html2pdf.149580.js", "assets/vendor.149580.js"])).default)().set(e).from(t).output("bloburl")
        },
        downloadPdf: async function (n, t = "CV") {
            try {
                const i = await(e = n, Wt.get(`/download-cv?cv_id=${e}&download_source=topcv_web`, {
                            responseType: "blob"
                        })),
                a = new Blob([i.data]),
                d = URL.createObjectURL(a),
                o = document.createElement("a");
                o.href = d,
                o.download = t + "-TopCV.vn.pdf",
                o.click()
            } catch (i) {
                return void bn({
                    message: "Tải xuống CV không thành công!",
                    type: "error"
                })
            }
            var e
        },
        getCvPreviewBlobUrl: async function (n) {
            try {
                const e = await(t = n, Wt.post("v2/cv/preview-cv-builder", t, {
                            responseType: "blob"
                        })),
                i = new Blob([e.data]);
                return URL.createObjectURL(i)
            } catch (e) {
                return bn({
                    message: "Xem trước CV không thành công!",
                    type: "error"
                }),
                null
            }
            var t
        }
    }
}
const fd = new class {
    constructor() {
        r(this, "secretKey", "auto-save-1355d944"),
        r(this, "keyStorage", "data-cv-auto-save")
    }
    encrypt(n) {
        return y.exports.AES.encrypt(JSON.stringify(n), this.secretKey).toString()
    }
    decrypt(n) {
        if (!n)
            return "";
        const t = y.exports.AES.decrypt(n, this.secretKey);
        return JSON.parse(t.toString(y.exports.enc.Utf8))
    }
    saveDataAutoSave(n) {
        n = JSON.stringify(n),
        localStorage.setItem(this.keyStorage, this.encrypt(n))
    }
    getDataAutoSave() {
        const n = localStorage.getItem(this.keyStorage);
        return this.decrypt(n)
    }
    deleteDataAutoSave() {
        localStorage.removeItem(this.keyStorage)
    }
};
function xd() {
    const n = it(),
    t = C(!1),
    e = C(!1),
    i = C({}),
    a = C(!1),
    d = C(!1),
    o = C(!1),
    w = C(!1),
    l = C(!1), {
        downloadPdf: r
    } = vd(),
    s = () => ye(f(n.builderData)),
    h = () => {
        const t = s(),
        e = n.cvData,
        i = document.head.querySelector('meta[name="csrf-token"]'),
        a = n.cvId,
        d = n.globalSetting,
        o = new URLSearchParams(window.location.search).get("ta_source");
        return {
            data_render: t,
            _token: null == i ? void 0 : i.content,
            cvoData: e,
            cv_id: null != a ? a : "",
            template_id: n.templateCvId,
            global_setting: d,
            lang: d.language,
            ta_source: o
        }
    },
    p = async() => {
        var t,
        e,
        i,
        a,
        d;
        try {
            const o = document.querySelector(".navbar");
            o && (o.style.cssText += "z-index: 1 !important"),
            await b();
            const w = h(),
            l = n.cvId,
            r = !n.cvId;
            if (l)
                return (null == (t = window.trackingTopCV) ? void 0 : t.updatedCv) ? null == (e = window.trackingTopCV) || e.updatedCv() : console.log("updatedCv function does not exist."), await(d = w, Wt.post("/v2/cv/edit-cv", d));
            if (r) {
                (null == (i = window.trackingTopCV) ? void 0 : i.createdCv) ? null == (a = window.trackingTopCV) || a.createdCv() : console.log("createdCv function does not exist.");
                const n = await function (n) {
                    return Wt.post("/v2/cv/create-cv", n)
                }
                (w);
                return function () {
                    const n = it(),
                    t = localStorage.getItem("startTime"),
                    e = (new Date).getTime();
                    if (t) {
                        const i = e - t,
                        a = Math.floor(i / 1e3 % 60);
                        window.ta(xa.TIME_CREATE_CV_SUCCESS, {
                            t_s: a,
                            t_i: n.templateCvId
                        })
                    }
                }
                (),
                fd.deleteDataAutoSave(),
                n
            }
        } catch (o) {
            alert(o.response.data.message),
            u()
        }
    },
    A = () => {
        if (!n.listTypeBlockUsed.includes("profile.business_card"))
            return bn({
                message: "Mời bổ sung nội dung mục danh thiếp",
                type: "error"
            }), !0;
        if (!n.listTypeBlockUsed.includes("profile"))
            return bn({
                message: "Mời bổ sung mục thông tin liên hệ",
                type: "error"
            }), !0;
        const t = n.validateErrors;
        if (!g(t)) {
            const n = [vn("p", {
                    class: "validate__title"
                }, "Vui lòng kiểm tra lại các nội dung sau trước khi Lưu CV:")];
            for (const e in t) {
                const i = t[e];
                n.push(vn("p", {
                        class: "validate__message"
                    }, `• ${i}`))
            }
            return bn({
                message: vn("div", null, n),
                type: "error",
                customClass: "validate-alert",
                duration: 5e3,
                showClose: !0
            }),
            !0
        }
        if ("" === m()) {
            const n = document.querySelector(".navbar");
            return n && (n.style.cssText += "z-index: 1 !important"),
            e.value = !0,
            !0
        }
        return m().length > 50 && (bn({
                message: "Tên CV không được dài quá 50 ký tự!",
                type: "error"
            }), !0)
    },
    u = () => {
        a.value = !1,
        d.value = !1
    },
    m = () => Q(n.getCvTitle.trim()),
    b = async() => {
        const t = f(n.builderData),
        e = ze(t);
        n.setBuilderData(e);
        const i = be(re(e));
        c(i, "global", n.cvData.global),
        n.setCvData(i)
    },
    v = async t => {
        n.setPathEdit("");
        const e = (() => {
            const t = document.createElement("div");
            return t.innerHTML = n.cvData.profile.fullname,
`CV ${t.innerText} - ${n.cvData.global.cv_title}`
        })();
        await r(t, e),
        d.value = !1,
        o.value = !1
    },
    x = E((() => e.value)),
    y = E((() => t.value)),
    k = E((() => a.value)),
    B = E((() => o.value)),
    S = E((() => i.value)),
    I = E((() => d.value)),
    V = () => {
        d.value = !0,
        o.value = !0,
        p().then((async a => {
                var d;
                await v(a.data.encrypted_cv_id),
                d = a,
                n.setCvId(d.data.cv_id),
                i.value = d.data,
                e.value = !1,
                t.value = !0
            }))
    },
    D = (t = !1) => {
        if (!A()) {
            if (n.isShowWarning = !0, a.value = !0, o.value = !0, !t && !g(n.validateWarnings))
                return w.value = !0, e.value = !1, a.value = !1, void(o.value = !1);
            p().then((n => {
                    a.value = !1,
                    window.onbeforeunload = function () {},
                    setTimeout((() => {
                            window.location.href = n.data.success_url
                        }), 200)
                }))
        }
    };
    return {
        getIsUpdateNameCv: x,
        getIsSaveSuccess: y,
        getDataCvSaveSuccess: S,
        getIsLoading: k,
        isDisable: o,
        getIsDisable: B,
        isShowWarningMissingData: w,
        saveCV: p,
        handleCloseSaveCvSuccess: () => {
            t.value = !1;
            const n = document.querySelector(".navbar");
            n && (n.style.cssText += "z-index: 1000 !important")
        },
        handleCloseUpdateNameCv: () => {
            e.value = !1,
            l.value = !1;
            const n = document.querySelector(".navbar");
            n && (n.style.cssText += "z-index: 1000 !important")
        },
        downloadCv: v,
        handleSaveCV: D,
        handleUpdateNameCvSuccess: () => {
            l.value ? V() : D()
        },
        handleSaveAndDownload: () => {
            l.value = !0,
            A() || V()
        },
        getIsLoadingSaveAndDownLoad: I,
        getSaveParams: h,
        updateCvData: b,
        autoSave: async() => {
            await b();
            const n = h();
            fd.saveDataAutoSave(n)
        },
        handleCloseModalWarningMissingData: () => {
            w.value = !1,
            a.value = !1,
            o.value = !1
        },
        handleSaveCVIgnoreWarning: () => {
            w.value = !1,
            D(!0)
        }
    }
}
const yd = {
    key: 0,
    class: "wrap-skeleton"
}, kd = (n => (X("data-v-34633ad8"), n = n(), Y(), n))((() => O("div", {
            class: "skeleton is-animated"
        }, null, -1))), Ed = ["src"];
var Bd = mi(S({
            props: {
                isShowPreview: {
                    type: Boolean,
                default:
                    !1
                }
            },
            emits: ["set-is-show-preview", "set-is-loading"],
            setup(n, {
                emit: t
            }) {
                const e = n,
                i = hn((() => Pn((() => import("./vue3-pdf-embed.149580.js").then((function (n) {
                                            return n.v
                                        }))), ["assets/vue3-pdf-embed.149580.js", "assets/vendor.149580.js"]))), {
                    disablePreview: a,
                    isChangeBuilderData: d,
                    setBuilderDataHash: o
                } = ni(),
                w = C(),
                l = C(!1),
                r = it(), {
                    getCvPreviewBlobUrl: s
                } = vd(),
                h = C(!0),
                c = () => {
                    a(),
                    t("set-is-show-preview", !1)
                };
                return I((() => e.isShowPreview), (() => {
                        Q(e.isShowPreview) ? (l.value = !0, h.value = !0, setTimeout((async() => {
                                    if (d()) {
                                        if (o(), w.value = await(async() => {
                                                const {
                                                    getSaveParams: n,
                                                    updateCvData: t
                                                } = xd();
                                                await t();
                                                const e = n(),
                                                i = {
                                                    data_render: e.data_render,
                                                    cvo_data: e.cvoData,
                                                    global_setting: e.global_setting,
                                                    lang: e.lang,
                                                    template_id: e.template_id
                                                };
                                                return await s(i)
                                            })(), r.setPdfBlobFileBuilderData(Q(w)), t("set-is-loading", !1), !w.value)
                                            return r.setBuilderDataHash(null), void c()
                                    } else
                                        w.value = r.pdfBlobFileBuilderData, t("set-is-loading", !1);
                                    h.value = !1
                                }), 100)) : l.value = !1
                    }), {
                    immediate: !0
                }),
                (n, t) => (U(), H(Q(K), {
                        onClosed: c,
                        modelValue: l.value,
                        "onUpdate:modelValue": t[0] || (t[0] = n => l.value = n),
                        title: "Xem trước CV",
                        width: "793px",
                        top: "35px",
                        "custom-class": "dialog-preview"
                    }, {
                    default:
                        G((() => [h.value ? (U(), T("div", yd, [kd, O("img", {
                                                    src: Q(Gt)("images/skeleton.png"),
                                                    alt: ""
                                                }, null, 8, Ed)])) : $("", !0), R(j(Q(i), {
                                            source: w.value
                                        }, null, 8, ["source"]), [[q, !h.value]])])),
                        _: 1
                    }, 8, ["modelValue"]))
            }
        }), [["__scopeId", "data-v-34633ad8"]]);
const Cd = O("span", {
    role: "heading",
    class: "change-title-cv__title"
}, "Tên CV", -1), Sd = S({
    props: {
        isShow: {
            type: Boolean,
        default:
            !1
        },
        cvTitle: {
            type: String,
        default:
            ""
        }
    },
    emits: ["close", "change-title"],
    setup(n, {
        emit: t
    }) {
        const e = n,
        i = C(!1),
        a = C(""),
        d = () => {
            t("close", !1)
        },
        o = () => {
            t("change-title", a.value),
            d()
        };
        return I((() => e.isShow), (() => {
                i.value = e.isShow,
                e.isShow ? a.value = e.cvTitle : a.value = ""
            }), {
            immediate: !0
        }),
        (n, t) => (U(), H(Q(K), {
                onClosed: d,
                modelValue: i.value,
                "onUpdate:modelValue": t[1] || (t[1] = n => i.value = n),
                title: "Tên CV",
                "show-close": !1,
                style: {
                    "--el-dialog-padding-primary": "10px"
                },
                width: "300px"
            }, {
                header: G((() => [Cd])),
                footer: G((() => [O("button", {
                                class: "btn-cv btn-cv--disable",
                                onClick: d
                            }, "Hủy"), O("button", {
                                class: "btn-cv btn-cv--success",
                                onClick: o
                            }, " Lưu lại ")])),
            default:
                G((() => [j(Q(fn), {
                                class: "modal-update-name-cv__input",
                                modelValue: a.value,
                                "onUpdate:modelValue": t[0] || (t[0] = n => a.value = n),
                                placeholder: "Untitled CV",
                                name: "input",
                                style: {
                                    height: "40px"
                                }
                            }, null, 8, ["modelValue"])])),
                _: 1
            }, 8, ["modelValue"]))
    }
});
const Id = {
    class: "fixed-zoom"
}, Vd = {
    class: "zoom"
}, Dd = {
    class: "zoom__slider slider"
}, Rd = {
    class: "slider__container"
}, qd = {
    class: "slider__wrapper"
}, Ud = (n => (X("data-v-00409a7e"), n = n(), Y(), n))((() => O("span", {
            class: "slider__tick"
        }, null, -1))), Td = {
    class: "zoom__title"
};
var Nd = mi(S({
            setup(n) {
                const t = C(100),
                e = it(),
                i = [50, 75, 100, 125],
                a = () => {
                    if (t.value <= 50)
                        return;
                    const n = i.filter((n => n < t.value));
                    t.value = n[n.length - 1]
                },
                d = () => {
                    if (t.value >= 125)
                        return;
                    const n = i.filter((n => n > t.value));
                    t.value = n[0]
                };
                I((() => t), (() => {
                        (() => {
                            let n = document.querySelector(".cv-section-wrapper");
                            if (n) {
                                for (var i = ["webkit", "moz", "ms", "o"], a = "scale(" + t.value / 100 + ")", d = 0; d < i.length; d++)
                                    n.style[i[d] + "Transform"] = a, n.style[i[d] + "transformOrigin"] = "0px 0px";
                                n.style.transform = a,
                                n.style.transformOrigin = "center 0px ",
                                o(),
                                e.setPathEdit("")
                            }
                        })()
                    }), {
                    deep: !0,
                    immediate: !0
                });
                const o = () => {
                    let n = document.querySelector(".cv-section-wrapper"),
                    e = document.querySelector(".cv-section-main");
                    if (e && e.style && n)
                        if (100 === t.value)
                            e.style.height = "inherit";
                        else {
                            const t = n.getBoundingClientRect().height;
                            e.style.height = t > 1097 ? t + "px" : "1097px"
                        }
                };
                return I((() => e.isApplyCv), (() => {
                        t.value = 100
                    })),
                (n, e) => (U(), T("div", Id, [O("div", Vd, [O("button", {
                                        class: "zoom__button",
                                        onClick: d
                                    }, "+"), O("div", Dd, [O("div", Rd, [O("div", qd, [R(O("input", {
                                                                    class: "slider__input",
                                                                    type: "range",
                                                                    min: "50",
                                                                    max: "125",
                                                                    step: "1",
                                                                    "onUpdate:modelValue": e[0] || (e[0] = n => t.value = n)
                                                                }, null, 512), [[xn, t.value]]), Ud])])]), O("span", Td, tn(t.value) + "%", 1), O("button", {
                                        class: "zoom__button",
                                        onClick: a
                                    }, "-")])]))
            }
        }), [["__scopeId", "data-v-00409a7e"]]);
const Md = {
    class: "header__font-setting"
}, Qd = S({
    setup(n) {
        const {
            changeFontFamily: t
        } = ai(),
        e = it(),
        i = C(""),
        a = C(),
        d = C();
        I((() => e.language), (n => {
                d.value = n === $n.JP ? Fa : Qa
            }), {
            immediate: !0
        }),
        I((() => e.fontFamily), (n => {
                ln((() => {
                        a.value.$el.querySelector("input").style.fontFamily = n
                    })),
                i.value = e.globalSettingStyle.fontFamily || "Roboto"
            }), {
            deep: !0,
            immediate: !0
        });
        const o = n => {
            e.setPathEdit(""),
            t(n, !0)
        },
        w = n => {
            a.value.$el.contains(n.target) || a.value.blur()
        };
        return D((() => {
                document.addEventListener("click", w)
            })),
        yn((() => {
                document.removeEventListener("click", w)
            })),
        (n, t) => (U(), T("div", Md, [j(Q(En), {
                        modelValue: i.value,
                        "onUpdate:modelValue": t[0] || (t[0] = n => i.value = n),
                        class: "m-2 w-160px font-setting",
                        placeholder: "Select",
                        onChange: o,
                        onClick: t[1] || (t[1] = () => Q(e).setPathEdit("")),
                        ref_key: "fontInput",
                        ref: a
                    }, {
                    default:
                        G((() => [(U(!0), T(an, null, dn(d.value, ((n, t) => (U(), H(Q(kn), {
                                                            key: t,
                                                            label: n,
                                                            value: n,
                                                            class: M(`ql-font-${t}`)
                                                        }, null, 8, ["label", "value", "class"])))), 128))])),
                        _: 1
                    }, 8, ["modelValue"])]))
    }
});
const Fd = {
    class: "background-radio"
}, Hd = ["id", "name", "value", "checked"], Gd = ["for"];
var Od = mi(S({
            props: {
                value: {
                    type: String,
                default:
                    ""
                },
                id: {
                    type: String,
                default:
                    ""
                },
                name: {
                    type: String,
                default:
                    ""
                },
                width: {
                    type: String,
                default:
                    "100px"
                },
                height: {
                    type: String,
                default:
                    "140px"
                },
                selected: {
                    type: String,
                default:
                    ""
                }
            },
            emits: ["change"],
            setup(n, {
                emit: t
            }) {
                const e = n,
                i = it(),
                a = () => {
                    t("change", e.value),
                    i.setPathEdit("")
                },
                d = E((() => ({
                                "--background-bg-image": `url('${e.value}')`,
                                "--background-width": e.width,
                                "--background-height": e.height
                            })));
                return (t, e) => (U(), T("div", Fd, [O("input", {
                                id: n.id,
                                name: n.name,
                                value: n.value,
                                checked: n.value === n.selected,
                                class: "background-radio__input",
                                type: "radio",
                                onChange: a
                            }, null, 40, Hd), O("label", {
                                for : n.id, class: "background-radio__label", style: N(Q(d))
                            }, [O("button", {
                                        class: "background-radio__btn",
                                        onClick: a
                                    }, " Chọn ")], 12, Gd)]))
            }
        }), [["__scopeId", "data-v-726b107c"]]);
const jd = {
    class: "flex change-background"
}, Ld = [(n => (X("data-v-257481e1"), n = n(), Y(), n))((() => O("i", {
                class: "fa-solid fa-image mr-6"
            }, null, -1))), W(" Hình nền CV ")], Pd = {
    class: "change-background__list"
};
var Kd = mi(S({
            setup(n) {
                const {
                    changeBackground: t
                } = ai(),
                e = C(ii[0]),
                i = it();
                I((() => i.globalSettingStyle), (() => {
                        e.value = i.globalSettingStyle.backgroundImage || ii[0]
                    }), {
                    immediate: !0
                });
                const a = C(),
                d = C(),
                o = () => {
                    var n,
                    t;
                    null == (t = null == (n = Q(d).popperRef) ? void 0 : n.delayHide) || t.call(n)
                },
                w = n => {
                    e.value = n,
                    t(n, !0),
                    Q(d).hide()
                };
                return (n, t) => (U(), T("div", jd, [R((U(), T("label", {
                                        class: "mr-4",
                                        ref_key: "buttonRef",
                                        ref: a
                                    }, Ld)), [[Q(Bn), o]]), j(Q(Cn), {
                                ref_key: "popoverRef",
                                ref: d,
                                "virtual-ref": a.value,
                                trigger: "click",
                                title: "Chọn hình nền",
                                "virtual-triggering": "",
                                width: "356px"
                            }, {
                            default:
                                G((() => [O("div", Pd, [(U(!0), T(an, null, dn(Q(ii), (n => (U(), H(Od, {
                                                                            key: n,
                                                                            id: n,
                                                                            value: n,
                                                                            selected: e.value,
                                                                            name: "background-change",
                                                                            class: "change-background__item",
                                                                            onChange: w
                                                                        }, null, 8, ["id", "value", "selected"])))), 128))])])),
                                _: 1
                            }, 8, ["virtual-ref"])]))
            }
        }), [["__scopeId", "data-v-257481e1"]]), Xd = (n => (n.SMALL = "1.8", n.NORMAL = "2.1", n.LARGE = "2.4", n))(Xd || {});
const Yd = O("label", {
    class: "padding-0-8"
}, "Khoảng cách dòng", -1), Wd = {
    class: "d-inline-flex align-items-center"
}, zd = S({
    setup(n) {
        const {
            changeLineHeightSetting: t
        } = ai(),
        e = n => {
            t(n, !0)
        },
        i = C(""),
        a = it();
        return I((() => a.globalSettingStyle), (() => {
                i.value = a.globalSettingStyle.lineHeight || Xd.SMALL
            }), {
            immediate: !0,
            deep: !0
        }),
        (n, t) => (U(), T(an, null, [Yd, O("div", Wd, [j(Q(En), {
                                modelValue: i.value,
                                "onUpdate:modelValue": t[0] || (t[0] = n => i.value = n),
                                class: "m-2 line-height-setting",
                                onChange: e,
                                onClick: t[1] || (t[1] = () => Q(a).setPathEdit("")),
                                ref: "fontInput"
                            }, {
                            default:
                                G((() => [(U(!0), T(an, null, dn(Q(Pa), ((n, t) => (U(), H(Q(kn), {
                                                                    key: t,
                                                                    label: n,
                                                                    value: n,
                                                                    class: M(`ql-line-height-${t}`)
                                                                }, null, 8, ["label", "value", "class"])))), 128))])),
                                _: 1
                            }, 8, ["modelValue"])])], 64))
    }
});
const Jd = S({
    name: "Board",
    props: {
        color: Sn.instanceOf(Nt),
        round: Sn.bool.def(!1),
        hide: Sn.bool.def(!0)
    },
    emits: ["change"],
    setup(n, {
        emit: t
    }) {
        var e,
        i,
        a;
        const d = In(),
        o = {
            h: (null == (e = n.color) ? void 0 : e.hue) || 0,
            s: 1,
            v: 1
        },
        w = new Nt(o).toHexString(),
        l = B({
            hueColor: w,
            saturation: (null == (i = n.color) ? void 0 : i.saturation) || 0,
            brightness: (null == (a = n.color) ? void 0 : a.brightness) || 0
        }),
        r = C(0),
        s = C(0),
        h = C(),
        c = C(),
        g = E((() => ({
                        top: r.value + "px",
                        left: s.value + "px"
                    }))),
        A = () => {
            if (d) {
                const n = d.vnode.el;
                s.value = l.saturation * (null == n ? void 0 : n.clientWidth),
                r.value = (1 - l.brightness) * (null == n ? void 0 : n.clientHeight)
            }
        },
        u = n => {
            if (d) {
                const e = d.vnode.el,
                i = null == e ? void 0 : e.getBoundingClientRect();
                let a = n.clientX - i.left,
                o = n.clientY - i.top;
                a = Qt(a, 0, i.width),
                o = Qt(o, 0, i.height);
                const w = a / i.width,
                h = Qt(-o / i.height + 1, 0, 1);
                s.value = a,
                r.value = o,
                l.saturation = w,
                l.brightness = h,
                t("change", w, h)
            }
        };
        return Vn((() => {
                d && d.vnode.el && h.value && (Rn.triggerDragEvent(h.value, {
                        drag: n => {
                            u(n)
                        },
                        end: n => {
                            u(n)
                        }
                    }), A())
            })),
        Dn((() => n.color), (n => {
                p(l, {
                    hueColor: new Nt({
                        h: n.hue,
                        s: 1,
                        v: 1
                    }).toHexString(),
                    saturation: n.saturation,
                    brightness: n.brightness
                }),
                A()
            }), {
            deep: !0
        }), {
            state: l,
            cursorElement: h,
            getCursorStyle: g,
            onClickBoard: n => {
                n.target !== c.value && u(n)
            }
        }
    }
}), Zd = n => (X("data-v-44db4b41"), n = n(), Y(), n), _d = Zd((() => O("div", {
                class: "vc-saturation__white"
            }, null, -1))), $d = Zd((() => O("div", {
                class: "vc-saturation__black"
            }, null, -1))), no = [Zd((() => O("div", null, null, -1)))];
var to = mi(Jd, [["render", function (n, t, e, i, a, d) {
                    return U(),
                    T("div", {
                        ref: "boardElement",
                        class: M(["vc-saturation", {
                                    "vc-saturation__chrome": n.round,
                                    "vc-saturation__hidden": n.hide
                                }
                            ]),
                        style: N({
                            backgroundColor: n.state.hueColor
                        }),
                        onClick: t[0] || (t[0] = (...t) => n.onClickBoard && n.onClickBoard(...t))
                    }, [_d, $d, O("div", {
                                class: "vc-saturation__cursor",
                                ref: "cursorElement",
                                style: N(n.getCursorStyle)
                            }, no, 4)], 6)
                }
            ], ["__scopeId", "data-v-44db4b41"]]);
const eo = S({
    name: "Hue",
    props: {
        color: Sn.instanceOf(Nt),
        size: Sn.oneOf(["small", "default"]).def("default")
    },
    emits: ["change"],
    setup(n, {
        emit: t
    }) {
        const e = C(null),
        i = C(null);
        let a = n.color || new Nt;
        const d = B({
            hue: a.hue || 0
        });
        I((() => n.color), (n => {
                n && (a = n, p(d, {
                        hue: a.hue
                    }))
            }), {
            deep: !0
        });
        const o = E((() => ({
                        top: (() => {
                            if (e.value && i.value) {
                                const n = e.value.getBoundingClientRect(),
                                t = i.value.offsetHeight;
                                return 360 === d.hue ? n.height - t / 2 : d.hue % 360 * (n.height - t) / 360 + t / 2
                            }
                            return 0
                        })() + "px",
                        left: 0
                    }))),
        w = n => {
            if (n.stopPropagation(), e.value && i.value) {
                const o = e.value.getBoundingClientRect(),
                w = i.value.offsetHeight;
                let l = n.clientY - o.top;
                l = Math.min(l, o.height - w / 2),
                l = Math.max(w / 2, l);
                const r = Math.round((l - w / 2) / (o.height - w) * 360);
                a.hue = r,
                d.hue = r,
                t("change", r)
            }
        };
        return Vn((() => {
                const n = {
                    drag: n => {
                        w(n)
                    },
                    end: n => {
                        w(n)
                    }
                };
                e.value && i.value && Rn.triggerDragEvent(e.value, n)
            })), {
            barElement: e,
            cursorElement: i,
            getCursorStyle: o,
            onClickSider: n => {
                n.target !== e.value && w(n)
            }
        }
    }
}), io = [(n => (X("data-v-41385d8a"), n = n(), Y(), n))((() => O("div", {
                class: "vc-hue-slider__bar-handle"
            }, null, -1)))];
var ao = mi(eo, [["render", function (n, t, e, i, a, d) {
                    return U(),
                    T("div", {
                        class: M(["vc-hue-slider", {
                                    "small-slider": "small" === n.size
                                }
                            ])
                    }, [O("div", {
                                ref: "barElement",
                                class: "vc-hue-slider__bar",
                                onClick: t[0] || (t[0] = (...t) => n.onClickSider && n.onClickSider(...t))
                            }, [O("div", {
                                        class: M(["vc-hue-slider__bar-pointer", {
                                                    "small-bar": "small" === n.size
                                                }
                                            ]),
                                        ref: "cursorElement",
                                        style: N(n.getCursorStyle)
                                    }, io, 6)], 512)], 2)
                }
            ], ["__scopeId", "data-v-41385d8a"]]);
const oo = S({
    name: "History",
    props: {
        colors: Sn.arrayOf(String).def((() => [])),
        round: Sn.bool.def(!1)
    },
    emits: ["change"],
    setup: (n, {
        emit: t
    }) => ({
        onColorSelect: n => {
            t("change", n)
        }
    })
}), wo = {
    key: 0,
    class: "vc-colorPicker__record"
}, lo = {
    class: "color-list"
}, ro = ["onClick"];
var so = mi(oo, [["render", function (n, t, e, i, a, d) {
                    return n.colors && n.colors.length > 0 ? (U(), T("div", wo, [O("div", lo, [(U(!0), T(an, null, dn(n.colors, ((t, e) => (U(), T("div", {
                                                                key: e,
                                                                class: M(["color-item", "transparent", {
                                                                            "color-item__round": n.round
                                                                        }
                                                                    ]),
                                                                onClick: e => n.onColorSelect(t)
                                                            }, [O("div", {
                                                                        class: "color-item__display",
                                                                        style: N({
                                                                            backgroundColor: t
                                                                        })
                                                                    }, null, 4)], 10, ro)))), 128))])])) : $("", !0)
                }
            ], ["__scopeId", "data-v-07cb7c39"]]);
const ho = S({
    name: "Palette",
    emits: ["change"],
    props: {
        paletteColor: {
            type: Array,
        default:
            [["#330093", "#5000E8", "#7329FF", "#8B50FC", "#9C72ED", "#BB9AFB", "#037C12", "#00A915", "#00CB19", "#00E933", "#78E790", "#B1F5C0"], ["#046190", "#0083B1", "#00AFD3", "#00CEFA", "#84DCEE", "#AAF0FF", "#9E0000", "#F30000", "#FF3737", "#FF3737", "#FF9797", "#FFC8C8"], ["#C57800", "#EC8F00", "#FFA211", "#FFB748", "#FFC56A", "#FFE79E", "#6D008B", "#9500BE", "#AC00DC", "#CC15FF", "#DE66FF", "#EBA5FF"], ["#111111", "#333333", "#555555", "#777777", "#999999", "#CCCCCC", "#EEEEEE", "#FFFFFF"]]
        }
    },
    setup: (n, {
        emit: t
    }) => ({
        palettes: n.paletteColor,
        computedBgStyle: n => "transparent" === n ? n : "advance" === n ? {}
         : {
            background: u(n).toRgbString()
        },
        onColorChange: n => {
            t("change", n)
        }
    })
}), co = {
    class: "vc-compact"
}, po = ["onClick"];
var go = mi(ho, [["render", function (n, t, e, i, a, d) {
                    return U(),
                    T("div", co, [(U(!0), T(an, null, dn(n.paletteColor, ((t, e) => (U(), T("div", {
                                                    key: e,
                                                    class: "vc-compact__row"
                                                }, [(U(!0), T(an, null, dn(t, ((t, e) => (U(), T("div", {
                                                                                key: e,
                                                                                class: "vc-compact__color-cube--wrap",
                                                                                onClick: e => n.onColorChange(t)
                                                                            }, [O("div", {
                                                                                        class: M(["vc-compact__color_cube", {
                                                                                                    advance: "advance" === t,
                                                                                                    transparent: "transparent" === t
                                                                                                }
                                                                                            ]),
                                                                                        style: N(n.computedBgStyle(t))
                                                                                    }, null, 6)], 8, po)))), 128))])))), 128))])
                }
            ], ["__scopeId", "data-v-18684b09"]]);
const Ao = S({
    name: "Display",
    props: {
        color: Sn.instanceOf(Nt),
        disableAlpha: Sn.bool.def(!1)
    },
    emits: ["update:color", "change"],
    setup(n, {
        emit: t
    }) {
        var e,
        i,
        a,
        d;
        const o = B({
            color: n.color,
            previewBgColor: null == (e = n.color) ? void 0 : e.toRgbString(),
            alpha: null != (a = null == (i = n.color) ? void 0 : i.alpha) ? a : 100,
            hex: null == (d = n.color) ? void 0 : d.hex
        }),
        w = E((() => ({
                        background: o.previewBgColor
                    })));
        return Dn((() => n.color), (n => {
                n && (o.color = n)
            }), {
            deep: !0
        }),
        Dn((() => o.color), (() => {
                o.color && (o.previewBgColor = o.color.toRgbString(), o.alpha = o.color.alpha, o.hex = o.color.hex, t("update:color", o.color), t("change", o.color))
            }), {
            deep: !0
        }), {
            state: o,
            getBgColorStyle: w,
            onAlphaBlur: n => {
                const t = n.target,
                e = parseInt(t.value.replace("%", ""));
                !isNaN(e) && o.color && (o.alpha = e, o.color.alpha = e)
            },
            onInputChange: n => {
                const t = n.target.value.replace("#", "");
                u(t).isValid() && o.color && (o.color.hex = t)
            }
        }
    }
}), uo = {
    class: "vc-display"
}, mo = {
    class: "vc-current-color vc-transparent"
}, bo = {
    class: "vc-color-input"
}, vo = ["value"], fo = {
    key: 0,
    class: "vc-alpha-input"
}, xo = ["value"];
var yo = mi(Ao, [["render", function (n, t, e, i, a, d) {
                    return U(),
                    T("div", uo, [O("div", mo, [O("div", {
                                        class: "color-cube",
                                        style: N(n.getBgColorStyle)
                                    }, null, 4)]), O("div", bo, [O("input", {
                                        value: n.state.hex,
                                        onBlur: t[0] || (t[0] = (...t) => n.onInputChange && n.onInputChange(...t))
                                    }, null, 40, vo)]), n.disableAlpha ? $("", !0) : (U(), T("div", fo, [O("input", {
                                            class: "vc-alpha-input__inner",
                                            type: "number",
                                            value: n.state.alpha,
                                            onBlur: t[1] || (t[1] = (...t) => n.onAlphaBlur && n.onAlphaBlur(...t))
                                        }, null, 40, xo)]))])
                }
            ], ["__scopeId", "data-v-aeb9116e"]]), ko = (n => (n.TRANSPARENT = "rgba(0,0,0,0)", n))(ko || {});
const Eo = S({
    name: "ChromeColorPicker",
    components: {
        Display: yo,
        Board: to,
        Hue: ao,
        History: so,
        Palette: go,
        ElButton: qn
    },
    props: {
        color: Sn.instanceOf(Nt),
        disableHistory: Sn.bool.def(!1),
        roundHistory: Sn.bool.def(!1),
        disableAlpha: Sn.bool.def(!1),
        paletteColor: Array,
        enableTransparent: Sn.bool.def(!1)
    },
    emits: ["update:color", "change", "close"],
    setup(n, {
        emit: t
    }) {
        const e = new _(window.navigator.userAgent),
        i = n.color || new Nt,
        a = B({
            color: i,
            hex: i.toHexString(),
            rgb: i.toRgbString()
        }),
        d = E((() => ({
                        background: a.rgb
                    }))),
        o = Un("color-history", [], {}),
        w = Tn((() => {
                    if (n.disableHistory)
                        return;
                    const t = a.color.toRgbString();
                    if (o.value = o.value.filter((n => !u.equals(n, t))), !o.value.includes(t)) {
                        for (; o.value.length > 8; )
                            o.value.pop();
                        o.value.unshift(t)
                    }
                }), 500);
        Dn((() => n.color), (n => {
                n && (a.color = n)
            }), {
            deep: !0
        }),
        Dn((() => a.color), (() => {
                a.hex = a.color.hex,
                a.rgb = a.color.toRgbString(),
                w()
            }), {
            deep: !0
        });
        const l = () => {
            t("update:color", a.color),
            t("change", a.color),
            t("close", !0)
        };
        return {
            state: a,
            previewStyle: d,
            historyColors: o,
            onAlphaChange: n => {
                a.color.alpha = n
            },
            onHueChange: n => {
                a.color.hue = n,
                a.color.alpha = 100
            },
            onBoardChange: (n, t) => {
                a.color.saturation = n,
                a.color.brightness = t,
                a.color.alpha = 100
            },
            onCompactChange: n => {
                "advance" !== n && (a.color.hex = n)
            },
            onPaletteChange: n => {
                a.color = new Nt(n),
                l()
            },
            saveColor: l,
            cancelPopupColor: () => {
                t("close", !0)
            },
            handleImageUrl: Gt,
            onClickTransparentColor: () => {
                a.color = new Nt(ko.TRANSPARENT),
                l()
            },
            md: e
        }
    }
}), Bo = n => (X("data-v-ed64cd7a"), n = n(), Y(), n), Co = {
    class: "vc-chrome-colorPicker chrome"
}, So = {
    class: "chrome__palette palette"
}, Io = Bo((() => O("p", {
                class: "palette__title"
            }, "Bảng màu gợi ý", -1))), Vo = ["src"], Do = Bo((() => O("p", null, "Trong suốt", -1))), Ro = Bo((() => O("div", {
                class: "chrome__quick-transparent__line"
            }, null, -1))), qo = {
    key: 1,
    class: "chrome__board"
}, Uo = {
    class: "d-flex"
}, To = {
    key: 2,
    class: "chrome__action"
}, No = W("Hủy"), Mo = W("Cập nhật");
var Qo = mi(Eo, [["render", function (n, t, e, i, a, d) {
                    const o = Nn("Palette"),
                    w = Nn("Hue"),
                    l = Nn("Board"),
                    r = Nn("Display"),
                    s = Nn("el-button"),
                    h = Nn("History");
                    return U(),
                    T("div", Co, [O("div", So, [Io, j(o, {
                                        onChange: n.onPaletteChange,
                                        "palette-color": n.paletteColor
                                    }, null, 8, ["onChange", "palette-color"])]), n.enableTransparent ? (U(), T("div", {
                                    key: 0,
                                    class: M(["chrome__quick-transparent", {
                                                "chrome__quick-transparent--active": 0 === n.color.alphaValue
                                            }
                                        ]),
                                    onClick: t[0] || (t[0] = (...t) => n.onClickTransparentColor && n.onClickTransparentColor(...t))
                                }, [O("img", {
                                            src: n.handleImageUrl("images/non-color.svg")
                                        }, null, 8, Vo), Do], 2)) : $("", !0), Ro, n.md.mobile() ? $("", !0) : (U(), T("div", qo, [O("div", Uo, [j(w, {
                                                    size: "small",
                                                    color: n.state.color,
                                                    onChange: n.onHueChange
                                                }, null, 8, ["color", "onChange"]), j(l, {
                                                    round: !0,
                                                    hide: !1,
                                                    color: n.state.color,
                                                    onChange: n.onBoardChange
                                                }, null, 8, ["color", "onChange"])]), j(r, {
                                            color: n.state.color,
                                            "disable-alpha": n.disableAlpha
                                        }, null, 8, ["color", "disable-alpha"])])), n.md.mobile() ? $("", !0) : (U(), T("div", To, [j(s, {
                                            type: "success",
                                            onClick: t[1] || (t[1] = t => n.cancelPopupColor()),
                                            class: "btn__topcv--disable"
                                        }, {
                                        default:
                                            G((() => [No])),
                                            _: 1
                                        }), j(s, {
                                            type: "success",
                                            onClick: t[2] || (t[2] = t => n.saveColor()),
                                            class: "btn__topcv"
                                        }, {
                                        default:
                                            G((() => [Mo])),
                                            _: 1
                                        })])), n.disableHistory ? $("", !0) : (U(), H(h, {
                                    key: 3,
                                    round: n.roundHistory,
                                    colors: n.historyColors,
                                    onChange: n.onCompactChange
                                }, null, 8, ["round", "colors", "onChange"]))])
                }
            ], ["__scopeId", "data-v-ed64cd7a"]]);
const Fo = {
    color: {
        type: String,
    default:
        () => "#FFFFFF"
    },
    disableAlpha: {
        type: Boolean,
    default:
        () => !0
    },
    disableHistory: {
        type: Boolean,
    default:
        () => !1
    },
    roundHistory: {
        type: Boolean,
    default:
        () => !1
    },
    displayColorPicker: {
        type: Boolean,
    default:
        () => !1
    },
    title: {
        type: String,
    default:
        () => "Màu sắc"
    },
    virtualElRef: HTMLElement,
    placement: {
        type: String,
    default:
        "bottom"
    },
    paletteColor: {
        type: Array
    },
    enableTransparent: {
        type: Boolean,
    default:
        !1
    },
    label: {
        type: String,
    default:
        "Màu chủ đề"
    },
    behindHeader: {
        type: Boolean,
    default:
        !1
    }
};
const Ho = {
    class: "padding-0-8 color-picker__title"
};
var Go = mi(S({
            props: Fo,
            emits: ["change"],
            setup(n, {
                emit: t
            }) {
                const e = n,
                i = it(),
                a = E((() => [i.templateColors])), {
                    getColor: d,
                    selectedColor: o,
                    isVisible: w,
                    colorPickerBtnRef: l,
                    virtualElRef: r,
                    colorPicker: s,
                    isTransparent: h,
                    change: c,
                    onClickButtonRef: p,
                    closeColorPicker: g
                } = function (n, t) {
                    const e = C("#FFFFFF"), {
                        color: i
                    } = z(n),
                    a = C(),
                    d = C(),
                    o = C(!1),
                    w = E((() => new Nt(n.color)));
                    function l() {
                        o.value = !1
                    }
                    function r() {
                        e.value = n.color
                    }
                    function s(n) {
                        a.value.$el.contains(n.target) || d.value.contains(n.target) || l()
                    }
                    D((() => {
                            document.addEventListener("click", s)
                        })),
                    yn((() => {
                            document.removeEventListener("click", s)
                        }));
                    const h = E((() => {
                                var t;
                                return null != (t = n.virtualElRef) ? t : d
                            })),
                    c = E((() => 0 === w.value.alpha));
                    return I(i, (() => {
                            r()
                        }), {
                        immediate: !0
                    }), {
                        selectedColor: e,
                        getColor: w,
                        isVisible: o,
                        colorPickerBtnRef: d,
                        virtualElRef: h,
                        colorPicker: a,
                        isTransparent: c,
                        change: function (n) {
                            let i = "#" + n.hex;
                            100 !== n.alphaValue && (i = "#" + n.hex + parseInt(n.alphaValue)),
                            n.hexWithOpacity = i,
                            e.value = i,
                            t("change", n)
                        },
                        mounted: r,
                        onClickButtonRef: function () {
                            o.value = !o.value
                        },
                        closeColorPicker: l
                    }
                }
                (e, t);
                return (n, t) => (U(), T(an, null, [O("div", {
                                class: "flex color-picker flex-row",
                                ref_key: "colorPickerBtnRef",
                                ref: l,
                                onClick: t[0] || (t[0] = (...n) => Q(p) && Q(p)(...n))
                            }, [O("label", Ho, tn(n.label), 1), O("div", {
                                        class: M(["color-picker__node", {
                                                    transparent: Q(h)
                                                }
                                            ])
                                    }, [O("div", {
                                                class: "color-picker__preview",
                                                style: N({
                                                    background: Q(o)
                                                })
                                            }, null, 4)], 2)], 512), j(Q(Cn), {
                                placement: n.placement,
                                width: "auto",
                                trigger: "false",
                                "popper-class": ["p-0", {
                                        "color-picker-popover--behind-header": n.behindHeader
                                    }
                                ],
                                "show-arrow": !1,
                                "virtual-ref": Q(r),
                                visible: Q(w)
                            }, {
                            default:
                                G((() => [j(Qo, {
                                                ref_key: "colorPicker",
                                                ref: s,
                                                color: Q(d),
                                                "disable-alpha": n.disableAlpha,
                                                "disable-history": !0,
                                                "round-history": !0,
                                                "palette-color": Q(a),
                                                "enable-transparent": n.enableTransparent,
                                                onChange: Q(c),
                                                onClose: Q(g)
                                            }, null, 8, ["color", "disable-alpha", "palette-color", "enable-transparent", "onChange", "onClose"])])),
                                _: 1
                            }, 8, ["placement", "popper-class", "virtual-ref", "visible"])], 64))
            }
        }), [["__scopeId", "data-v-5ca71d20"]]);
const Oo = {
    class: "header__color-setting"
};
var jo = mi(S({
            setup(n) {
                const {
                    currentColorPrimary: t,
                    changeColorPrimary: e
                } = ai();
                return (n, i) => (U(), T("div", Oo, [j(Go, {
                                "disable-history": !0,
                                color: Q(t),
                                "disable-alpha": !0,
                                "show-arrow": !1,
                                onChange: i[0] || (i[0] = n => {
                                        return t = n.toHexString(),
                                        void e(t, !0);
                                        var t
                                    })
                            }, null, 8, ["color"])]))
            }
        }), [["__scopeId", "data-v-bcb6f8ea"]]);
const Lo = {
    class: "content__item--image"
}, Po = ["src"], Ko = ["src"], Xo = S({
    props: {
        name: {
            type: String,
        default:
            ""
        },
        tooltip: {
            type: String,
        default:
            ""
        },
        img: {
            type: String,
        default:
            ""
        },
        selected: {
            type: String,
        default:
            ""
        }
    },
    emits: ["change"],
    setup(n, {
        emit: t
    }) {
        const e = n,
        i = it(),
        a = E((() => i.language === e.name));
        return (i, d) => (U(), T("div", {
                class: M(["content__item", {
                            active: Q(a)
                        }
                    ]),
                onClick: d[0] || (d[0] = e => {
                        return i = n.name,
                        void t("change", i);
                        var i
                    })
            }, [O("div", Lo, [j(Q(wn), {
                                content: n.tooltip,
                                placement: "top"
                            }, {
                            default:
                                G((() => [O("img", {
                                                alt: "",
                                                src: Q(Gt)(`images/language/${e.img}`)
                                            }, null, 8, Po)])),
                                _: 1
                            }, 8, ["content"])]), O("img", {
                        alt: "",
                        class: "content__item--check",
                        src: Q(Gt)("images/language/check.png")
                    }, null, 8, Ko)], 2))
    }
});
var Yo = (n => (n.DANGER = "danger", n.WARNING = "warning", n.INFO = "info", n))(Yo || {});
const Wo = {
    class: "confirm-modal__header"
}, zo = {
    key: 0,
    class: "confirm-modal__icon"
}, Jo = {
    class: "confirm-modal__title"
}, Zo = [O("i", {
        class: "fa fa-xmark"
    }, null, -1)], _o = {
    class: "confirm-modal__detail"
}, $o = {
    class: "confirm-modal__button-container"
}, nw = S({
    props: {
        type: {
            type: String,
        default:
            Yo.INFO
        },
        icon: String,
        title: String,
        cancelLabel: {
            type: String,
        default:
            "Quay lại"
        },
        confirmLabel: {
            type: String,
        default:
            "Tôi đồng ý"
        },
        customClass: {
            type: String,
        default:
            ""
        },
        isShow: {
            type: Boolean,
        default:
            !1,
            required: !0
        },
        buttonCancel: {
            type: Boolean,
        default:
            !0
        },
        buttonConfirm: {
            type: Boolean,
        default:
            !0
        },
        buttonClose: {
            type: Boolean,
        default:
            !0
        }
    },
    emits: ["close", "cancel", "confirm"],
    setup(n, {
        emit: t
    }) {
        const e = n, {
            isShow: i
        } = z(e),
        a = () => {
            t("close")
        },
        d = () => {
            t("cancel")
        },
        o = () => {
            t("confirm")
        },
        w = E((() => e.type === Yo.DANGER ? "confirm-modal__button-cancel--danger" : e.type === Yo.WARNING ? "confirm-modal__button-cancel--warning" : e.type === Yo.INFO ? "confirm-modal__button-cancel--info" : "")),
        l = E((() => e.type === Yo.DANGER ? "confirm-modal__button-confirm--danger" : e.type === Yo.WARNING ? "confirm-modal__button-confirm--warning" : e.type === Yo.INFO ? "confirm-modal__button-confirm--info" : ""));
        return (t, e) => (U(), T("div", {
                class: M(["confirm-modal", n.customClass])
            }, [j(Q(K), {
                        modelValue: Q(i),
                        "onUpdate:modelValue": e[0] || (e[0] = n => Mn(i) ? i.value = n : null),
                        width: "33%",
                        "show-close": !1,
                        "before-close": a
                    }, {
                    default:
                        G((() => [O("div", Wo, [n.icon ? (U(), T("div", zo, [O("i", {
                                                            class: M(n.icon)
                                                        }, null, 2)])) : $("", !0), O("div", Jo, tn(n.title), 1), n.buttonClose ? (U(), T("div", {
                                                    key: 1,
                                                    class: "confirm-modal__close-button",
                                                    onClick: a
                                                }, Zo)) : $("", !0)]), O("div", _o, [Qn(t.$slots, "default")]), O("div", $o, [n.buttonCancel ? (U(), T("div", {
                                                    key: 0,
                                                    class: M(["confirm-modal__button-cancel", Q(w)]),
                                                    onClick: d
                                                }, tn(n.cancelLabel), 3)) : $("", !0), n.buttonConfirm ? (U(), T("div", {
                                                    key: 1,
                                                    class: M(["confirm-modal__button-confirm", Q(l)]),
                                                    onClick: o
                                                }, tn(n.confirmLabel), 3)) : $("", !0)])])),
                        _: 3
                    }, 8, ["modelValue"])], 2))
    }
}), tw = O("p", null, " Tất cả dữ liệu bạn nhập vào sẽ bị mất nếu bạn thay đổi ngôn ngữ. Bạn có chắc chắn thay đổi không? ", -1), ew = S({
    props: {
        isShow: {
            type: Boolean,
        default:
            !1
        }
    },
    emits: ["close", "accept"],
    setup(n, {
        emit: t
    }) {
        const e = n,
        i = C(e.isShow),
        a = () => {
            t("close")
        };
        I((() => e), (n => {
                i.value = n.isShow
            }), {
            deep: !0,
            immediate: !0
        });
        const d = () => {
            t("accept")
        };
        return (n, t) => (U(), H(nw, {
                "is-show": i.value,
                onClose: a,
                onCancel: a,
                onConfirm: d,
                type: Q(Yo).DANGER,
                title: "Thay đổi ngôn ngữ CV?",
                icon: "fa-regular fa-triangle-exclamation"
            }, {
            default:
                G((() => [tw])),
                _: 1
            }, 8, ["is-show", "type"]))
    }
}), iw = {
    class: "header__language items-center flex-row align-items-center"
}, aw = O("label", {
    class: "padding-0-8"
}, "Ngôn ngữ CV", -1), dw = {
    class: "header__language--content content"
}, ow = S({
    setup(n) {
        const {
            listLanguage: t,
            handleChangeLanguage: e,
            isShowModalChangeLanguage: i,
            handleAcceptChangeLanguage: a,
            handleCloseChangeLanguage: d
        } = ri();
        return (n, o) => (U(), T(an, null, [O("div", iw, [aw, O("div", dw, [(U(!0), T(an, null, dn(Q(t), (n => (U(), H(Xo, {
                                                            key: n.name,
                                                            name: n.name,
                                                            img: n.img,
                                                            tooltip: n.tooltip,
                                                            onChange: o[0] || (o[0] = n => {
                                                                    e(n)
                                                                })
                                                        }, null, 8, ["name", "img", "tooltip"])))), 128))])]), Q(i) ? (U(), H(nn, {
                            key: 0,
                            to: "#portal-cvo-popup-modal"
                        }, [j(ew, {
                                    isShow: Q(i),
                                    onClose: Q(d),
                                    onAccept: Q(a)
                                }, null, 8, ["isShow", "onClose", "onAccept"])])) : $("", !0)], 64))
    }
}), ww = {
    class: "header__preview-cv"
}, lw = {
    key: 0,
    class: "mr-8 fa-light fa-eye"
}, rw = {
    key: 1,
    class: "mr-8 fa-light fa-spinner-third spinner"
}, sw = O("span", {
    class: "btn-cv__text"
}, "Xem trước", -1), hw = S({
    props: {
        isLoading: {
            type: Boolean,
        default:
            !1
        }
    },
    emits: ["preview-setting-cv"],
    setup(n, {
        emit: t
    }) {
        const e = () => {
            t("preview-setting-cv")
        };
        return (t, i) => (U(), T("div", ww, [O("button", {
                        class: "btn-cv btn-cv--success btn-cv--fix-size is-plain",
                        onClick: e
                    }, [n.isLoading ? (U(), T("i", rw)) : (U(), T("i", lw)), sw])]))
    }
});
var cw = (n => (n.HEADER_ADVANCED = "header__advanced", n.ACTIVE_FOCUS_ELEMENT = "cvb-active-focus", n.ELEMENT_MAIN_ERROR = "element-main--error", n.ELEMENT_MAIN_WARNING = "element-main--warning", n))(cw || {}), pw = (n => (n.parentElement = "#cvo-editor-toolbar", n.GLOBAL_EDIT = ".cvb-global-edit", n))(pw || {});
const gw = {
    key: 0,
    class: "mr-8 fa-solid fa-arrow-down-to-line"
}, Aw = {
    key: 1,
    class: "mr-8 fa-light fa-spinner-third spinner"
}, uw = O("span", {
    class: "btn-cv__text"
}, "Lưu và tải xuống", -1), mw = S({
    props: {
        getIsLoading: {
            type: Boolean,
        default:
            !1
        },
        isDisable: {
            type: Boolean,
        default:
            !1
        }
    },
    emits: ["save"],
    setup(n, {
        emit: t
    }) {
        const e = n, {
            isDisable: i
        } = z(e),
        a = () => {
            (null == i ? void 0 : i.value) || t("save")
        };
        return (t, e) => (U(), T("div", null, [O("button", {
                        class: "ml-20 mr-20 btn-cv btn-cv--success btn-cv--fix-size is-plain",
                        onClick: a
                    }, [n.getIsLoading ? (U(), T("i", Aw)) : (U(), T("i", gw)), uw])]))
    }
}), bw = {
    class: "save-cv"
}, vw = {
    key: 0,
    class: "save-cv__icon fa-solid fa-floppy-disk mr-8"
}, fw = {
    key: 1,
    class: "mr-8 fa-light fa-spinner-third spinner"
}, xw = O("span", {
    class: "btn-cv__text"
}, "Lưu lại", -1), yw = S({
    props: {
        getIsLoading: {
            type: Boolean,
        default:
            !1
        },
        isDisable: {
            type: Boolean,
        default:
            !1
        }
    },
    emits: ["save"],
    setup(n, {
        emit: t
    }) {
        const e = n, {
            isDisable: i
        } = z(e),
        a = () => {
            (null == i ? void 0 : i.value) || t("save")
        };
        return (t, e) => (U(), T("div", bw, [O("button", {
                        class: "save-cv save-cv__btn btn-cv btn-cv--success btn-cv--fix-size",
                        onClick: a
                    }, [n.getIsLoading ? (U(), T("i", fw)) : (U(), T("i", vw)), xw])]))
    }
});
const kw = O("div", {
    class: "modal-save-cv-success__content content"
}, [O("div", {
            class: "content__icon icon"
        }, [O("div", {
                    class: "icon__block"
                }, [O("i", {
                            class: "fa-solid fa-check"
                        })])]), O("p", {
            class: "content__title"
        }, "Lưu và tải xuống CV thành công"), O("p", {
            class: "content__desc"
        }, " CV của bạn đã được lưu và tải xuống. Giờ đây bạn có thể sử dụng CV này để ứng tuyển các công việc phù hợp hoặc chia sẻ CV của bạn với các nhà tuyển dụng! ")], -1), Ew = {
    class: "dialog-footer"
}, Bw = [O("span", {
        class: "btn-cv__text"
    }, "Đóng lại", -1)], Cw = ["href"], Sw = [O("span", {
        class: "btn-cv__text"
    }, "Xem CV", -1)], Iw = S({
        props: {
            isShow: {
                type: Boolean,
            default:
                !1
            },
            dataCvSaveSuccess: {
                type: Object,
            default:
                null
            }
        },
        emits: ["close", "accept"],
        setup(n, {
            emit: t
        }) {
            const e = n,
            i = C(e.isShow),
            a = () => {
                t("close")
            };
            return I((() => e), (n => {
                    i.value = n.isShow
                }), {
                deep: !0
            }),
            (t, e) => (U(), T("div", null, [j(Q(K), {
                            modelValue: i.value,
                            "onUpdate:modelValue": e[0] || (e[0] = n => i.value = n),
                            width: "30%",
                            title: "",
                            "show-close": !1,
                            center: "",
                            "custom-class": "modal-save-cv-success"
                        }, {
                            footer: G((() => [O("span", Ew, [O("button", {
                                                    class: "btn-cv btn-cv--disable",
                                                    onClick: a
                                                }, Bw), O("a", {
                                                    href: n.dataCvSaveSuccess.origin_url,
                                                    class: "btn-cv btn-cv--success",
                                                    target: "_blank"
                                                }, Sw, 8, Cw)])])),
                        default:
                            G((() => [kw])),
                            _: 1
                        }, 8, ["modelValue"])]))
        }
    });
const Vw = O("div", {
    class: "modal-update-name-cv__title"
}, [O("div", {
            class: "modal-update-name-cv__icon"
        }, [O("i", {
                    class: "fa-solid fa-lightbulb"
                })]), W(" Việc đặt tên cho CV sẽ khiến việc quản lý CV trở nên dễ dàng hơn. ")], -1), Dw = S({
        props: {
            isShow: {
                type: Boolean,
            default:
                !1
            },
            isDisable: {
                type: Boolean,
            default:
                !1
            }
        },
        emits: ["close", "accept"],
        setup(n, {
            emit: t
        }) {
            const e = n,
            i = it(),
            a = C(),
            d = C(),
            o = C(e.isShow), {
                isDisable: w
            } = z(e);
            D((() => {
                    ln((() => {
                            l()
                        }))
                }));
            const l = () => {
                d.value.querySelector("input[name='input']").focus()
            },
            r = () => {
                p.value = "",
                t("close")
            },
            s = () => "" == h() ? (bn({
                    message: "Tên CV không được để trống",
                    type: "error"
                }), l(), !0) : h().length > 50 ? (bn({
                    message: "Tên CV không được dài quá 50 ký tự!",
                    type: "error"
                }), l(), !0) : (c(i.cvData, "global.cv_title", h()), void((null == w ? void 0 : w.value) || t("accept"))),
            h = () => p.value.trim();
            I((() => e), (n => {
                    o.value = n.isShow,
                    a.value = !0
                }), {
                deep: !0
            });
            const p = C("");
            return (n, t) => (U(), T("div", {
                    ref_key: "modalUpdateNameCv",
                    ref: d
                }, [j(Q(K), {
                            modelValue: o.value,
                            "onUpdate:modelValue": t[1] || (t[1] = n => o.value = n),
                            width: "30%",
                            title: "Đặt tên cho CV của bạn",
                            "custom-class": "modal-update-name-cv",
                            "before-close": r
                        }, {
                            footer: G((() => [O("button", {
                                            class: "btn-cv btn-cv--disable",
                                            onClick: r
                                        }, " Quay lại"), O("button", {
                                            class: "btn-cv btn-cv--success",
                                            onClick: s
                                        }, "Tiếp tục")])),
                        default:
                            G((() => [Vw, j(Q(fn), {
                                            class: "modal-update-name-cv__input",
                                            modelValue: p.value,
                                            "onUpdate:modelValue": t[0] || (t[0] = n => p.value = n),
                                            placeholder: "Tên CV (Ví dụ: CV Marketing, CV Lập trình, CV ứng tuyển công ty...)",
                                            name: "input"
                                        }, null, 8, ["modelValue"])])),
                            _: 1
                        }, 8, ["modelValue"])], 512))
        }
    }), Rw = W(" Các trường thông tin: "), qw = W(" có nội dung còn để trống. Bạn nhớ hoàn thiện đầy đủ trước khi ứng tuyển nhé. "), Uw = S({
        props: {
            isShow: {
                type: Boolean,
            default:
                !1
            }
        },
        emits: ["close", "accept"],
        setup(n, {
            emit: t
        }) {
            const e = n,
            i = C(!0),
            a = it(),
            d = E((() => {
                        const n = a.validateWarnings;
                        let t = "";
                        const e = {};
                        for (const i in n) {
                            const a = n[i].block;
                            e[a] || (e[a] = n[i].error, t += `${t ? ", " : ""}${a}`)
                        }
                        return t
                    })),
            o = () => {
                t("close")
            };
            I((() => e), (n => {
                    i.value = n.isShow
                }), {
                deep: !0,
                immediate: !0
            });
            const w = () => {
                t("accept")
            };
            return (n, t) => (U(), H(nw, {
                    "is-show": i.value,
                    icon: "",
                    onClose: o,
                    onCancel: o,
                    onConfirm: w,
                    type: Q(Yo).WARNING,
                    title: "Lưu ý",
                    "confirm-label": "Lưu CV, tôi sẽ hoàn thiện sau",
                    "cancel-label": "Hoàn thiện tiếp"
                }, {
                default:
                    G((() => [O("p", null, [Rw, O("strong", null, tn(Q(d)), 1), qw])])),
                    _: 1
                }, 8, ["is-show", "type"]))
        }
    }), Tw = S({
        setup(n) {
            const {
                getIsSaveSuccess: t,
                getIsUpdateNameCv: e,
                getDataCvSaveSuccess: i,
                getIsLoading: a,
                handleCloseSaveCvSuccess: d,
                handleCloseUpdateNameCv: o,
                handleSaveCV: w,
                handleUpdateNameCvSuccess: l,
                handleSaveAndDownload: r,
                getIsLoadingSaveAndDownLoad: s,
                getIsDisable: h,
                isShowWarningMissingData: c,
                handleCloseModalWarningMissingData: p,
                handleSaveCVIgnoreWarning: g
            } = xd(),
            A = new _(window.navigator.userAgent).mobile();
            return (n, u) => (U(), T(an, null, [Q(A) ? $("", !0) : (U(), H(mw, {
                                key: 0,
                                getIsLoading: Q(s),
                                isDisable: Q(h),
                                onSave: u[0] || (u[0] = n => Q(r)())
                            }, null, 8, ["getIsLoading", "isDisable"])), j(yw, {
                            isDisable: Q(h),
                            getIsLoading: Q(a),
                            onSave: u[1] || (u[1] = n => Q(w)())
                        }, null, 8, ["isDisable", "getIsLoading"]), Q(t) ? (U(), H(Iw, {
                                key: 1,
                                dataCvSaveSuccess: Q(i),
                                isShow: Q(t),
                                onClose: Q(d)
                            }, null, 8, ["dataCvSaveSuccess", "isShow", "onClose"])) : $("", !0), Q(e) ? (U(), H(Dw, {
                                key: 2,
                                isShow: Q(e),
                                isDisable: Q(h),
                                onClose: Q(o),
                                onAccept: Q(l)
                            }, null, 8, ["isShow", "isDisable", "onClose", "onAccept"])) : $("", !0), j(Uw, {
                            "is-show": Q(c),
                            onClose: Q(p),
                            onAccept: Q(g)
                        }, null, 8, ["is-show", "onClose", "onAccept"])], 64))
        }
    });
const Nw = {
    class: "header__container"
}, Mw = {
    class: "flex"
}, Qw = [O("i", {
        class: "fa-solid fa-pen"
    }, null, -1)], Fw = {
    class: "header__tool"
}, Hw = {
    id: "header_advanced",
    class: "header__advanced"
}, Gw = {
    class: "d-flex justify-content-center align-items-center cvb-global-edit"
}, Ow = {
    key: 0,
    id: "blockLanguage",
    class: "border-r d-inline-block"
}, jw = {
    class: "mr-20"
}, Lw = {
    id: "blockEditToolbar"
}, Pw = {
    class: "border-r d-inline-block"
}, Kw = {
    class: "ml-5 mr-5 flex-row align-items-center"
}, Xw = {
    class: "border-r d-inline-block"
}, Yw = {
    class: "ml-5 mr-5 flex-row align-items-center"
}, Ww = {
    class: "border-r d-inline-block"
}, zw = {
    class: "ml-5 mr-5 header__line-height-setting flex-row align-items-center"
}, Jw = {
    id: "blockBackground",
    class: "border-r"
}, Zw = {
    class: "d-inline-block"
}, _w = {
    class: "ml-5 mr-5 header__background-setting flex-row align-items-center"
}, $w = {
    class: "undo-redo-wrapper ml-15 flex border-r"
}, nl = [O("i", {
        class: "fa-solid fa fa-undo",
        "aria-hidden": "true"
    }, null, -1)], tl = [O("i", {
        class: "fa-solid fa fa-redo",
        "aria-hidden": "true"
    }, null, -1)], el = {
    class: "d-inline-block"
}, il = [O("i", {
        class: "fa fa-table-layout"
    }, null, -1), O("span", null, " Tuỳ chỉnh bố cục ", -1)], al = O("div", {
        id: "cvo-editor-toolbar"
    }, null, -1), dl = S({
        setup(n) {
            const t = !!new _(window.navigator.userAgent).mobile(),
            e = hn((() => Pn((() => import("./ModalCustomLayout.149580.js")), ["assets/ModalCustomLayout.149580.js", "assets/ModalCustomLayout.149580.css", "assets/debounce.149580.js", "assets/vendor.149580.js", "assets/usePopper.149580.js"]))),
            i = it(),
            a = C(!1),
            d = C(!1),
            o = C(""),
            w = C(""),
            l = C(!1),
            r = C(!1), {
                enablePreview: s
            } = ni(), {
                activeRedo: h,
                activeUndo: p,
                handleUndo: g,
                handleRedo: A
            } = ei(),
            u = C(),
            m = C(""),
            b = C(!1),
            v = async() => {
                g()
            },
            f = async() => {
                A()
            },
            x = -1 != navigator.userAgent.indexOf("Mac OS X") ? "Command + Z" : "Ctrl + Z",
            y = -1 != navigator.userAgent.indexOf("Mac OS X") ? "Command + Shift + Z" : "Ctrl + Shift + Z",
            k = (n, t) => {
                var e;
                m.value = t,
                u.value = null == (e = null == n ? void 0 : n.target) ? void 0 : e.closest(".button")
            },
            E = async() => {
                s(),
                a.value = !0,
                d.value = !0,
                i.setPathEdit("")
            },
            B = n => {
                a.value = n
            },
            S = n => {
                d.value = n
            };
            I((() => i.cvData.global), (() => {
                    (() => {
                        var n;
                        const t = null != (n = i.getCvTitle) ? n : "Tên CV của bạn";
                        o.value = t,
                        i.setCvTitle(t)
                    })()
                }), {
                deep: !0,
                immediate: !0
            });
            const V = function () {
                l.value = !1;
                const n = Q(o);
                c(i.cvData, "global.cv_title", n.trim())
            },
            D = () => {
                0 == document.querySelector(pw.parentElement).clientHeight && i.setPathEdit("")
            },
            q = () => {
                t ? r.value = !0 : w.value.focus()
            },
            N = () => {
                t && (r.value = !0)
            },
            F = n => {
                o.value = n,
                i.setCvTitle(n)
            },
            L = n => {
                r.value = n
            },
            P = n => {
                b.value = n
            };
            return (n, s) => (U(), T(an, null, [O("div", {
                            class: "header",
                            onClick: D
                        }, [j(Q(Gn), null, {
                                default:
                                    G((() => [j(Q(Fn), {
                                                    span: 24
                                                }, {
                                                default:
                                                    G((() => [j(Q(Hn), {
                                                                    style: {
                                                                        padding: "0"
                                                                    }
                                                                }, {
                                                                default:
                                                                    G((() => [O("div", Nw, [O("div", Mw, [O("div", {
                                                                                                    class: M(["header__title", {
                                                                                                                "outline-error": l.value
                                                                                                            }
                                                                                                        ])
                                                                                                }, [R(O("input", {
                                                                                                                type: "text",
                                                                                                                "onUpdate:modelValue": s[0] || (s[0] = n => o.value = n),
                                                                                                                onInput: V,
                                                                                                                class: "header__input",
                                                                                                                ref_key: "cvTitleRef",
                                                                                                                ref: w,
                                                                                                                placeholder: "CV chưa đặt tên",
                                                                                                                readonly: t,
                                                                                                                onClick: N
                                                                                                            }, null, 544), [[xn, o.value]]), t ? (U(), T("div", {
                                                                                                                key: 0,
                                                                                                                class: "header__edit",
                                                                                                                onClick: s[1] || (s[1] = n => q())
                                                                                                            }, Qw)) : $("", !0)], 2), O("div", Fw, [j(hw, {
                                                                                                            onPreviewSettingCv: E,
                                                                                                            "is-loading": d.value
                                                                                                        }, null, 8, ["is-loading"]), j(Tw)])])]), O("div", Hw, [O("div", Gw, ["create-cv" === Q(i).builderWidget.route ? (U(), T("div", Ow, [O("div", jw, [j(ow)])])) : $("", !0), O("div", Lw, [O("div", Pw, [O("div", Kw, [j(Qd)])]), O("div", Xw, [O("div", Yw, [j(jo)])]), O("div", Ww, [O("div", zw, [j(zd)])])]), O("div", Jw, [O("div", Zw, [O("div", _w, [j(Kd)])])]), O("div", $w, [O("div", {
                                                                                                            class: M(["button mr-5", {
                                                                                                                        "button--disable": !Q(p)
                                                                                                                    }
                                                                                                                ]),
                                                                                                            onClick: v,
                                                                                                            onMouseover: s[2] || (s[2] = n => k(n, Q(x)))
                                                                                                        }, nl, 34), O("div", {
                                                                                                            class: M(["button mr-5", {
                                                                                                                        "button--disable": !Q(h)
                                                                                                                    }
                                                                                                                ]),
                                                                                                            onClick: f,
                                                                                                            onMouseover: s[3] || (s[3] = n => k(n, Q(y)))
                                                                                                        }, tl, 34)]), O("div", el, [O("div", {
                                                                                                            class: "mr-15 header__layout-setting ml-15",
                                                                                                            onClick: s[4] || (s[4] = n => {
                                                                                                                    return t = !0,
                                                                                                                    void(b.value = t);
                                                                                                                    var t
                                                                                                                })
                                                                                                        }, il)])]), al])])),
                                                                    _: 1
                                                                })])),
                                                    _: 1
                                                })])),
                                    _: 1
                                })]), j(Bd, {
                            onSetIsShowPreview: B,
                            "is-show-preview": a.value,
                            onSetIsLoading: S
                        }, null, 8, ["is-show-preview"]), j(Sd, {
                            "cv-title": o.value,
                            "is-show": r.value,
                            onClose: L,
                            onChangeTitle: F
                        }, null, 8, ["cv-title", "is-show"]), t ? $("", !0) : (U(), H(Nd, {
                                key: 0
                            })), j($i, {
                            "trigger-ref": u.value,
                            "tooltip-content": m.value
                        }, null, 8, ["trigger-ref", "tooltip-content"]), b.value ? (U(), H(Q(e), {
                                key: 1,
                                "is-show-setting-layout": b.value,
                                onSetIsLoading: S,
                                onClose: P
                            }, null, 8, ["is-show-setting-layout"])) : $("", !0)], 64))
        }
    });
const ol = O("p", {
    class: "feedback-dialog__title"
}, " Góp ý về công cụ tạo CV mới của TopCV ", -1), wl = O("p", {
    class: "feedback-dialog__description"
}, " Team Sản phẩm TopCV cảm ơn bạn đã trải nghiệm công cụ tạo CV mới của TopCV.vn. Chúng mình rất mong nhận được những góp ý và phản hồi của bạn để tiếp tục tối ưu sản phẩm và mang lại cho bạn những trải nghiệm ngày một tốt hơn nữa. ", -1), ll = [O("i", {
        class: "fa fa-xmark"
    }, null, -1)], rl = {
    class: "progress-step"
}, sl = {
    key: 0
}, hl = [O("i", {
        class: "fa-solid fa-circle-check"
    }, null, -1)], cl = {
    key: 1
}, pl = [O("i", {
        class: "fa-solid fa-circle"
    }, null, -1)], gl = O("div", {
        class: "line"
    }, null, -1), Al = {
    key: 2
}, ul = [O("i", {
        class: "fa-solid fa-circle-check"
    }, null, -1)], ml = {
    key: 3
}, bl = [O("i", {
        class: "fa-solid fa-circle"
    }, null, -1)], vl = O("div", {
        class: "line"
    }, null, -1), fl = {
    key: 4
}, xl = [O("i", {
        class: "fa-solid fa-circle-check"
    }, null, -1)], yl = {
    key: 5
}, kl = [O("i", {
        class: "fa-solid fa-circle"
    }, null, -1)], El = {
    key: 0,
    class: "wrap-question"
}, Bl = {
    class: "question-text"
}, Cl = {
    class: "answer d-flex"
}, Sl = ["onClick"], Il = ["src"], Vl = {
    key: 1,
    class: "wrap-question"
}, Dl = {
    class: "question-text"
}, Rl = {
    class: "answer d-flex"
}, ql = ["onClick"], Ul = ["src"], Tl = {
    key: 2,
    class: "wrap-question"
}, Nl = {
    class: "question-text"
}, Ml = {
    class: "answer__input"
}, Ql = ["onChange"], Fl = {
    class: "dialog-footer"
}, Hl = S({
    props: {
        dialogFeedbackVisible: {
            type: Boolean,
        default:
            !1
        },
        stepFeedbackCurrent: {
            type: Number,
        default:
            1
        }
    },
    emits: ["close", "success"],
    setup(n, {
        emit: t
    }) {
        const e = n,
        i = C(!0),
        a = C(),
        d = C(1),
        o = C(!1),
        w = [{
                id: 1,
                answerText: "Rất tệ",
                image: Gt("images/feedback/very-sad.png"),
                class: "very-sad"
            }, {
                id: 2,
                answerText: "Tệ",
                image: Gt("images/feedback/sad.png"),
                class: "sad"
            }, {
                id: 3,
                answerText: "Tạm ổn",
                image: Gt("images/feedback/fine.png"),
                class: "fine"
            }, {
                id: 4,
                answerText: "Tốt",
                image: Gt("images/feedback/happiness.png"),
                class: "happiness"
            }, {
                id: 5,
                answerText: "Tuyệt zờii",
                image: Gt("images/feedback/smile.png"),
                class: "smile"
            }
        ],
        l = [{
                id: 1,
                questionText: "Đánh giá mức độ hài lòng của bạn khi sử dụng công cụ tạo CV mới của TopCV?"
            }, {
                id: 2,
                questionText: "Đánh giá mức độ hài lòng của bạn với tính năng thay đổi mẫu CV?"
            }, {
                id: 3,
                questionText: "Đánh giá mức độ thuận tiện khi bạn thực hiện chỉnh sửa và định dạng text, ảnh và icon trong CV?"
            }
        ],
        r = [{
                id: 4,
                questionText: "Đánh giá mức độ thuận tiện khi bạn thêm mới, di chuyển vị trí và cấu hình cho từng Mục nội dung (vd: Học vấn, Kinh nghiệm, Kỹ năng,....) và từng mục con trong các mục này?"
            }, {
                id: 5,
                questionText: "Đánh giá mức độ thuận tiện khi bạn thêm mới, di chuyển, thay đổi bố cục của các hàng và cấu hình cho từng cột trong hàng?"
            }
        ],
        s = [{
                id: 6,
                questionText: "Bạn có thể đề xuất thêm một số thay đổi cần thiết cho công cụ tạo CV mới của TopCV?"
            }, {
                id: 7,
                questionText: "Bạn thấy hài lòng nhất về điều gì khi sử dụng công cụ tạo CV mới của TopCV?"
            }
        ],
        h = C({}),
        p = C({
            1: 0,
            2: 0,
            3: 0,
            4: 0,
            5: 0
        });
        I((() => e), (n => {
                o.value = n.dialogFeedbackVisible,
                d.value = n.stepFeedbackCurrent
            }), {
            immediate: !0,
            deep: !0
        }),
        I((() => d.value), (() => {
                3 === d.value && (i.value = !1)
            }), {
            immediate: !0
        });
        const g = (n, t, e, i) => {
            p.value[e] = i,
            c(h.value, `${e}`, i),
            A()
        },
        A = () => {
            1 === d.value ? i.value = Object.keys(h.value).length !== l.length : 2 === d.value ? i.value = Object.keys(h.value).length !== r.length : i.value = !1
        },
        u = () => {
            var n;
            i.value || (n = (() => {
                    const n = {
                        step: d.value
                    };
                    return c(n, "data", f(h.value)),
                    n
                })(), Wt.post("v2/create-feedback-cv-builder", {
                    data: n
                }), h.value = {}, i.value = !0, 3 === d.value ? (d.value = 1, t("success", d.value)) : d.value++)
        },
        m = () => {
            t("close", d.value)
        };
        return (n, t) => (U(), T("div", null, [O("div", {
                        class: "feedback-dialog",
                        ref_key: "feedbackDialog",
                        ref: a
                    }, [j(Q(K), {
                                modelValue: o.value,
                                "onUpdate:modelValue": t[0] || (t[0] = n => o.value = n),
                                "close-on-click-modal": !1,
                                "show-close": !1,
                                onClose: m,
                                class: ""
                            }, {
                                footer: G((() => [O("span", Fl, [O("button", {
                                                        class: "btn btn-close",
                                                        onClick: m
                                                    }, "Đóng"), O("button", {
                                                        class: M(["btn btn-submit", {
                                                                    disable: i.value
                                                                }
                                                            ]),
                                                        onClick: u
                                                    }, tn(3 === d.value ? "Hoàn thành" : "Tiếp tục"), 3)])])),
                            default:
                                G((() => [O("div", {
                                                class: "feedback-dialog__header"
                                            }, [ol, wl, O("div", {
                                                        class: "feedback-dialog__close-button",
                                                        onClick: m
                                                    }, ll)]), O("div", rl, [d.value >= 1 ? (U(), T("p", sl, hl)) : (U(), T("p", cl, pl)), gl, d.value >= 2 ? (U(), T("p", Al, ul)) : (U(), T("p", ml, bl)), vl, d.value >= 3 ? (U(), T("p", fl, xl)) : (U(), T("p", yl, kl))]), 1 === d.value ? (U(), T("div", El, [(U(), T(an, null, dn(l, ((n, t) => O("div", {
                                                                            key: t,
                                                                            class: "question__item"
                                                                        }, [O("p", Bl, tn(n.questionText), 1), O("div", Cl, [(U(), T(an, null, dn(w, ((t, e) => O("div", {
                                                                                                            key: e,
                                                                                                            class: M(["answer-item", [t.class, {
                                                                                                                            active: Q(p)[n.id] === t.id
                                                                                                                        }
                                                                                                                    ]]),
                                                                                                            onClick: e => g(n.questionText, t.answerText, n.id, t.id)
                                                                                                        }, [O("img", {
                                                                                                                    src: t.image,
                                                                                                                    alt: ""
                                                                                                                }, null, 8, Il), O("p", null, tn(t.answerText), 1)], 10, Sl))), 64))])]))), 64))])) : $("", !0), 2 === d.value ? (U(), T("div", Vl, [(U(), T(an, null, dn(r, ((n, t) => O("div", {
                                                                            key: t,
                                                                            class: "question__item"
                                                                        }, [O("p", Dl, tn(n.questionText), 1), O("div", Rl, [(U(), T(an, null, dn(w, ((t, e) => O("div", {
                                                                                                            key: e,
                                                                                                            class: M(["answer-item", [t.class, {
                                                                                                                            active: Q(p)[n.id] === t.id
                                                                                                                        }
                                                                                                                    ]]),
                                                                                                            onClick: e => g(n.questionText, t.answerText, n.id, t.id)
                                                                                                        }, [O("img", {
                                                                                                                    src: t.image,
                                                                                                                    alt: ""
                                                                                                                }, null, 8, Ul), O("p", null, tn(t.answerText), 1)], 10, ql))), 64))])]))), 64))])) : $("", !0), 3 === d.value ? (U(), T("div", Tl, [(U(), T(an, null, dn(s, ((n, t) => O("div", {
                                                                            key: t,
                                                                            class: "question__item"
                                                                        }, [O("p", Nl, tn(n.questionText), 1), O("div", Ml, [O("textarea", {
                                                                                            name: "",
                                                                                            id: "",
                                                                                            cols: "30",
                                                                                            rows: "10",
                                                                                            placeholder: "Nhập câu trả lời của bạn",
                                                                                            onChange: t => ((n, t) => {
                                                                                                h.value[n] = t
                                                                                            })(n.id, t.target.value)
                                                                                        }, null, 40, Ql)])]))), 64))])) : $("", !0)])),
                                _: 1
                            }, 8, ["modelValue"])], 512)]))
    }
});
const Gl = {
    class: "success-feedback-dialog",
    ref: "successFeedbackDialog"
}, Ol = ["src"], jl = O("p", {
    class: "title"
}, " Team sản phẩm TopCV xin cảm ơn chia sẻ của bạn. Chúc bạn một ngày tốt lành! ", -1), Ll = S({
    props: {
        dialogSuccessFeedbackVisible: {
            type: Boolean,
        default:
            !1
        }
    },
    emits: ["close"],
    setup(n, {
        emit: t
    }) {
        const e = n,
        i = C(!1);
        I((() => e), (n => {
                i.value = n.dialogSuccessFeedbackVisible
            }), {
            immediate: !0,
            deep: !0
        }),
        D((async() => {}));
        const a = () => {
            t("close")
        };
        return (n, t) => (U(), T("div", null, [O("div", Gl, [j(Q(K), {
                                modelValue: i.value,
                                "onUpdate:modelValue": t[0] || (t[0] = n => i.value = n),
                                "show-close": !1,
                                onClose: a,
                                class: ""
                            }, {
                                footer: G((() => [])),
                            default:
                                G((() => [O("img", {
                                                src: Q(Gt)("images/feedback/feedback-success.png"),
                                                alt: ""
                                            }, null, 8, Ol), jl, O("span", {
                                                class: "dialog-footer"
                                            }, [O("button", {
                                                        class: "btn btn-close",
                                                        onClick: a
                                                    }, "Đóng")])])),
                                _: 1
                            }, 8, ["modelValue"])], 512)]))
    }
});
const Pl = ["src"], Kl = O("span", {
    class: "text"
}, "Góp ý về sản phẩm", -1), Xl = S({
    emits: ["doneFeedback"],
    setup(n, {
        emit: t
    }) {
        const e = C(1),
        i = C(!1),
        a = C(!1),
        d = () => {
            i.value = !0
        },
        o = n => {
            a.value = !0,
            i.value = !1,
            e.value = n,
            t("doneFeedback")
        };
        D((async() => {
                const n = await Wt.get("v2/step-feedback-cv-builder");
                3 === n.data.step ? e.value = 1 : e.value = n.data.step + 1
            }));
        const w = n => {
            i.value = !1,
            e.value = n
        };
        return (n, t) => (U(), T(an, null, [O("a", {
                        class: "footer_feedback",
                        href: "javascript:void(0)",
                        onClick: d
                    }, [O("img", {
                                class: "selection__column--image",
                                src: Q(Gt)("images/feedback.png"),
                                alt: ""
                            }, null, 8, Pl), Kl]), (U(), H(nn, {
                            to: "body"
                        }, [i.value ? (U(), H(Hl, {
                                        key: 0,
                                        dialogFeedbackVisible: i.value,
                                        stepFeedbackCurrent: e.value,
                                        onClose: w,
                                        onSuccess: o
                                    }, null, 8, ["dialogFeedbackVisible", "stepFeedbackCurrent"])) : $("", !0), a.value ? (U(), H(Ll, {
                                        key: 1,
                                        dialogSuccessFeedbackVisible: a.value,
                                        onClose: t[0] || (t[0] = n => a.value = !1)
                                    }, null, 8, ["dialogSuccessFeedbackVisible"])) : $("", !0)]))], 64))
    }
});
const Yl = ["id"], Wl = ["src"], zl = {
    key: 0,
    class: "caption"
}, Jl = {
    key: 1,
    class: "label-hot"
}, Zl = [(n => (X("data-v-077f1d26"), n = n(), Y(), n))((() => O("p", null, "Hot", -1)))];
var _l = mi(S({
            props: {
                activeIcon: {
                    type: String,
                default:
                    ""
                },
                icon: {
                    type: String,
                default:
                    ""
                },
                text: {
                    type: String,
                default:
                    ""
                },
                id: {
                    type: String,
                default:
                    ""
                },
                active: {
                    type: Boolean,
                default:
                    !1
                },
                labelHot: {
                    type: Boolean,
                default:
                    !1
                }
            },
            setup(n) {
                const t = n,
                e = C(t.icon);
                I((() => t.activeIcon), (() => {
                        t.activeIcon === t.icon ? e.value = `${t.icon}-active` : e.value = `${t.icon}`
                    }), {
                    immediate: !0
                });
                const i = () => {
                    e.value = `${t.icon}-active`
                },
                a = () => {
                    t.activeIcon !== t.icon && (e.value = `${t.icon}`)
                };
                return (t, d) => (U(), T("div", {
                        id: n.id,
                        class: M(n.active ? "active" : "icon__item"),
                        onMouseover: i,
                        onMouseout: a
                    }, [O("span", null, [O("img", {
                                        src: Q(Gt)(`images/tab-navigation/${e.value}.svg`),
                                        alt: ""
                                    }, null, 8, Wl)]), n.text ? (U(), T("p", zl, tn(n.text), 1)) : $("", !0), n.labelHot ? (U(), T("div", Jl, Zl)) : $("", !0)], 42, Yl))
            }
        }), [["__scopeId", "data-v-077f1d26"]]);
const $l = {
    component: "LayoutRender",
    block: "section",
    flex: "grid",
    styles: {
        gap: "0px"
    },
    classes: [],
    children: [{
            block: "column",
            component: "LayoutRender",
            classes: [],
            flex: "column",
            styles: {},
            children: []
        }
    ]
}, nr = {
    block: "column",
    component: "LayoutRender",
    classes: [],
    flex: "column",
    styles: {},
    children: []
};
var tr = (n => (n.TAB_CHANGE_TEMPLATE = "change-template", n.TAB_SUGGEST_WRITE_CV = "suggest-write-cv", n.TAB_ADD_LAYOUT = "add-layout", n.TAB_ADD_ELEMENT = "add-element", n.TAB_SETTING_CV = "setting-cv", n.TAB_ADD_BLOCK = "add-block", n.TAB_CHANGE_DATA_SAMPLE = "change-data-template", n.TAB_SUGGEST_JOB = "suggest-job", n))(tr || {});
const er = new _(window.navigator.userAgent);
function ir() {
    const n = it();
    return {
        handleAddSection: () => {
            var t,
            e;
            const i = f($l);
            ne(i),
            n.setBuilderDataWithKey({
                value: i,
                path: null != (e = null == (t = n.builderData) ? void 0 : t.length) ? e : 0
            })
        },
        handleAddLayout: () => {
            n.setPathEdit(""),
            n.setCurrentActiveTab(tr.TAB_ADD_LAYOUT)
        },
        handleAddBlock: () => {
            n.setPathEdit(""),
            n.setCurrentActiveTab(tr.TAB_ADD_BLOCK)
        },
        handleAddElement: () => {
            n.setPathEdit(""),
            n.setCurrentActiveTab(tr.TAB_ADD_ELEMENT)
        },
        handleSettingCv: () => {
            n.setPathEdit(""),
            n.setCurrentActiveTab(tr.TAB_SETTING_CV)
        },
        handleChangeTemplate: () => {
            n.setPathEdit(""),
            n.setCurrentActiveTab(tr.TAB_CHANGE_TEMPLATE)
        },
        handleSuggestWriteCv: () => {
            n.setCurrentActiveTab(tr.TAB_SUGGEST_WRITE_CV)
        },
        handleChangeDataSample: () => {
            n.setPathEdit(""),
            n.setCurrentActiveTab(tr.TAB_CHANGE_DATA_SAMPLE)
        },
        handleHiddenAllAction: () => {
            er.mobile() && n.setCurrentActiveTab("")
        },
        handleSuggestJob: () => {
            n.setPathEdit(""),
            n.setCurrentActiveTab(tr.TAB_SUGGEST_JOB),
            ya(xa.CLICK_MENU_SUGGEST_JOB)
        }
    }
}
var ar = (n => (n.SUGGEST_WRITE_CV = "suggest-write-cv", n.SUGGEST_USE = "suggest-use", n.KEY_SHOW_BOX_SUGGEST_JOB = "show_box_suggest_job", n))(ar || {});
const dr = h({
    id: "menu-support",
    state: () => ({
        isShowModal: !0
    }),
    getters: {
        getIsShowModal: n => n.isShowModal
    },
    actions: {
        setIsShowModal(n) {
            this.isShowModal = n
        }
    }
});
const or = {
    class: "ml-20 tab-navigation"
}, wr = {
    class: "tab-navigation__container"
}, lr = {
    class: "tab-navigation__tool"
}, rr = {
    key: 0,
    class: "tab-navigation__action"
};
var sr = mi(S({
            setup(n) {
                const t = dr(), {
                    TAB_CHANGE_TEMPLATE: e,
                    TAB_ADD_BLOCK: i,
                    TAB_SUGGEST_WRITE_CV: a,
                    TAB_CHANGE_DATA_SAMPLE: d,
                    TAB_SUGGEST_JOB: o
                } = tr,
                w = new _(window.navigator.userAgent),
                l = hn((() => Pn((() => import("./ChangeTemplate.149580.js")), ["assets/ChangeTemplate.149580.js", "assets/ChangeTemplate.149580.css", "assets/vendor.149580.js", "assets/HeaderSupportMenu.149580.js", "assets/mapTypeBlockToText.149580.js"]))),
                r = hn((() => Pn((() => import("./AddBlock.149580.js")), ["assets/AddBlock.149580.js", "assets/AddBlock.149580.css", "assets/HeaderSupportMenu.149580.js", "assets/vendor.149580.js", "assets/useCategoryList.149580.js"]))),
                s = hn((() => Pn((() => import("./ChangeDataSample.149580.js")), ["assets/ChangeDataSample.149580.js", "assets/ChangeDataSample.149580.css", "assets/HeaderSupportMenu.149580.js", "assets/vendor.149580.js"]))),
                h = {
                    [e]: l,
                    [i]: r,
                    [a]: hn((() => Pn((() => import("./SuggestWriteCv.149580.js")), ["assets/SuggestWriteCv.149580.js", "assets/SuggestWriteCv.149580.css", "assets/vendor.149580.js", "assets/HeaderSupportMenu.149580.js"]))),
                    [d]: s,
                    [o]: hn((() => Pn((() => import("./SuggestJob.149580.js")), ["assets/SuggestJob.149580.js", "assets/SuggestJob.149580.css", "assets/HeaderSupportMenu.149580.js", "assets/vendor.149580.js"])))
                },
                c = it(), {
                    handleChangeTemplate: p,
                    handleSuggestWriteCv: g,
                    handleAddBlock: A,
                    handleChangeDataSample: u,
                    handleHiddenAllAction: m,
                    handleSuggestJob: b
                } = ir();
                w.mobile() || g();
                const v = C(""),
                f = C([{
                                tabKey: tr.TAB_CHANGE_TEMPLATE,
                                icon: "change-template",
                                text: "Đổi mẫu CV",
                                id: "btnChangeTemplate",
                                callback: p,
                                hidden: !1
                            }, {
                                tabKey: tr.TAB_ADD_BLOCK,
                                icon: "block-content",
                                text: "Thêm mục",
                                active: !1,
                                id: "btnAddBlock",
                                callback: A,
                                hidden: w.mobile()
                            }, {
                                tabKey: tr.TAB_CHANGE_DATA_SAMPLE,
                                icon: "cv-sample",
                                text: "Thư viện CV",
                                active: !1,
                                labelHot: !1,
                                id: "btnCvSample",
                                callback: u,
                                hidden: !1
                            }, {
                                tabKey: tr.TAB_SUGGEST_WRITE_CV,
                                icon: "suggest-write-cv",
                                text: "Hướng dẫn viết CV",
                                active: !1,
                                labelHot: !1,
                                id: "btnSuggest",
                                callback: g,
                                hidden: !1
                            }, {
                                tabKey: tr.TAB_SUGGEST_JOB,
                                icon: "job-offer",
                                text: "Việc làm phù hợp",
                                active: !1,
                                id: "btnJobSuggest",
                                callback: b,
                                hidden: !1
                            }
                        ]),
                x = E((() => t.isShowModal)),
                y = n => !!x.value && (n.tabKey === c.currentActiveTab && (v.value = n.icon, !0)),
                k = E((() => f.value.filter((n => !n.hidden))));
                I(x, (n => {
                        n || (v.value = "")
                    }));
                return D((() => {
                        window.addEventListener("click", (function (n) {
                                const t = document.querySelector(".tab-navigation");
                                !(null == t ? void 0 : t.contains(n.target)) && w.mobile() && (m(), v.value = "")
                            }))
                    })),
                (n, e) => (U(), T("div", or, [O("div", wr, [O("div", lr, [(U(!0), T(an, null, dn(Q(k), ((n, e) => (U(), H(_l, {
                                                                    key: e,
                                                                    class: "tab-navigation__item",
                                                                    icon: n.icon,
                                                                    activeIcon: v.value,
                                                                    id: n.id,
                                                                    text: n.text,
                                                                    labelHot: n.labelHot,
                                                                    active: y(n),
                                                                    onClick: e => (n => {
                                                                        v.value = n.icon,
                                                                        t.setIsShowModal(!0),
                                                                        n.tabKey == tr.TAB_SUGGEST_WRITE_CV && localStorage.setItem(ar.KEY_SHOW_BOX_SUGGEST_JOB, "true"),
                                                                        n.callback && n.callback()
                                                                    })(n)
                                                                }, null, 8, ["icon", "activeIcon", "id", "text", "labelHot", "active", "onClick"])))), 128))]), Q(x) ? (U(), T("div", rr, [(U(), H(on(h[Q(c).currentActiveTab])))])) : $("", !0)])]))
            }
        }), [["__scopeId", "data-v-459c5eba"]]);
const hr = n => (X("data-v-54d8cbe0"), n = n(), Y(), n), cr = {
    class: "cv-builder-wrapper"
}, pr = {
    class: "is-vertical"
}, gr = {
    class: "block-navigation",
    id: "block-navigation",
    style: {
        "padding-right": "11px"
    }
}, Ar = {
    class: "block-preview"
}, ur = {
    class: "cv-section-main"
}, mr = hr((() => O("div", {
                id: "portal-cvo-action-advance"
            }, null, -1))), br = hr((() => O("div", {
                id: "portal-list-block-content"
            }, null, -1))), vr = hr((() => O("div", {
                id: "portal-cvo-popup-menu"
            }, null, -1))), fr = hr((() => O("div", {
                id: "portal-cvo-popup-modal"
            }, null, -1))), xr = {
    key: 0,
    class: "loader-global"
}, yr = [hr((() => O("div", {
                class: "loader"
            }, null, -1)))];
var kr = mi(S({
            setup(n) {
                const t = it(),
                e = C(!1),
                i = C(!1),
                a = C(!1),
                d = C(!1);
                D((() => {
                        var n;
                        w();
                        const {
                            addFontQuill: e,
                            addLineHeightQuill: i,
                            addSizeQuill: a
                        } = td(null);
                        e(),
                        i(),
                        a(),
                        t.setDataExampleByLanguage();
                        var l = new _(window.navigator.userAgent);
                        d.value = Boolean(l.mobile()),
                        d.value || o(),
                        null == (n = document.getElementById("main")) || n.addEventListener("click", (function (n) {
                                var t;
                                n.target.closest("#cvb-section-content") || null == (t = document.getElementById("cvb-section-content")) || t.classList.remove("has-element-selected")
                            }))
                    }));
                const o = () => {
                    setTimeout((() => {
                            var n;
                            i.value || (null == (n = document.querySelector(".footer_feedback")) || n.classList.add("active"), setTimeout((() => {
                                        var n;
                                        null == (n = document.querySelector(".footer_feedback")) || n.classList.remove("active")
                                    }), 3e4))
                        }), 6e4)
                },
                w = () => {
                    const n = document.querySelector(".block-preview");
                    n && (n.addEventListener("mousedown", (() => e.value = !1)), n.addEventListener("mousemove", (() => {
                                e.value = !0
                            })), n.addEventListener("mouseup", (n => {
                                const i = window.getSelection().toString();
                                if (e.value && i || e.value && t.resizingImage)
                                    return;
                                const a = document.querySelector(".cv-section-main");
                                if (a && !a.contains(n.target)) {
                                    document.querySelector(pw.parentElement).style.zIndex = -1,
                                    t.setPathEdit("")
                                }
                            })))
                };
                return I((() => t.isLoadingApi), (() => {
                        a.value = t.isLoadingApi
                    })),
                I((() => t.pathEdit), (() => {
                        if (!t.pathEdit) {
                            document.querySelector(pw.parentElement).style.zIndex = -1;
                            document.querySelectorAll(".blur,.shine").forEach((n => {
                                    n.classList.remove("blur", "shine")
                                }))
                        }
                    })),
                (n, e) => (U(), T("div", cr, [O("div", pr, [j(dl), j(Q(Gn), {
                                        class: "overwrite-row",
                                        style: {
                                            "flex-wrap": "unset",
                                            "padding-top": "191px"
                                        }
                                    }, {
                                    default:
                                        G((() => [O("div", gr, [j(sr)]), O("div", Ar, [j(Q(Gn), {
                                                                class: "row-bg",
                                                                justify: "center"
                                                            }, {
                                                            default:
                                                                G((() => [O("div", ur, [O("div", {
                                                                                        id: "cv-section-content-pdf",
                                                                                        class: M(["cv-section-wrapper", {
                                                                                                    preview: Q(t).isPreview
                                                                                                }
                                                                                            ])
                                                                                    }, [j(Ma, {
                                                                                                sections: Q(t).builderData
                                                                                            }, null, 8, ["sections"])], 2)])])),
                                                                _: 1
                                                            })])])),
                                        _: 1
                                    })]), mr, br, vr, fr, a.value ? (U(), T("div", xr, yr)) : $("", !0), d.value ? $("", !0) : (U(), H(Xl, {
                                    key: 1,
                                    onDoneFeedback: e[0] || (e[0] = n => i.value = !0)
                                }))]))
            }
        }), [["__scopeId", "data-v-54d8cbe0"]]);
const Er = S({
    setup(n) {
        const {
            disablePreview: t,
            setBuilderDataModeEdit: e,
            setBuilderDataModeCreate: i
        } = ni(), {
            setListTypeBlockUsed: a
        } = ti(), {
            handleGlobalSetting: d
        } = ai(),
        o = it(), {
            getCvDataExampleByLanguage: w,
            getProjectLabelExampleByLanguage: l
        } = ri();
        return V((() => {
                t(),
                d(),
                o.setDataExampleByLanguage()
            })),
        D((async() => {
                const {
                    getTemplate: n
                } = ti(),
                t = await n(o.templateCvId);
                o.setRenderData(t.renderData);
                let d = o.builderWidget.renderData;
                if (!d || !d.length) {
                    d = f(t.renderData),
                    ad(o.cvDataWidget, d);
                    od(w(o.language), o.cvDataWidget);
                    const n = l(o.language),
                    e = p(o.cvDataWidget, n);
                    i(f(d), e)
                } else
                    e(f(d), o.cvDataWidget);
                o.setCvData(o.cvDataWidget),
                a(),
                ya(xa.EDIT_CV, {
                    t_i: o.templateCvId
                })
            })),
        (n, t) => (U(), H(kr))
    }
});
var Br = (n => (n.NEW = "new", n.LASTEST = "lastest", n.RECOVERY = "recovery", n))(Br || {});
const Cr = O("span", {
    role: "heading",
    class: "change-title-cv__title"
}, "Xác nhận", -1), Sr = O("p", {
    style: {
        "word-break": "break-word"
    }
}, " Bạn có dữ liệu chưa lưu từ lần viết CV trước đó. Bạn có muốn khôi phục không? ", -1), Ir = S({
    props: {
        isShow: {
            type: Boolean,
        default:
            !1
        },
        cvTitle: {
            type: String,
        default:
            ""
        }
    },
    emits: ["close", "restore"],
    setup(n, {
        emit: t
    }) {
        const e = n,
        i = C(!1),
        a = C(""),
        d = () => {
            t("close", !1)
        },
        o = () => {
            t("restore", !0)
        };
        return I((() => e.isShow), (() => {
                i.value = e.isShow,
                e.isShow ? a.value = e.cvTitle : a.value = ""
            }), {
            immediate: !0
        }),
        (n, t) => (U(), H(Q(K), {
                onClosed: d,
                modelValue: i.value,
                "onUpdate:modelValue": t[0] || (t[0] = n => i.value = n),
                title: "Xác nhận",
                "show-close": !1,
                width: "400px"
            }, {
                header: G((() => [Cr])),
                footer: G((() => [O("button", {
                                class: "btn-cv btn-cv--disable",
                                onClick: d
                            }, "Không"), O("button", {
                                class: "btn-cv btn-cv--success",
                                onClick: o
                            }, "Có")])),
            default:
                G((() => [Sr])),
                _: 1
            }, 8, ["modelValue"]))
    }
});
const Vr = S({
    setup(n) {
        const t = it(), {
            setListTypeBlockUsed: e
        } = ti(), {
            disablePreview: i,
            setBuilderDataModeCreate: a
        } = ni(), {
            handleGlobalSetting: d
        } = ai(), {
            getBlockMetaDataExampleByLanguage: o,
            getProjectLabelExampleByLanguage: w
        } = ri(), {
            autoSave: l
        } = xd(),
        r = C(!1);
        let s = Q(null),
        h = Q(null);
        function c() {
            r.value = !1,
            localStorage.removeItem("data-cv-auto-save"),
            A()
        }
        function g() {
            var n;
            let e = fd.getDataAutoSave();
            e = JSON.parse(e);
            let i = e.cvoData;
            t.builderWidget.globalSetting.language = null != (n = e.global_setting.lang) ? n : "vi",
            u(i),
            r.value = !1
        }
        function A() {
            h = o(t.language);
            const n = w(t.language);
            let e;
            e = p(h, t.cvDataWidget, n),
            u(e)
        }
        function u(n) {
            var i;
            t.setCvData(n),
            a(f(s.renderData), n),
            e(),
            ya(xa.CREATE_CV, {
                t_i: t.templateCvId,
                b: null != (i = Xt("type")) ? i : "default"
            }),
            setInterval((function () {
                    l()
                }), 2e4)
        }
        return V((() => {
                i(),
                d(),
                t.setDataExampleByLanguage()
            })),
        D((async() => {
                localStorage.setItem("startTime", (new Date).getTime());
                const {
                    getTemplate: n
                } = ti();
                if (s = await n(t.templateCvId), t.setRenderData(s.renderData), t.builderWidget.typeCreateCv == Br.RECOVERY)
                    g();
                else if (t.builderWidget.typeCreateCv == Br.NEW) {
                    if (fd.getDataAutoSave())
                        return void(r.value = !0);
                    A()
                } else {
                    u(t.cvDataWidget)
                }
            })),
        (n, t) => (U(), T(an, null, [j(kr), r.value ? (U(), H(Ir, {
                            key: 0,
                            "is-show": r.value,
                            onClose: c,
                            onRestore: g
                        }, null, 8, ["is-show"])) : $("", !0)], 64))
    }
});
const Dr = {
    class: "cv-wrapper"
}, Rr = {
    key: 0,
    class: "overlay-disable-action"
};
const qr = A(S({
            setup(n) {
                const t = it(), {
                    handleRedo: e,
                    handleUndo: i
                } = ei(),
                a = t.builderWidget,
                d = {
                    "view-cv": hd,
                    "edit-cv": Er,
                    "create-cv": Vr,
                    "preview-cv": bd
                },
                o = E((() => {
                            const n = a.route;
                            return d[n]
                        }));
                "create-cv" !== a.route && "edit-cv" !== a.route || (window.onbeforeunload = function () {
                    return !0
                });
                const w = C(!1);
                return D((async() => {
                        document.addEventListener("keyup", (n => {
                                "Escape" === n.key && t.setPathEdit("")
                            })),
                        document.addEventListener("keydown", (n => {
                                if ((n.ctrlKey || n.metaKey) && !n.shiftKey && "z" == n.key) {
                                    if (n.preventDefault(), 0 === t.undoStack.length)
                                        return;
                                    return i(),
                                    !1
                                }
                            })),
                        document.addEventListener("keydown", (n => {
                                if ((n.ctrlKey || n.metaKey) && n.shiftKey && "z" == n.key.toLowerCase()) {
                                    if (n.preventDefault(), 0 === t.redoStack.length)
                                        return;
                                    return e(),
                                    !1
                                }
                            })),
                        (async() => {
                            await Ze.createObjectStore("builder-activity-log", [_e.UNDO, _e.REDO]),
                            await Ze.clearAll([_e.UNDO, _e.REDO])
                        })()
                    })),
                (n, t) => (U(), T("div", Dr, [(U(), H(on(Q(o)))), w.value ? (U(), T("div", Rr)) : $("", !0)]))
            }
        }));
var Ur, Tr;
!function () {
    const n = "G-F385SHE0Y3",
    t = document.createElement("script");
    t.async = !0,
    t.src = `https://www.googletagmanager.com/gtag/js?id=${n}`,
    document.head.appendChild(t),
    t.onload = () => {
        function t(n, t) {
            window.dataLayer.push(arguments)
        }
        window.dataLayer = window.dataLayer || [],
        window.gtag = t,
        t("js", new Date),
        t("config", n)
    }
}
(), _n(qr), function (n) {
    n.directive("builder", Vt)
}
(Ur = qr), function (n) {
    n.directive("hover-class-builder", Dt)
}
(Ur), function (n) {
    !function (n) {
        const t = it(),
        e = {
            options: {},
            async init(e) {
                var i,
                a,
                d,
                o,
                w,
                l,
                r,
                s;
                const h = e;
                null === h.globalSetting && (h.globalSetting = null == (a = null == (i = e.cvData) ? void 0 : i.global) ? void 0 : a.settings),
                t.setBuilderWidget(f(h)),
                t.setTemplateColors(h.templateColors),
                t.setCvId(null != (d = h.cvId) ? d : ""),
                t.setTemplateCvId(null != (o = h.templateCvId) ? o : 0),
                t.setTemplateCvInfo(null != (w = h.templateCvInfo) ? w : ""),
                t.setTemplateCvDataSample(null != (l = h.templateCvDataSample) ? l : "");
                const {
                    getDataSample: c
                } = li();
                await c(null != (s = null == (r = h.globalSetting) ? void 0 : r.language) ? s : $n.VN),
                this.changeAxios(e),
                this.validateParams(h),
                n.mount(`#${null == e ? void 0 : e.selector}`)
            },
            changeAxios(n) {
                var t,
                e,
                i,
                a;
                (null == (t = null == n ? void 0 : n.router) ? void 0 : t.baseUrl) && (Wt.defaults.baseURL = null == (e = null == n ? void 0 : n.router) ? void 0 : e.baseUrl),
                (null == (i = null == n ? void 0 : n.axios) ? void 0 : i.request) && Wt.interceptors.request.use(null == n ? void 0 : n.axios.request),
                (null == (a = null == n ? void 0 : n.axios) ? void 0 : a.response) && Wt.interceptors.response.use(null == n ? void 0 : n.axios.response)
            },
            getOptions() {
                return this.options
            },
            validateParams(n) {
                "view-cv" === n.route && (n.renderData || console.error("Eror: RenderData null"), n.cvData || console.error("Error: CvData null"))
            }
        };
        window.$builderWidget = e
    }
    (n)
}
(qr), function (n) {
    var t;
    On({
        app: n,
        dsn: "https://bd6f817b56e84041a19cb60c709bdbb1@sentry.topworking.vn/37",
        integrations: [new jn({
                tracingOrigins: [null != (t = {}
                        .VITE_API_URL) ? t : "", /^\//]
            })],
        tracesSampleRate: 1,
        logErrors: !0,
        initialScope: {
            level: "error"
        },
        attachProps: !0,
        attachStacktrace: !0
    })
}
(qr), (Tr = window).ta = Tr.ta || function () {
    (Tr.ta.q = Tr.ta.q || []).push([...arguments])
};
export {
    td as $,
    li as A,
    Xn as B,
    cw as C,
    Ae as D,
    at as E,
    Ot as F,
    Jt as G,
    ya as H,
    xa as I,
    _i as J,
    $i as K,
    Yn as L,
    pt as M,
    ar as N,
    Ne as O,
    Me as P,
    $e as Q,
    Te as R,
    Ut as S,
    pw as T,
    Jn as U,
    Pt as V,
    ko as W,
    Mt as X,
    Ke as Y,
    te as Z,
    Pn as _,
    Kn as a,
    Nt as a0,
    $n as a1,
    Fa as a2,
    Qa as a3,
    Pa as a4,
    Ga as a5,
    za as a6,
    Qo as a7,
    mt as a8,
    Lt as a9,
    dr as b,
    ir as c,
    ri as d,
    fa as e,
    $t as f,
    ee as g,
    mi as h,
    zn as i,
    ti as j,
    Yt as k,
    we as l,
    ei as m,
    ne as n,
    nr as o,
    be as p,
    re as q,
    $l as r,
    Yo as s,
    nw as t,
    it as u,
    gt as v,
    ae as w,
    zt as x,
    ie as y,
    Gt as z
};
