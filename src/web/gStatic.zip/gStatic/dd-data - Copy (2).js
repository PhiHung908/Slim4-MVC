var _ddData = {
  "_defaultAction": [
    "act_move",
    "act_plus",
    "act_add_padding",
    "act_delete"
  ],
  "_defaultActionLine": [
    "act_line_up",
    "act_line_down",
    "act_add_padding",
    "act_ql_toolbar"
  ],
  "_allLabelReadonly": true,
  "_AnhDaiDien": {
    "order": 10,
    "headLogo": {
      "hint": "Nhap head logo URL",
      "text": "",
      "caption": "",
      "order": 1010,
      "options": {
        "logoPostion": "left"
      }
    },
    "headLabel": {
      "hint": "Ảnh đại diện",
      "order": 1020
    }
  },
  "DanhThiep": {
    "actions": [
      "act_move",
      "act_plus",
      "act_add_padding",
      "act_line_show"
    ],
    "order": 100,
    "contentLogo": {
      "hint": "Nhap content logo",
      "text": "",
      "caption": "",
      "order": 400,
      "options": {
        "logoPostion": "left",
        "hidden": true,
        "dPath": ".DanhThiep.contentLogo",
        "order": 400,
        "formats": false,
        "hint": "Nhap content logo",
        "textEmpty": true,
        "readonly": false
      }
    },
    "headLabel": {
      "hint": "Thong tin ca nhan cua ban",
      "actions": [
        "act_line_up",
        "act_line_down",
        "act_add_padding",
        "act_line_hidden",
        "act_ql_toolbar"
      ],
      "text": "Thông tin cá nhân",
      "icon": "fa-light fa-user-tag",
      "order": 100,
      "options": {
        "readonly": true,
        "class": "",
        "style": "",
        "data": "",
        "dPath": ".DanhThiep.headLabel",
        "order": 400,
        "formats": false,
        "hint": "Thong tin ca nhan cua ban"
      },
      "lineLabel": {
        "hint": "Gõ vào địa chỉ email",
        "actions": [
          "act_line_up",
          "act_line_down",
          "act_add_padding",
          "act_line_hidden",
          "act_ql_toolbar"
        ],
        "text": "Email",
        "order": 500,
        "options": {
          "dPath": ".DanhThiep.headLabel.lineLabel",
          "order": 500,
          "formats": false,
          "hint": "Gõ vào địa chỉ email"
        }
      },
      "lineValue": {
        "hint": "Email, Địa chỉ",
        "text": "vmkeyb908@gmail.com\n\t\t  0974 471 724\n\t\t  Trung Mỹ Tây - Q12",
        "order": 600
      },
      "lineLabel_1": {
        "hint": "Sở thích",
        "text": "So thich",
        "order": 700
      },
      "lineValue_1": {
        "text": "Xem phim",
        "order": 800
      }
    }
  },
  "ThongTinLienHe": {
    "headLabel": {
      "hint": "Thông tin liên hệ",
      "icon": "fa-light fa-circle-info",
      "headValue": {
        "hint": "Thông tin liên hệ",
        "order": 2100
      },
      "contentLabel": {
        "hint": "Tiêu đề nội dung chính",
        "order": 2200
      },
      "contentValue": {
        "hint": "Nội dung chính",
        "order": 2300
      },
      "contentLabel_1": {
        "hint": "Tiêu đề nội dung phụ 1",
        "order": 2400
      },
      "contentValue_1": {
        "hint": "Nội dung phụ 1",
        "order": 2500
      },
      "contentLabel_2": {
        "hint": "Tiêu đề nội dung phụ 2",
        "order": 2600
      },
      "contentValue_2": {
        "hint": "Nội dung phụ 2",
        "order": 2700
      },
      "order": 2000,
      "options": {
        "dPath": ".ThongTinLienHe.headLabel",
        "order": 2900,
        "readonly": false,
        "formats": false,
        "hint": "Thông tin liên hệ",
        "textEmpty": true
      }
    },
    "order": 200
  },
  "MucTieuNgheNghiep": {
    "headLabel": {
      "hint": "Mục tiêu nghề nghiệp",
      "icon": "fa-light fa-bullseye-arrow",
      "headValue": {
        "hint": "Mục tiêu nghề nghiệp",
        "order": 4100
      },
      "contentLabel": {
        "hint": "Tiêu đề nội dung chính",
        "order": 4200
      },
      "contentValue": {
        "hint": "Nội dung chính",
        "order": 4300
      },
      "contentLabel_1": {
        "hint": "Tiêu đề nội dung phụ 1",
        "order": 4400
      },
      "contentValue_1": {
        "hint": "Nội dung phụ 1",
        "order": 4500
      },
      "contentLabel_2": {
        "hint": "Tiêu đề nội dung phụ 2",
        "order": 4600
      },
      "contentValue_2": {
        "hint": "Nội dung phụ 2",
        "order": 4700
      },
      "order": 4000,
      "options": {
        "dPath": ".MucTieuNgheNghiep.headLabel",
        "order": 4900,
        "readonly": false,
        "formats": false,
        "hint": "Mục tiêu nghề nghiệp",
        "textEmpty": true
      }
    },
    "order": 400
  },
  "KinhNghiemLamViec": {
    "headLabel": {
      "text": "Kinh nghiệm làm việc",
      "hint": "nhap ten kinh nghiem",
      "icon": "fa-light fa-briefcase",
      "headValue": {
        "text": "",
        "hint": "nhap kinh nghiem",
        "order": 6100
      },
      "contentLabel": {
        "hint": "Tiêu đề nội dung chính",
        "order": 6200
      },
      "contentValue": {
        "hint": "Nội dung chính",
        "order": 6300
      },
      "contentLabel_1": {
        "hint": "Tiêu đề nội dung phụ 1",
        "order": 6400
      },
      "contentValue_1": {
        "hint": "Nội dung phụ 1",
        "order": 6500
      },
      "contentLabel_2": {
        "hint": "Tiêu đề nội dung phụ 2",
        "order": 6600
      },
      "contentValue_2": {
        "hint": "Nội dung phụ 2",
        "order": 6700
      },
      "order": 6000,
      "options": {
        "dPath": ".KinhNghiemLamViec.headLabel",
        "order": 6900,
        "readonly": true,
        "formats": false,
        "hint": "nhap ten kinh nghiem"
      }
    },
    "order": 600
  },
  "HocVan": {
    "headLabel": {
      "hint": "Học vấn",
      "text": "Học Vấn",
      "icon": "fa-light fa-graduation-cap",
      "headValue": "Phổ Thông",
      "contentLabel": {
        "hint": "Ngành nghề",
        "text": "Công nghệ thông tin",
        "order": 8200
      },
      "contentValue": {
        "hint": "Thời gian và trường đào tạo",
        "text": "24/08/18 - 24/12/22\nĐại học Cần Thơ\nline3\nline4\n",
        "order": 8300,
        "options": {
          "formats": "<p><strong>24/08/18 - 24/12/22</strong></p><p>Đại học Cần Thơ</p><p>line3</p><p>line4</p>",
          "dPath": ".HocVan.headLabel.contentValue",
          "order": 8300,
          "hint": "Thời gian và trường đào tạo",
          "markDel": 0
        }
      },
      "contentLabel_1": {
        "hint": "Ngành nghề phụ",
        "text": "Cơ khí",
        "order": 8400
      },
      "contentValue_1": {
        "hint": "Thời gian và trường đào tạo",
        "text": "20/08/23 - 24/12/24\n\t\t\tĐại học Cong Nghiệp TPHCM",
        "order": 8500
      },
      "contentValue_1_a": {
        "hint": "Mark force Delete",
        "text": "Dòng 2 trở lên sẽ mất nếu xóa",
        "order": 8600
      },
      "contentLabel_2": {
        "hint": "Ngành nghề phụ 2",
        "text": "Nông nghiệp",
        "order": 8700
      },
      "contentValue_2": {
        "hint": "Thời gian và trường đào tạo",
        "text": "24/08/23 - 24/12/24\n\t\t\tĐại học Nông Nghiệp CAN THO",
        "order": 8800
      },
      "order": 8000,
      "options": {
        "dPath": ".HocVan.headLabel",
        "order": 9000,
        "readonly": true,
        "formats": false,
        "hint": "Học vấn"
      }
    },
    "order": 800
  },
  "KyNang": {
    "headLabel": {
      "hint": "Kỹ năng",
      "icon": "fa-light fa-pen-fancy",
      "headValue": {
        "hint": "Kỹ năng",
        "order": 10100
      },
      "contentLabel": {
        "hint": "Tiêu đề nội dung chính",
        "order": 10200
      },
      "contentValue": {
        "hint": "Nội dung chính",
        "order": 10300
      },
      "contentLabel_1": {
        "hint": "Tiêu đề nội dung phụ 1",
        "order": 10400
      },
      "contentValue_1": {
        "hint": "Nội dung phụ 1",
        "order": 10500
      },
      "contentLabel_2": {
        "hint": "Tiêu đề nội dung phụ 2",
        "order": 10600
      },
      "contentValue_2": {
        "hint": "Nội dung phụ 2",
        "order": 10700
      },
      "order": 10000,
      "options": {
        "dPath": ".KyNang.headLabel",
        "order": 10900,
        "readonly": false,
        "formats": false,
        "hint": "Kỹ năng",
        "textEmpty": true
      }
    },
    "order": 1000
  },
  "DuAn": {
    "headLabel": {
      "hint": "Dự án",
      "icon": "fa-light fa-diagram-project",
      "headValue": {
        "hint": "Dự án",
        "order": 12100
      },
      "contentLabel": {
        "text": "Quản lý Hồ sơ VNC",
        "order": 12200
      },
      "contentLines": {
        "text": "24/08/18 - 24/12/22\t\t\tCông ty Kiểm định VNC",
        "order": 12300
      },
      "contentLabel_2": {
        "text": "Ứng dụng quản lý kho",
        "order": 12400
      },
      "contentLines_2": {
        "text": "24/08/23 - 24/12/24\t\t\tCông ty thương nghiệp HÒA BÌNH",
        "order": 12500
      },
      "order": 12000,
      "options": {
        "dPath": ".DuAn.headLabel",
        "order": 12700,
        "readonly": false,
        "formats": false,
        "hint": "Dự án",
        "textEmpty": true
      }
    },
    "order": 1200
  },
  "GiaiThuong": {
    "headLabel": {
      "hint": "Giải thưởng",
      "icon": "fa-light fa-award",
      "headValue": {
        "hint": "Giải thưởng",
        "order": 14100
      },
      "contentLabel": {
        "hint": "Tiêu đề nội dung chính",
        "order": 14200
      },
      "contentValue": {
        "hint": "Nội dung chính",
        "order": 14300
      },
      "contentLabel_1": {
        "hint": "Tiêu đề nội dung phụ 1",
        "order": 14400
      },
      "contentValue_1": {
        "hint": "Nội dung phụ 1",
        "order": 14500
      },
      "contentLabel_2": {
        "hint": "Tiêu đề nội dung phụ 2",
        "order": 14600
      },
      "contentValue_2": {
        "hint": "Nội dung phụ 2",
        "order": 14700
      },
      "order": 14000,
      "options": {
        "dPath": ".GiaiThuong.headLabel",
        "order": 14900,
        "readonly": false,
        "formats": false,
        "hint": "Giải thưởng",
        "textEmpty": true
      }
    },
    "order": 1400
  },
  "ChungChi": {
    "headLabel": {
      "hint": "Chứng chỉ",
      "icon": "fa-light fa-file-certificate",
      "headValue": {
        "hint": "Chứng chỉ",
        "order": 16100
      },
      "contentLabel": {
        "hint": "Tiêu đề nội dung chính",
        "order": 16200
      },
      "contentValue": {
        "hint": "Nội dung chính",
        "order": 16300
      },
      "contentLabel_1": {
        "hint": "Tiêu đề nội dung phụ 1",
        "order": 16400
      },
      "contentValue_1": {
        "hint": "Nội dung phụ 1",
        "order": 16500
      },
      "contentLabel_2": {
        "hint": "Tiêu đề nội dung phụ 2",
        "order": 16600
      },
      "contentValue_2": {
        "hint": "Nội dung phụ 2",
        "order": 16700
      },
      "order": 16000,
      "options": {
        "dPath": ".ChungChi.headLabel",
        "order": 16900,
        "readonly": false,
        "formats": false,
        "hint": "Chứng chỉ",
        "textEmpty": true
      }
    },
    "order": 1600
  },
  "HoatDong": {
    "headLabel": {
      "hint": "Hoạt động",
      "icon": "fa-light fa-hand",
      "headValue": {
        "hint": "Hoạt động",
        "order": 18100
      },
      "contentLabel": {
        "hint": "Tiêu đề nội dung chính",
        "order": 18200
      },
      "contentValue": {
        "hint": "Nội dung chính",
        "order": 18300
      },
      "contentLabel_1": {
        "hint": "Tiêu đề nội dung phụ 1",
        "order": 18400
      },
      "contentValue_1": {
        "hint": "Nội dung phụ 1",
        "order": 18500
      },
      "contentLabel_2": {
        "hint": "Tiêu đề nội dung phụ 2",
        "order": 18600
      },
      "contentValue_2": {
        "hint": "Nội dung phụ 2",
        "order": 18700
      },
      "order": 18000,
      "options": {
        "dPath": ".HoatDong.headLabel",
        "order": 18900,
        "readonly": false,
        "formats": false,
        "hint": "Hoạt động",
        "textEmpty": true
      }
    },
    "order": 1800
  },
  "NguoiThamChieu": {
    "headLabel": {
      "hint": "Tiêu đề Người tham chiếu",
      "icon": "fa-light fa-user-plus",
      "headValue": {
        "hint": "Người tham chiếu",
        "order": 20100
      },
      "contentLabel": {
        "hint": "Tiêu đề nội dung chính",
        "order": 20200
      },
      "contentValue": {
        "hint": "Nội dung chính",
        "order": 20300
      },
      "contentLabel_1": {
        "hint": "Tiêu đề nội dung phụ 1",
        "order": 20400
      },
      "contentValue_1": {
        "hint": "Nội dung phụ 1",
        "order": 20500
      },
      "contentLabel_2": {
        "hint": "Tiêu đề nội dung phụ 2",
        "order": 20600
      },
      "contentValue_2": {
        "hint": "Nội dung phụ 2",
        "order": 20700
      },
      "order": 20000,
      "options": {
        "dPath": ".NguoiThamChieu.headLabel",
        "order": 20900,
        "readonly": false,
        "formats": false,
        "hint": "Tiêu đề Người tham chiếu",
        "textEmpty": true
      }
    },
    "order": 2000
  },
  "SoThich": {
    "headLabel": {
      "hint": "Tiêu đề Sở thích",
      "icon": "fa-light fa-thumbs-up",
      "headValue": {
        "hint": "Sở thích",
        "order": 22100
      },
      "contentLabel": {
        "hint": "Tiêu đề nội dung chính",
        "order": 22200
      },
      "contentValue": {
        "hint": "Nội dung chính",
        "order": 22300
      },
      "contentLabel_1": {
        "hint": "Tiêu đề nội dung phụ 1",
        "order": 22400
      },
      "contentValue_1": {
        "hint": "Nội dung phụ 1",
        "order": 22500
      },
      "contentLabel_2": {
        "hint": "Tiêu đề nội dung phụ 2",
        "order": 22600
      },
      "contentValue_2": {
        "hint": "Nội dung phụ 2",
        "order": 22700
      },
      "order": 22000,
      "options": {
        "dPath": ".SoThich.headLabel",
        "order": 22900,
        "readonly": false,
        "formats": false,
        "hint": "Tiêu đề Sở thích",
        "textEmpty": true
      }
    },
    "order": 2200
  }
}
ddData = JSON.stringify(_ddData)
