var _ddData = {
    _defaultAction: ["act_move", "act_plus", "act_add_padding", "act_delete"],
    _defaultActionLine: ["act_line_up", "act_line_down", "act_add_padding", "act_ql_toolbar"],
    _allLabelReadonly: true,
    _AnhDaiDien: {
		order: 10,
        headLogo: {
            hint: "Nhap head logo URL",
            text: "",
            caption: "",
			order: 1010,
            options: {
                logoPostion: "left"
            }
        },
        headLabel: {
            hint: "Ảnh đại diện",
			order: 1020,
        }
    },
    DanhThiep: {
        actions: ["act_move", "act_plus", "act_add_padding", "act_line_show"],
		order:20,
        contentLogo: {
            hint: "Nhap content logo",
            text: "",
            caption: "",
			order: 2010,
            options: {
                logoPostion: "left",
                hidden: true
            }
        },
        headLabel: {
            hint: "Thong tin ca nhan cua ban",
            actions: ["act_line_up", "act_line_down", "act_add_padding", "act_line_hidden", "act_ql_toolbar"],
            text: "Thông tin cá nhân",
			icon: "fa-light fa-user-tag",
			order: 2020,
            options: {
                readonly: true,
                class: "",
                style: "",
                data: ""
            }
        },
        lineLabel: {
            hint: "Gõ vào địa chỉ email",
            actions: ["act_line_up", "act_line_down", "act_add_padding", "act_line_hidden", "act_ql_toolbar"],
            text: "Email",
			order: 2030,
            options: {}
        },
        lineValue: {
			hint: "Email, Địa chỉ",
			text: `vmkeyb908@gmail.com
	  0974 471 724
	  Trung Mỹ Tây - Q12`,
			order: 2040
		},
        lineLabel_1: {
			hint: "Sở thích",
			text: "So thich",
			order: 2050,
		},
        lineValue_1: `Xem phim`
    },
    ThongTinLienHe: {
        headLabel: {
            hint: "Thông tin liên hệ",
			icon: "fa-light fa-circle-info"
        },
        headValue: {
            hint: "Thông tin liên hệ"
        },
        contentLabel: {
            hint: "Tiêu đề nội dung chính"
        },
        contentValue: {
            hint: "Nội dung chính"
        },
        contentLabel_1: {
            hint: "Tiêu đề nội dung phụ 1"
        },
        contentValue_1: {
            hint: "Nội dung phụ 1"
        },
        contentLabel_2: {
            hint: "Tiêu đề nội dung phụ 2"
        },
        contentValue_2: {
            hint: "Nội dung phụ 2"
        }
    },
    MucTieuNgheNghiep: {
        headLabel: {
            hint: "Mục tiêu nghề nghiệp",
			icon: "fa-light fa-bullseye-arrow"
        },
        headValue: {
            hint: "Mục tiêu nghề nghiệp"
        },
        contentLabel: {
            hint: "Tiêu đề nội dung chính"
        },
        contentValue: {
            hint: "Nội dung chính"
        },
        contentLabel_1: {
            hint: "Tiêu đề nội dung phụ 1"
        },
        contentValue_1: {
            hint: "Nội dung phụ 1"
        },
        contentLabel_2: {
            hint: "Tiêu đề nội dung phụ 2"
        },
        contentValue_2: {
            hint: "Nội dung phụ 2"
        }
    },
    KinhNghiemLamViec: {
        headLabel: {
            text: "Kinh nghiệm làm việc",
            hint: "nhap ten kinh nghiem",
			icon: "fa-light fa-briefcase"
        },
        headValue: {
            text: "",
            hint: "nhap kinh nghiem"
        },
        contentLabel: {
            hint: "Tiêu đề nội dung chính"
        },
        contentValue: {
            hint: "Nội dung chính"
        },
        contentLabel_1: {
            hint: "Tiêu đề nội dung phụ 1"
        },
        contentValue_1: {
            hint: "Nội dung phụ 1"
        },
        contentLabel_2: {
            hint: "Tiêu đề nội dung phụ 2"
        },
        contentValue_2: {
            hint: "Nội dung phụ 2"
        }
    },
    HocVan: {
        headLabel: {
            hint: "Học vấn",
            text: "Học Vấn",
			icon: "fa-light fa-graduation-cap",
			contentLabel: {
				hint: "label sub head 1",
				text: "label sub head 1"
			},
			contentValue: {
				hint: "value sub head 1",
				text: "value sub head 1"
			}
        },
        headValue: "Phổ Thông",
        contentLabel: "Công nghệ thông tin",
        contentValue: {
            text: `<p>24/08/18 - 24/12/22</p>
<p>Đại học Cần Thơ</p>
line3
line4`,
            options: {
                formats: ""
            }
        },
        contentLabel_1: "Cơ khí",
        contentValue_1: `24/08/23 - 24/12/24
	  Đại học Cong Nghiệp TPHCM`,
        contentLabel_2: "Nông nghiệp",
        contentValue_2: "24/08/23 - 24/12/24\n\
        Đại học Nông Nghiệp CAN THO"
    },
    KyNang: {
        headLabel: {
            hint: "Kỹ năng",
			icon: "fa-light fa-pen-fancy"
        },
        headValue: {
            hint: "Kỹ năng"
        },
        contentLabel: {
            hint: "Tiêu đề nội dung chính"
        },
        contentValue: {
            hint: "Nội dung chính"
        },
        contentLabel_1: {
            hint: "Tiêu đề nội dung phụ 1"
        },
        contentValue_1: {
            hint: "Nội dung phụ 1"
        },
        contentLabel_2: {
            hint: "Tiêu đề nội dung phụ 2"
        },
        contentValue_2: {
            hint: "Nội dung phụ 2"
        }
    },
    DuAn: {
        headLabel: {
            hint: "Dự án",
			icon: "fa-light fa-diagram-project"
        },
        headValue: {
            hint: "Dự án"
        },
        contentLabel: "Quản lý Hồ sơ VNC",
        contentLines: "24/08/18 - 24/12/22\
        Công ty Kiểm định VNC",
        contentLabel_2: "Ứng dụng quản lý kho",
        contentLines_2: "24/08/23 - 24/12/24\
        Công ty thương nghiệp HÒA BÌNH"
    },
    GiaiThuong: {
        headLabel: {
            hint: "Giải thưởng",
			icon: "fa-light fa-award"
        },
        headValue: {
            hint: "Giải thưởng"
        },
        contentLabel: {
            hint: "Tiêu đề nội dung chính"
        },
        contentValue: {
            hint: "Nội dung chính"
        },
        contentLabel_1: {
            hint: "Tiêu đề nội dung phụ 1"
        },
        contentValue_1: {
            hint: "Nội dung phụ 1"
        },
        contentLabel_2: {
            hint: "Tiêu đề nội dung phụ 2"
        },
        contentValue_2: {
            hint: "Nội dung phụ 2"
        }
    },
    ChungChi: {
        headLabel: {
            hint: "Chứng chỉ",
			icon: "fa-light fa-file-certificate"
        },
        headValue: {
            hint: "Chứng chỉ"
        },
        contentLabel: {
            hint: "Tiêu đề nội dung chính"
        },
        contentValue: {
            hint: "Nội dung chính"
        },
        contentLabel_1: {
            hint: "Tiêu đề nội dung phụ 1"
        },
        contentValue_1: {
            hint: "Nội dung phụ 1"
        },
        contentLabel_2: {
            hint: "Tiêu đề nội dung phụ 2"
        },
        contentValue_2: {
            hint: "Nội dung phụ 2"
        }
    },
    HoatDong: {
        headLabel: {
            hint: "Hoạt động",
			icon: "fa-light fa-hand"
        },
        headValue: {
            hint: "Hoạt động"
        },
        contentLabel: {
            hint: "Tiêu đề nội dung chính"
        },
        contentValue: {
            hint: "Nội dung chính"
        },
        contentLabel_1: {
            hint: "Tiêu đề nội dung phụ 1"
        },
        contentValue_1: {
            hint: "Nội dung phụ 1"
        },
        contentLabel_2: {
            hint: "Tiêu đề nội dung phụ 2"
        },
        contentValue_2: {
            hint: "Nội dung phụ 2"
        }
    },
    NguoiThamChieu: {
        headLabel: {
            hint: "Tiêu đề Người tham chiếu",
			icon: "fa-light fa-user-plus"
        },
        headValue: {
            hint: "Người tham chiếu"
        },
        contentLabel: {
            hint: "Tiêu đề nội dung chính"
        },
        contentValue: {
            hint: "Nội dung chính"
        },
        contentLabel_1: {
            hint: "Tiêu đề nội dung phụ 1"
        },
        contentValue_1: {
            hint: "Nội dung phụ 1"
        },
        contentLabel_2: {
            hint: "Tiêu đề nội dung phụ 2"
        },
        contentValue_2: {
            hint: "Nội dung phụ 2"
        }
    },
    SoThich: {
        headLabel: {
            hint: "Tiêu đề Sở thích",
			icon: "fa-light fa-thumbs-up"
        },
        headValue: {
            hint: "Sở thích"
        },
        contentLabel: {
            hint: "Tiêu đề nội dung chính"
        },
        contentValue: {
            hint: "Nội dung chính"
        },
        contentLabel_1: {
            hint: "Tiêu đề nội dung phụ 1"
        },
        contentValue_1: {
            hint: "Nội dung phụ 1"
        },
        contentLabel_2: {
            hint: "Tiêu đề nội dung phụ 2"
        },
        contentValue_2: {
            hint: "Nội dung phụ 2"
        }
    }
}

ddData = JSON.stringify(_ddData)
