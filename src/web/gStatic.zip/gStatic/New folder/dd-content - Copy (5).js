(function($){
$.widget("PH_utils.ddContent",  $.PH_utils.uiBase, {
	version: "1.0",

	_create: function(){
//console.log('create...');
		//this.element.addClass("hwgTree");
		
		wgThis = this;
		
		wgThis.value('classN',((wgThis.element.parentsUntil('.drag-drop-container').parent().attr('class') || '').match(/(\s+|^)(drag-drop-container_[\d]+)($|\s)/) || ['','',''])[2])
		wgThis.value('classN') && wgThis.value('classN','.' + wgThis.value('classN'))
		actCont$ = $(wgThis.value('classN') + ' .action-container')
		$('body').prepend('<style>\
		' + wgThis.value('classN') + ' .action-container {\
			margin-top: -' + actCont$.height() + 'px;\
			margin-left: -0.8em;\
			position: relative;\
			z-index: 9;\
		}\
		</style>');
		
		this.element.draggable(Object.assign(this.options,{
			snap: false,
			
			start: function() {
				wgThis.value('rDraging', true)
				$(wgThis.value('classN')).children('.col-dd-container').removeClass("z-1")
				$(this).addClass("z-1")
				return true
			},
			//handle: '.act_move',
			cancel: ".ql-container",
			revert: "invalid",
			stop: function()
			{
				$(this).removeClass("d-none, z-1")
				wgThis.value('rDraging', false)
				$(wgThis.value('classN')).find('.col-dd-container').removeClass('hint-drop-left hint-drop-right hint-drop-top hint-drop-bottom');
				return true;
			}
		}));
		
		this.element.droppable({
			greedy: true,
			tolerance: "pointer",
			//hoverClass :  "ui-state-hover",
			over: function(event, ui) {
				$(wgThis.value('classN')).find('.col-dd-container').removeClass('hint-drop-left hint-drop-right hint-drop-top hint-drop-bottom');
				var that$ = $(this), ofs = that$.offset(), yCenter = that$.height()/2+ofs.top, xCenter = that$.width()/2+ofs.left;
				if (ui.offset.top > yCenter /*|| ui.offset.left > xCenter*/) {
					$(this).addClass("hint-drop-right");
				} else {
					$(this).addClass("hint-drop-left");
				}
				return true;
			},
			drop: function( event, ui ) {
				var that$ = $(this), ofs = that$.offset(), yCenter = that$.height()/2+ofs.top, xCenter = that$.width()/2+ofs.left;
				var style = ui.draggable.attr("style").replace(/;\s*left[^;]+/,'').replace(/;\s*XXposition[^;]+/,'').replace(/;\s*top[^;]+/,'');
				ui.draggable.left = 0;
				if (ui.offset.top > yCenter /* || ui.offset.left > xCenter */) {
				  ui.draggable.attr('style',style).insertAfter(this);
				} else {
				  ui.draggable.attr('style',style).insertBefore(this);
				}
		  }
		});
		 
		$('.act_move').on('mousedown', function(event, ui) {
			event.type = 'mousedown.draggable'
			event.target = $(this).parentsUntil('.col-dd-container').parent().get(0)
			$(this).parentsUntil('.col-dd-container').parent().trigger(event);
		})
		
		
		
		actCont$.children().on('click', function() {
			actCont$.addClass('d-none')
		});
 
		this.element.on('click mouseenter', function(e) {
			if (e.type=='mouseenter' && wgThis.value('rDraging')) return true;
			actCont$.children().addClass('d-none')
			var actList = $(this).data('actList') || false;
			
			$(this).prepend(actCont$.removeClass('d-none'))
			
			if (actList) {
				actCont$.removeClass('invisible').children('.'+actList.join(',.')).removeClass('d-none')
				actCont$.children('.act_add_padding,.act_remove_padding').addClass('d-none')
				var classOn = '.act_add_padding';
				if (actCont$.parent().hasClass('p-3')) classOn = '.act_remove_padding'
				actCont$.children(classOn).removeClass('d-none')
			}
			actCont$.find('.act_plus').attr("title", phUtils.vi2e("Thêm " + ($(this).find('.head-label').find('p').html()||'' ),22));
		});
		
		
		$(wgThis.value('classN')).prev().on('mouseenter', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
		});
		$(wgThis.value('classN')).next().on('mouseenter', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
		});
		$(wgThis.value('classN')).parent().on('mouseenter', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
		});
		$(wgThis.value('classN')).children('.row-dd-container').children('.col-dd-container').children('div,p').on('click', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
			return false;
		});
		
		this._m = {} //chứa widget nên cần phải khởi tạo trước
		  //this.options._values = {}
		
		this._super( this.options );
		if (!this.pluginStopped ) {
			
			 
			//$.proxy(
			//this._initWrapElem()
			;//, this);
			
			//$.proxy(
			//this._initSetEvent()
			;//, this);
		}
		else {
		  //this._promptPlaceHolderShow(); 
		}
	  },
	_destroy: function(){
//console.log("destroy...");
	  },
	_init: function(o) {
//console.log('init...', this, this.values('options'));
		this._super( this.options );
		
		this.refresh($.proxy(function(){
				//
			}, this));
			
	  },

	resize: function() {
		//this._superApply( arguments );
	},
	refresh: function(succOnloadCb) {
		//
	},


});
})(jQuery);


(function($){
$.widget("PH_utils.mkDdCont",  $.PH_utils.uiBase, {
	_init: function(o) {
		this._super()
		var wgThis = this;
		$(this.options.containerClassName).addClass('drag-drop-container')
		if (this.options.isCloneClassEvent) {
			$(this.options.containerClassName).append($(this.options.eventClassName).clone(true).addClass('action-container'))
		}
		this.mkIconEvent()
		
		$(this.options.containerClassName).each(function(i){
			$(this).addClass('drag-drop-container_'+i)
			wgThis.value('classN', '.drag-drop-container_'+i);
			var row$, n = 0;
			
			for (k in wgThis.options.ddData) {
				if (k[0] == '_') continue;
				if (n % wgThis.options.col == 0) {
					row$ = wgThis.mkRowDD()
					$(this).append(row$)
				}
				dd$ = wgThis.mkColDD(wgThis.options.ddData, k);
				row$.append(dd$);
				dd$.ddContent();
				n++
				var maxW = 0, aItemLabel = dd$.find('[class^="line-label"], [class*=" line-label"]')
				aItemLabel.each(function(i){
					var m = $(this).width();
					if (m>maxW) for (var z = i-1; z>=0; z--) $(aItemLabel[z]).css({width: m+'px'});
				})
				dd$.find('.ql-container').each(function() {
					//new Quill(this)
					var childP = $(this).children('p');
					
					var dOpts = $(this).data('ddOpts'), qOpts = {};
					
					if (dOpts.textEmpty) {
						var t = $(childP[0]).html() || '';
						$(childP[0]).empty()
						qOpts.placeholder = t;
					}
					
					$(this).data('oQuill', new Quill(this, qOpts));
					
					childP = $(this).children().children('p');
					
					childP.each(function(){
						if (!this.innerHTML.replace('<br>','').length) $(this).remove()
					})
					if (dOpts.readonly) {
						$(this).children().prop('contenteditable','false')
					} 
					if (dOpts.hidden) {
						$(this).addClass('d-none')
					}
				})
			}
		})
	},
	mkRowDD: function() {
		return $('<div class="row row-dd-container"></div>');
	},
	mkColDD: function(d, k) {
		var act = d[k].actions === undefined ? d._defaultAction : (d[k].actions !== false ? d[k].actions : false)
			, dd$ = $(('<div class="col col-dd-container border tmp-dd" ' + (act ? (' data-act-list = \'["' + act.join('","') + '"]\'') : '') + '></div>'))
			;
		//dd$.append(this.mkLinesQ(d[k],k));
		//dd$.append($('<div style="height:0.6rem">&nbsp;</div>'));
		this.mkLinesQ(dd$, d, k)
		return dd$;
	},
	mkLinesQ: function(q$, dRoot, kWork) {
		var d = dRoot[kWork];
		function mkLines(v, k, mClass = '', opts = {}, cssProp = '') {
			var s = '';
			for (var i=0; i<k.length; i++) {
				if (k[i] == '_' || k[i] == '-' ) s += '';
				else if (k[i].toUpperCase() == k[i]) s += (i==0 ? '' : '-' + k[i].toLowerCase());
				else s += k[i];
			}
			var sCont = '<div class="ql-container item-dd-container ' + s + ' '+mClass + '" ' + cssProp+ '><p>$2</p></div>';
			if (v=='' || !v) return $(sCont.replace('$2','')).data('ddOpts',opts)
			return $(v.replace(/(<p>)(.*)(<\/p>)/gm,'$2\n').replace(/[\r]+/gm,'').replace(/(\n|^)([^\n$]+)/gm,(sCont)).replace(/\n+$/,'')).data('ddOpts',opts)
		}
	
		var dFlex = '<div class="d-flex item-dd-container">', waitLineValue = 0, divFlex$ = $(dFlex), hasFirstLine = true;
		
		var doLineLabel = function(ks, k, opts) {
				var classAdd = 'ms-3' + (hasFirstLine ? ' mt-3' : ''), prop = opts.readonly ? 'contenteditable="false"' : '';
				//divFlex$ = $('<div class="d-flex">')
				divFlex$.append(mkLines(ks, k, classAdd, opts, prop))
				waitLineValue = 1;
			},
			doLineValue = function(ks, k, opts) {
				var classAdd = 'ms-3' + (hasFirstLine ? ' mt-3' : ''), prop = opts.readonly ? 'contenteditable="false"' : '';
				if (waitLineValue !== 1) {
					divFlex$.append(mkLines(' ', 'lineLabel', classAdd, opts, prop))
					divFlex$.append(mkLines(ks,k, classAdd, opts, prop))
					q$.append(divFlex$);
					waitLineValue = 0
					divFlex$ = $(dFlex)
					hasFirstLine = false
					return
				}
				divFlex$.append(mkLines(ks,k, classAdd, opts, prop))
				var elP$;
				divFlex$.children().each(function(i) {
					if (i==0) return true;
					if (i==1) {elP$ = $(this); return true}
					elP$.children().append($(this).find('p'))
					$(this).remove()
				})
				q$.append(divFlex$)
				waitLineValue = 0
				divFlex$ = $(dFlex)
				hasFirstLine = false
				return
			},
			isEmpty = function isEmpty(obj) {
			  for (const prop in obj) {
				if (Object.hasOwn(obj, prop)) {
				  return false;
				}
			  }
			  return true;
			}
			;
			
		for (k in d) {
			if (typeof d[k] === 'string') {
				ks = d[k]
				opts = {}
			} else {
				ks = d[k].text || false
				opts = d[k].options || {}
			}
			
			if (opts.readonly === undefined && dRoot._allLabelReadonly && k.indexOf('Label')>=0) {
				opts.readonly = dRoot._allLabelReadonly
			}
			
			//if (opts.hidden) continue;
			
			if (!ks) {
				opts.textEmpty = true
				opts.readonly = false
				ks = d[k].hint
				if (isEmpty(d[k])) opts.objEmpty = true
			}
			
			switch(k) {
				case 'headLabel' :
					q$.append( mkLines(ks,k, '', opts) );
					break;
				case 'headValue' :
					q$.append( mkLines(ks, k, '', opts) );
					break;
				case 'lineLabel' :
					doLineLabel(ks, k, opts)
					break;
				case 'lineValue' :
					doLineValue(ks, k, opts);
					break;
				case 'contentLabel' :
					q$.append( mkLines(ks,k, '', opts) );
					break;
				case 'contentValue' :
					q$.append( mkLines(ks,k, '', opts) );
					break;
				default:
					if (k.indexOf('lineLabel')==0) doLineLabel(ks, k, opts);
					else if (k.indexOf('lineValue')==0) doLineValue(ks, k, opts);
					else q$.append( mkLines(ks, k, '', opts) );
					break;
			}
		}
	},
	mkIconEvent: function() {
		var wgThis = this;
		this.element.find('.action-container').children('div').each(function(i) {
			var that$ = $(this);
			if (that$.hasClass('act_add_padding')) {
				that$.on('click', function() {
					var that$ = $(this);
					that$.addClass('d-none').parent().find('.act_remove_padding').removeClass('d-none')
					that$.parent().parent().addClass('p-3')
				})
			} else if (that$.hasClass('act_remove_padding')) {
				that$.on('click', function() {
					var that$ = $(this);
					that$.addClass('d-none').parent().find('.act_add_padding').removeClass('d-none')
					that$.parent().parent().removeClass('p-3')
				})
			} else if (that$.hasClass('act_line_up')) {
				that$.on('click', function() {
					var contAct$ = $(this).parent().parent();
					contAct$.insertBefore(contAct$.prev());
				})
			} else if (that$.hasClass('act_line_down')) {
				that$.on('click', function() {
					var contAct$ = $(this).parent().parent();
					contAct$.insertAfter(contAct$.next());
				})
			} else if (that$.hasClass('act_plus')) {
				that$.on('click', function() {
					var contAct$ = $(this).parent().parent(), clone$ = contAct$.clone(false);
					clone$.insertAfter(contAct$).find('.action-container').remove()
					clone$.ddContent()
					//triggerCloneRegion
				})
			} else if (that$.hasClass('act_delete')) {
				that$.on('click', function() {
					var contAct$ = $(this).parent().parent();
					contAct$.parent().append(contAct$.find('.action-container'))
					contAct$.remove()
					//triggerRemoveRegion
				})
			}
		})
	},
});
})(jQuery);



window.addEventListener('load', function() {
	$('.dd-cont2').mkDdCont({
		containerClassName: '.dd-cont2',
		eventClassName: '.action-container',
		isCloneClassEvent: true,
		col: 3,
		ddData: window.ddData
	});
})