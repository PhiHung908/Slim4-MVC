(function($){
$.widget("PH_utils.ddContent",  $.PH_utils.uiBase, {
	version: "1.0",

	_create: function(){
//console.log('create...');
		//this.element.addClass("hwgTree");
		
		wgThis = this;
		
		wgThis.value('classN',((wgThis.element.parentsUntil('.drag-drop-container').parent().attr('class') || '').match(/(\s+|^)(drag-drop-container_[\d]+)($|\s)/) || ['','',''])[2])
		wgThis.value('classN') && wgThis.value('classN','.' + wgThis.value('classN'))
		actCont$ = $(wgThis.value('classN') + ' .action-container')
		$('body').prepend('<style>\
		' + wgThis.value('classN') + ' .action-container {\
			margin-top: -' + actCont$.height() + 'px;\
			margin-left: -0.8em;\
			position: relative;\
			z-index: 9;\
		}\
		</style>');
		
		this.element.draggable(Object.assign(this.options,{
			snap: false,
			
			start: function() {
				wgThis.value('rDraging', true)
				$(wgThis.value('classN')).children('.col-dd-container').removeClass("z-1")
				$(this).addClass("z-1")
				return true
			},
			//handle: '.act_move',
			cancel: ".ql-container",
			revert: "invalid",
			stop: function()
			{
				$(this).removeClass("d-none, z-1")
				wgThis.value('rDraging', false)
				$(wgThis.value('classN')).find('.col-dd-container').removeClass('hint-drop-left hint-drop-right hint-drop-top hint-drop-bottom');
				return true;
			}
		}));
		
		this.element.droppable({
			greedy: true,
			tolerance: "pointer",
			//hoverClass :  "ui-state-hover",
			over: function(event, ui) {
				$(wgThis.value('classN')).find('.col-dd-container').removeClass('hint-drop-left hint-drop-right hint-drop-top hint-drop-bottom');
				var that$ = $(this), ofs = that$.offset(), yCenter = that$.height()/2+ofs.top, xCenter = that$.width()/2+ofs.left;
				if (ui.offset.top > yCenter /*|| ui.offset.left > xCenter*/) {
					$(this).addClass("hint-drop-right");
				} else {
					$(this).addClass("hint-drop-left");
				}
				return true;
			},
			drop: function( event, ui ) {
				var that$ = $(this), ofs = that$.offset(), yCenter = that$.height()/2+ofs.top, xCenter = that$.width()/2+ofs.left;
				var style = ui.draggable.attr("style").replace(/;\s*left[^;]+/,'').replace(/;\s*XXposition[^;]+/,'').replace(/;\s*top[^;]+/,'');
				ui.draggable.left = 0;
				if (ui.offset.top > yCenter /* || ui.offset.left > xCenter */) {
				  ui.draggable.attr('style',style).insertAfter(this);
				} else {
				  ui.draggable.attr('style',style).insertBefore(this);
				}
		  }
		});
		 
		$('.act_move').on('mousedown', function(event, ui) {
			event.type = 'mousedown.draggable'
			event.target = $(this).parentsUntil('.col-dd-container').parent().get(0)
			$(this).parentsUntil('.col-dd-container').parent().trigger(event);
		})
		
		
		
		actCont$.children().on('click', function() {
			actCont$.addClass('d-none')
		});
 
		this.element.on('click mouseenter', function(e) {
			if (e.type=='mouseenter' && wgThis.value('rDraging')) return true;
			actCont$.children().addClass('d-none')
			var actList = $(this).data('actList') || false;
//console.log(actList, $(this).data)
			actList.length && actCont$.removeClass('invisible').children('.'+actList.join(',.')).removeClass('d-none')
			elPlus = actCont$.find('.act_plus');
			elPlus.attr("title", elPlus.attr("title").replace('#LABEL#', $(this).find('.head-label').find('p').html()||'' ));
			$(this).prepend(actCont$.removeClass('d-none'))
		});
		
		
		$(wgThis.value('classN')).prev().on('mouseenter', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
		});
		$(wgThis.value('classN')).next().on('mouseenter', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
		});
		$(wgThis.value('classN')).parent().on('mouseenter', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
		});
		$(wgThis.value('classN')).children('.row-dd-container').children('.col-dd-container').children('div,p').on('click', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
			return false;
		});
		
		this._m = {} //chứa widget nên cần phải khởi tạo trước
		  //this.options._values = {}
		
		this._super( this.options );
		if (!this.pluginStopped ) {
			
			 
			//$.proxy(
			//this._initWrapElem()
			;//, this);
			
			//$.proxy(
			//this._initSetEvent()
			;//, this);
		}
		else {
		  //this._promptPlaceHolderShow(); 
		}
	  },
	_destroy: function(){
//console.log("destroy...");
	  },
	_init: function(o) {
//console.log('init...', this, this.values('options'));
		
		
		this.refresh($.proxy(function(){
				//
			}, this));
			
	  },

	resize: function() {
		//this._superApply( arguments );
	},
	refresh: function(succOnloadCb) {
		//
	},


});
})(jQuery);


(function($){
$.widget("PH_utils.mkDdCont",  $.PH_utils.uiBase, {
	_init: function(o) {
		this._super()
		var wgThis = this;
		$(this.options.containerClassName).addClass('drag-drop-container')
		if (this.options.isCloneClassEvent) {
			$(this.options.containerClassName).append($(this.options.eventClassName).clone(true).addClass('action-container'))
		}
		/*$(this.options.containerClassName).each(function(i){
			$(this).addClass('drag-drop-container_'+i)
			.children(".row.row-dd-container ").children(".col.col-dd-container ").each(function(){
				$(this).ddContent({XXgrid:[1,1], XXXcontainment: '.drag-drop-container_'+i, scroll: false, XXXconnectToSortable: '.drag-drop-container_'+i, Xrevert: "invalid"});
			})
			//$('body>div .ql-container').each(function() {
			$(this).find('.ql-container').each(function() {
				$(this).data('oQuill',new Quill(this));
			})
		})*/
		
		$(this.options.containerClassName).each(function(i){
			$(this).addClass('drag-drop-container_'+i)
			var row$, n = 0;
			
			for (k in wgThis.options.ddData) {
				if (k[0] == '_') continue;
				if (n % wgThis.options.col == 0) {
					row$ = wgThis.mkRowDD()
					$(this).append(row$)
				}
				dd$ = wgThis.mkColDD(wgThis.options.ddData, k);
				row$.append(dd$);
				dd$.ddContent();
				n++
				var maxW = 0, aItemLabel = dd$.find('[class^="line-label"], [class*=" line-label"]')
				aItemLabel.each(function(i){
					var m = $(this).width();
					if (m>maxW) for (var z = i-1; z>=0; z--) $(aItemLabel[z]).css({width: m+'px'});
				})
				dd$.find('.ql-container').each(function() {
				//$(this).data('oQuill', new Quill(this));
					new Quill(this)
					$(this).children().children('p').each(function(){
						if (!this.innerHTML.replace('<br>','').length) $(this).remove()
					})
					
					if ($(this).data('ddOpts').readonly) {
						$(this).children().prop('contenteditable','false')
					}
				})
			}
			
			/*
			$(this).find('.ql-container').each(function() {
				//$(this).data('oQuill', new Quill(this));
				new Quill(this)
				$(this).children().children('p').each(function(){
					if (!this.innerHTML.replace('<br>','').length) $(this).remove()
				})
			})
			*/
			
			
		})
	},
	mkRowDD: function() {
		return $('<div class="row row-dd-container"></div>');
	},
	mkColDD: function(d, k) {
		var act = d[k].actions === undefined ? d._defaultAction : (d[k].actions !== false ? d[k].actions : false)
			, dd$ = $(('<div class="col col-dd-container border tmp-dd" ' + (act ? (' data-act-list = \'["' + act.join('","') + '"]\'') : '') + '></div>'))
			;
		//dd$.append(this.mkLinesQ(d[k],k));
		//dd$.append($('<div style="height:0.6rem">&nbsp;</div>'));
		this.mkLinesQ(dd$, d, k)
		return dd$;
	},
	mkLinesQ: function(q$, dRoot, kWork) {
		var d = dRoot[kWork];
		function mkLines(v, k, mClass = '', opts = {}, cssProp = '') {
			var s = '';
			for (var i=0; i<k.length; i++) {
				if (k[i] == '_' || k[i] == '-' ) s += '';
				else if (k[i].toUpperCase() == k[i]) s += (i==0 ? '' : '-' + k[i].toLowerCase());
				else s += k[i];
			}
			//return v.replace(/(<p>)(.*)(<\/p>)/gm,'$2\n').replace(/[\r]+/gm,'').replace(/(\n|^)([^\n$]+)/gm,('<div class="ql-container ' + s + ' '+mClass + '" ' + cssProp+ '><p>$2</p></div>')).replace(/\n+$/,'')
			return $(v.replace(/(<p>)(.*)(<\/p>)/gm,'$2\n').replace(/[\r]+/gm,'').replace(/(\n|^)([^\n$]+)/gm,('<div class="ql-container ' + s + ' '+mClass + '" ' + cssProp+ '><p>$2</p></div>')).replace(/\n+$/,'')).data('ddOpts',opts)
		}
	
		var waitLineValue = 0, divFlex$ = $('<div class="d-flex">'), hasFirstLine = true;
		
		var doLineLabel = function(ks, k, opts) {
				var classAdd = 'ms-3' + (hasFirstLine ? ' mt-3' : ''), prop = opts.readonly ? 'contenteditable="false"' : '';
				//divFlex$ = $('<div class="d-flex">')
				divFlex$.append(mkLines(ks, k, classAdd, opts, prop))
				waitLineValue = 1;
			},
			doLineValue = function(ks, k, opts) {
				var classAdd = 'ms-3' + (hasFirstLine ? ' mt-3' : ''), prop = opts.readonly ? 'contenteditable="false"' : '';
				if (waitLineValue !== 1) {
					divFlex$.append(mkLines(' ', 'lineLabel', classAdd, opts, prop))
					divFlex$.append(mkLines(ks,k, classAdd, opts, prop))
					q$.append(divFlex$);
					waitLineValue = 0
					divFlex$ = $('<div class="d-flex">')
					hasFirstLine = false
					return
				}
				divFlex$.append(mkLines(ks,k, classAdd, opts, prop))
				var elP$;
				divFlex$.children().each(function(i) {
					if (i==0) return true;
					if (i==1) {elP$ = $(this); return true}
					elP$.children().append($(this).find('p'))
					$(this).remove()
				})
				q$.append(divFlex$)
				waitLineValue = 0
				divFlex$ = $('<div class="d-flex">')
				hasFirstLine = false
				return
			}
		for (k in d) {
			if (typeof d[k] === 'string') {
				ks = d[k]
				opts = {}
			} else {
				ks = d[k].text
				opts = d[k].options
			}
			
			if (opts.readonly === undefined && dRoot._allLabelReadonly && k.indexOf('Label')>=0) {
				opts.readonly = dRoot._allLabelReadonly;
			}
			
			switch(k) {
				case 'headLabel' :
					q$.append( mkLines(ks,k, '', opts) );
					break;
				case 'headValue' :
					q$.append( mkLines(ks, k, '', opts) );
					break;
				case 'lineLabel' :
					doLineLabel(ks, k, opts)
					break;
				case 'lineValue' :
					doLineValue(ks, k, opts);
					break;
				case 'contentLabel' :
					q$.append( mkLines(ks,k, '', opts) );
					break;
				case 'contentValue' :
					q$.append( mkLines(ks,k, '', opts) );
					break;
				default:
					if (k.indexOf('lineLabel')==0) doLineLabel(ks, k, opts);
					else if (k.indexOf('lineValue')==0) doLineValue(ks, k, opts);
					else q$.append( mkLines(ks, k, '', opts) );
					break;
			}
		}
	},
});
})(jQuery);



window.addEventListener('load', function() {
	$('.drag-drop-container').mkDdCont({
		containerClassName: '.dd-cont2',
		eventClassName: '.action-container',
		isCloneClassEvent: true,
		col: 3,
		ddData: window.ddData
	});
})