(function($){
$.widget("PH_utils.ddContent",  $.PH_utils.uiBase, {
	version: "1.0",

	_create: function(){
//console.log('create...');
		//this.element.addClass("hwgTree");
		
		wgThis = this;
		
		wgThis.value('classN',((wgThis.element.parentsUntil('.drag-drop-container').parent().attr('class') || '').match(/(\s+|^)(drag-drop-container_[\d]+)($|\s)/) || ['','',''])[2])
		wgThis.value('classN') && wgThis.value('classN','.' + wgThis.value('classN'))
		actCont$ = $(wgThis.value('classN') + ' .action-container')
		$('body').prepend('<style>\
		' + wgThis.value('classN') + ' .action-container {\
			margin-top: -' + actCont$.height() + 'px;\
			margin-left: -0.8em;\
			position: relative;\
			z-index: 9;\
		}\
		</style>');
		
		this.element.draggable(Object.assign(this.options,{
			snap: false,
			
			start: function() {
				wgThis.value('rDraging', true)
				$(wgThis.value('classN')).children('.col-dd-container').removeClass("z-1")
				$(this).addClass("z-1")
				return true
			},
			//handle: '.act_move',
			cancel: ".ql-container",
			revert: "invalid",
			stop: function()
			{
				$(this).removeClass("d-none, z-1")
				wgThis.value('rDraging', false)
				$(wgThis.value('classN')).find('.col-dd-container').removeClass('hint-drop-left hint-drop-right hint-drop-top hint-drop-bottom');
				return true;
			}
		}));
		
		this.element.droppable({
			greedy: true,
			tolerance: "pointer",
			//hoverClass :  "ui-state-hover",
			over: function(event, ui) {
				$(wgThis.value('classN')).find('.col-dd-container').removeClass('hint-drop-left hint-drop-right hint-drop-top hint-drop-bottom');
				var that$ = $(this), ofs = that$.offset(), yCenter = that$.height()/2+ofs.top, xCenter = that$.width()/2+ofs.left;
				if (ui.offset.top > yCenter /*|| ui.offset.left > xCenter*/) {
					$(this).addClass("hint-drop-right");
				} else {
					$(this).addClass("hint-drop-left");
				}
				return true;
			},
			drop: function( event, ui ) {
				var that$ = $(this), ofs = that$.offset(), yCenter = that$.height()/2+ofs.top, xCenter = that$.width()/2+ofs.left;
				var style = ui.draggable.attr("style").replace(/;\s*left[^;]+/,'').replace(/;\s*XXposition[^;]+/,'').replace(/;\s*top[^;]+/,'');
				ui.draggable.left = 0;
				if (ui.offset.top > yCenter /* || ui.offset.left > xCenter */) {
				  ui.draggable.attr('style',style).insertAfter(this);
				} else {
				  ui.draggable.attr('style',style).insertBefore(this);
				}
		  }
		});
		 
		$('.act_move').on('mousedown', function(event, ui) {
			event.type = 'mousedown.draggable'
			event.target = $(this).parentsUntil('.col-dd-container').parent().get(0)
			$(this).parentsUntil('.col-dd-container').parent().trigger(event);
		})
		
		
		
		actCont$.children().on('click', function() {
			actCont$.addClass('d-none')
		});
 
		this.element.on('click mouseenter', function(e) {
			if (e.type=='mouseenter' && wgThis.value('rDraging')) return true;
			actCont$.children().addClass('d-none')
			var actList = $(this).data('actList') || false;
			actList.length && actCont$.removeClass('invisible').children('.'+actList.join(',.')).removeClass('d-none')
			$(this).prepend(actCont$.removeClass('d-none'))
		});
		
		
		$(wgThis.value('classN')).prev().on('mouseenter', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
		});
		$(wgThis.value('classN')).next().on('mouseenter', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
		});
		$(wgThis.value('classN')).parent().on('mouseenter', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
		});
		$(wgThis.value('classN')).children('.row-dd-container').children('.col-dd-container').children('div,p').on('click', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
			return false;
		});
		
		this._m = {} //chứa widget nên cần phải khởi tạo trước
		  //this.options._values = {}
		
		this._super( this.options );
		if (!this.pluginStopped ) {
			
			 
			//$.proxy(
			//this._initWrapElem()
			;//, this);
			
			//$.proxy(
			//this._initSetEvent()
			;//, this);
		}
		else {
		  //this._promptPlaceHolderShow(); 
		}
	  },
	_destroy: function(){
//console.log("destroy...");
	  },
	_init: function(o) {
//console.log('init...', this, this.values('options'));
		
		
		this.refresh($.proxy(function(){
				//
			}, this));
			
	  },

	resize: function() {
		//this._superApply( arguments );
	},
	refresh: function(succOnloadCb) {
		//
	},


});
})(jQuery);


(function($){
$.widget("PH_utils.mkDdCont",  $.PH_utils.uiBase, {
	_init: function(o) {
		this._super()
		$(this.options.containerClassName).addClass('drag-drop-container')
		if (this.options.isCloneClassEvent) {
			$(this.options.containerClassName).append($(this.options.eventClassName).clone(true).addClass('action-container'))
		}
		
		$(this.options.containerClassName).each(function(i){
			$(this).addClass('drag-drop-container_'+i)
			.children(".row.row-dd-container ").children(".col.col-dd-container ").each(function(){
				$(this).ddContent({XXgrid:[1,1], XXXcontainment: '.drag-drop-container_'+i, scroll: false, XXXconnectToSortable: '.drag-drop-container_'+i, Xrevert: "invalid"});
			});
			//$('body>div .ql-container').each(function() {
			$(this).find('.ql-container').each(function() {
				$(this).data('oQuill',new Quill(this));
			});
		})
	}
});
})(jQuery);



window.addEventListener('load', function() {
	$('.drag-drop-container').mkDdCont({
		containerClassName: '.drag-drop-container',
		eventClassName: '.action-container',
		isCloneClassEvent: false,
		ddData: window.ddData
	});
})