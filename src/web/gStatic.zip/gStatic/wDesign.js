
window.wTpl = {tplName: 'tpl_001', items: [
	{
		order: 100,
		type: 'page',
		attributes: {
		}
	},
	{
		order: 200,
		type: 'header',
		attributes: {
		}
	},
	{
		order: 300,
		type: 'body',
		attributes: {
		},
		items: [
			{
				order: 3000, 
				type: 'region',
				id: "r_3000",
				name: 'region_3000',
				attributes: {},
				items: [
						{order: 3001, type: 'input', options:{} },
						{order: 3002, type: 'input', options:{} }
					]
			},
			{
				order: 3100, 
				type: 'region',
				name: 'region_3100',
			}
			,
			{
				order: 3200, 
				type: 'region',
				name: 'region_3200',
			}
		]
	},
	{
		order: 400,
		type: 'footer',
		attributes: {
		}
	},
]};

(function(){
$.widget("PH_utils.wDesign",  $.PH_utils.uiBase, {
	version: "1.0",
	options: {
	},
	u: function() {
		return window.phUtils
	},
	_stackFunc: [],
	_doRender: function(aData) {
		for(var k in aData) {
			var dElm = aData[k]
			this._stackFunc.push(dElm['type'] + '/end')
			this.render(dElm['type'] + '/begin', {order: dElm.order, name: dElm.name})
			!!dElm['items'] && this._doRender(dElm['items']);
			this.render(this._stackFunc.pop(),{order: dElm.order, name: dElm.name})
		}
	},
	_create: function(){
		this._super()
		this.element.addClass('hwgWebDesign')
		console.log('create...')
		
		if (!this.options.rootDotClass || $(this.options.rootDotClass).length) {
			this.options.rootDotClass = '.hwg-webDesign'
			this.element.prepend('<div class="' + this.options.rootDotClass + '">')
		}
		this.options.root$ = $(this.element.children($(this.options.rootDotClass)).get(0))
		this.options.root$.addClass('row XXcontainer-fluid')
		
		this._doRender(this.options.tplData.items)
	},
	_init: function(){
		this._super()
		console.log('init...')
	},
	render: function(func) {
		var wgThis = this;
		const oFunc = {
			'page': {
				begin:function(){
					document.write(`<div class="container-fluid">`)
				},
				end: function(){
					document.write(`</div>`)
				}
			},
			'header': {
				begin:function(){
					document.write(`<div class="header">`)
				},
				end: function(){
					document.write(`</div>`)
				}
			},
			'body': {
				begin:function(){
					document.write(`<div class="body">`)
				},
				end: function(){
					document.write(`</div>`)
				}
			},
			'region': {
				begin:function(d){
					document.write(`
<div class="row g-0"><div class="container-content p-0 border border-dark-subtle rounded-top-2">
    <div class="container-header d-flex text-bg-primary rounded-top-2 border border-light border-bottom-0" data-bs-theme="dark">
		<h5 class="container-title m-0 p-2 ps-3">` + d[0].name + `</h5><button type="button" data-bs-dismiss="modalXXX" aria-label="Close" class="btn-close ms-auto p-3"></button>
	</div>
	<div class="container-fluid pt-2 mt-1 pb-2"><div class="row g-3">aa
`)
					console.log('region begin', d[0].order)
				},
				end: function(d){
					document.write(`</div></div>
	<div class="container-footer">
		<button type="button" class="btn btn-secondary" data-bs-dismiss="modalXXX">Close</button>
		<button type="button" class="btn btn-primary">Save changes</button>
	</div>
</div></div>`)
					console.log('region end', d[0].order)
				}
			},
			'footer': {
				begin:function(){
					document.write(`<div class="footer">`)
				},
				end: function(){
					document.write(`</div>`)
				}
			},
		}
		var fun = (func || 'region/body').split('/')
		if (!oFunc[fun[0]]) return undefined;
		return oFunc[fun[0]][fun[1]](Array.prototype.slice.call(arguments, 1))
	}
	,
})
})()
