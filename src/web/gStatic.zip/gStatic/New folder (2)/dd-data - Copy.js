var ddData = {
  _defaultAction: ["act_move","act_plus","act_add_padding","act_delete"],
  _defaultActionLine: ["act_line_up","act_line_down","act_add_padding","act_line_hide","act_ql_toolbar"],
  _allLabelReadonly: true,
  AnhDaiDien: {
	  headLogo: {
		  text: "url()",
		  hint: "Nhap head logo",
		  caption: "",
		  options: {
			  logoPostion: "left",
		  },
	  },
  },
  DanhThiep: {
	  actions: ["act_move","act_plus","act_add_padding","act_line_show"],
	  contentLogo: {
		  text: "",
		  hint: "Nhap content logo",
		  caption: "",
		  options: {
			  logoPostion: "left",
			  hidden: true,
		  },
	  },
	  headLabel: {
		  text: "Thông tin cá nhân",
		  hint: "Thong tin ca nhan cua ban",
		  options: {
			  readonly: true,
			  class: '',
			  style: '',
			  data: '',
		  }
	  },
	  lineLabel: {
		  text: "Email",
		  hint: "Gõ vào địa chỉ email",
		  options: {
		  }
	  },
	  lineValue: `vmkeyb908@gmail.com
	  0974 471 724
	  Trung Mỹ Tây - Q12`,
	  lineLabel_1: 'So thich',
	  lineValue_1: `Xem phim
	  `,
  },
  ThongTinLienHe: {
  },
  MucTieuNgheNghiep: {
  },
  KinhNghiemLamViec: {
	   headLabel: {
		   text:'kinh nghiem',
		   hint: 'nhap ten kinh nghiem',
	   },
	   headValue: {
		   text:'',
		   hint: 'nhap kinh nghiem',
	   },
	   contentLabel: {
		   text:'',
		   hint: 'nhap khoang thoi gian',
	   },
	   contentValue: {
		   text:'',
		   hint: 'tom tat qua trinh cong tac',
	   },
  },
  HocVan: {
	  headLabel: "Học Vấn",
	  headValue: "Phổ Thông",
	  contentLabel: "Công nghệ thông tin",
	  contentValue: `<p>24/08/18 - 24/12/22</p>
<p>Đại học Cần Thơ</p>
`,
	  contentLabel_1: "Cơ khí",
	  contentValue_1: `24/08/23 - 24/12/24
	  Đại học Công Nghiệp TPHCM`,
	  contentLabel_2: "Nông nghiệp",
	  contentValue_2: '24/08/23 - 24/12/24\n\
	  Đại học Công Nghiệp TPHCM',
  },
  KyNang: {
  },
  DuAn: {
	  headLabel: "Dự Án", 
	  contentLabel: "Quản lý Hồ sơ VNC",
	  contentLines: "24/08/18 - 24/12/22\
	  Cônt ty Kiểm định VNC",
	  contentLabel_2: "Ứng dụng quản lý kho",
	  contentLines_2: "24/08/23 - 24/12/24\
	  Công ty thương nghiệp HÒA BÌNH"
  },
  GiaiThuong: {
  },
  ChungChi: {
  },
  HoatDong: {
  },
  NguoiThamChieu: {
  },
  SoThich: {
  }
}