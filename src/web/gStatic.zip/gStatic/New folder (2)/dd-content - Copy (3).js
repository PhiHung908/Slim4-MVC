(function($){
$.widget("PH_utils.ddContent",  $.PH_utils.uiBase, {
	version: "1.0",

	_create: function(){
//console.log('create...');
		this.element.addClass("hwgDdContent");
		
		wgThis = this;
		
		wgThis.value('classN',((wgThis.element.parentsUntil('.drag-drop-container').parent().attr('class') || '').match(/(\s+|^)(drag-drop-container_[\d]+)($|\s)/) || ['','',''])[2])
		wgThis.value('classN') && wgThis.value('classN','.' + wgThis.value('classN'))
		actCont$ = $(wgThis.value('classN') + ' .action-container')
		if (!$('body .dd-dyn-style').length) {
			$('body').prepend('<div class="dd-dyn-style"><style>\
			' + wgThis.value('classN') + ' .action-container {\
				margin:0 !important;\
				padding:0 !important;\
				line-height: 1 !important;\
				margin-top: -' + actCont$.height() + 'px !important;\
				position: relative;\
				z-index: 9;\
				width: 0.001px !important;\
			}\
			</style></div>');
		}
		
		this.element.draggable(Object.assign(this.options,{
			snap: false,
			
			start: function() {
				wgThis.value('rDraging', true)
				$(wgThis.value('classN')).children('.col-dd-container').removeClass("z-1")
				$(this).addClass("z-1")
				return true
			},
			//handle: '.act_move',
			cancel: ".ql-container",
			revert: "invalid",
			stop: function()
			{
				$(this).removeClass("d-none, z-1")
				wgThis.value('rDraging', false)
				$(wgThis.value('classN')).find('.col-dd-container').removeClass('hint-drop-left hint-drop-right hint-drop-top hint-drop-bottom');
				return true;
			}
		}));
		
		this.element.droppable({
			greedy: true,
			tolerance: "pointer",
			//hoverClass :  "ui-state-hover",
			over: function(event, ui) {
				$(wgThis.value('classN')).find('.col-dd-container').removeClass('hint-drop-left hint-drop-right hint-drop-top hint-drop-bottom');
				var that$ = $(this), ofs = that$.offset(), yCenter = that$.height()/2+ofs.top, xCenter = that$.width()/2+ofs.left;
				if (ui.offset.top > yCenter /*|| ui.offset.left > xCenter*/) {
					$(this).addClass("hint-drop-right");
				} else {
					$(this).addClass("hint-drop-left");
				}
				return true;
			},
			drop: function( event, ui ) {
				var that$ = $(this), ofs = that$.offset(), yCenter = that$.height()/2+ofs.top, xCenter = that$.width()/2+ofs.left;
				var style = ui.draggable.attr("style").replace(/;\s*left[^;]+/,'').replace(/;\s*top[^;]+/,'');
				ui.draggable.left = 0;
				if (ui.offset.top > yCenter /* || ui.offset.left > xCenter */) {
				  ui.draggable.attr('style',style).insertAfter(this);
				} else {
				  ui.draggable.attr('style',style).insertBefore(this);
				}
		  }
		});
		 
		$('.act_move').on('mousedown', function(event, ui) {
			event.type = 'mousedown.draggable'
			event.target = $(this).parentsUntil('.col-dd-container').parent().get(0)
			$(this).parentsUntil('.col-dd-container').parent().trigger(event);
		})
		
		
		
		actCont$.children().on('click', function() {
			actCont$.addClass('d-none')
		});
 
		this.element.on('click mouseenter dmyClick', function(e, d) {
			if (e.type =='mouseenter' && !wgThis.options.gToolbar.hasClass('tbar-draged')) {
				wgThis.options.gToolbar.addClass('d-none')
			}
			if (e.type == 'mouseenter' && wgThis.value('rDraging')) return true;
			var target$ = $((d && d.target) || e.currentTarget), actList = (d ? d.actList : target$.data('actList')) || false;
			actCont$.children().addClass('d-none')
			if (!actList || target$.hasClass('head-label')) return;
			
			target$.prepend(actCont$.removeClass('d-none'))
			
			actCont$.removeClass('invisible').children('.'+actList.join(',.')).removeClass('d-none')
			actCont$.children('.act_add_padding,.act_remove_padding').addClass('d-none')
			var classOn = '.act_add_padding';
			if (d && target$.parentsUntil('.dd-lines-container').parent().hasClass(wgThis.options.settings.indentClass || 'ps-3')) classOn = '.act_remove_padding';
			else if (actCont$.parent().hasClass(wgThis.options.settings.paddingClass || 'p-3')) classOn = '.act_remove_padding';
			actCont$.children(classOn).removeClass('d-none')
		
			actCont$.find('.act_plus').attr("title", phUtils.vi2e("Thêm " + (target$.find('.head-label').find('p').html()||'' ),22));
		});
		
		
		$(wgThis.value('classN')).prev().on('mouseenter', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
		});
		$(wgThis.value('classN')).next().on('mouseenter', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
		});
		$(wgThis.value('classN')).parent().on('mouseenter', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
		});
		/*
		$(wgThis.value('classN')).children('.row-dd-container').children('.col-dd-container').children('div,p').on('click', function() {
			actCont$.addClass('d-none')
			wgThis.value('rDraging', false)
			return false;
		});
		*/
		
		//*
		wgThis.element.find('.dd-lines-container').each(function() {
			var lines = this;
			$(this).children('.dd-line-container').on('mouseenter', function(){
				var cont$ = $(this).find('>.ql-container:last-child'); //$(this).children('.ql-container');
				if (cont$.hasClass('head-label') || cont$.find('[contenteditable="false"]').length || cont$ && cont$.data('oQuill').editor.isBlank()) {
					//$(this).find('.action-container').addClass('d-none')
					actCont$.addClass('d-none')
					return;
				}
				wgThis.element.trigger('dmyClick',{target: lines, actList: cont$.data('actList')});
			})
			
		})
		//*/
		
		this._m = {} //chứa widget nên cần phải khởi tạo trước
		  //this.options._values = {}
		
		this._super( this.options );
		if (!this.pluginStopped ) {
			
			 
			//$.proxy(
			//this._initWrapElem()
			;//, this);
			
			//$.proxy(
			//this._initSetEvent()
			;//, this);
		}
		else {
		  //this._promptPlaceHolderShow(); 
		}
	  },
	_destroy: function(){
//console.log("destroy...");
	  },
	_init: function(o) {
//console.log('init...', this, this.values('options'));
		this._super( this.options );
		
		this.refresh($.proxy(function(){
				//
			}, this));
			
	  },

	resize: function() {
		//this._superApply( arguments );
	},
	refresh: function(succOnloadCb) {
		//
	},
	_mkItemDragDrop: function() {
		var wgThis = this;
		wgThis.find('.item-dd-container').each(function() {
		})
	},
});
})(jQuery);


(function($){
$.widget("PH_utils.mkDdCont",  $.PH_utils.uiBase, {
	_init: function(o) {
		this._super()
		var wgThis = this;
		$(this.options.containerDotClass).addClass('drag-drop-container')
		if (this.options.isCloneClassEvent) {
			$(this.options.containerDotClass).append($(this.options.eventDotClass).clone(true).addClass('action-container'))
		}
		this.mkIconEvent()
		
		$(this.options.containerDotClass).each(function(i){
			$(this).addClass('drag-drop-container_'+i)
			wgThis.value('classN', '.drag-drop-container_'+i);
			var row$, n = 0;
			
			for (k in wgThis.options.ddData) {
				if (k[0] == '_') continue;
				if (n % wgThis.options.col == 0) {
					row$ = wgThis.mkRowDD()
					$(this).append(row$)
				}
				dd$ = wgThis.mkColDD(wgThis.options.ddData, k);
				row$.append(dd$);
				dd$.ddContent(wgThis.options);
				n++
				var maxW = 0, aItemLabel = dd$.find('[class^="line-label"], [class*=" line-label"]')
				aItemLabel.each(function(i){
					var m = $(this).width();
					if (m>maxW) for (var z = i-1; z>=0; z--) $(aItemLabel[z]).css({width: m+'px'});
				})
				dd$.find('.ql-container').each(function(i) {
					//new Quill(this)
					var childP = $(this).children('p');
					
					var dOpts = $(this).parent().data('ddOpts'), qOpts = {};
					
					if (dOpts.textEmpty) {
						var t = $(childP[0]).html() || '';
						$(childP[0]).empty()
						qOpts.placeholder = t;
					}
					

					qOpts = Object.assign({
					  modules: {
						toolbar: [
						  [{ header: [1, 2, 3, 4, 5, 6, false] }],
						  ['bold', 'italic', 'underline'],
						  ['image', 'code-block'],
						],
					  },
					  theme: 'snow', // or 'bubble'
					}, qOpts);
	
					
					$(this).data('oQuill', new Quill(this, qOpts));
					
					var qBar = $(this).prev();
					if (qBar.length && qBar.hasClass('ql-toolbar')) qBar.addClass('d-none dd-dyn-toolbar');
					
					qBar.append($('<span class="ql-formats"><button type="button" onclick="wgThis.options.gToolbar.addClass(\'d-none\').removeClass(\'tbar-draged\');" aria-pressed="false" aria-label="hide-tools"><i class="fa-solid fa-eye-slash"></i></button></span>'))
		
$(qBar.children()[0]).prepend(`<span class="tbar-move-head" title="Di chuyển thanh công cụ" style="margin-left:-0.5rem !important; cursor:move">
<span tabindex="0" role="button" class="pt-4 pb-4" style="border-left:2px solid lightgray; cursor:move">
  &nbsp;</span>
 <span tabindex="0" role="button" style="border-left:2px solid lightgray; margin-left:-3px !important; cursor:move" class="p-4 ps-0">
  &nbsp;</span>
</span>
`);
		
					wgThis.dynToolBar($(this).data('oQuill'))
		
					childP = $(this).children().children('p');
					
					childP.each(function(){
						if (!this.innerHTML.replace('<br>','').length) $(this).remove()
					})
					if (dOpts.readonly) {
						$(this).children().prop('contenteditable','false')
					} 
					if (dOpts.hidden) {
						$(this).addClass('d-none')
					}
				});
				/*dd$.on('click', function() {
					wgThis.dynToolBar()
					return false
				});*/
			}
		})
	},
	dynToolBar: function(oQuill) {
		if ((this.options.lastQuillObject || false) === oQuill) {console.log(999); return}
		var wgThis = this, tBar = wgThis.options.gToolbar;
		if (!wgThis.options.gToolbar) {
			wgThis.options.gToolbar = $(wgThis.options.toolbarSelector || '#dd-dyn-toolbar');
			if (!wgThis.options.gToolbar.length) {
				tBar = $('<div>');
				wgThis.options.gToolbar = $('body').append(tBar);
			}
			wgThis.options.gToolbar.addClass('dd-dyn-toolbar-container dd-toolbar-fixed d-none');
		}
		
		var restoreTbar = function(pContSaved$) {
				if (pContSaved$) {
						var tBar = wgThis.options.gToolbar.children('.ql-toolbar')
						if (tBar.length) {
							pContSaved$.parent().prepend(tBar.addClass('d-none'))
							pContSaved$.append(wgThis.options.gToolbar.children('.ql-tooltip')) //.addClass('d-none'))
						}
					}
			};
		if (!oQuill) {
			oQuill = this.options.lastQuillObject || false
			if (!oQuill) {
				restoreTbar(wgThis.options.pCont)
				this.options.lastQuillObject  = false;
				return;
			}
		}
		
		
		this.options.lastQuillObject = oQuill
		
		oQuill && oQuill.on('selection-change', function(range, oldRange, source) {
			if (range) {
				var pContSaved$ = wgThis.options.pCont
					, pCont$ = $(this.domListeners.selectionchange[0].node.activeElement).parent()
					;
				
				restoreTbar(pContSaved$)
				
				wgThis.options.pCont = pCont$
				if (pCont$.length) {
					wgThis.options.gToolbar.prepend(pCont$.parent().children('.ql-toolbar').removeClass('d-none'))
					wgThis.options.gToolbar.append (pCont$.children('.ql-tooltip').removeClass('XXXd-none'))
				} else wgThis.options.pCont = false;
			}
		});
	},
	mkRowDD: function() {
		return $('<div class="row row-dd-container"></div>');
	},
	mkColDD: function(d, k) {
		var dd$ = $(('<div class="col col-dd-container border tmp-dd" ' + this._getAction(d,k, d, true) + '></div>'));
		//this.mkLinesQ(dd$, d, k)
		//return dd$;
		
		return dd$.append(this.mkLinesQ(dd$, d, k))
	},
	_getAction: function(d, k, dRoot = {}, isDefaultHead = false) {
		var act = d[k].actions === undefined ? (isDefaultHead ? (d._defaultAction || dRoot._defaultAction || false) : (d._defaultActionLine || dRoot._defaultActionLine || false)) : (d[k].actions !== false ? d[k].actions : false);
		return act ? (' data-act-list = \'["' + act.join('","') + '"]\'') : ''
	},
	mkLineContainer: function(line$) {
		return $('<div class="dd-lines-container">').append(line$);
	},
	mkLinesQ: function(q$, dRoot, kWork) {
		var d = dRoot[kWork], wgThis = this;
		//var q$ = this.mkLineContainer(qq$);
		
		var mkLines = function(v, k, mClass = '', opts = {}, cssProp = '', wrapLine = true, col2class = '') {
			var s = '';
			for (var i=0; i<k.length; i++) {
				if (k[i] == '_' || k[i] == '-' ) s += '';
				else if (k[i].toUpperCase() == k[i]) s += (i==0 ? '' : '-' + k[i].toLowerCase());
				else s += k[i];
			}
			var sCont = '<div class="dd-line-container ' + col2class + '"><div class="ql-container item-dd-container ' + s + ' '+mClass + '" ' + cssProp+ wgThis._getAction(d,k,dRoot) + '><p>$2</p></div></div>';
			if (v=='' || !v) return $(sCont.replace('$2','')).data('ddOpts',opts)
			line$ = $(v.replace(/(<p>)(.*)(<\/p>)/gm,'$2\n').replace(/[\r]+/gm,'').replace(/(\n|^)([^\n$]+)/gm, sCont).replace(/\n+$/,'')).data('ddOpts',opts)
			if (!wrapLine) return line$	
			return wgThis.mkLineContainer(line$)
		}
	
		var dFlex = function(d,k){return '<div class="d-flex item-dd-container"' + wgThis._getAction(d,k,dRoot) + '></div>'}, waitLineValue = 0, divFlex$, hasFirstLine = true;
		
		var doLineLabel = function(ks, k, opts) {
				var classAdd = 'ms-3' + (hasFirstLine ? ' mt-3' : ''), prop = opts.readonly ? 'contenteditable="false"' : '';
				divFlex$ = $(dFlex(d,k))
				divFlex$.append(mkLines(ks, k, classAdd, opts, prop).removeClass('item-dd-container'))
				waitLineValue = 1;
			},
			doLineValue = function(ks, k, opts) {
				var classAdd = 'ms-3' + (hasFirstLine ? ' mt-3' : ''), prop = opts.readonly ? 'contenteditable="false"' : '';
				if (waitLineValue !== 1) {
					divFlex$.append(mkLines(' ', 'lineLabel', classAdd, opts, prop, false).removeClass('item-dd-container'))
					divFlex$.append(mkLines(ks,k, classAdd , opts, prop, false, 'col').removeClass('item-dd-container'))
					q$.append(wgThis.mkLineContainer(divFlex$.removeClass('item-dd-container')))
					waitLineValue = 0
					divFlex$ = $(dFlex(d,k))
					hasFirstLine = false
					return
				}
				divFlex$.append(mkLines(ks,k, classAdd, opts, prop, false, 'col').removeClass('item-dd-container'))
				var elP$;
				divFlex$.children().each(function(i) {
					if (i==0) return true;
					if (i==1) {elP$ = $(this); return true}
					elP$.children().append($(this).find('p'))
					$(this).remove()
				})
				q$.append(wgThis.mkLineContainer(divFlex$))
				waitLineValue = 0
				divFlex$ = $(dFlex(d,k))
				hasFirstLine = false
				return
			},
			isEmpty = function isEmpty(obj) {
			  for (const prop in obj) {
				if (Object.hasOwn(obj, prop)) {
				  return false;
				}
			  }
			  return true;
			}
			;
			
		for (k in d) {
			if (typeof d[k] === 'string') {
				ks = d[k]
				opts = {}
			} else {
				ks = d[k].text || false
				opts = d[k].options || {}
			}
			
			if (opts.readonly === undefined && dRoot._allLabelReadonly && k.indexOf('Label')>=0) {
				opts.readonly = dRoot._allLabelReadonly
			}
			
			if (!ks) {
				opts.textEmpty = true
				opts.readonly = false
				ks = d[k].hint
				if (isEmpty(d[k])) opts.objEmpty = true
			}
			
			switch(k) {
				case 'headLabel' :
					q$.append( mkLines(ks,k, '', opts) );
					break;
				case 'headValue' :
					q$.append( mkLines(ks, k, '', opts) );
					break;
				case 'lineLabel' :
					doLineLabel(ks, k, opts)
					break;
				case 'lineValue' :
					doLineValue(ks, k, opts);
					break;
				case 'contentLabel' :
					q$.append( mkLines(ks,k, '', opts) );
					break;
				case 'contentValue' :
					q$.append( mkLines(ks,k, '', opts) );
					break;
				default:
					if (k.indexOf('lineLabel')==0) doLineLabel(ks, k, opts);
					else if (k.indexOf('lineValue')==0) doLineValue(ks, k, opts);
					else q$.append( mkLines(ks, k, '', opts) );
					break;
			}
			//wgThis.mkWrapElement(q$);
		}
	},
	mkIconEvent: function() {
		var wgThis = this;
		this.element.find('.action-container').children('div').each(function(i) {
			var that$ = $(this);
			if (that$.hasClass('act_add_padding')) {
				that$.on('click', function() {
					var that$ = $(this), contAct$ = that$.parent().parent();
					that$.addClass('d-none').parent().find('.act_remove_padding').removeClass('d-none')
					if (contAct$.hasClass('item-dd-container')) {
						that$.parentsUntil('.dd-lines-container').parent().addClass(wgThis.options.settings.indentClass || 'ps-3')
					}
					else contAct$.addClass(wgThis.options.settings.paddingClass || 'p-3');
					that$.parent().addClass('d-none')
				})
			} else if (that$.hasClass('act_remove_padding')) {
				that$.on('click', function() {
					var that$ = $(this), contAct$ = that$.parent().parent();
					that$.addClass('d-none').parent().find('.act_add_padding').removeClass('d-none')
					if (contAct$.hasClass('item-dd-container')) {
						that$.parentsUntil('.dd-lines-container').parent().removeClass(wgThis.options.settings.indentClass || 'ps-3')
					}
					else contAct$.removeClass(wgThis.options.settings.paddingClass || 'p-3');
					that$.parent().addClass('d-none')
				})
			} else if (that$.hasClass('act_line_up')) {
				that$.on('click', function() {
					
					var that$ = $(this), contAct$ = that$.parentsUntil('.dd-lines-container').parent(), prev$ = contAct$.prev();
					
					$(contAct$.get(0)).insertBefore(contAct$.prev().get(0))
					that$.parent().addClass('d-none')
				})
			} else if (that$.hasClass('act_line_down')) {
				that$.on('click', function() {
					var that$ = $(this), contAct$ = that$.parentsUntil('.dd-lines-container').parent();
					$(contAct$.get(0)).insertAfter(contAct$.next().get(0))
					that$.parent().addClass('d-none')
				})
			} else if (that$.hasClass('act_plus')) {
				that$.on('click', function() {
					var contAct$ = $(this).parent().parent(), clone$ = contAct$.clone(false);
					clone$.insertAfter(contAct$).find('.action-container').remove()
					clone$.ddContent(wgThis.options)
					that$.parent().addClass('d-none')
					//triggerCloneRegion
				})
			} else if (that$.hasClass('act_delete')) {
				that$.on('click', function() {
					var contAct$ = $(this).parent().parent();
					$(this).parent().addClass('d-none')
					contAct$.parent().append(contAct$.find('.action-container'))
					contAct$.remove()
					//triggerRemoveRegion
				})
			} else if (that$.hasClass('act_ql_toolbar')) {
				that$.on('click', function() {
					var tBar$ = wgThis.options.gToolbar;
					if (tBar$.children('.ql-toolbar').length) {
						tBar$.addClass('invisible').removeClass('d-none')
						var tWid = tBar$.children('.ql-toolbar').width()+20, reg$ =  $(this).parentsUntil('.col-dd-container').parent(), ofs = reg$.offset(); //, tbarLastItm = tBar$.children('.ql-toolbar').find('>:last-child'); , width: tbarLastItm.offset().left+tbarLastItm.width()+30
						wgThis.options.gToolbar.css({'width': tWid})
						var bLeft = ofs.left + tWid <= screen.width ?  0 : - (tWid-reg$.width()); 

						
						reg$.append(tBar$)
						
						tBar$.css({top: $(this).offset().top-wgThis.options.gToolbar.height() -ofs.top -5, left: bLeft})
							.removeClass('invisible');
							
						phUtils.fastDragElement({element: wgThis.options.gToolbar,
									 start: function(e, ui) {
										reg$.draggable( "widget" ).draggable( "disable" )
										wgThis.options.gToolbar.addClass('tbar-draged')
									 },
									 stop: function(e, ui) {
										 reg$.draggable( "widget" ).draggable( "enable" )
									 }
								})
					} else {
						tBar$.addClass('d-none')
					}
					//window.scrollTo(0,tBar$.offset().top)
					return false;
				})
			}
			//if (!that$.hasClass('act_move')) that$.parent().addClass('d-none')
		})
	},
});
})(jQuery);



window.addEventListener('load', function() {
	$('.dd-cont2').mkDdCont({
		containerDotClass: '.dd-cont2',
		eventDotClass: '.action-container',
		isCloneClassEvent: true,
		col: 3,
		settings: {
			indentClass: 'ps-3',
			paddingClass: 'p-3',
		},
		toolbarSelector: '#dd-dyn-toolbar',
		ddData: window.ddData
	});
})